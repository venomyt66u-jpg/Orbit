# Orbit — Smart Reminder & Personal Assistant (Android)

> **Don't just remind users. Help them follow through.**

Native Android app (Kotlin + Jetpack Compose) with a Dark Premium design system, a reliable
offline reminder engine, kind follow-ups, habit tracking with a tasbih counter, an on-device
command assistant (English + Arabic), and a Signal Feed for RSS / GitHub updates.

---

## 🇪🇬 بالعربي — إزاي تطلّع ملف APK

### الطريقة 1: من غير أي برامج (GitHub Actions) — الأسهل
1. اعمل حساب على github.com لو مش عندك.
2. اعمل **Repository جديد** (New repository) — سمّيه `Orbit`.
3. ارفع **كل محتوى الفولدر** (اسحب الملفات وأفلتها في صفحة الـ repo → *Upload files* → *Commit*).
   - مهم: لازم فولدر `.github` يترفع كمان. لو المتصفح ما رفعوش، أنشئ الملف يدويًا من *Add file → Create new file* بالاسم
     `.github/workflows/build-apk.yml` وانسخ محتواه.
4. افتح تبويب **Actions** → هتلاقي "Build APK" شغّال (أو اضغط *Run workflow*).
5. بعد ~6–10 دقايق ادخل على الـ run → تحت **Artifacts** نزّل `Orbit-debug-apk` → فك الضغط → ثبّت الـ APK على موبايلك
   (هتحتاج تسمح بـ "تثبيت من مصادر غير معروفة").

### الطريقة 2: Android Studio
1. نزّل Android Studio (أحدث نسخة).
2. *File → Open* واختار فولدر `Orbit`.
3. استنى الـ Gradle Sync يخلص، وصل الموبايل (USB debugging) أو شغّل Emulator، واضغط ▶ Run.

> لو ظهر أي خطأ في البناء، انسخ رسالة الخطأ من الـ log وابعتهالي وأنا أصلّحه فورًا.

---

## Build (English)

| Way | Steps |
|---|---|
| **GitHub Actions** | Push this folder to a GitHub repo → *Actions* → **Build APK** → download the `Orbit-debug-apk` artifact. Runs unit tests, builds a debug APK and a minified release APK (signed with the debug key for side-loading). |
| **Android Studio** | Open the folder (Ladybug 2024.2+ / JDK 17+), let Gradle sync, press **Run**. |
| **CLI** | `./gradlew testDebugUnitTest assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk` |

Requirements: JDK 17, Android SDK 35. `minSdk` 26 (Android 8.0), `targetSdk` 35.
For Google Play, replace the release `signingConfig` in `app/build.gradle.kts` with your own keystore.

---

## What's inside

```
app/src/main/java/com/orbit/followthrough/
├── domain/        Pure logic: Recurrence (DST-safe), FollowUpPolicy, QuietHours, enums   ← unit tested
├── data/db/       Room: reminders, events, habits, habit logs, signal sources/items, notification log
├── data/prefs/    DataStore settings (theme, profiles, per-channel sounds, quiet hours, AI, keywords…)
├── engine/        ReminderEngine (state machine), HabitEngine, AlarmScheduler, receivers
├── notify/        Versioned notification channels, Notifier, built-in SoundLibrary, vibration patterns
├── overlay/       Optional floating reminder (TYPE_APPLICATION_OVERLAY, user-granted)
├── ai/            CommandParser (EN/AR, offline), Insights, SmartMessages, AiProvider (local / your backend)
├── signals/       FeedParser (RSS/Atom), SignalClassifier, AccountResolver, SignalRepository + WorkManager sync
├── market/        CoinGecko prices, global stats, Fear & Greed, news, price alerts
├── wallets/       Chains, ActivityClassifier (buy/sell/swap), WalletRepository (Etherscan V2, mempool, Solana RPC)
├── network/       LAN discovery, router connector framework, usage math
├── watch/         Live mode foreground service + 15-min WorkManager fallback
├── net/           Minimal HttpURLConnection client (no third-party networking)
└── ui/            Compose design system + Home, Habits, Tasbih, Signals, Sources, Assistant, Settings,
                   Sounds, Permissions, History, Privacy, Onboarding, Help & animated tutorials
backend/functions/ Optional Firebase Cloud Function: LLM proxy that keeps API keys server-side
tools/             Sound synthesiser (original WAVs) and EN/AR string generator + checker
docs/              ARCHITECTURE.md · INTEGRATIONS.md · STATUS.md (implemented vs pending)
```

**v1.1:** Market & price alerts · named wallet tracker (ETH/Base/Arbitrum/BNB/Polygon/BTC/SOL) · follow accounts · Live mode · bring-your-own-key AI (Claude/OpenAI/Gemini) · saved tasbih history · home-network section.

Read **docs/STATUS.md** for the honest list of what is implemented and what is pending.
