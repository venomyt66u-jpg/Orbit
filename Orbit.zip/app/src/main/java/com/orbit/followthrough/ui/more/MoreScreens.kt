package com.orbit.followthrough.ui.more

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.ai.LlmProvider
import com.orbit.followthrough.data.prefs.SecretStore
import com.orbit.followthrough.net.Http
import com.orbit.followthrough.ui.components.AiEmblem
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.ScreenHeader
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.SettingRow
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.home.BOTTOM_SPACE
import com.orbit.followthrough.ui.nav.LocalAppContainer
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.launch

@Composable
fun MoreScreen(nav: NavHostController) {
    val c = Orbit.colors
    val s = LocalSettings.current
    val container = LocalAppContainer.current
    val aiReady = container.ai.ready(s)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = BOTTOM_SPACE.dp)) {
        item { ScreenHeader(stringResource(R.string.tab_more), subtitle = stringResource(R.string.more_subtitle)) }
        item {
            GlassCard(Modifier.fillMaxWidth(), highlight = c.violet, onClick = { nav.navigate(Routes.ASSISTANT) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AiEmblem(size = 72.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.tab_assistant), style = OrbitType.title, color = c.text)
                        Text(stringResource(R.string.assistant_card_body), style = OrbitType.caption, color = c.textSecondary)
                        Tag(
                            if (aiReady) container.ai.config(s).provider.label else stringResource(R.string.ai_mode_local),
                            if (aiReady) c.violet else c.green, icon = OrbitIcons.Spark, modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HubTile(OrbitIcons.Router, stringResource(R.string.home_network), stringResource(R.string.home_network_hint), c.cyan, Modifier.weight(1f)) { nav.navigate(Routes.NETWORK) }
                HubTile(OrbitIcons.Key, stringResource(R.string.ai_and_keys), stringResource(R.string.ai_and_keys_hint), c.amber, Modifier.weight(1f)) { nav.navigate(Routes.KEYS) }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HubTile(OrbitIcons.Layers, stringResource(R.string.all_reminders), stringResource(R.string.all_reminders_hint), c.electric, Modifier.weight(1f)) { nav.navigate(Routes.REMINDERS) }
                HubTile(OrbitIcons.Sound, stringResource(R.string.sounds_vibration), stringResource(R.string.sounds_short_hint), c.green, Modifier.weight(1f)) { nav.navigate(Routes.SOUNDS) }
            }
        }
        item { SectionHeader(stringResource(R.string.system_privacy), Modifier.padding(top = 18.dp)) }
        item {
            GlassCard(Modifier.fillMaxWidth(), padding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)) {
                listOf(
                    Triple(OrbitIcons.Settings, R.string.tab_settings, Routes.SETTINGS),
                    Triple(OrbitIcons.Shield, R.string.permissions, Routes.PERMISSIONS),
                    Triple(OrbitIcons.Lock, R.string.privacy_data, Routes.PRIVACY),
                    Triple(OrbitIcons.History, R.string.notification_history, Routes.HISTORY),
                    Triple(OrbitIcons.Help, R.string.help_tutorials, Routes.HELP),
                ).forEach { (icon, label, route) ->
                    SettingRow(stringResource(label), icon = icon, onClick = { nav.navigate(route) }) {
                        Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun HubTile(icon: ImageVector, title: String, body: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    val c = Orbit.colors
    GlassCard(modifier, onClick = onClick, padding = PaddingValues(16.dp)) {
        GlyphBadge(icon, color)
        Spacer(Modifier.height(12.dp))
        Text(title, style = OrbitType.subtitle, color = c.text, maxLines = 1)
        Text(body, style = OrbitType.caption, color = c.textSecondary, maxLines = 2)
    }
}

// ------------------------------------------------------------------ AI & keys

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KeysScreen(nav: NavHostController) {
    val c = Orbit.colors
    val s = LocalSettings.current
    val container = LocalAppContainer.current
    val secrets = container.secrets
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val provider = LlmProvider.entries.firstOrNull { it.name == s.llmProvider } ?: LlmProvider.NONE
    var model by remember(provider) { mutableStateOf(s.llmModel.ifBlank { provider.defaultModel }) }
    var key by remember { mutableStateOf("") }
    var test by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var ethKey by remember { mutableStateOf("") }
    var bsKey by remember { mutableStateOf("") }
    val bsMasked = remember(tick) { secrets.masked(SecretStore.Key.BLOCKSCOUT) }
    var cgKey by remember { mutableStateOf("") }
    val masked = remember(tick) { secrets.masked(SecretStore.Key.LLM) }
    val ethMasked = remember(tick) { secrets.masked(SecretStore.Key.ETHERSCAN) }
    val cgMasked = remember(tick) { secrets.masked(SecretStore.Key.COINGECKO) }

    fun open(url: String) = runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    LazyColumn(Modifier.fillMaxSize().imePadding().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 40.dp)) {
        item { TopBar(stringResource(R.string.ai_and_keys), { nav.popBackStack() }, stringResource(R.string.back)) }
        item { Text(stringResource(R.string.keys_intro), style = OrbitType.body, color = c.textSecondary, modifier = Modifier.padding(bottom = 12.dp)) }

        // ---- AI provider ----
        item {
            GlassCard(Modifier.fillMaxWidth(), highlight = c.violet) {
                Text(stringResource(R.string.ai_provider), style = OrbitType.title, color = c.text)
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LlmProvider.entries.forEach { p ->
                        OrbitChip(if (p == LlmProvider.NONE) stringResource(R.string.off) else p.label, provider == p, {
                            scope.launch { container.settings.update { llmProvider = p.name; llmModel = p.defaultModel } }
                            test = null
                        }, accent = c.violet)
                    }
                }
                if (provider.needsKey) {
                    Spacer(Modifier.height(12.dp))
                    OrbitTextField(model, { model = it.trim() }, stringResource(R.string.model_name), Modifier.fillMaxWidth(), leading = OrbitIcons.Spark)
                    Spacer(Modifier.height(10.dp))
                    SecretField(key, { key = it }, if (masked != null) stringResource(R.string.key_saved, masked) else stringResource(R.string.paste_api_key))
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PrimaryButton(stringResource(if (testing) R.string.testing else R.string.save_and_test), {
                            if (!testing) scope.launch {
                                testing = true
                                if (key.isNotBlank()) secrets.put(SecretStore.Key.LLM, key)
                                container.settings.update { llmModel = model }
                                key = ""; tick++
                                val r = container.ai.test(container.settings.current())
                                test = r.fold({ "ok" }, { Http.reason(it) })
                                testing = false
                            }
                        }, Modifier.weight(1f), icon = OrbitIcons.Check)
                        if (masked != null) SecondaryButton(stringResource(R.string.remove), { secrets.put(SecretStore.Key.LLM, null); tick++; test = null }, tint = c.rose)
                    }
                    test?.let {
                        Spacer(Modifier.height(8.dp))
                        Text(if (it == "ok") stringResource(R.string.ai_connected) else stringResource(R.string.ai_error, it), style = OrbitType.label, color = if (it == "ok") c.green else c.amber)
                    }
                    Spacer(Modifier.height(8.dp))
                    val (url, label) = when (provider) {
                        LlmProvider.ANTHROPIC -> "https://console.anthropic.com/settings/keys" to "console.anthropic.com"
                        LlmProvider.OPENAI -> "https://platform.openai.com/api-keys" to "platform.openai.com"
                        else -> "https://aistudio.google.com/apikey" to "aistudio.google.com"
                    }
                    Text(stringResource(R.string.get_key_at, label), style = OrbitType.caption, color = c.cyan, modifier = Modifier.pressable({ open(url) }))
                } else if (provider == LlmProvider.BACKEND) {
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.backend_hint), style = OrbitType.caption, color = c.textSecondary)
                    SecondaryButton(stringResource(R.string.open_settings), { nav.navigate(Routes.SETTINGS) }, Modifier.padding(top = 8.dp), icon = OrbitIcons.Settings)
                }
                Spacer(Modifier.height(10.dp))
                Text(stringResource(R.string.ai_privacy_disclosure), style = OrbitType.caption, color = c.textMuted)
            }
        }

        // ---- Blockscout (recommended: one free key, many networks incl. Base & Robinhood Chain) ----
        item { SectionHeader(stringResource(R.string.data_keys), Modifier.padding(top = 18.dp)) }
        item {
            GlassCard(Modifier.fillMaxWidth().padding(bottom = 12.dp), highlight = c.gold) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphBadge(OrbitIcons.Radar, c.gold, size = 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.blockscout_key), style = OrbitType.subtitle, color = c.text)
                        Text(stringResource(R.string.blockscout_key_hint), style = OrbitType.caption, color = c.textSecondary)
                    }
                }
                Spacer(Modifier.height(10.dp))
                SecretField(bsKey, { bsKey = it }, if (bsMasked != null) stringResource(R.string.key_saved, bsMasked) else stringResource(R.string.paste_api_key))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    SecondaryButton(stringResource(R.string.save), { if (bsKey.isNotBlank()) { secrets.put(SecretStore.Key.BLOCKSCOUT, bsKey); bsKey = ""; tick++ } }, icon = OrbitIcons.Check)
                    Text(stringResource(R.string.get_key_at, "dev.blockscout.com"), style = OrbitType.caption, color = c.cyan, modifier = Modifier.pressable({ open("https://dev.blockscout.com") }))
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphBadge(OrbitIcons.Wallet, c.violet, size = 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.etherscan_key), style = OrbitType.subtitle, color = c.text)
                        Text(stringResource(R.string.etherscan_key_hint), style = OrbitType.caption, color = c.textSecondary)
                    }
                }
                Spacer(Modifier.height(10.dp))
                SecretField(ethKey, { ethKey = it }, if (ethMasked != null) stringResource(R.string.key_saved, ethMasked) else stringResource(R.string.paste_api_key))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    SecondaryButton(stringResource(R.string.save), { if (ethKey.isNotBlank()) { secrets.put(SecretStore.Key.ETHERSCAN, ethKey); ethKey = ""; tick++ } }, icon = OrbitIcons.Check)
                    Text(stringResource(R.string.get_key_at, "etherscan.io/myapikey"), style = OrbitType.caption, color = c.cyan, modifier = Modifier.pressable({ open("https://etherscan.io/myapikey") }))
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphBadge(OrbitIcons.Chart, c.amber, size = 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.coingecko_key), style = OrbitType.subtitle, color = c.text)
                        Text(stringResource(R.string.coingecko_key_hint), style = OrbitType.caption, color = c.textSecondary)
                    }
                }
                Spacer(Modifier.height(10.dp))
                SecretField(cgKey, { cgKey = it }, if (cgMasked != null) stringResource(R.string.key_saved, cgMasked) else stringResource(R.string.optional_key))
                Spacer(Modifier.height(8.dp))
                SecondaryButton(stringResource(R.string.save), { secrets.put(SecretStore.Key.COINGECKO, cgKey.ifBlank { null }); cgKey = ""; tick++ }, icon = OrbitIcons.Check)
            }
        }
        item {
            Text(stringResource(R.string.keys_footer), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 16.dp).navigationBarsPadding())
        }
    }
}

@Composable
private fun SecretField(value: String, onChange: (String) -> Unit, placeholder: String) {
    val c = Orbit.colors
    androidx.compose.foundation.text.BasicTextField(
        value = value, onValueChange = { onChange(it.trim()) }, singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        textStyle = OrbitType.body.copy(color = c.text),
        cursorBrush = androidx.compose.ui.graphics.SolidColor(c.cyan),
        modifier = Modifier.fillMaxWidth(),
        decorationBox = { inner ->
            Row(
                Modifier
                    .androidx_clip()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(OrbitIcons.Key, null, tint = c.textMuted, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) Text(placeholder, style = OrbitType.body, color = c.textMuted, maxLines = 1)
                    inner()
                }
            }
        },
    )
}

@Composable
private fun Modifier.androidx_clip(): Modifier {
    val c = Orbit.colors
    val shape = RoundedCornerShape(18.dp)
    return this.clip(shape).background(c.surface).border(1.dp, c.stroke, shape)
}
