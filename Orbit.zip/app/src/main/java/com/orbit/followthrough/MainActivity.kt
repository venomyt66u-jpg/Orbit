package com.orbit.followthrough

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.orbit.followthrough.engine.OrbitIntents
import com.orbit.followthrough.ui.nav.OrbitRoot
import kotlinx.coroutines.flow.MutableStateFlow

class MainActivity : ComponentActivity() {

    private val pendingRoute = MutableStateFlow<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingRoute.value = intent?.getStringExtra(OrbitIntents.EXTRA_ROUTE)
        val container = (application as OrbitApp).container
        setContent {
            OrbitRoot(container, pendingRoute) { pendingRoute.value = null }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent.getStringExtra(OrbitIntents.EXTRA_ROUTE)?.let { pendingRoute.value = it }
    }
}
