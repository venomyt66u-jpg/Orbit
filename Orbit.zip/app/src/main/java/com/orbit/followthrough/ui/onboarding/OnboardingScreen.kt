package com.orbit.followthrough.ui.onboarding

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.nav.LocalAppContainer
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Tutorial(val key: String, val titleRes: Int, val stepsRes: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector)

val tutorials = listOf(
    Tutorial("reminders", R.string.tut_reminders_title, R.array.tut_reminders, OrbitIcons.Bell),
    Tutorial("habits", R.string.tut_habits_title, R.array.tut_habits, OrbitIcons.Habits),
    Tutorial("ai", R.string.tut_ai_title, R.array.tut_ai, OrbitIcons.Assistant),
    Tutorial("signals", R.string.tut_signals_title, R.array.tut_signals, OrbitIcons.Signal),
)

/** Auto-advancing step index (paused when the user prefers reduced motion). */
@Composable
fun rememberAutoStep(count: Int, key: Any, enabled: Boolean = true): Pair<Int, (Int) -> Unit> {
    var step by remember(key) { mutableIntStateOf(0) }
    val reduced = Orbit.reducedMotion
    LaunchedEffect(key, step, enabled) {
        if (!reduced && enabled && count > 1) {
            delay(3200)
            step = (step + 1) % count
        }
    }
    return step to { s: Int -> step = s.coerceIn(0, count - 1) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(nav: NavHostController) {
    val c = Orbit.colors
    val container = LocalAppContainer.current
    val scope = rememberCoroutineScope()
    val pages = 5
    val pager = rememberPagerState { pages }

    fun finish() {
        scope.launch {
            container.settings.update { onboardingDone = true }
            if (nav.previousBackStackEntry == null) {
                nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
            } else {
                nav.popBackStack() // replayed from Help
            }
        }
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { finish() }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Icon(OrbitIcons.Home, null, tint = c.cyan, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.app_name), style = OrbitType.subtitle, color = c.text)
            }
            if (pager.currentPage < pages - 1) {
                Text(
                    stringResource(R.string.skip),
                    style = OrbitType.label, color = c.textSecondary,
                    modifier = Modifier.clip(CircleShape).pressable({ scope.launch { pager.animateScrollToPage(pages - 1) } }).padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }

        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            Column(Modifier.fillMaxSize().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                when (page) {
                    0 -> {
                        TutorialScene("intro", 0)
                        Text(stringResource(R.string.onb_title_0), style = OrbitType.display, color = c.text, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text(stringResource(R.string.onb_body_0), style = OrbitType.body, color = c.textSecondary, textAlign = TextAlign.Center)
                    }
                    in 1..3 -> {
                        val t = tutorials[page - 1]
                        val captions = stringArrayResource(t.stepsRes)
                        val (step, _) = rememberAutoStep(captions.size, page, enabled = pager.currentPage == page)
                        TutorialScene(t.key, step)
                        Text(stringResource(t.titleRes), style = OrbitType.headline, color = c.text, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(10.dp))
                        Text(captions.getOrElse(step) { "" }, style = OrbitType.body, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.height(66.dp))
                    }
                    else -> PermissionPrimer()
                }
            }
        }

        // indicators + CTA
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center) {
            repeat(pages) { i ->
                val sel = pager.currentPage == i
                val w by animateDpAsState(if (sel) 26.dp else 8.dp, label = "dot")
                val col by animateColorAsState(if (sel) c.cyan else c.strokeStrong, label = "dotc")
                Box(Modifier.padding(horizontal = 4.dp).height(8.dp).width(w).clip(CircleShape).background(col))
            }
        }
        Box(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp)) {
            if (pager.currentPage < pages - 1) {
                PrimaryButton(stringResource(R.string.next), { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }, Modifier.fillMaxWidth())
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PrimaryButton(stringResource(R.string.allow_and_start), {
                        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else finish()
                    }, Modifier.fillMaxWidth(), icon = OrbitIcons.Bell)
                    SecondaryButton(stringResource(R.string.maybe_later), { finish() }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun PermissionPrimer() {
    val c = Orbit.colors
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        GlyphBadge(OrbitIcons.Shield, c.green, size = 84.dp)
        Spacer(Modifier.height(18.dp))
        Text(stringResource(R.string.onb_perm_title), style = OrbitType.headline, color = c.text, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.onb_perm_body), style = OrbitType.body, color = c.textSecondary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        GlassCard(Modifier.fillMaxWidth(), padding = PaddingValues(16.dp)) {
            PrimerLine(OrbitIcons.Bell, stringResource(R.string.perm_notifications), stringResource(R.string.onb_perm_notif))
            PrimerLine(OrbitIcons.Lock, stringResource(R.string.onb_perm_private), stringResource(R.string.onb_perm_private_body))
            PrimerLine(OrbitIcons.Settings, stringResource(R.string.onb_perm_control), stringResource(R.string.onb_perm_control_body))
        }
    }
}

@Composable
private fun PrimerLine(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, body: String) {
    val c = Orbit.colors
    Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = c.cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = OrbitType.subtitle, color = c.text)
            Text(body, style = OrbitType.caption, color = c.textSecondary)
        }
    }
}

// ------------------------------------------------------------------ Help & tutorials

@Composable
fun HelpScreen(nav: NavHostController) {
    val c = Orbit.colors
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { TopBar(stringResource(R.string.help_tutorials), { nav.popBackStack() }, stringResource(R.string.back)) }
        item { Text(stringResource(R.string.help_intro), style = OrbitType.body, color = c.textSecondary, modifier = Modifier.padding(bottom = 14.dp)) }
        items(tutorials, key = { it.key }) { t ->
            GlassCard(Modifier.fillMaxWidth().padding(bottom = 12.dp), onClick = { nav.navigate(Routes.tutorial(t.key)) }, padding = PaddingValues(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphBadge(t.icon, c.cyan)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(t.titleRes), style = OrbitType.subtitle, color = c.text)
                        Text(stringArrayResource(t.stepsRes).firstOrNull() ?: "", style = OrbitType.caption, color = c.textSecondary, maxLines = 2)
                    }
                    Icon(OrbitIcons.Play, null, tint = c.cyan, modifier = Modifier.size(18.dp))
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth(), onClick = { nav.navigate(Routes.ONBOARDING) }, padding = PaddingValues(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphBadge(OrbitIcons.Home, c.violet)
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(R.string.replay_intro), style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f))
                    Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun TutorialScreen(nav: NavHostController, key: String) {
    val c = Orbit.colors
    val t = tutorials.firstOrNull { it.key == key } ?: tutorials.first()
    val captions = stringArrayResource(t.stepsRes)
    val (step, setStep) = rememberAutoStep(captions.size, key)
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).navigationBarsPadding()) {
        TopBar(stringResource(t.titleRes), { nav.popBackStack() }, stringResource(R.string.back))
        Spacer(Modifier.weight(0.3f))
        TutorialScene(t.key, step)
        Spacer(Modifier.height(16.dp))
        // captions (always visible for accessibility)
        captions.forEachIndexed { i, cap ->
            Row(
                Modifier.fillMaxWidth().clip(CircleShape).pressable({ setStep(i) }).padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(if (i == step) c.cyan else c.surfaceHigh), contentAlignment = Alignment.Center) {
                    Text("${i + 1}", style = OrbitType.caption, color = if (i == step) c.onAccent else c.textSecondary)
                }
                Spacer(Modifier.width(12.dp))
                Text(cap, style = OrbitType.body, color = if (i == step) c.text else c.textMuted)
            }
        }
        Spacer(Modifier.weight(0.5f))
        Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SecondaryButton(stringResource(R.string.previous), { setStep(step - 1) }, Modifier.weight(1f))
            PrimaryButton(stringResource(if (step == captions.lastIndex) R.string.done else R.string.next), {
                if (step == captions.lastIndex) nav.popBackStack() else setStep(step + 1)
            }, Modifier.weight(1f))
        }
    }
}
