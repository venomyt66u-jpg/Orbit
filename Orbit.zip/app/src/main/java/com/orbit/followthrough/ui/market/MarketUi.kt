package com.orbit.followthrough.ui.market

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.CoinEntity
import com.orbit.followthrough.data.db.WalletActivityEntity
import com.orbit.followthrough.domain.Numbers
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.Sparkline
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.parseSpark
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import kotlinx.coroutines.delay

/** Round monogram for a coin/token (no third-party logos are downloaded). */
@Composable
fun CoinMark(symbol: String, color: Color, size: androidx.compose.ui.unit.Dp = 40.dp) {
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(color.copy(alpha = 0.35f), color.copy(alpha = 0.08f))))
            .border(1.dp, color.copy(alpha = 0.45f), CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text(symbol.take(4), style = OrbitType.caption.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold), color = color, maxLines = 1) }
}

@Composable
fun coinColor(symbol: String): Color {
    val c = Orbit.colors
    return when (symbol.uppercase()) {
        "BTC" -> c.amber
        "ETH" -> c.electric
        "SOL" -> c.violet
        "BNB" -> c.gold
        "XRP" -> c.cyan
        "TON" -> c.cyan
        "DOGE" -> c.gold
        else -> c.habit(symbol.hashCode())
    }
}

/** Highlight pulse for deep-linked rows: glows for a few seconds, then settles. */
@Composable
fun highlightColor(active: Boolean): Color {
    var on by remember { mutableStateOf(active) }
    LaunchedEffect(active) { if (active) { on = true; delay(3500); on = false } }
    val c by animateColorAsState(if (on) Orbit.colors.cyan.copy(alpha = 0.16f) else Color.Transparent, tween(600), label = "hl")
    return c
}

@Composable
fun CoinRow(coin: CoinEntity, onClick: () -> Unit, highlighted: Boolean = false) {
    val c = Orbit.colors
    val color = coinColor(coin.symbol)
    val change = coin.change24h
    val up = (change ?: 0.0) >= 0
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(highlightColor(highlighted)).pressable(onClick).padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CoinMark(coin.symbol, color)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(coin.symbol, style = OrbitType.subtitle, color = c.text)
            Text(coin.name, style = OrbitType.caption, color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Sparkline(parseSpark(coin.sparkline), if (up) c.green else c.rose, Modifier.width(72.dp).height(30.dp))
        Spacer(Modifier.width(12.dp))
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.width(96.dp)) {
            Text(coin.price?.let { Numbers.price(it) } ?: "—", style = OrbitType.numericSmall, color = c.text, maxLines = 1)
            Text(change?.let { Numbers.percent(it) } ?: "", style = OrbitType.caption.copy(fontFeatureSettings = "tnum"), color = if (up) c.green else c.rose)
            if (coin.alertAbove != null || coin.alertBelow != null) Icon(OrbitIcons.Bell, null, tint = c.amber, modifier = Modifier.size(12.dp))
        }
    }
}

/** Localised network name (the "all networks" pseudo-chain gets a translated label). */
@Composable
fun chainLabel(chain: com.orbit.followthrough.wallets.Chain): String =
    if (chain == com.orbit.followthrough.wallets.Chain.ALL_EVM) stringResource(R.string.all_networks) else chain.label

fun activityIcon(kind: String): ImageVector = when (kind) {
    "MINT" -> OrbitIcons.Spark
    "BUY" -> OrbitIcons.ArrowDown
    "SELL" -> OrbitIcons.ArrowUp
    "SWAP" -> OrbitIcons.Swap
    "RECEIVE" -> OrbitIcons.ArrowDown
    "SEND" -> OrbitIcons.ArrowUp
    else -> OrbitIcons.Link
}

@Composable
fun activityColor(kind: String): Color {
    val c = Orbit.colors
    return when (kind) {
        "MINT" -> c.gold
        "BUY", "RECEIVE" -> c.green
        "SELL", "SEND" -> c.rose
        "SWAP" -> c.violet
        else -> c.textSecondary
    }
}

@Composable
fun activityTitle(a: WalletActivityEntity): String = when (a.kind) {
    "MINT" -> stringResource(R.string.act_minted, a.inSymbol ?: "NFT")
    "BUY" -> stringResource(R.string.act_bought, a.inSymbol ?: "")
    "SELL" -> stringResource(R.string.act_sold, a.outSymbol ?: "")
    "SWAP" -> stringResource(R.string.act_swapped, a.outSymbol ?: "", a.inSymbol ?: "")
    "RECEIVE" -> stringResource(R.string.act_received, a.inSymbol ?: "")
    "SEND" -> stringResource(R.string.act_sent, a.outSymbol ?: "")
    else -> stringResource(R.string.act_contract)
}

@Composable
fun ActivityRow(a: WalletActivityEntity, walletName: String?, onClick: () -> Unit, highlighted: Boolean = false) {
    val c = Orbit.colors
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val color = activityColor(a.kind)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(highlightColor(highlighted))
            .then(if (highlighted) Modifier.border(1.dp, c.cyan.copy(alpha = 0.5f), RoundedCornerShape(18.dp)) else Modifier)
            .pressable(onClick).padding(vertical = 10.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(CircleShape).background(color.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            Icon(activityIcon(a.kind), null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(activityTitle(a), style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (!a.read) { Spacer(Modifier.width(6.dp)); Box(Modifier.size(7.dp).clip(CircleShape).background(c.cyan)) }
            }
            val amounts = listOfNotNull(
                a.inAmount?.let { "+" + Numbers.compact(it) + " " + (a.inSymbol ?: "") },
                a.outAmount?.let { "−" + Numbers.compact(it) + " " + (a.outSymbol ?: "") },
            ).joinToString("  ")
            val net = a.chain.takeIf { it.isNotBlank() }?.let { com.orbit.followthrough.wallets.Chain.of(it).label }
            Text(listOfNotNull(walletName, net, amounts.ifBlank { null }).joinToString(" · "), style = OrbitType.caption, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            a.valueUsd?.let { Text("≈" + Numbers.compact(it, "$"), style = OrbitType.numericSmall, color = c.text) }
            Text(Fmt.ago(a.at), style = OrbitType.caption, color = c.textMuted)
        }
    }
}

@Composable
fun StatPill(label: String, value: String, accent: Color, modifier: Modifier = Modifier, sub: String? = null) {
    val c = Orbit.colors
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(c.surface.copy(alpha = 0.6f)).border(1.dp, c.stroke, RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Text(label, style = OrbitType.overline, color = c.textMuted, maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Text(value, style = OrbitType.subtitle.copy(fontFeatureSettings = "tnum"), color = c.text, maxLines = 1)
        if (sub != null) Tag(sub, accent, modifier = Modifier.padding(top = 4.dp))
    }
}
