package com.orbit.followthrough.notify

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.orbit.followthrough.R
import com.orbit.followthrough.ai.SmartMessages
import com.orbit.followthrough.data.db.HabitEntity
import com.orbit.followthrough.data.db.NotificationLogDao
import com.orbit.followthrough.data.db.NotificationLogEntity
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.data.db.SignalItemEntity
import com.orbit.followthrough.data.prefs.AppSettings
import com.orbit.followthrough.domain.NotificationProfile
import com.orbit.followthrough.domain.ReminderCategory
import com.orbit.followthrough.engine.OrbitIntents
import java.time.ZoneId

class Notifier(
    private val context: Context,
    private val channels: ChannelManager,
    private val logDao: NotificationLogDao,
    private val smart: SmartMessages,
) {
    private val nm = NotificationManagerCompat.from(context)

    fun canPost(): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return nm.areNotificationsEnabled()
    }

    private fun reminderChannel(r: ReminderEntity, s: AppSettings, now: Long): ChannelKey {
        val bypass = r.important && s.importantBypassQuiet
        return when {
            s.profile == NotificationProfile.SILENT -> ChannelKey.QUIET
            !bypass && s.quietHours.isQuiet(now, ZoneId.systemDefault()) -> ChannelKey.QUIET
            r.important || s.profile == NotificationProfile.HIGH -> ChannelKey.URGENT
            else -> ChannelKey.REMINDER
        }
    }

    /** @return true when the notification was posted. */
    suspend fun showReminder(r: ReminderEntity, kind: SmartMessages.Kind, followUpIndex: Int, s: AppSettings, now: Long): Boolean {
        val key = reminderChannel(r, s, now)
        val body = smart.reminderBody(r, kind, followUpIndex, s.aiTone, s.aiEnabled)
        val laterMinutes = if (r.followUpMinutes > 0) r.followUpMinutes else s.defaultFollowUpMinutes
        val res = context.resources

        val builder = NotificationCompat.Builder(context, channels.channelId(key, s))
            .setSmallIcon(R.drawable.ic_stat_orbit)
            .setColor(categoryColor(r.category))
            .setContentTitle(r.title)
            .setContentText(body.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(if (key == ChannelKey.QUIET) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setWhen(r.pendingOccurrenceAt ?: now)
            .setShowWhen(true)
            .setAutoCancel(true)
            .setContentIntent(OrbitIntents.openApp(context, "home", reminderNotificationId(r.id)))
            .setDeleteIntent(OrbitIntents.action(context, OrbitIntents.DISMISS, r.id))
            .addAction(0, res.getString(R.string.action_done), OrbitIntents.action(context, OrbitIntents.COMPLETE, r.id))
            .addAction(0, res.getString(R.string.action_later_minutes, laterMinutes), OrbitIntents.action(context, OrbitIntents.SNOOZE, r.id, laterMinutes))
            .addAction(0, res.getString(R.string.action_skip), OrbitIntents.action(context, OrbitIntents.SKIP, r.id))

        if (kind == SmartMessages.Kind.FOLLOW_UP) {
            builder.setSubText(res.getString(R.string.notif_followup_of, followUpIndex, r.maxFollowUps))
        }
        return post(reminderNotificationId(r.id), builder, key.id, r.title, body, s)
    }

    suspend fun showHabit(h: HabitEntity, current: Int, s: AppSettings): Boolean {
        val key = if (s.profile == NotificationProfile.SILENT || s.quietHours.isQuiet(System.currentTimeMillis(), ZoneId.systemDefault()))
            ChannelKey.QUIET else ChannelKey.HABIT
        val remaining = (h.target - current).coerceAtLeast(0)
        val body = smart.habitBody(h.name, remaining, s.aiTone, s.aiEnabled)
        val res = context.resources
        val builder = NotificationCompat.Builder(context, channels.channelId(key, s))
            .setSmallIcon(R.drawable.ic_stat_orbit)
            .setColor(0xFF3DDC97.toInt())
            .setContentTitle(h.name)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(OrbitIntents.openApp(context, "habits", habitNotificationId(h.id)))
            .addAction(0, res.getString(R.string.action_plus_one), OrbitIntents.action(context, OrbitIntents.HABIT_PLUS, h.id))
            .addAction(0, res.getString(R.string.action_done_today), OrbitIntents.action(context, OrbitIntents.HABIT_DONE, h.id))
        return post(habitNotificationId(h.id), builder, key.id, h.name, body, s)
    }

    /** Posts up to 3 individual signal notifications and groups the rest under a summary. */
    suspend fun showSignals(items: List<SignalItemEntity>, s: AppSettings) {
        if (items.isEmpty()) return
        val res = context.resources
        val group = "orbit_signals"
        val important = items.any { it.importance >= 2 }
        val key = if (important && s.profile != NotificationProfile.SILENT) ChannelKey.SIGNAL_ALERT else ChannelKey.SIGNAL_QUIET
        val channelId = channels.channelId(key, s)
        items.sortedByDescending { it.importance }.take(3).forEach { item ->
            val b = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_stat_orbit)
                .setColor(0xFF8B5CFF.toInt())
                .setContentTitle(item.title)
                .setContentText(item.sourceName)
                .setSubText(item.sourceName)
                .setStyle(NotificationCompat.BigTextStyle().bigText(item.summary.ifBlank { item.title }))
                .setGroup(group)
                .setAutoCancel(true)
                .setContentIntent(OrbitIntents.openApp(context, "signals", signalNotificationId(item.id)))
            post(signalNotificationId(item.id), b, key.id, item.title, item.sourceName, s)
        }
        if (items.size > 1) {
            val summary = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_stat_orbit)
                .setColor(0xFF8B5CFF.toInt())
                .setContentTitle(res.getQuantityString(R.plurals.signals_new, items.size, items.size))
                .setContentText(items.take(3).joinToString(" · ") { it.sourceName }.take(80))
                .setGroup(group)
                .setGroupSummary(true)
                .setAutoCancel(true)
                .setContentIntent(OrbitIntents.openApp(context, "signals", SIGNAL_SUMMARY_ID))
            postRaw(SIGNAL_SUMMARY_ID, summary)
        }
    }

    /** New post from a followed account – one rich notification per post (max 3, then grouped). */
    suspend fun showAccountPosts(source: com.orbit.followthrough.data.db.SignalSourceEntity, items: List<SignalItemEntity>, s: AppSettings) {
        val key = if (s.profile == NotificationProfile.SILENT) ChannelKey.QUIET else ChannelKey.SOCIAL
        val channelId = channels.channelId(key, s)
        val res = context.resources
        val group = "orbit_social_${source.id}"
        items.sortedByDescending { it.publishedAt ?: it.discoveredAt }.take(3).forEach { item ->
            val title = res.getString(R.string.notif_new_post, source.name)
            val b = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_stat_orbit)
                .setColor(0xFF3BE3FF.toInt())
                .setContentTitle(title)
                .setContentText(item.title)
                .setStyle(NotificationCompat.BigTextStyle().setBigContentTitle(title).bigText(item.title + (if (item.summary.isNotBlank()) "\n\n" + item.summary.take(260) else "")))
                .setGroup(group)
                .setCategory(NotificationCompat.CATEGORY_SOCIAL)
                .setAutoCancel(true)
                .setContentIntent(OrbitIntents.openApp(context, "signals?hl=${item.id}", signalNotificationId(item.id)))
            post(signalNotificationId(item.id), b, key.id, title, item.title, s)
        }
    }

    /** Price crossed a user alert level. */
    suspend fun showPriceAlert(coin: com.orbit.followthrough.data.db.CoinEntity, level: Double, up: Boolean, s: AppSettings) {
        val key = if (s.profile == NotificationProfile.SILENT) ChannelKey.QUIET else ChannelKey.MARKET
        val res = context.resources
        val price = com.orbit.followthrough.domain.Numbers.price(coin.price ?: level)
        val title = res.getString(if (up) R.string.notif_price_up else R.string.notif_price_down, coin.symbol, com.orbit.followthrough.domain.Numbers.price(level))
        val body = res.getString(R.string.notif_price_body, price, coin.change24h?.let { com.orbit.followthrough.domain.Numbers.percent(it) } ?: "—")
        val b = NotificationCompat.Builder(context, channels.channelId(key, s))
            .setSmallIcon(R.drawable.ic_stat_orbit)
            .setColor(if (up) 0xFF3DDC97.toInt() else 0xFFFF7AA8.toInt())
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(OrbitIntents.openApp(context, "market?coin=${coin.id}", 500_000 + coin.id.hashCode() % 1000))
        post(500_000 + (coin.id.hashCode() and 0xFFFF), b, key.id, title, body, s)
    }

    /** A tracked wallet bought / sold / moved something. Expanded view shows the full breakdown. */
    suspend fun showWalletActivity(w: com.orbit.followthrough.data.db.WalletEntity, a: com.orbit.followthrough.data.db.WalletActivityEntity, chain: com.orbit.followthrough.wallets.Chain, s: AppSettings) {
        val key = if (s.profile == NotificationProfile.SILENT) ChannelKey.QUIET else ChannelKey.WALLET
        val res = context.resources
        val N = com.orbit.followthrough.domain.Numbers
        fun amt(v: Double?, sym: String?) = if (v == null || sym == null) "" else "${N.compact(v)} $sym"
        val title = when (a.kind) {
            "MINT" -> res.getString(R.string.notif_wallet_mint, w.name, a.inSymbol ?: "NFT", chain.label)
            "BUY" -> res.getString(R.string.notif_wallet_buy, w.name, a.inSymbol ?: "")
            "SELL" -> res.getString(R.string.notif_wallet_sell, w.name, a.outSymbol ?: "")
            "SWAP" -> res.getString(R.string.notif_wallet_swap, w.name, a.outSymbol ?: "", a.inSymbol ?: "")
            "RECEIVE" -> res.getString(R.string.notif_wallet_receive, w.name, amt(a.inAmount, a.inSymbol))
            "SEND" -> res.getString(R.string.notif_wallet_send, w.name, amt(a.outAmount, a.outSymbol))
            else -> res.getString(R.string.notif_wallet_other, w.name)
        }
        val lines = buildList {
            if (a.inSymbol != null) add("↓ " + amt(a.inAmount, a.inSymbol))
            if (a.outSymbol != null) add("↑ " + amt(a.outAmount, a.outSymbol))
            a.valueUsd?.let { add("≈ " + N.compact(it, "$")) }
            add(chain.label + " · " + N.shortAddress(w.address))
        }
        val inbox = NotificationCompat.InboxStyle().setBigContentTitle(title)
        lines.forEach { inbox.addLine(it) }
        val b = NotificationCompat.Builder(context, channels.channelId(key, s))
            .setSmallIcon(R.drawable.ic_stat_orbit)
            .setColor(0xFF8B5CFF.toInt())
            .setContentTitle(title)
            .setContentText(lines.take(2).joinToString("  "))
            .setStyle(inbox)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setGroup("orbit_wallet_${w.id}")
            .setContentIntent(OrbitIntents.openApp(context, "wallet/${w.id}?hl=${a.id}", 600_000 + (a.id % 90_000).toInt()))
            .addAction(0, res.getString(R.string.open_explorer), android.app.PendingIntent.getActivity(
                context, 700_000 + (a.id % 90_000).toInt(),
                android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(a.explorerUrl)),
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT,
            ))
        post(600_000 + (a.id % 90_000).toInt(), b, key.id, title, lines.joinToString(" · "), s)
    }

    suspend fun showNewDevices(devices: List<com.orbit.followthrough.data.db.NetDeviceEntity>, s: AppSettings) {
        val key = if (s.profile == NotificationProfile.SILENT) ChannelKey.QUIET else ChannelKey.NETWORK
        val res = context.resources
        val title = res.getQuantityString(R.plurals.notif_new_devices, devices.size, devices.size)
        val body = devices.joinToString("\n") { (it.hostname ?: it.ip) + " · " + it.ip }
        val b = NotificationCompat.Builder(context, channels.channelId(key, s))
            .setSmallIcon(R.drawable.ic_stat_orbit)
            .setColor(0xFF3BE3FF.toInt())
            .setContentTitle(title)
            .setContentText(body.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(OrbitIntents.openApp(context, "network", 800_001))
        post(800_001, b, key.id, title, body, s)
    }

    /** Ongoing notification required while Live mode runs as a foreground service. */
    fun liveNotification(s: AppSettings, summary: String): android.app.Notification =
        NotificationCompat.Builder(context, channels.channelId(ChannelKey.LIVE, s))
            .setSmallIcon(R.drawable.ic_stat_orbit)
            .setColor(0xFF3BE3FF.toInt())
            .setContentTitle(context.getString(R.string.live_title))
            .setContentText(summary)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(OrbitIntents.openApp(context, "market", 800_002))
            .build()

    fun cancelReminder(id: Long) = nm.cancel(reminderNotificationId(id))
    fun cancelHabit(id: Long) = nm.cancel(habitNotificationId(id))

    private suspend fun post(id: Int, builder: NotificationCompat.Builder, channel: String, title: String, text: String, s: AppSettings): Boolean {
        val posted = postRaw(id, builder)
        if (posted && s.historyEnabled) {
            runCatching {
                logDao.insert(NotificationLogEntity(channel = channel, title = title, text = text.take(300), at = System.currentTimeMillis()))
            }
        }
        return posted
    }

    @SuppressLint("MissingPermission")
    private fun postRaw(id: Int, builder: NotificationCompat.Builder): Boolean {
        if (!canPost()) return false
        return try {
            nm.notify(id, builder.build())
            true
        } catch (_: SecurityException) {
            false
        }
    }

    companion object {
        const val SIGNAL_SUMMARY_ID = 399_999
        fun reminderNotificationId(id: Long): Int = 100_000 + (id % 90_000).toInt()
        fun habitNotificationId(id: Long): Int = 200_000 + (id % 90_000).toInt()
        fun signalNotificationId(id: Long): Int = 300_000 + (id % 90_000).toInt()

        fun categoryColor(c: ReminderCategory): Int = when (c) {
            ReminderCategory.GENERAL -> 0xFF4D7CFF.toInt()
            ReminderCategory.WORK -> 0xFF8B5CFF.toInt()
            ReminderCategory.HEALTH -> 0xFF3DDC97.toInt()
            ReminderCategory.STUDY -> 0xFF3BE3FF.toInt()
            ReminderCategory.SPIRITUAL -> 0xFFFFC266.toInt()
            ReminderCategory.PERSONAL -> 0xFFFF7AA8.toInt()
        }
    }
}
