package com.orbit.followthrough.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.orbit.followthrough.domain.EventType
import com.orbit.followthrough.domain.HabitKind
import com.orbit.followthrough.domain.NotifyMode
import com.orbit.followthrough.domain.ReminderCategory
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.domain.Schedule
import com.orbit.followthrough.domain.SourceType
import com.orbit.followthrough.domain.SyncStatus
import java.time.LocalDate

@Entity(
    tableName = "reminders",
    indices = [Index("status"), Index("nextOccurrenceAt")]
)
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val note: String = "",
    val category: ReminderCategory = ReminderCategory.GENERAL,
    val important: Boolean = false,
    val repeatType: RepeatType = RepeatType.ONCE,
    val hour: Int,
    val minute: Int,
    /** Epoch day of the first occurrence. */
    val startEpochDay: Long,
    val weekdays: Int = 0,
    val interval: Int = 1,
    val dayOfMonth: Int = 1,
    /** 0 = no automatic follow-up when the notification is dismissed. */
    val followUpMinutes: Int = 10,
    val maxFollowUps: Int = 3,
    /** No occurrences or follow-ups are delivered after this moment. */
    val deadlineAt: Long? = null,
    val status: ReminderStatus = ReminderStatus.SCHEDULED,
    val nextOccurrenceAt: Long? = null,
    /** The occurrence currently waiting for an action (status == PENDING). */
    val pendingOccurrenceAt: Long? = null,
    val followUpAt: Long? = null,
    val followUpsUsed: Int = 0,
    val snoozeCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

fun ReminderEntity.schedule(): Schedule = Schedule(
    type = repeatType,
    hour = hour,
    minute = minute,
    startDate = LocalDate.ofEpochDay(startEpochDay),
    weekdays = weekdays,
    interval = interval,
    dayOfMonth = dayOfMonth,
)

/** The single alarm that must exist for this reminder (earliest of follow-up / next occurrence). */
fun ReminderEntity.nextAlarmAt(): Long? = when (status) {
    ReminderStatus.DONE, ReminderStatus.PAUSED -> null
    else -> listOfNotNull(nextOccurrenceAt, followUpAt).minOrNull()
}

fun ReminderEntity.isRecurring(): Boolean = repeatType != RepeatType.ONCE

/** The moment that best represents "when" this reminder is relevant (for sorting / display). */
fun ReminderEntity.focusTime(): Long? = when (status) {
    ReminderStatus.PENDING -> followUpAt ?: pendingOccurrenceAt
    ReminderStatus.SCHEDULED -> nextOccurrenceAt
    else -> null
}

@Entity(
    tableName = "reminder_events",
    indices = [Index("reminderId"), Index("at")]
)
data class ReminderEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reminderId: Long,
    val type: EventType,
    val at: Long,
    /** Local hour of day when it happened – used for postponement-pattern insights. */
    val hourOfDay: Int,
    val title: String = "",
)

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val glyph: String,
    val colorIndex: Int = 0,
    val target: Int = 1,
    val unit: String = "",
    val kind: HabitKind = HabitKind.STANDARD,
    /** Tasbih: the dhikr phrase (from the verified preset list or the user's own text). */
    val phrase: String = "",
    /** Tasbih: beads per round (33 / 99 / 100). */
    val roundSize: Int = 33,
    val reminderEnabled: Boolean = false,
    val reminderHour: Int = 9,
    val reminderMinute: Int = 0,
    val spiritual: Boolean = false,
    val archived: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "habit_logs", primaryKeys = ["habitId", "epochDay"], indices = [Index("epochDay")])
data class HabitLogEntity(
    val habitId: Long,
    val epochDay: Long,
    val count: Int,
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "signal_sources")
data class SignalSourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: SourceType,
    /** RSS/Atom URL, or "owner/repo" for GitHub. */
    val target: String,
    val enabled: Boolean = true,
    val notifyMode: NotifyMode = NotifyMode.IMPORTANT,
    val status: SyncStatus = SyncStatus.NEVER,
    val lastAttemptAt: Long? = null,
    val lastSuccessAt: Long? = null,
    val lastError: String? = null,
    val etag: String? = null,
    val lastModified: String? = null,
    val itemCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "signal_items",
    indices = [
        Index(value = ["sourceId", "guid"], unique = true),
        Index("discoveredAt"),
        Index("titleKey"),
    ]
)
data class SignalItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: Long,
    val sourceName: String,
    val guid: String,
    val title: String,
    /** Normalised title for cross-source duplicate detection. */
    val titleKey: String,
    val link: String,
    val summary: String,
    /** When the event happened according to the source (may be unknown). */
    val publishedAt: Long?,
    /** When Orbit detected it. Always shown separately from [publishedAt]. */
    val discoveredAt: Long,
    /** 0 = low, 1 = normal, 2 = important. */
    val importance: Int,
    val category: String,
    val matchedKeyword: String? = null,
    val read: Boolean = false,
)

@Entity(tableName = "notification_log", indices = [Index("at")])
data class NotificationLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channel: String,
    val title: String,
    val text: String,
    val at: Long,
)
