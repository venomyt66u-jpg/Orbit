package com.orbit.followthrough.ui.settings

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.notify.ChannelKey
import com.orbit.followthrough.notify.SoundLibrary
import com.orbit.followthrough.notify.SoundPreviewPlayer
import com.orbit.followthrough.notify.VibePattern
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SoundWave
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType

fun channelColorIndex(key: ChannelKey): Int = when (key) {
    ChannelKey.REMINDER -> 0
    ChannelKey.URGENT -> 6
    ChannelKey.HABIT -> 2
    ChannelKey.SIGNAL_ALERT -> 4
    ChannelKey.ASSISTANT -> 1
    ChannelKey.WALLET -> 4
    ChannelKey.MARKET -> 3
    ChannelKey.SOCIAL -> 1
    ChannelKey.NETWORK -> 0
    else -> 5
}

fun channelIcon(key: ChannelKey) = when (key) {
    ChannelKey.REMINDER -> OrbitIcons.Bell
    ChannelKey.URGENT -> OrbitIcons.Flag
    ChannelKey.HABIT -> OrbitIcons.Leaf
    ChannelKey.SIGNAL_ALERT, ChannelKey.SIGNAL_QUIET -> OrbitIcons.Signal
    ChannelKey.ASSISTANT -> OrbitIcons.Spark
    ChannelKey.QUIET -> OrbitIcons.Moon
    ChannelKey.WALLET -> OrbitIcons.Wallet
    ChannelKey.MARKET -> OrbitIcons.Chart
    ChannelKey.SOCIAL -> OrbitIcons.Person
    ChannelKey.NETWORK -> OrbitIcons.Router
    ChannelKey.LIVE -> OrbitIcons.Bolt
}

@Composable
fun SoundsScreen(nav: NavHostController) {
    val vm = orbitViewModel { SettingsViewModel(it) }
    val s = LocalSettings.current
    val c = Orbit.colors
    val ctx = LocalContext.current
    val player = remember { SoundPreviewPlayer(ctx.applicationContext) }
    var playing by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf<ChannelKey?>(ChannelKey.REMINDER) }
    var pickingFor by remember { mutableStateOf<ChannelKey?>(null) }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val key = pickingFor
        if (result.resultCode == Activity.RESULT_OK && key != null) {
            val uri = result.data?.let { IntentCompat.getParcelableExtra(it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java) }
            vm.setChannelSound(key, if (uri == null) "silent" else "uri:$uri")
        }
        pickingFor = null
    }

    fun preview(id: String) {
        playing = id
        player.play(id) { if (playing == id) playing = null }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { TopBar(stringResource(R.string.sounds_vibration), { nav.popBackStack() }, stringResource(R.string.back)) }
        item { Text(stringResource(R.string.sounds_intro), style = OrbitType.body, color = c.textSecondary, modifier = Modifier.padding(bottom = 14.dp)) }

        items(ChannelKey.entries.filter { it.userConfigurable }, key = { it.name }) { key ->
            val style = s.style(key)
            val color = c.habit(channelColorIndex(key))
            val isOpen = expanded == key
            val soundName = when {
                style.sound == "silent" -> stringResource(R.string.sound_silent)
                style.sound == "system" -> stringResource(R.string.sound_system)
                style.sound.startsWith("uri:") -> stringResource(R.string.sound_custom)
                else -> SoundLibrary.builtIn(style.sound)?.let { stringResource(it.nameRes) } ?: style.sound
            }
            GlassCard(Modifier.fillMaxWidth().padding(bottom = 12.dp), highlight = if (isOpen) color else null, padding = PaddingValues(16.dp)) {
                Row(Modifier.fillMaxWidth().pressable({ expanded = if (isOpen) null else key }), verticalAlignment = Alignment.CenterVertically) {
                    GlyphBadge(channelIcon(key), color)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(key.nameRes), style = OrbitType.subtitle, color = c.text)
                        Text(soundName + " · " + stringResource(style.vibe.nameRes), style = OrbitType.caption, color = c.textSecondary)
                    }
                    Icon(if (isOpen) OrbitIcons.ChevronDown else OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                }
                AnimatedVisibility(isOpen) {
                    Column(Modifier.padding(top = 14.dp)) {
                        Text(stringResource(key.descRes), style = OrbitType.caption, color = c.textMuted)
                        Spacer(Modifier.height(10.dp))
                        SoundLibrary.sounds.forEach { snd ->
                            val id = "raw:${snd.key}"
                            val selected = style.sound == id
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (selected) color.copy(alpha = 0.12f) else c.surface.copy(alpha = 0.5f))
                                    .border(1.dp, if (selected) color.copy(alpha = 0.6f) else c.stroke, RoundedCornerShape(16.dp))
                                    .pressable({ vm.setChannelSound(key, id); preview(id) })
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.16f)).pressable({ if (playing == id) { player.stop(); playing = null } else preview(id) }), contentAlignment = Alignment.Center) {
                                    Icon(if (playing == id) OrbitIcons.Stop else OrbitIcons.Play, stringResource(R.string.preview), tint = color, modifier = Modifier.size(16.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(stringResource(snd.nameRes), style = OrbitType.subtitle, color = c.text)
                                    Text(stringResource(snd.moodRes), style = OrbitType.caption, color = c.textMuted)
                                }
                                SoundWave(playing == id, color, Modifier.width(64.dp).height(24.dp), bars = 10)
                                if (selected) {
                                    Spacer(Modifier.width(8.dp))
                                    Icon(OrbitIcons.Check, null, tint = color, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OrbitChip(stringResource(R.string.sound_system), style.sound == "system", { vm.setChannelSound(key, "system"); preview("system") }, accent = color)
                            OrbitChip(stringResource(R.string.sound_silent), style.sound == "silent", { vm.setChannelSound(key, "silent") }, accent = color)
                            OrbitChip(stringResource(R.string.sound_from_device), style.sound.startsWith("uri:"), {
                                pickingFor = key
                                val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                                    .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                    .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                runCatching { picker.launch(intent) }
                            }, icon = OrbitIcons.Sound, accent = color)
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(stringResource(R.string.vibration), style = OrbitType.caption, color = c.textMuted)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            VibePattern.entries.forEach { v ->
                                OrbitChip(stringResource(v.nameRes), style.vibe == v, { vm.setChannelVibe(key, v) }, icon = OrbitIcons.Vibrate, accent = color)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        SecondaryButton(stringResource(R.string.system_channel_settings), {
                            val channelId = vm.c.channels.channelId(key, s)
                            val i = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                                .putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            runCatching { ctx.startActivity(i) }
                        }, icon = OrbitIcons.Settings)
                    }
                }
            }
        }
        item {
            Text(stringResource(R.string.sounds_footer), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.navigationBarsPadding())
        }
    }
}
