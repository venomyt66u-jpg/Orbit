package com.orbit.followthrough.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ReminderEntity::class,
        ReminderEventEntity::class,
        HabitEntity::class,
        HabitLogEntity::class,
        SignalSourceEntity::class,
        SignalItemEntity::class,
        NotificationLogEntity::class,
        // v2
        DhikrLogEntity::class,
        CoinEntity::class,
        WalletEntity::class,
        WalletActivityEntity::class,
        NetDeviceEntity::class,
        NetUsageEntity::class,
        NetCounterEntity::class,
    ],
    version = 2,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class OrbitDatabase : RoomDatabase() {
    abstract fun reminders(): ReminderDao
    abstract fun events(): ReminderEventDao
    abstract fun habits(): HabitDao
    abstract fun signals(): SignalDao
    abstract fun notificationLog(): NotificationLogDao
    abstract fun dhikr(): DhikrDao
    abstract fun market(): MarketDao
    abstract fun wallets(): WalletDao
    abstract fun network(): NetworkDao

    companion object {
        /** v1 → v2: dhikr log, market watchlist, wallet tracker, home-network tables. Existing data untouched. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS `dhikr_log` (`phrase` TEXT NOT NULL, `epochDay` INTEGER NOT NULL, `taps` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`phrase`, `epochDay`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `coins` (`id` TEXT NOT NULL, `symbol` TEXT NOT NULL, `name` TEXT NOT NULL, `sortOrder` INTEGER NOT NULL, `price` REAL, `change24h` REAL, `marketCap` REAL, `high24h` REAL, `low24h` REAL, `sparkline` TEXT NOT NULL, `alertAbove` REAL, `alertBelow` REAL, `updatedAt` INTEGER, PRIMARY KEY(`id`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `wallets` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `address` TEXT NOT NULL, `chain` TEXT NOT NULL, `enabled` INTEGER NOT NULL, `notify` INTEGER NOT NULL, `minUsd` REAL NOT NULL, `cursor` TEXT, `lastCheckedAt` INTEGER, `lastActivityAt` INTEGER, `status` TEXT NOT NULL, `lastError` TEXT, `createdAt` INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `wallet_activity` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `walletId` INTEGER NOT NULL, `txHash` TEXT NOT NULL, `kind` TEXT NOT NULL, `inSymbol` TEXT, `inAmount` REAL, `outSymbol` TEXT, `outAmount` REAL, `valueUsd` REAL, `at` INTEGER NOT NULL, `discoveredAt` INTEGER NOT NULL, `read` INTEGER NOT NULL, `explorerUrl` TEXT NOT NULL, `chain` TEXT NOT NULL)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_wallet_activity_walletId_txHash` ON `wallet_activity` (`walletId`, `txHash`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_wallet_activity_at` ON `wallet_activity` (`at`)")
                db.execSQL("CREATE TABLE IF NOT EXISTS `net_devices` (`deviceKey` TEXT NOT NULL, `alias` TEXT, `hostname` TEXT, `ip` TEXT NOT NULL, `mac` TEXT, `firstSeen` INTEGER NOT NULL, `lastSeen` INTEGER NOT NULL, `online` INTEGER NOT NULL, PRIMARY KEY(`deviceKey`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `net_usage` (`deviceKey` TEXT NOT NULL, `epochDay` INTEGER NOT NULL, `rxBytes` INTEGER NOT NULL, `txBytes` INTEGER NOT NULL, PRIMARY KEY(`deviceKey`, `epochDay`))")
                db.execSQL("CREATE TABLE IF NOT EXISTS `net_counters` (`deviceKey` TEXT NOT NULL, `rx` INTEGER NOT NULL, `tx` INTEGER NOT NULL, `at` INTEGER NOT NULL, PRIMARY KEY(`deviceKey`))")
            }
        }

        /** Explicit migrations only – user data must survive updates (no destructive fallback on upgrade). */
        val MIGRATIONS: Array<Migration> = arrayOf(MIGRATION_1_2)

        fun build(context: Context): OrbitDatabase =
            Room.databaseBuilder(context, OrbitDatabase::class.java, "orbit.db")
                .addMigrations(*MIGRATIONS)
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
    }
}
