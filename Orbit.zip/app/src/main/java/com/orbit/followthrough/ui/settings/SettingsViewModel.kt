package com.orbit.followthrough.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.data.db.NotificationLogEntity
import com.orbit.followthrough.data.db.ReminderEventEntity
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.notify.ChannelKey
import com.orbit.followthrough.notify.VibePattern
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class SettingsViewModel(val c: AppContainer) : ViewModel() {

    fun update(block: SettingsRepository.SettingsEditor.() -> Unit) = viewModelScope.launch {
        c.settings.update(block)
    }

    fun setSyncHours(h: Int) = viewModelScope.launch {
        c.settings.update { signalSyncHours = h }
        c.signals.schedulePeriodic()
    }

    fun setChannelSound(key: ChannelKey, sound: String) = viewModelScope.launch { c.settings.setChannelStyle(key, sound = sound) }
    fun setChannelVibe(key: ChannelKey, vibe: VibePattern) = viewModelScope.launch { c.settings.setChannelStyle(key, vibe = vibe) }

    // history (paginated by growing limit)
    val historyLimit = MutableStateFlow(50)
    val notificationHistory: StateFlow<List<NotificationLogEntity>?> = historyLimit
        .flatMapLatest { c.db.notificationLog().observe(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val eventHistory: StateFlow<List<ReminderEventEntity>?> = historyLimit
        .flatMapLatest { c.db.events().observeRecent(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun loadMoreHistory() { historyLimit.value = historyLimit.value + 50 }

    fun clearHistory() = viewModelScope.launch {
        c.db.notificationLog().deleteAll()
        c.db.events().deleteAll()
    }

    fun clearSignals() = viewModelScope.launch { c.db.signals().deleteAllItems() }

    fun deleteEverything(onDone: () -> Unit) = viewModelScope.launch {
        c.deleteAllData()
        onDone()
    }

    fun rescheduleAll() = viewModelScope.launch {
        c.reminderEngine.rescheduleAll()
        c.habitEngine.rescheduleAll()
    }
}
