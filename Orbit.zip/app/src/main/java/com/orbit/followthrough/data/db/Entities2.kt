package com.orbit.followthrough.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Per-phrase, per-day tasbih counts. "Delete all" wipes this table only. */
@Entity(tableName = "dhikr_log", primaryKeys = ["phrase", "epochDay"])
data class DhikrLogEntity(
    val phrase: String,
    val epochDay: Long,
    val taps: Int,
    val updatedAt: Long = System.currentTimeMillis(),
)

/** Watch-listed coin (CoinGecko id) with the latest quote and optional price alerts. */
@Entity(tableName = "coins")
data class CoinEntity(
    @PrimaryKey val id: String,
    val symbol: String,
    val name: String,
    val sortOrder: Int = 0,
    val price: Double? = null,
    val change24h: Double? = null,
    val marketCap: Double? = null,
    val high24h: Double? = null,
    val low24h: Double? = null,
    /** 7-day hourly prices, comma separated (kept small: ~168 points). */
    val sparkline: String = "",
    val alertAbove: Double? = null,
    val alertBelow: Double? = null,
    val updatedAt: Long? = null,
)

/** A tracked public wallet with a user-chosen name. */
@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val address: String,
    /** [com.orbit.followthrough.wallets.Chain] name. */
    val chain: String,
    val enabled: Boolean = true,
    val notify: Boolean = true,
    /** Only notify for activity worth at least this much (0 = everything). */
    val minUsd: Double = 0.0,
    /** Chain-specific progress marker (timestamp / last signature). */
    val cursor: String? = null,
    val lastCheckedAt: Long? = null,
    val lastActivityAt: Long? = null,
    val status: String = "NEVER",
    val lastError: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "wallet_activity",
    indices = [Index(value = ["walletId", "txHash"], unique = true), Index("at")]
)
data class WalletActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val walletId: Long,
    val txHash: String,
    /** [com.orbit.followthrough.wallets.ActivityKind] name. */
    val kind: String,
    val inSymbol: String? = null,
    val inAmount: Double? = null,
    val outSymbol: String? = null,
    val outAmount: Double? = null,
    val valueUsd: Double? = null,
    /** When it happened on-chain. */
    val at: Long,
    val discoveredAt: Long,
    val read: Boolean = false,
    val explorerUrl: String,
    /** Network the transaction happened on (matters for "all networks" wallets). */
    val chain: String = "",
)

/** A device seen on the local network (by LAN scan or router connector). */
@Entity(tableName = "net_devices")
data class NetDeviceEntity(
    @PrimaryKey val deviceKey: String,
    val alias: String? = null,
    val hostname: String? = null,
    val ip: String,
    val mac: String? = null,
    val firstSeen: Long,
    val lastSeen: Long,
    val online: Boolean,
)

/** Daily traffic per device (filled by a router connector). */
@Entity(tableName = "net_usage", primaryKeys = ["deviceKey", "epochDay"])
data class NetUsageEntity(
    val deviceKey: String,
    val epochDay: Long,
    val rxBytes: Long,
    val txBytes: Long,
)

/** Last raw cumulative counter per device, used to compute deltas. */
@Entity(tableName = "net_counters")
data class NetCounterEntity(
    @PrimaryKey val deviceKey: String,
    val rx: Long,
    val tx: Long,
    val at: Long,
)
