package com.orbit.followthrough.ui.nav

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.ui.assistant.AssistantScreen
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PillShape
import com.orbit.followthrough.ui.components.auroraBackground
import com.orbit.followthrough.ui.habits.HabitEditorScreen
import com.orbit.followthrough.ui.habits.HabitsScreen
import com.orbit.followthrough.ui.habits.TasbihScreen
import com.orbit.followthrough.ui.home.HomeScreen
import com.orbit.followthrough.ui.onboarding.HelpScreen
import com.orbit.followthrough.ui.onboarding.OnboardingScreen
import com.orbit.followthrough.ui.onboarding.TutorialScreen
import com.orbit.followthrough.ui.reminder.AllRemindersScreen
import com.orbit.followthrough.ui.reminder.ReminderEditorScreen
import com.orbit.followthrough.ui.settings.HistoryScreen
import com.orbit.followthrough.ui.settings.PermissionsScreen
import com.orbit.followthrough.ui.settings.PrivacyScreen
import com.orbit.followthrough.ui.settings.SettingsScreen
import com.orbit.followthrough.ui.settings.SoundsScreen
import com.orbit.followthrough.ui.signals.SignalsScreen
import com.orbit.followthrough.ui.signals.SourcesScreen
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitTheme
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.flow.StateFlow

@Composable
fun OrbitRoot(container: AppContainer, pendingRoute: StateFlow<String?>, onRouteConsumed: () -> Unit) {
    val settingsState by container.settings.settings.collectAsStateWithLifecycle(initialValue = null)
    val settings = settingsState ?: return // DataStore loads in a few ms; the window background shows meanwhile.

    OrbitTheme(settings.themeMode) {
        val c = Orbit.colors
        val view = LocalView.current
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !c.isDark
                isAppearanceLightNavigationBars = !c.isDark
            }
        }
        CompositionLocalProvider(LocalAppContainer provides container, LocalSettings provides settings) {
            val nav = rememberNavController()
            val start = remember { if (settings.onboardingDone) Routes.HOME else Routes.ONBOARDING }
            val route by pendingRoute.collectAsStateWithLifecycle()
            LaunchedEffect(route) {
                val r = route ?: return@LaunchedEffect
                if (settings.onboardingDone) openDeepLink(nav, container, r)
                onRouteConsumed()
            }

            Box(
                Modifier
                    .fillMaxSize()
                    .drawBehind { auroraBackground(c.void, c.abyss, c.violet, c.cyan, c.isDark) }
            ) {
                OrbitNavHost(nav, start)
                val backStack by nav.currentBackStackEntryAsState()
                val current = backStack?.destination?.route
                AnimatedVisibility(
                    visible = current in Routes.topLevel,
                    enter = fadeIn() + slideInVertically { it / 2 },
                    exit = fadeOut() + slideOutVertically { it / 2 },
                    modifier = Modifier.align(Alignment.BottomCenter),
                ) {
                    BottomBar(current = current, onSelect = { nav.navigateTopLevel(it) })
                }
            }
        }
    }
}

/** Notification deep links: "signals?hl=12", "wallet/3?hl=9", "market?coin=bitcoin", or a top-level route. */
fun openDeepLink(nav: NavHostController, container: AppContainer, raw: String) {
    val path = raw.substringBefore('?')
    val query = raw.substringAfter('?', "").split('&').mapNotNull { kv -> kv.split('=').takeIf { it.size == 2 }?.let { it[0] to it[1] } }.toMap()
    when {
        path.startsWith("wallet/") -> {
            query["hl"]?.let { container.highlight.value = "activity" to it }
            nav.navigate(path) { launchSingleTop = true }
        }
        path == Routes.SIGNALS -> {
            query["hl"]?.let { container.highlight.value = "signal" to it }
            nav.navigateTopLevel(Routes.SIGNALS)
        }
        path == Routes.MARKET -> {
            query["coin"]?.let { container.highlight.value = "coin" to it }
            nav.navigateTopLevel(Routes.MARKET)
        }
        path in Routes.topLevel -> nav.navigateTopLevel(path)
        path == Routes.NETWORK || path == Routes.ASSISTANT -> nav.navigate(path) { launchSingleTop = true }
    }
}

fun NavHostController.navigateTopLevel(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun OrbitNavHost(nav: NavHostController, start: String) {
    val reduced = Orbit.reducedMotion
    val d = if (reduced) 0 else 260
    NavHost(
        navController = nav,
        startDestination = start,
        enterTransition = { fadeIn(tween(d)) + slideInVertically(tween(d)) { it / 30 } },
        exitTransition = { fadeOut(tween(d / 2)) },
        popEnterTransition = { fadeIn(tween(d)) },
        popExitTransition = { fadeOut(tween(d / 2)) + slideOutVertically(tween(d)) { it / 30 } },
    ) {
        composable(Routes.ONBOARDING) { OnboardingScreen(nav) }
        composable(Routes.HOME) { HomeScreen(nav) }
        composable(Routes.HABITS) { HabitsScreen(nav) }
        composable(Routes.SIGNALS) { SignalsScreen(nav) }
        composable(Routes.ASSISTANT) { AssistantScreen(nav) }
        composable(Routes.SETTINGS) { SettingsScreen(nav) }
        composable(
            Routes.EDITOR,
            arguments = listOf(navArgument("id") { type = NavType.LongType; defaultValue = -1L }),
        ) { entry -> ReminderEditorScreen(nav, entry.arguments?.getLong("id") ?: -1L) }
        composable(Routes.REMINDERS) { AllRemindersScreen(nav) }
        composable(
            Routes.TASBIH,
            arguments = listOf(navArgument("id") { type = NavType.LongType }),
        ) { entry -> TasbihScreen(nav, entry.arguments?.getLong("id") ?: -1L) }
        composable(
            Routes.HABIT_EDIT,
            arguments = listOf(navArgument("id") { type = NavType.LongType; defaultValue = -1L }),
        ) { entry -> HabitEditorScreen(nav, entry.arguments?.getLong("id") ?: -1L) }
        composable(Routes.SOURCES) { SourcesScreen(nav) }
        composable(Routes.HISTORY) { HistoryScreen(nav) }
        composable(Routes.SOUNDS) { SoundsScreen(nav) }
        composable(Routes.PERMISSIONS) { PermissionsScreen(nav) }
        composable(Routes.PRIVACY) { PrivacyScreen(nav) }
        composable(Routes.HELP) { HelpScreen(nav) }
        composable(Routes.MARKET) { com.orbit.followthrough.ui.market.MarketScreen(nav) }
        composable(Routes.MORE) { com.orbit.followthrough.ui.more.MoreScreen(nav) }
        composable(Routes.NETWORK) { com.orbit.followthrough.ui.network.NetworkScreen(nav) }
        composable(Routes.KEYS) { com.orbit.followthrough.ui.more.KeysScreen(nav) }
        composable(
            Routes.WALLET,
            arguments = listOf(navArgument("id") { type = NavType.LongType }),
        ) { entry -> com.orbit.followthrough.ui.market.WalletScreen(nav, entry.arguments?.getLong("id") ?: -1L) }
        composable(Routes.TUTORIAL) { entry -> TutorialScreen(nav, entry.arguments?.getString("key") ?: "reminders") }
    }
}

private data class Tab(val route: String, val icon: ImageVector, val label: Int)

@Composable
private fun BottomBar(current: String?, onSelect: (String) -> Unit) {
    val c = Orbit.colors
    val tabs = remember {
        listOf(
            Tab(Routes.HOME, OrbitIcons.Home, R.string.tab_home),
            Tab(Routes.HABITS, OrbitIcons.Habits, R.string.tab_habits),
            Tab(Routes.MARKET, OrbitIcons.Chart, R.string.tab_market),
            Tab(Routes.SIGNALS, OrbitIcons.Signal, R.string.tab_signals),
            Tab(Routes.MORE, OrbitIcons.Grid, R.string.tab_more),
        )
    }
    Box(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(PillShape)
                .background(Brush.verticalGradient(listOf(c.surfaceHigh.copy(alpha = 0.96f), c.surface.copy(alpha = 0.98f))))
                .border(1.dp, c.strokeStrong, PillShape)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            tabs.forEach { tab ->
                val selected = current == tab.route
                val label = stringResource(tab.label)
                Column(
                    Modifier
                        .weight(1f)
                        .clip(PillShape)
                        .background(if (selected) c.cyan.copy(alpha = 0.10f) else androidx.compose.ui.graphics.Color.Transparent)
                        .clickable(role = Role.Tab) { onSelect(tab.route) }
                        .semantics { this.selected = selected }
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(tab.icon, label, tint = if (selected) c.cyan else c.textMuted, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.height(3.dp))
                    if (selected) {
                        Text(label, style = OrbitType.caption, color = c.text, maxLines = 1)
                    } else {
                        Box(Modifier.size(4.dp).clip(CircleShape))
                    }
                }
            }
        }
    }
}
