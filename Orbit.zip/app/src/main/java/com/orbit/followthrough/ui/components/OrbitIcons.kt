package com.orbit.followthrough.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Orbit's original line-icon set (24×24, 1.8px rounded strokes). Drawn as vectors, so they are
 * crisp at any size, tint with the theme and weigh nothing. Directional icons auto-mirror in RTL.
 */
object OrbitIcons {

    private fun icon(name: String, mirror: Boolean = false, filled: Boolean = false, block: PathBuilder.() -> Unit): ImageVector =
        ImageVector.Builder(
            name = name,
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f,
            autoMirror = mirror,
        ).path(
            fill = if (filled) SolidColor(Color.Black) else null,
            stroke = if (filled) null else SolidColor(Color.Black),
            strokeLineWidth = 1.8f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
            pathBuilder = block,
        ).build()

    private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
        moveTo(cx - r, cy)
        arcToRelative(r, r, 0f, true, true, 2 * r, 0f)
        arcToRelative(r, r, 0f, true, true, -2 * r, 0f)
        close()
    }

    // ---- navigation ----
    val Home = icon("home") {
        // orbit ring with a satellite: "what's next"
        moveTo(18.6f, 7.4f); arcTo(8f, 8f, 0f, true, true, 13.4f, 4.1f)
        circle(17.6f, 5.2f, 1.6f)
        moveTo(12f, 8.6f); lineTo(12f, 12f); lineTo(14.4f, 13.6f)
    }
    val Habits = icon("habits") {
        moveTo(12f, 3.5f); arcTo(8.5f, 8.5f, 0f, true, true, 3.5f, 12f)
        moveTo(12f, 7.5f); arcTo(4.5f, 4.5f, 0f, true, true, 7.5f, 12f)
        circle(12f, 12f, 0.9f)
    }
    val Signal = icon("signal") {
        circle(12f, 16.5f, 1.4f)
        moveTo(8.2f, 12.8f); arcTo(5.4f, 5.4f, 0f, false, true, 15.8f, 12.8f)
        moveTo(5f, 9.6f); arcTo(9.9f, 9.9f, 0f, false, true, 19f, 9.6f)
        moveTo(2.4f, 6.4f); arcTo(13.6f, 13.6f, 0f, false, true, 21.6f, 6.4f)
    }
    val Assistant = icon("assistant") {
        moveTo(12f, 3f); curveTo(12.6f, 7.8f, 14.2f, 9.4f, 19f, 10f); curveTo(14.2f, 10.6f, 12.6f, 12.2f, 12f, 17f)
        curveTo(11.4f, 12.2f, 9.8f, 10.6f, 5f, 10f); curveTo(9.8f, 9.4f, 11.4f, 7.8f, 12f, 3f); close()
        moveTo(18.5f, 15.5f); lineTo(18.5f, 20.5f); moveTo(16f, 18f); lineTo(21f, 18f)
    }
    val Settings = icon("settings") {
        moveTo(4f, 7f); lineTo(11f, 7f); moveTo(17f, 7f); lineTo(20f, 7f); circle(14f, 7f, 2.4f)
        moveTo(4f, 17f); lineTo(7f, 17f); moveTo(13f, 17f); lineTo(20f, 17f); circle(10f, 17f, 2.4f)
    }

    // ---- actions ----
    val Plus = icon("plus") { moveTo(12f, 5f); lineTo(12f, 19f); moveTo(5f, 12f); lineTo(19f, 12f) }
    val Check = icon("check") { moveTo(5f, 12.5f); lineTo(10f, 17.5f); lineTo(19f, 7.5f) }
    val Close = icon("close") { moveTo(6f, 6f); lineTo(18f, 18f); moveTo(18f, 6f); lineTo(6f, 18f) }
    val Back = icon("back", mirror = true) { moveTo(15f, 5f); lineTo(8f, 12f); lineTo(15f, 19f) }
    val ChevronRight = icon("chevron", mirror = true) { moveTo(9f, 5f); lineTo(16f, 12f); lineTo(9f, 19f) }
    val ChevronDown = icon("chevron_down") { moveTo(6f, 9f); lineTo(12f, 15f); lineTo(18f, 9f) }
    val Later = icon("later") {
        circle(12f, 13f, 7.5f); moveTo(12f, 9f); lineTo(12f, 13f); lineTo(15f, 15f)
        moveTo(9.5f, 2.8f); lineTo(14.5f, 2.8f)
    }
    val Skip = icon("skip", mirror = true) {
        moveTo(5f, 6f); lineTo(12f, 12f); lineTo(5f, 18f); close(); moveTo(12f, 6f); lineTo(19f, 12f); lineTo(12f, 18f); close()
    }
    val Send = icon("send", mirror = true) { moveTo(4f, 12f); lineTo(20f, 4.5f); lineTo(14.5f, 20f); lineTo(11.5f, 13f); close(); moveTo(11.5f, 13f); lineTo(20f, 4.5f) }
    val Search = icon("search") { circle(10.5f, 10.5f, 6f); moveTo(15f, 15f); lineTo(20f, 20f) }
    val Trash = icon("trash") {
        moveTo(4.5f, 7f); lineTo(19.5f, 7f); moveTo(9.5f, 7f); lineTo(10f, 4f); lineTo(14f, 4f); lineTo(14.5f, 7f)
        moveTo(6.5f, 7f); lineTo(7.5f, 20f); lineTo(16.5f, 20f); lineTo(17.5f, 7f)
    }
    val Edit = icon("edit") { moveTo(4f, 20f); lineTo(4.6f, 16f); lineTo(15.8f, 4.8f); lineTo(19.2f, 8.2f); lineTo(8f, 19.4f); close(); moveTo(13.5f, 7f); lineTo(17f, 10.5f) }
    val External = icon("external", mirror = true) { moveTo(13f, 5f); lineTo(19f, 5f); lineTo(19f, 11f); moveTo(19f, 5f); lineTo(11f, 13f); moveTo(16f, 14f); lineTo(16f, 19f); lineTo(5f, 19f); lineTo(5f, 8f); lineTo(10f, 8f) }
    val Refresh = icon("refresh") { moveTo(19f, 12f); arcTo(7f, 7f, 0f, true, true, 16.9f, 7f); moveTo(17.5f, 3.5f); lineTo(17.5f, 7.5f); lineTo(13.5f, 7.5f) }
    val Pause = icon("pause") { moveTo(9f, 6f); lineTo(9f, 18f); moveTo(15f, 6f); lineTo(15f, 18f) }
    val Play = icon("play", filled = true) { moveTo(8f, 5.5f); lineTo(18.5f, 12f); lineTo(8f, 18.5f); close() }
    val Stop = icon("stop", filled = true) { moveTo(7f, 7f); lineTo(17f, 7f); lineTo(17f, 17f); lineTo(7f, 17f); close() }
    val Minus = icon("minus") { moveTo(5f, 12f); lineTo(19f, 12f) }
    val Undo = icon("undo", mirror = true) { moveTo(9f, 6f); lineTo(4.5f, 10.5f); lineTo(9f, 15f); moveTo(4.5f, 10.5f); lineTo(14f, 10.5f); arcTo(5f, 5f, 0f, false, true, 14f, 20.5f); lineTo(11f, 20.5f) }

    // ---- objects ----
    val Bell = icon("bell") {
        moveTo(6f, 16.5f); lineTo(6f, 11f); arcTo(6f, 6f, 0f, false, true, 18f, 11f); lineTo(18f, 16.5f); lineTo(19.5f, 18f); lineTo(4.5f, 18f); close()
        moveTo(10f, 20.5f); lineTo(14f, 20.5f)
    }
    val Moon = icon("moon") { moveTo(19.5f, 14.5f); arcTo(8f, 8f, 0f, true, true, 9.5f, 4.5f); arcTo(6.5f, 6.5f, 0f, false, false, 19.5f, 14.5f); close() }
    val Sun = icon("sun") {
        circle(12f, 12f, 4f)
        moveTo(12f, 2.5f); lineTo(12f, 4.5f); moveTo(12f, 19.5f); lineTo(12f, 21.5f); moveTo(2.5f, 12f); lineTo(4.5f, 12f); moveTo(19.5f, 12f); lineTo(21.5f, 12f)
        moveTo(5.3f, 5.3f); lineTo(6.7f, 6.7f); moveTo(17.3f, 17.3f); lineTo(18.7f, 18.7f); moveTo(5.3f, 18.7f); lineTo(6.7f, 17.3f); moveTo(17.3f, 6.7f); lineTo(18.7f, 5.3f)
    }
    val Sound = icon("sound") { moveTo(4f, 9.5f); lineTo(4f, 14.5f); lineTo(8f, 14.5f); lineTo(13f, 19f); lineTo(13f, 5f); lineTo(8f, 9.5f); close(); moveTo(16.5f, 9f); arcTo(4f, 4f, 0f, false, true, 16.5f, 15f); moveTo(19f, 6.5f); arcTo(7.5f, 7.5f, 0f, false, true, 19f, 17.5f) }
    val Vibrate = icon("vibrate") { moveTo(8f, 4f); lineTo(16f, 4f); lineTo(16f, 20f); lineTo(8f, 20f); close(); moveTo(4.5f, 8f); lineTo(4.5f, 16f); moveTo(19.5f, 8f); lineTo(19.5f, 16f) }
    val Shield = icon("shield") { moveTo(12f, 3f); lineTo(19f, 6f); lineTo(19f, 11.5f); curveTo(19f, 16f, 16f, 19.5f, 12f, 21f); curveTo(8f, 19.5f, 5f, 16f, 5f, 11.5f); lineTo(5f, 6f); close(); moveTo(9f, 12f); lineTo(11.2f, 14.2f); lineTo(15.2f, 10f) }
    val Help = icon("help") { circle(12f, 12f, 8.5f); moveTo(9.6f, 9.6f); arcTo(2.5f, 2.5f, 0f, true, true, 12.8f, 12f); curveTo(12.2f, 12.3f, 12f, 12.8f, 12f, 13.6f); moveTo(12f, 16.6f); lineTo(12f, 16.7f) }
    val Repeat = icon("repeat", mirror = true) { moveTo(4.5f, 11f); lineTo(4.5f, 9.5f); arcTo(3f, 3f, 0f, false, true, 7.5f, 6.5f); lineTo(19f, 6.5f); moveTo(16f, 3.5f); lineTo(19f, 6.5f); lineTo(16f, 9.5f); moveTo(19.5f, 13f); lineTo(19.5f, 14.5f); arcTo(3f, 3f, 0f, false, true, 16.5f, 17.5f); lineTo(5f, 17.5f); moveTo(8f, 14.5f); lineTo(5f, 17.5f); lineTo(8f, 20.5f) }
    val Calendar = icon("calendar") { moveTo(4.5f, 6f); lineTo(19.5f, 6f); lineTo(19.5f, 20f); lineTo(4.5f, 20f); close(); moveTo(4.5f, 10f); lineTo(19.5f, 10f); moveTo(8.5f, 3.5f); lineTo(8.5f, 7.5f); moveTo(15.5f, 3.5f); lineTo(15.5f, 7.5f) }
    val Flag = icon("flag", mirror = true) { moveTo(5.5f, 21f); lineTo(5.5f, 4f); moveTo(5.5f, 4.5f); lineTo(18.5f, 4.5f); lineTo(15.5f, 9f); lineTo(18.5f, 13.5f); lineTo(5.5f, 13.5f) }
    val Lock = icon("lock") { moveTo(5.5f, 11f); lineTo(18.5f, 11f); lineTo(18.5f, 20f); lineTo(5.5f, 20f); close(); moveTo(8.5f, 11f); lineTo(8.5f, 8f); arcTo(3.5f, 3.5f, 0f, false, true, 15.5f, 8f); lineTo(15.5f, 11f) }
    val Layers = icon("layers") { moveTo(12f, 4f); lineTo(20f, 8.5f); lineTo(12f, 13f); lineTo(4f, 8.5f); close(); moveTo(4f, 12.5f); lineTo(12f, 17f); lineTo(20f, 12.5f); moveTo(4f, 16f); lineTo(12f, 20.5f); lineTo(20f, 16f) }
    val History = icon("history", mirror = true) { moveTo(4.5f, 12f); arcTo(7.5f, 7.5f, 0f, true, false, 7f, 6.4f); moveTo(4f, 4.5f); lineTo(4f, 8.5f); lineTo(8f, 8.5f); moveTo(12f, 8f); lineTo(12f, 12f); lineTo(14.8f, 14f) }
    val Window = icon("window") { moveTo(4f, 5f); lineTo(20f, 5f); lineTo(20f, 19f); lineTo(4f, 19f); close(); moveTo(12f, 9f); lineTo(17f, 9f); lineTo(17f, 13f); lineTo(12f, 13f); close() }
    val Battery = icon("battery") { moveTo(3.5f, 8f); lineTo(18f, 8f); lineTo(18f, 16f); lineTo(3.5f, 16f); close(); moveTo(20.5f, 10.5f); lineTo(20.5f, 13.5f); moveTo(6f, 10.5f); lineTo(10f, 10.5f); lineTo(10f, 13.5f); lineTo(6f, 13.5f); close() }
    val Alarm = icon("alarm") { circle(12f, 13f, 7f); moveTo(12f, 9.5f); lineTo(12f, 13f); lineTo(14.5f, 14.5f); moveTo(3.5f, 6f); lineTo(6.5f, 3.5f); moveTo(20.5f, 6f); lineTo(17.5f, 3.5f) }
    val Palette = icon("palette") { moveTo(12f, 3.5f); arcTo(8.5f, 8.5f, 0f, true, false, 12f, 20.5f); curveTo(13.5f, 20.5f, 13.8f, 19.2f, 13f, 18.2f); curveTo(12.2f, 17.2f, 12.8f, 15.5f, 14.5f, 15.5f); lineTo(16.5f, 15.5f); arcTo(4f, 4f, 0f, false, false, 20.5f, 11.5f); curveTo(20.5f, 7f, 16.7f, 3.5f, 12f, 3.5f); close(); circle(8f, 11f, 0.8f); circle(11f, 7.5f, 0.8f); circle(15.5f, 8.5f, 0.8f) }
    val Link = icon("link") { moveTo(10f, 14f); lineTo(14f, 10f); moveTo(8.5f, 11.5f); lineTo(6.5f, 13.5f); arcTo(3.2f, 3.2f, 0f, false, false, 10.5f, 17.5f); lineTo(12.5f, 15.5f); moveTo(11.5f, 8.5f); lineTo(13.5f, 6.5f); arcTo(3.2f, 3.2f, 0f, false, true, 17.5f, 10.5f); lineTo(15.5f, 12.5f) }
    val Github = icon("code") { moveTo(8.5f, 7.5f); lineTo(4f, 12f); lineTo(8.5f, 16.5f); moveTo(15.5f, 7.5f); lineTo(20f, 12f); lineTo(15.5f, 16.5f); moveTo(13.5f, 5f); lineTo(10.5f, 19f) }
    val Rss = icon("rss") { moveTo(5f, 11f); arcTo(8f, 8f, 0f, false, true, 13f, 19f); moveTo(5f, 5f); arcTo(14f, 14f, 0f, false, true, 19f, 19f); circle(6f, 18f, 1.2f) }
    val Key = icon("key") { circle(8f, 15f, 3.8f); moveTo(10.8f, 12.3f); lineTo(19f, 4f); moveTo(16f, 7f); lineTo(18.5f, 9.5f); moveTo(13.8f, 9.2f); lineTo(15.8f, 11.2f) }
    val Spark = icon("spark") { moveTo(12f, 4f); lineTo(13.6f, 10.4f); lineTo(20f, 12f); lineTo(13.6f, 13.6f); lineTo(12f, 20f); lineTo(10.4f, 13.6f); lineTo(4f, 12f); lineTo(10.4f, 10.4f); close() }
    val Info = icon("info") { circle(12f, 12f, 8.5f); moveTo(12f, 11f); lineTo(12f, 16.5f); moveTo(12f, 7.6f); lineTo(12f, 7.7f) }
    val Clock = icon("clock") { circle(12f, 12f, 8.5f); moveTo(12f, 7.5f); lineTo(12f, 12f); lineTo(15f, 14f) }
    val Target = icon("target") { circle(12f, 12f, 8.5f); circle(12f, 12f, 4.5f); circle(12f, 12f, 0.8f) }

    // ---- category / habit glyphs ----
    val Dot = icon("dot") { circle(12f, 12f, 3.5f); circle(12f, 12f, 8f) }
    val Briefcase = icon("briefcase") { moveTo(4f, 8f); lineTo(20f, 8f); lineTo(20f, 19f); lineTo(4f, 19f); close(); moveTo(9f, 8f); lineTo(9f, 5.5f); lineTo(15f, 5.5f); lineTo(15f, 8f); moveTo(4f, 13f); lineTo(20f, 13f) }
    val Heart = icon("heart") { moveTo(12f, 19.5f); curveTo(5f, 15f, 3.5f, 11.5f, 3.5f, 9f); arcTo(4.2f, 4.2f, 0f, false, true, 12f, 7f); arcTo(4.2f, 4.2f, 0f, false, true, 20.5f, 9f); curveTo(20.5f, 11.5f, 19f, 15f, 12f, 19.5f); close() }
    val Book = icon("book") { moveTo(12f, 6.5f); curveTo(10f, 5f, 7f, 4.5f, 4f, 5f); lineTo(4f, 18.5f); curveTo(7f, 18f, 10f, 18.5f, 12f, 20f); curveTo(14f, 18.5f, 17f, 18f, 20f, 18.5f); lineTo(20f, 5f); curveTo(17f, 4.5f, 14f, 5f, 12f, 6.5f); close(); moveTo(12f, 6.5f); lineTo(12f, 20f) }
    val Crescent = icon("crescent") { moveTo(16.5f, 18.5f); arcTo(7.8f, 7.8f, 0f, true, true, 16.5f, 5.5f); arcTo(6.4f, 6.4f, 0f, true, false, 16.5f, 18.5f); close(); moveTo(18.5f, 10f); lineTo(19.2f, 11.6f); lineTo(20.8f, 12f); lineTo(19.2f, 12.4f); lineTo(18.5f, 14f) }
    val Person = icon("person") { circle(12f, 8f, 3.6f); moveTo(4.5f, 20f); curveTo(5.5f, 15.8f, 8.5f, 14f, 12f, 14f); curveTo(15.5f, 14f, 18.5f, 15.8f, 19.5f, 20f) }
    val Drop = icon("drop") { moveTo(12f, 3.5f); curveTo(15f, 7.5f, 18f, 10.6f, 18f, 14f); arcTo(6f, 6f, 0f, false, true, 6f, 14f); curveTo(6f, 10.6f, 9f, 7.5f, 12f, 3.5f); close(); moveTo(9.5f, 14.5f); arcTo(2.6f, 2.6f, 0f, false, false, 12f, 17f) }
    val Walk = icon("walk") { circle(13f, 4.8f, 1.6f); moveTo(9f, 21f); lineTo(11.5f, 14f); lineTo(14f, 16f); lineTo(15f, 21f); moveTo(11.5f, 14f); lineTo(12.5f, 8.5f); lineTo(16.5f, 12f); lineTo(19f, 12f); moveTo(12.5f, 8.5f); lineTo(9f, 10f); lineTo(7.5f, 13.5f) }
    val Beads = icon("beads") {
        circle(12f, 4.5f, 1.5f); circle(17.3f, 6.7f, 1.5f); circle(19.5f, 12f, 1.5f); circle(17.3f, 17.3f, 1.5f)
        circle(6.7f, 6.7f, 1.5f); circle(4.5f, 12f, 1.5f); circle(6.7f, 17.3f, 1.5f); moveTo(12f, 18f); lineTo(12f, 21.5f); circle(12f, 17f, 1.2f)
    }
    val Pen = icon("pen") { moveTo(5f, 19f); lineTo(6f, 15f); lineTo(16f, 5f); lineTo(19f, 8f); lineTo(9f, 18f); close(); moveTo(4f, 21f); lineTo(20f, 21f) }
    val Dumbbell = icon("dumbbell") { moveTo(7f, 8f); lineTo(7f, 16f); moveTo(17f, 8f); lineTo(17f, 16f); moveTo(4f, 10f); lineTo(4f, 14f); moveTo(20f, 10f); lineTo(20f, 14f); moveTo(7f, 12f); lineTo(17f, 12f) }
    val Leaf = icon("leaf") { moveTo(5f, 19f); curveTo(5f, 10f, 10f, 5f, 19.5f, 4.5f); curveTo(19f, 14f, 14f, 19f, 5f, 19f); close(); moveTo(5f, 19f); lineTo(13f, 11f) }
    val Star = icon("star") { moveTo(12f, 3.8f); lineTo(14.5f, 9f); lineTo(20.2f, 9.6f); lineTo(16f, 13.4f); lineTo(17.2f, 19f); lineTo(12f, 16.2f); lineTo(6.8f, 19f); lineTo(8f, 13.4f); lineTo(3.8f, 9.6f); lineTo(9.5f, 9f); close() }
    val Coffee = icon("coffee") { moveTo(4.5f, 9f); lineTo(16.5f, 9f); lineTo(16.5f, 15f); arcTo(4f, 4f, 0f, false, true, 12.5f, 19f); lineTo(8.5f, 19f); arcTo(4f, 4f, 0f, false, true, 4.5f, 15f); close(); moveTo(16.5f, 10.5f); lineTo(18f, 10.5f); arcTo(2.2f, 2.2f, 0f, false, true, 18f, 14.9f); lineTo(16.5f, 14.9f); moveTo(8.5f, 3.5f); lineTo(8.5f, 6f); moveTo(12.5f, 3.5f); lineTo(12.5f, 6f) }
    val Bed = icon("bed") { moveTo(3.5f, 18f); lineTo(3.5f, 6f); moveTo(3.5f, 14f); lineTo(20.5f, 14f); lineTo(20.5f, 18f); moveTo(3.5f, 11f); lineTo(20.5f, 11f); lineTo(20.5f, 14f); circle(7.5f, 8.5f, 1.4f) }

    // ---- v2: market, wallets, network ----
    val Wallet = icon("wallet") { moveTo(4f, 7.5f); lineTo(4f, 18.5f); lineTo(20f, 18.5f); lineTo(20f, 7.5f); close(); moveTo(4f, 7.5f); lineTo(16f, 4.5f); lineTo(16.8f, 7.5f); moveTo(15f, 11f); lineTo(20f, 11f); lineTo(20f, 15f); lineTo(15f, 15f); close() }
    val Chart = icon("chart") { moveTo(3.5f, 17f); lineTo(8.5f, 11.5f); lineTo(12.5f, 14.5f); lineTo(20.5f, 6f); moveTo(15.5f, 6f); lineTo(20.5f, 6f); lineTo(20.5f, 11f); moveTo(3.5f, 20.5f); lineTo(20.5f, 20.5f) }
    val Router = icon("router") { moveTo(3.5f, 13.5f); lineTo(20.5f, 13.5f); lineTo(20.5f, 19f); lineTo(3.5f, 19f); close(); moveTo(7f, 16.3f); lineTo(7.1f, 16.3f); moveTo(10.5f, 16.3f); lineTo(10.6f, 16.3f); moveTo(16f, 13.5f); lineTo(17.5f, 6f); moveTo(9.5f, 8.5f); arcTo(4f, 4f, 0f, false, true, 14.5f, 8.5f); moveTo(7.2f, 6f); arcTo(7.2f, 7.2f, 0f, false, true, 16.8f, 6f) }
    val Bolt = icon("bolt") { moveTo(13f, 3f); lineTo(5.5f, 13.5f); lineTo(11.5f, 13.5f); lineTo(10.5f, 21f); lineTo(18.5f, 10f); lineTo(12.5f, 10f); close() }
    val Phone = icon("phone") { moveTo(7.5f, 3f); lineTo(16.5f, 3f); lineTo(16.5f, 21f); lineTo(7.5f, 21f); close(); moveTo(11f, 18f); lineTo(13f, 18f) }
    val Laptop = icon("laptop") { moveTo(5f, 6f); lineTo(19f, 6f); lineTo(19f, 15.5f); lineTo(5f, 15.5f); close(); moveTo(2.5f, 18.5f); lineTo(21.5f, 18.5f) }
    val Tv = icon("tv") { moveTo(3f, 5.5f); lineTo(21f, 5.5f); lineTo(21f, 17f); lineTo(3f, 17f); close(); moveTo(8f, 20.5f); lineTo(16f, 20.5f) }
    val Printer = icon("printer") { moveTo(7f, 9f); lineTo(7f, 4f); lineTo(17f, 4f); lineTo(17f, 9f); moveTo(4f, 9f); lineTo(20f, 9f); lineTo(20f, 16f); lineTo(4f, 16f); close(); moveTo(7f, 13.5f); lineTo(17f, 13.5f); lineTo(17f, 20f); lineTo(7f, 20f); close() }
    val Gamepad = icon("gamepad") { moveTo(7f, 8f); lineTo(17f, 8f); arcTo(4.5f, 4.5f, 0f, false, true, 17f, 17f); lineTo(7f, 17f); arcTo(4.5f, 4.5f, 0f, false, true, 7f, 8f); close(); moveTo(7f, 11f); lineTo(7f, 14f); moveTo(5.5f, 12.5f); lineTo(8.5f, 12.5f); circle(16.5f, 11.5f, 0.6f); circle(15f, 14f, 0.6f) }
    val Speaker = icon("speaker") { moveTo(6.5f, 3.5f); lineTo(17.5f, 3.5f); lineTo(17.5f, 20.5f); lineTo(6.5f, 20.5f); close(); circle(12f, 14f, 3f); circle(12f, 7.5f, 1f) }
    val Grid = icon("grid") { moveTo(4f, 4f); lineTo(10f, 4f); lineTo(10f, 10f); lineTo(4f, 10f); close(); moveTo(14f, 4f); lineTo(20f, 4f); lineTo(20f, 10f); lineTo(14f, 10f); close(); moveTo(4f, 14f); lineTo(10f, 14f); lineTo(10f, 20f); lineTo(4f, 20f); close(); moveTo(14f, 14f); lineTo(20f, 14f); lineTo(20f, 20f); lineTo(14f, 20f); close() }
    val Copy = icon("copy") { moveTo(8f, 8f); lineTo(19f, 8f); lineTo(19f, 19f); lineTo(8f, 19f); close(); moveTo(16f, 8f); lineTo(16f, 5f); lineTo(5f, 5f); lineTo(5f, 16f); lineTo(8f, 16f) }
    val ArrowUp = icon("arrow_up") { moveTo(12f, 19f); lineTo(12f, 5f); moveTo(6.5f, 10.5f); lineTo(12f, 5f); lineTo(17.5f, 10.5f) }
    val ArrowDown = icon("arrow_down") { moveTo(12f, 5f); lineTo(12f, 19f); moveTo(6.5f, 13.5f); lineTo(12f, 19f); lineTo(17.5f, 13.5f) }
    val Swap = icon("swap") { moveTo(4f, 8f); lineTo(19f, 8f); moveTo(15f, 4f); lineTo(19f, 8f); lineTo(15f, 12f); moveTo(20f, 16f); lineTo(5f, 16f); moveTo(9f, 12f); lineTo(5f, 16f); lineTo(9f, 20f) }
    val Radar = icon("radar") { circle(12f, 12f, 8.5f); circle(12f, 12f, 4.5f); moveTo(12f, 12f); lineTo(18f, 6f) }
    val At = icon("at") { circle(12f, 12f, 3.5f); moveTo(15.5f, 12f); lineTo(15.5f, 13.5f); arcTo(2.5f, 2.5f, 0f, false, false, 20.5f, 13.5f); lineTo(20.5f, 12f); arcTo(8.5f, 8.5f, 0f, true, false, 17f, 18.8f) }

    val habitGlyphs: Map<String, ImageVector> by lazy {
        linkedMapOf(
            "drop" to Drop, "book" to Book, "walk" to Walk, "beads" to Beads, "crescent" to Crescent,
            "pen" to Pen, "dumbbell" to Dumbbell, "leaf" to Leaf, "heart" to Heart, "star" to Star,
            "sun" to Sun, "moon" to Moon, "coffee" to Coffee, "bed" to Bed, "target" to Target, "spark" to Spark,
        )
    }

    fun habit(glyph: String): ImageVector = habitGlyphs[glyph] ?: Target
}
