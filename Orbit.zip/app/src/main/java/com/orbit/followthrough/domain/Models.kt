package com.orbit.followthrough.domain

/** How a reminder repeats. */
enum class RepeatType { ONCE, DAILY, WEEKLY, MONTHLY, INTERVAL }

/**
 * Lifecycle of a reminder.
 * SCHEDULED: waiting for its next occurrence.
 * PENDING:   an occurrence fired and the user has not completed/skipped it yet
 *            (dismissing the notification keeps it PENDING – it is never "done" by accident).
 * DONE:      a one-time reminder that was completed / skipped, or a series that ended.
 * PAUSED:    the user paused it; no alarms are scheduled.
 */
enum class ReminderStatus { SCHEDULED, PENDING, DONE, PAUSED }

/** Visual identity + default notification behaviour of a reminder. */
enum class ReminderCategory { GENERAL, WORK, HEALTH, STUDY, SPIRITUAL, PERSONAL }

/** Everything that happens to a reminder is logged; insights are derived from this. */
enum class EventType { CREATED, FIRED, FOLLOW_UP, DISMISSED, SNOOZED, COMPLETED, SKIPPED, MISSED }

enum class HabitKind { STANDARD, TASBIH }

enum class SourceType { RSS, GITHUB, ACCOUNT }

enum class NotifyMode { ALL, IMPORTANT, NONE }

enum class SyncStatus { NEVER, SYNCING, OK, ERROR }

enum class ThemeMode { SYSTEM, DARK, LIGHT }

/** Global notification profile. */
enum class NotificationProfile { SILENT, NORMAL, HIGH }

enum class AiTone { GENTLE, FRIENDLY, DIRECT }

/** Weekday bitmask helpers – bit 0 = Monday … bit 6 = Sunday (ISO order). */
object Weekdays {
    const val MON = 1
    const val TUE = 1 shl 1
    const val WED = 1 shl 2
    const val THU = 1 shl 3
    const val FRI = 1 shl 4
    const val SAT = 1 shl 5
    const val SUN = 1 shl 6
    const val ALL = 0b1111111
    const val WORKWEEK_MON_FRI = MON or TUE or WED or THU or FRI
    const val WORKWEEK_SUN_THU = SUN or MON or TUE or WED or THU
    const val WEEKEND_SAT_SUN = SAT or SUN
    const val WEEKEND_FRI_SAT = FRI or SAT

    fun bit(dayOfWeek: java.time.DayOfWeek): Int = 1 shl (dayOfWeek.value - 1)
    fun has(mask: Int, dayOfWeek: java.time.DayOfWeek): Boolean = mask and bit(dayOfWeek) != 0
}
