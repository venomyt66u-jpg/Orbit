package com.orbit.followthrough.engine

import com.orbit.followthrough.data.db.HabitDao
import com.orbit.followthrough.data.db.HabitEntity
import com.orbit.followthrough.data.db.HabitLogEntity
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.domain.Schedule
import com.orbit.followthrough.domain.Recurrence
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.notify.Notifier
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Habit logging + optional, independent daily habit reminders. */
class HabitEngine(
    private val dao: HabitDao,
    private val scheduler: AlarmScheduler,
    private val notifier: Notifier,
    private val settings: SettingsRepository,
    private val clock: () -> Long = System::currentTimeMillis,
    private val zone: () -> ZoneId = ZoneId::systemDefault,
) {
    private val mutex = Mutex()

    fun today(): Long = LocalDate.now(zone()).toEpochDay()

    suspend fun add(habitId: Long, delta: Int = 1): Int = mutex.withLock {
        val day = today()
        val current = dao.log(habitId, day)?.count ?: 0
        val next = (current + delta).coerceIn(0, 100_000)
        dao.upsertLog(HabitLogEntity(habitId, day, next, clock()))
        if (delta > 0) {
            val h = dao.get(habitId)
            if (h != null && next >= h.target) notifier.cancelHabit(habitId)
        }
        next
    }

    suspend fun setToday(habitId: Long, count: Int) = mutex.withLock {
        dao.upsertLog(HabitLogEntity(habitId, today(), count.coerceAtLeast(0), clock()))
    }

    suspend fun markDone(habitId: Long) = mutex.withLock {
        val h = dao.get(habitId) ?: return@withLock
        val current = dao.log(habitId, today())?.count ?: 0
        if (current < h.target) dao.upsertLog(HabitLogEntity(habitId, today(), h.target, clock()))
        notifier.cancelHabit(habitId)
    }

    suspend fun save(h: HabitEntity): Long {
        val id = if (h.id == 0L) dao.insert(h) else { dao.update(h); h.id }
        sync(h.copy(id = id))
        return id
    }

    suspend fun delete(habitId: Long) {
        scheduler.cancelHabit(habitId)
        notifier.cancelHabit(habitId)
        dao.deleteLogs(habitId)
        dao.deleteHabitRow(habitId)
    }

    suspend fun onAlarm(habitId: Long) {
        val h = dao.get(habitId) ?: return scheduler.cancelHabit(habitId)
        if (!h.reminderEnabled || h.archived) return scheduler.cancelHabit(habitId)
        val count = dao.log(habitId, today())?.count ?: 0
        if (count < h.target) notifier.showHabit(h, count, settings.current())
        sync(h)
    }

    fun sync(h: HabitEntity) {
        if (!h.reminderEnabled || h.archived) { scheduler.cancelHabit(h.id); return }
        val schedule = Schedule(RepeatType.DAILY, h.reminderHour, h.reminderMinute, LocalDate.now(zone()))
        val next = Recurrence.next(schedule, Instant.ofEpochMilli(clock()), zone()) ?: return
        scheduler.setHabit(h.id, next.toEpochMilli())
    }

    suspend fun rescheduleAll() {
        dao.habits().forEach { sync(it) }
    }
}
