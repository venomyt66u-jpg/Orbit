package com.orbit.followthrough.meter

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.os.Build
import android.os.IBinder
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.orbit.followthrough.MainActivity
import com.orbit.followthrough.R
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Ssid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

object Notifications {
    const val CHANNEL_METER = "meter_v2"
    const val CHANNEL_ALERTS = "alerts_v1"
    const val METER_ID = 4_101

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        val keep = setOf(CHANNEL_METER, CHANNEL_ALERTS)
        runCatching { nm.notificationChannels.filter { it.id !in keep }.forEach { nm.deleteNotificationChannel(it.id) } }
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_METER, "عداد الواي فاي", NotificationManager.IMPORTANCE_LOW).apply {
                description = "إشعار هادي وثابت بيوضح استهلاك النهارده وقت العدّ"
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, "تنبيهات الأدمن", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "لما حد يقفل إذن أو يبطّل يبعت أرقام"
            }
        )
    }

    private fun openApp(context: Context, code: Int): PendingIntent = PendingIntent.getActivity(
        context, code, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    fun meter(context: Context, now: WifiNow?): Notification {
        val title = when {
            now == null -> "العداد شغال"
            now.onTarget -> "متصل بـ${Config.TARGET_SSID} · بيعدّ"
            now.maybeTarget -> "على راوتر ${Config.TARGET_SSID} · محتاج إذن الموقع"
            now.onWifi -> "على واي فاي تاني · مش بيعدّ"
            else -> "مش متصل بـ${Config.TARGET_SSID}"
        }
        val text = "النهارده " + Fmt.bytes(Recorder.today(context).total)
        return NotificationCompat.Builder(context, CHANNEL_METER)
            .setSmallIcon(R.drawable.ic_stat_wifi)
            .setColor(0xFF3BE3FF.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openApp(context, 1))
            .build()
    }

    @SuppressLint("MissingPermission")
    fun alert(context: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(context, CHANNEL_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_wifi)
            .setColor(0xFFFFB547.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openApp(context, 2))
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(id, n) }
    }
}

/**
 * Counts all the time. Android reports every Wi‑Fi join and loss to this service the moment it
 * happens, so each switch is measured exactly; a reading is also taken every minute.
 */
class MeterService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var callback: ConnectivityManager.NetworkCallback? = null

    companion object {
        fun start(context: Context) {
            val p = Profile(context)
            if (p.slot == null || !p.setupDone) return
            runCatching { ContextCompat.startForegroundService(context, Intent(context, MeterService::class.java)) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifications.ensureChannels(this)
        try {
            ServiceCompat.startForeground(
                this, Notifications.METER_ID, Notifications.meter(this, null),
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
            )
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        registerCallback()
        if (loop?.isActive != true) {
            loop = scope.launch {
                var lastSync = 0L
                while (isActive) {
                    val now = runCatching { Recorder.sample(this@MeterService) }.getOrNull()
                    update(now)
                    val t = System.currentTimeMillis()
                    if (t - lastSync > 5 * 60_000L) {
                        lastSync = t
                        runCatching { SyncEngine.sync(this@MeterService, onTarget = now?.onTarget == true) }
                    }
                    delay(60_000)
                }
            }
        }
        return START_STICKY
    }

    private fun update(now: WifiNow?) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        runCatching { NotificationManagerCompat.from(this).notify(Notifications.METER_ID, Notifications.meter(this, now)) }
    }

    /** Called on the network thread the moment Wi‑Fi changes: take the reading right now. */
    private fun onSwitch() {
        val now = runCatching { Recorder.sample(this, atSwitch = true) }.getOrNull()
        update(now)
    }

    private fun registerCallback() {
        if (callback != null) return
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val cb = if (Build.VERSION.SDK_INT >= 31) WifiCallbackS { onSwitch() } else WifiCallbackLegacy { onSwitch() }
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
        if (runCatching { cm.registerNetworkCallback(req, cb) }.isSuccess) callback = cb
    }

    override fun onDestroy() {
        callback?.let { cb -> runCatching { getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) } }
        callback = null
        scope.cancel()
        super.onDestroy()
    }
}

@RequiresApi(31)
private class WifiCallbackS(private val changed: () -> Unit) :
    ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
    private var lastName: String? = null

    override fun onAvailable(network: Network) = changed()

    override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
        val name = Ssid.clean((caps.transportInfo as? WifiInfo)?.ssid)
        WifiProbe.callbackName = name
        if (name != lastName) {
            lastName = name
            changed()
        }
    }

    override fun onLost(network: Network) {
        WifiProbe.callbackName = null
        lastName = null
        changed()
    }
}

private class WifiCallbackLegacy(private val changed: () -> Unit) : ConnectivityManager.NetworkCallback() {
    override fun onAvailable(network: Network) = changed()
    override fun onLost(network: Network) = changed()
}
