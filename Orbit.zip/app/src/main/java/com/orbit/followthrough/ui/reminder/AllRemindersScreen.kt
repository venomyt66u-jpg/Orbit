package com.orbit.followthrough.ui.reminder

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.ui.components.EmptyState
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitHero
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AllRemindersViewModel(private val c: AppContainer) : ViewModel() {
    val all: StateFlow<List<ReminderEntity>?> = c.db.reminders().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun complete(id: Long) = viewModelScope.launch { c.reminderEngine.complete(id) }
}

@Composable
fun AllRemindersScreen(nav: NavHostController) {
    val vm = orbitViewModel { AllRemindersViewModel(it) }
    val list by vm.all.collectAsStateWithLifecycle()
    val c = Orbit.colors
    var filter by rememberSaveable { mutableStateOf(0) } // 0 active, 1 paused, 2 done

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        TopBar(stringResource(R.string.all_reminders), { nav.popBackStack() }, stringResource(R.string.back))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
            OrbitChip(stringResource(R.string.filter_active), filter == 0, { filter = 0 })
            OrbitChip(stringResource(R.string.filter_paused), filter == 1, { filter = 1 })
            OrbitChip(stringResource(R.string.filter_done), filter == 2, { filter = 2 })
        }
        val shown = list.orEmpty().filter {
            when (filter) {
                0 -> it.status == ReminderStatus.PENDING || it.status == ReminderStatus.SCHEDULED
                1 -> it.status == ReminderStatus.PAUSED
                else -> it.status == ReminderStatus.DONE
            }
        }
        LazyColumn(Modifier.fillMaxSize().navigationBarsPadding(), contentPadding = PaddingValues(bottom = 32.dp)) {
            if (list != null && shown.isEmpty()) {
                item {
                    EmptyState(stringResource(R.string.nothing_here), stringResource(R.string.nothing_here_body), art = { OrbitHero(0.2f, c.textMuted) })
                }
            }
            val pending = shown.filter { it.status == ReminderStatus.PENDING }
            if (pending.isNotEmpty()) {
                item { SectionHeader(stringResource(R.string.needs_you)) }
                items(pending, key = { it.id }) { r -> ReminderRow(r, { nav.navigate(Routes.editor(r.id)) }, onDone = { vm.complete(r.id) }) }
            }
            val rest = shown.filter { it.status != ReminderStatus.PENDING }
            if (rest.isNotEmpty()) {
                if (pending.isNotEmpty()) item { SectionHeader(stringResource(R.string.scheduled)) }
                items(rest, key = { it.id }) { r -> ReminderRow(r, { nav.navigate(Routes.editor(r.id)) }) }
            }
        }
    }
}
