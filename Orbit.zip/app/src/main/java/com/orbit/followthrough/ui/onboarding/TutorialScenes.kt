package com.orbit.followthrough.ui.onboarding

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.R
import com.orbit.followthrough.ui.components.AiEmblem
import com.orbit.followthrough.ui.components.CompletionCheck
import com.orbit.followthrough.ui.components.OrbitHero
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.ProgressRing
import com.orbit.followthrough.ui.components.SignalIllustration
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType

/** Lightweight motion-graphics scenes (pure Compose, no video assets). Extensible for future video tutorials. */
@Composable
fun TutorialScene(key: String, step: Int, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
        when (key) {
            "reminders" -> PersistenceScene(step)
            "habits" -> HabitsScene(step)
            "ai" -> AiScene(step)
            "signals" -> SignalsScene(step)
            else -> IntroScene()
        }
    }
}

@Composable
private fun IntroScene() {
    val c = Orbit.colors
    Box(contentAlignment = Alignment.Center) {
        OrbitHero(0.72f, c.cyan, size = 240.dp)
        Icon(OrbitIcons.Check, null, tint = c.text, modifier = Modifier.size(54.dp))
    }
}

private fun spec(reduced: Boolean, ms: Int = 650) = tween<Float>(if (reduced) 0 else ms)

@Composable
private fun PersistenceScene(step: Int) {
    val c = Orbit.colors
    val reduced = Orbit.reducedMotion
    val offset by animateFloatAsState(if (step == 1) 1f else 0f, spec(reduced), label = "swipe")
    val clock by animateFloatAsState(if (step >= 1) 1f else 0f, tween(if (reduced) 0 else 2200), label = "clock")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.widthIn(max = 320.dp).fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
            // the "returning" clock behind the card
            ProgressRing(clock, size = 96.dp, stroke = 6.dp, colors = listOf(c.violet, c.cyan), modifier = Modifier.alpha(offset)) {
                Text(stringResource(R.string.minutes_short, 10), style = OrbitType.label, color = c.text)
            }
            NotificationMock(
                followUp = step >= 2,
                modifier = Modifier.graphicsLayer {
                    translationX = offset * size.width * 1.1f
                    alpha = 1f - offset
                    rotationZ = offset * 8f
                },
            )
            CompletionCheck(step >= 2, c.green, Modifier.size(72.dp).align(Alignment.TopEnd))
        }
    }
}

@Composable
private fun NotificationMock(followUp: Boolean, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(c.surfaceHigh)
            .border(1.dp, c.strokeStrong, RoundedCornerShape(22.dp))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(OrbitIcons.Home, null, tint = c.cyan, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Orbit", style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.weight(1f))
            if (followUp) Tag(stringResource(R.string.notif_followup_of, 1, 3), c.violet)
        }
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.demo_task), style = OrbitType.subtitle, color = c.text)
        Text(stringResource(R.string.demo_task_body), style = OrbitType.caption, color = c.textSecondary)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(stringResource(R.string.action_done), style = OrbitType.label, color = if (followUp) c.green else c.cyan)
            Text(stringResource(R.string.action_later), style = OrbitType.label, color = c.cyan)
            Text(stringResource(R.string.action_skip), style = OrbitType.label, color = c.cyan)
        }
    }
}

@Composable
private fun HabitsScene(step: Int) {
    val c = Orbit.colors
    val targets = when (step) {
        0 -> listOf(0.25f, 0.1f, 0f)
        1 -> listOf(0.7f, 0.5f, 0.3f)
        else -> listOf(1f, 1f, 0.85f)
    }
    val colors = listOf(listOf(c.cyan, c.electric), listOf(c.green, c.cyan), listOf(c.gold, c.amber))
    val icons = listOf(OrbitIcons.Drop, OrbitIcons.Book, OrbitIcons.Beads)
    Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
        targets.forEachIndexed { i, p ->
            Box(contentAlignment = Alignment.Center) {
                ProgressRing(p, size = if (i == 1) 120.dp else 88.dp, stroke = if (i == 1) 9.dp else 7.dp, colors = colors[i]) {
                    Icon(icons[i], null, tint = colors[i][0], modifier = Modifier.size(if (i == 1) 34.dp else 26.dp))
                }
                if (i < 2) CompletionCheck(step >= 2, colors[i][0], Modifier.size(if (i == 1) 120.dp else 88.dp))
            }
        }
    }
}

@Composable
private fun AiScene(step: Int) {
    val c = Orbit.colors
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 16.dp)) {
        Box(
            Modifier.align(Alignment.End).clip(RoundedCornerShape(18.dp)).background(c.electric.copy(alpha = 0.22f)).padding(horizontal = 14.dp, vertical = 10.dp)
        ) { Text(stringResource(R.string.demo_command), style = OrbitType.body, color = c.text) }
        Spacer(Modifier.height(10.dp))
        AiEmblem(size = 72.dp, active = step == 1)
        Spacer(Modifier.height(10.dp))
        AnimatedVisibility(step >= 2, enter = fadeIn() + slideInVertically { it / 3 }, exit = fadeOut()) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(c.surfaceHigh).border(1.dp, c.cyan.copy(alpha = 0.5f), RoundedCornerShape(20.dp)).padding(14.dp)
            ) {
                Text(stringResource(R.string.proposal_header).uppercase(), style = OrbitType.overline, color = c.cyan)
                Text(stringResource(R.string.demo_proposal_title), style = OrbitType.subtitle, color = c.text)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Tag(stringResource(R.string.every_day), c.cyan, icon = OrbitIcons.Repeat)
                    Tag("9:00", c.cyan, icon = OrbitIcons.Clock)
                    Tag(stringResource(R.string.confirm_schedule), c.green, icon = OrbitIcons.Check)
                }
            }
        }
    }
}

@Composable
private fun SignalsScene(step: Int) {
    val c = Orbit.colors
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        SignalIllustration(size = 130.dp)
        Spacer(Modifier.height(8.dp))
        listOf(R.string.demo_signal_1, R.string.demo_signal_2).forEachIndexed { i, res ->
            AnimatedVisibility(step >= i + 1, enter = fadeIn() + slideInVertically { it / 2 }) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surfaceHigh)
                        .border(1.dp, if (i == 0) c.amber.copy(alpha = 0.5f) else c.stroke, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(res), style = OrbitType.label, color = c.text)
                        Text(stringResource(R.string.demo_signal_times), style = OrbitType.caption, color = c.textMuted)
                    }
                    if (i == 0) Tag(stringResource(R.string.important_short), c.amber)
                }
            }
        }
    }
}
