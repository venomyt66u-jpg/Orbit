package com.orbit.followthrough.ai

import android.content.Context
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.domain.AiTone
import java.time.LocalDate

/**
 * On-device "smart follow-up" copywriter. Runs instantly, offline, and never sends reminder text
 * anywhere. Wording rotates so the same reminder does not read identically every time, and all
 * templates are written to be encouraging – never guilt-based.
 */
class SmartMessages(private val context: Context) {

    enum class Kind { OCCURRENCE, FOLLOW_UP, LATE }

    fun reminderBody(r: ReminderEntity, kind: Kind, followUpIndex: Int, tone: AiTone, enabled: Boolean): String {
        val res = context.resources
        if (kind == Kind.LATE) {
            return listOf(res.getString(R.string.notif_late_body), r.note).filter { it.isNotBlank() }.joinToString("\n")
        }
        if (!enabled) return r.note.ifBlank { res.getString(R.string.notif_default_body) }

        val arrayRes = when {
            kind == Kind.OCCURRENCE && isWater(r.title) -> R.array.smart_water
            kind == Kind.FOLLOW_UP -> when (tone) {
                AiTone.GENTLE -> R.array.followup_gentle
                AiTone.FRIENDLY -> R.array.followup_friendly
                AiTone.DIRECT -> R.array.followup_direct
            }
            else -> when (tone) {
                AiTone.GENTLE -> R.array.smart_gentle
                AiTone.FRIENDLY -> R.array.smart_friendly
                AiTone.DIRECT -> R.array.smart_direct
            }
        }
        val templates = res.getStringArray(arrayRes)
        if (templates.isEmpty()) return r.note.ifBlank { res.getString(R.string.notif_default_body) }
        val day = LocalDate.now().dayOfYear
        val index = ((r.id + day + followUpIndex * 3L) % templates.size).toInt().coerceIn(0, templates.lastIndex)
        val line = runCatching { String.format(templates[index], r.title.trim()) }.getOrDefault(templates[index])
        return if (r.note.isBlank()) line else "$line\n${r.note}"
    }

    fun habitBody(name: String, remaining: Int, tone: AiTone, enabled: Boolean): String {
        val res = context.resources
        if (!enabled) return res.getString(R.string.habit_notif_plain, name)
        val arr = res.getStringArray(if (tone == AiTone.DIRECT) R.array.habit_direct else R.array.habit_gentle)
        if (arr.isEmpty()) return res.getString(R.string.habit_notif_plain, name)
        val i = (LocalDate.now().dayOfYear % arr.size)
        return runCatching { String.format(arr[i], name, remaining) }.getOrDefault(arr[i])
    }

    companion object {
        private val waterWords = listOf("water", "hydrate", "drink", "ماء", "مياه", "ميه", "مايه", "اشرب")
        fun isWater(title: String): Boolean = waterWords.any { title.contains(it, ignoreCase = true) }
    }
}
