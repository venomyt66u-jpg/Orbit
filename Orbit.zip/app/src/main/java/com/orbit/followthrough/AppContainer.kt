package com.orbit.followthrough

import android.content.Context
import com.orbit.followthrough.ai.AiProvider
import com.orbit.followthrough.ai.LocalAiProvider
import com.orbit.followthrough.ai.RemoteAiProvider
import com.orbit.followthrough.ai.SmartMessages
import com.orbit.followthrough.data.db.HabitEntity
import com.orbit.followthrough.data.db.OrbitDatabase
import com.orbit.followthrough.data.prefs.AppSettings
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.domain.HabitKind
import com.orbit.followthrough.engine.AlarmScheduler
import com.orbit.followthrough.engine.HabitEngine
import com.orbit.followthrough.engine.ReminderEngine
import com.orbit.followthrough.notify.ChannelManager
import com.orbit.followthrough.notify.Notifier
import com.orbit.followthrough.overlay.FloatingReminder
import com.orbit.followthrough.signals.SignalRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Manual dependency container – small, explicit, no reflection, fast cold start. */
class AppContainer(val app: Context) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val db: OrbitDatabase by lazy { OrbitDatabase.build(app) }
    val settings = SettingsRepository(app)
    val channels = ChannelManager(app)
    val smart = SmartMessages(app)
    val notifier by lazy { Notifier(app, channels, db.notificationLog(), smart) }
    val scheduler = AlarmScheduler(app)
    val overlay = FloatingReminder(app)
    val reminderEngine by lazy { ReminderEngine(db.reminders(), db.events(), scheduler, notifier, settings, overlay, appScope) }
    val habitEngine by lazy { HabitEngine(db.habits(), scheduler, notifier, settings) }
    val signals by lazy { SignalRepository(app, db.signals(), settings, notifier) }
    val secrets = com.orbit.followthrough.data.prefs.SecretStore(app)
    val market by lazy { com.orbit.followthrough.market.MarketRepository(db.market(), settings, secrets, notifier) }
    val wallets by lazy { com.orbit.followthrough.wallets.WalletRepository(db.wallets(), secrets, settings, market, notifier) }
    val network by lazy { com.orbit.followthrough.network.NetworkRepository(app, db.network(), settings, secrets, notifier) }
    val ai by lazy { com.orbit.followthrough.ai.AiHub(app, secrets) }

    /** Deep-link highlight target set when a notification is tapped (kind → id). */
    val highlight = kotlinx.coroutines.flow.MutableStateFlow<Pair<String, String>?>(null)

    fun aiProvider(s: AppSettings): AiProvider =
        if (s.aiEnabled && s.aiCloudEnabled && s.aiBackendUrl.startsWith("https://")) RemoteAiProvider(s.aiBackendUrl)
        else LocalAiProvider()

    /** First-run starter habits (names localised at creation time; fully editable/deletable). */
    suspend fun seedIfNeeded() {
        if (settings.isSeeded()) return
        val habits = db.habits()
        if (habits.count() == 0) {
            val r = app.resources
            listOf(
                HabitEntity(name = r.getString(R.string.preset_water), glyph = "drop", colorIndex = 1, target = 8, unit = r.getString(R.string.unit_cups), sortOrder = 0),
                HabitEntity(name = r.getString(R.string.preset_reading), glyph = "book", colorIndex = 0, target = 20, unit = r.getString(R.string.unit_pages), sortOrder = 1),
                HabitEntity(name = r.getString(R.string.preset_walk), glyph = "walk", colorIndex = 2, target = 1, sortOrder = 2),
                HabitEntity(
                    name = r.getString(R.string.preset_tasbih), glyph = "beads", colorIndex = 3, target = 100, kind = HabitKind.TASBIH,
                    phrase = "سُبْحَانَ اللَّهِ", roundSize = 33, spiritual = true, sortOrder = 3,
                ),
            ).forEach { habits.insert(it) }
        }
        settings.markSeeded()
    }

    suspend fun runMaintenance() {
        val now = System.currentTimeMillis()
        val day = 24 * 60 * 60_000L
        db.events().deleteOlderThan(now - 180 * day)
        db.notificationLog().deleteOlderThan(now - 30 * day)
    }

    /** Privacy: wipe every local record and cancel all scheduled work. */
    suspend fun deleteAllData() {
        db.reminders().active().forEach { scheduler.cancelReminder(it.id); notifier.cancelReminder(it.id) }
        db.habits().habits().forEach { scheduler.cancelHabit(it.id) }
        db.reminders().deleteAll()
        db.events().deleteAll()
        db.habits().deleteAllLogs()
        db.habits().deleteAllHabits()
        db.signals().deleteAllItems()
        db.signals().deleteAllSources()
        db.notificationLog().deleteAll()
        db.dhikr().deleteAll()
        db.network().deleteUsage()
        db.network().deleteDevices()
        signals.schedulePeriodic()
        db.market().coins().forEach { db.market().delete(it.id) }
        db.wallets().enabled().forEach { wallets.delete(it.id) }
        secrets.clearAll()
        settings.clearAll()
        settings.update { onboardingDone = true }
        settings.markSeeded()
    }
}
