package com.orbit.followthrough.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.ui.theme.Orbit
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** A shared clock for ambient motion; frozen when the user prefers reduced motion. */
@Composable
fun ambientPhase(durationMillis: Int = 8000, enabled: Boolean = true): Float {
    if (Orbit.reducedMotion || !enabled) return 0.15f
    val transition = rememberInfiniteTransition(label = "ambient")
    val v by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    return v
}

/** Luminous progress ring with a soft glow and rounded caps. */
@Composable
fun ProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    size: Dp = 56.dp,
    stroke: Dp = 6.dp,
    colors: List<Color> = listOf(Orbit.colors.electric, Orbit.colors.cyan),
    track: Color = Orbit.colors.stroke,
    glow: Boolean = true,
    content: @Composable () -> Unit = {},
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = if (Orbit.reducedMotion) tween(0) else tween(900, easing = FastOutSlowInEasing),
        label = "ring",
    )
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = stroke.toPx()
            val inset = sw / 2 + if (glow) sw * 0.6f else 0f
            val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
            val topLeft = Offset(inset, inset)
            drawArc(track, 0f, 360f, false, topLeft, arcSize, style = Stroke(sw))
            if (animated > 0f) {
                val brush = Brush.sweepGradient(colors + colors.first(), center = center)
                rotate(-90f) {
                    if (glow) drawArc(brush, 0f, 360f * animated, false, topLeft, arcSize, alpha = 0.22f, style = Stroke(sw * 2.2f, cap = StrokeCap.Round))
                    drawArc(brush, 0f, 360f * animated, false, topLeft, arcSize, style = Stroke(sw, cap = StrokeCap.Round))
                }
            }
        }
        content()
    }
}

/**
 * Home hero: an orbit around the next action. The satellite's position shows how much of the
 * waiting time has elapsed (progress), the ring breathes gently.
 */
@Composable
fun OrbitHero(progress: Float, accent: Color, modifier: Modifier = Modifier, size: Dp = 132.dp, urgent: Boolean = false) {
    val c = Orbit.colors
    val phase = ambientPhase(if (urgent) 2400 else 9000)
    val animatedProgress by animateFloatAsState(progress.coerceIn(0f, 1f), tween(1200, easing = FastOutSlowInEasing), label = "hero")
    Canvas(modifier.size(size)) {
        val r = min(this.size.width, this.size.height) / 2f
        val ring = r * 0.78f
        // ambient halo
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.28f), Color.Transparent), center, r), r)
        // dotted outer orbit
        val dots = 48
        for (i in 0 until dots) {
            val a = (i.toFloat() / dots) * 2 * PI.toFloat() + phase * 2 * PI.toFloat() * 0.15f
            val p = Offset(center.x + cos(a) * r * 0.96f, center.y + sin(a) * r * 0.96f)
            drawCircle(c.textMuted.copy(alpha = 0.25f), r * 0.012f + 0.6f, p)
        }
        // track + elapsed arc
        drawCircle(c.stroke, ring, style = Stroke(r * 0.045f))
        rotate(-90f) {
            drawArc(
                Brush.sweepGradient(listOf(accent.copy(alpha = 0.1f), accent, accent.copy(alpha = 0.1f))),
                0f, 360f * animatedProgress, false,
                Offset(center.x - ring, center.y - ring), Size(ring * 2, ring * 2),
                style = Stroke(r * 0.06f, cap = StrokeCap.Round),
            )
        }
        // satellite
        val a = (-90f + 360f * animatedProgress) * (PI.toFloat() / 180f)
        val sat = Offset(center.x + cos(a) * ring, center.y + sin(a) * ring)
        val pulse = 1f + 0.25f * sin(phase * 2 * PI.toFloat() * (if (urgent) 2f else 1f))
        drawCircle(accent.copy(alpha = 0.25f), r * 0.11f * pulse, sat)
        drawCircle(accent, r * 0.055f, sat)
        drawCircle(Color.White.copy(alpha = 0.9f), r * 0.022f, sat)
        // core
        drawCircle(Brush.radialGradient(listOf(c.surfaceHigh, c.surface), center, ring * 0.62f), ring * 0.62f)
        drawCircle(c.strokeStrong, ring * 0.62f, style = Stroke(1.dp.toPx()))
    }
}

/** Abstract AI emblem: three counter-rotating orbital ellipses around a luminous core. */
@Composable
fun AiEmblem(modifier: Modifier = Modifier, size: Dp = 96.dp, active: Boolean = false) {
    val c = Orbit.colors
    val phase = ambientPhase(if (active) 2600 else 12000)
    Canvas(modifier.size(size)) {
        val r = min(this.size.width, this.size.height) / 2f
        drawCircle(Brush.radialGradient(listOf(c.violet.copy(alpha = 0.35f), Color.Transparent), center, r), r)
        val colors = listOf(c.cyan, c.violet, c.electric)
        for (i in 0 until 3) {
            val angle = phase * 360f * (if (i % 2 == 0) 1f else -1f) + i * 60f
            rotate(angle) {
                drawOval(
                    brush = Brush.linearGradient(listOf(colors[i], colors[i].copy(alpha = 0.1f))),
                    topLeft = Offset(center.x - r * 0.82f, center.y - r * 0.32f),
                    size = Size(r * 1.64f, r * 0.64f),
                    style = Stroke(r * 0.035f),
                )
            }
        }
        val pulse = 1f + 0.08f * sin(phase * 2 * PI.toFloat() * 3f)
        drawCircle(Brush.radialGradient(listOf(Color.White, c.cyan, c.electric.copy(alpha = 0f)), center, r * 0.3f * pulse), r * 0.3f * pulse)
    }
}

/** Sound-wave visual used in the sound library; animates while a preview plays. */
@Composable
fun SoundWave(playing: Boolean, color: Color, modifier: Modifier = Modifier, bars: Int = 18) {
    val phase = ambientPhase(1200, enabled = playing)
    Canvas(modifier) {
        val gap = this.size.width / (bars * 2f)
        for (i in 0 until bars) {
            val base = 0.25f + 0.55f * ((sin(i * 1.7f) + 1f) / 2f)
            val h = if (playing) base * (0.55f + 0.45f * sin((phase * 2 * PI.toFloat() * 2f) + i * 0.6f)) else base * 0.45f
            val x = gap + i * gap * 2
            val barH = this.size.height * h.coerceIn(0.08f, 1f)
            drawLine(color.copy(alpha = if (playing) 1f else 0.5f), Offset(x, (this.size.height - barH) / 2), Offset(x, (this.size.height + barH) / 2), strokeWidth = gap * 0.9f, cap = StrokeCap.Round)
        }
    }
}

/** Signal Feed illustration: sources (dots) emitting waves that converge into one stream. */
@Composable
fun SignalIllustration(modifier: Modifier = Modifier, size: Dp = 120.dp) {
    val c = Orbit.colors
    val phase = ambientPhase(3600)
    Canvas(modifier.size(size)) {
        val w = this.size.width; val h = this.size.height
        val origin = Offset(w * 0.5f, h * 0.88f)
        for (k in 0 until 3) {
            val t = (phase + k / 3f) % 1f
            val radius = w * 0.15f + t * w * 0.55f
            drawArc(c.cyan.copy(alpha = (1f - t) * 0.6f), 205f, 130f, false, Offset(origin.x - radius, origin.y - radius), Size(radius * 2, radius * 2), style = Stroke(w * 0.022f, cap = StrokeCap.Round))
        }
        val sources = listOf(Offset(w * 0.18f, h * 0.22f) to c.violet, Offset(w * 0.5f, h * 0.1f) to c.electric, Offset(w * 0.82f, h * 0.24f) to c.amber)
        sources.forEachIndexed { i, (p, col) ->
            val path = Path().apply { moveTo(p.x, p.y); quadraticBezierTo(p.x, origin.y - h * 0.25f, origin.x, origin.y) }
            drawPath(path, col.copy(alpha = 0.35f), style = Stroke(w * 0.012f))
            val pm = PathMeasure().apply { setPath(path, false) }
            val pos = pm.getPosition(((phase * 1.4f + i * 0.33f) % 1f) * pm.length)
            drawCircle(col, w * 0.022f, pos)
            drawCircle(col.copy(alpha = 0.25f), w * 0.07f, p)
            drawCircle(col, w * 0.035f, p)
        }
        drawCircle(c.cyan, w * 0.045f, origin)
    }
}

/** Animated check that draws itself – used for completions. */
@Composable
fun CompletionCheck(visible: Boolean, color: Color, modifier: Modifier = Modifier) {
    val progress = remember { Animatable(0f) }
    val reduced = Orbit.reducedMotion
    LaunchedEffect(visible) {
        if (visible) {
            if (reduced) progress.snapTo(1f) else { progress.snapTo(0f); progress.animateTo(1f, tween(520, easing = FastOutSlowInEasing)) }
        } else progress.snapTo(0f)
    }
    Canvas(modifier) {
        val p = progress.value
        if (p <= 0f) return@Canvas
        val w = this.size.width
        drawCircle(color.copy(alpha = 0.18f * p), w / 2 * (0.6f + 0.4f * p))
        val path = Path().apply { moveTo(w * 0.28f, w * 0.52f); lineTo(w * 0.44f, w * 0.68f); lineTo(w * 0.74f, w * 0.36f) }
        val pm = PathMeasure().apply { setPath(path, false) }
        val seg = Path()
        pm.getSegment(0f, pm.length * p, seg, true)
        drawPath(seg, color, style = Stroke(w * 0.08f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
    }
}

/** Tasbih bead ring: [total] beads, the first [lit] glowing; the next bead pulses. */
fun DrawScope.beadRing(total: Int, lit: Int, accent: Color, dim: Color, pulse: Float) {
    val r = min(size.width, size.height) / 2f * 0.9f
    val n = total.coerceIn(1, 100)
    val beadR = (2 * PI.toFloat() * r / n) * 0.28f
    for (i in 0 until n) {
        val a = (-90f + 360f * i / n) * (PI.toFloat() / 180f)
        val p = Offset(center.x + cos(a) * r, center.y + sin(a) * r)
        when {
            i < lit -> {
                drawCircle(accent.copy(alpha = 0.25f), beadR * 1.9f, p)
                drawCircle(accent, beadR, p)
            }
            i == lit -> drawCircle(accent.copy(alpha = 0.35f + 0.35f * pulse), beadR * (1f + 0.25f * pulse), p)
            else -> drawCircle(dim, beadR * 0.8f, p)
        }
    }
}

/** Ambient app background: deep gradient with a faint aurora. */
fun DrawScope.auroraBackground(void: Color, abyss: Color, violet: Color, cyan: Color, dark: Boolean) {
    drawRect(Brush.verticalGradient(listOf(abyss, void)))
    val a = if (dark) 0.22f else 0.10f
    drawCircle(Brush.radialGradient(listOf(violet.copy(alpha = a), Color.Transparent), Offset(size.width * 0.15f, size.height * 0.02f), size.width * 0.9f), size.width * 0.9f, Offset(size.width * 0.15f, size.height * 0.02f))
    drawCircle(Brush.radialGradient(listOf(cyan.copy(alpha = a * 0.6f), Color.Transparent), Offset(size.width * 1.05f, size.height * 0.35f), size.width * 0.7f), size.width * 0.7f, Offset(size.width * 1.05f, size.height * 0.35f))
}
