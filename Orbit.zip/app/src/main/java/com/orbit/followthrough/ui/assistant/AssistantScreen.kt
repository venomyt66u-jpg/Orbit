package com.orbit.followthrough.ui.assistant

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.ai.Insight
import com.orbit.followthrough.ai.ReminderDraft
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.ui.components.AiEmblem
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TimePickerDialog
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.reminder.categoryIcon
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import java.time.LocalDate

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssistantScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val vm = orbitViewModel { AssistantViewModel(it, ctx.applicationContext) }
    val messages by vm.messages.collectAsStateWithLifecycle()
    val thinking by vm.thinking.collectAsStateWithLifecycle()
    val insights by vm.insights.collectAsStateWithLifecycle()
    val settings = LocalSettings.current
    val container = com.orbit.followthrough.ui.nav.LocalAppContainer.current
    val aiLabel = if (container.ai.ready(settings)) container.ai.config(settings).provider.label else null
    val c = Orbit.colors
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    var timeFor by androidx.compose.runtime.remember { mutableStateOf<ChatMsg.Clarify?>(null) }

    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(listState.layoutInfo.totalItemsCount.coerceAtLeast(1) - 1) }

    val imeVisible = WindowInsets.isImeVisible
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
            item { AssistantHeader(thinking, aiLabel = aiLabel, onClear = { vm.clearChat() }, canClear = messages.isNotEmpty(), onBack = { nav.popBackStack() }) }

            if (!settings.aiEnabled) {
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.ai_off_title), style = OrbitType.title, color = c.text)
                        Text(stringResource(R.string.ai_off_body), style = OrbitType.body, color = c.textSecondary)
                        Spacer(Modifier.height(12.dp))
                        SecondaryButton(stringResource(R.string.open_settings), { nav.navigate(Routes.SETTINGS) }, icon = OrbitIcons.Settings)
                    }
                }
            }

            if (insights.isNotEmpty()) {
                item { SectionHeader(stringResource(R.string.smart_suggestions)) }
                items(insights, key = { it.key }) { i -> InsightCard(i, onAccept = { vm.acceptInsight(i) }, onDismiss = { vm.dismissInsight(i) }) }
            }

            item {
                androidx.compose.foundation.layout.Row(
                    Modifier.fillMaxWidth().androidxHScroll().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OrbitChip(stringResource(R.string.quick_market), false, { vm.quickAi("market") }, icon = OrbitIcons.Chart, accent = c.violet)
                    OrbitChip(stringResource(R.string.quick_wallets), false, { vm.quickAi("wallets") }, icon = OrbitIcons.Wallet, accent = c.violet)
                    OrbitChip(stringResource(R.string.quick_feed), false, { vm.quickAi("feed") }, icon = OrbitIcons.Signal, accent = c.violet)
                    if (aiLabel == null) OrbitChip(stringResource(R.string.connect_ai), true, { nav.navigate(Routes.KEYS) }, icon = OrbitIcons.Key, accent = c.amber)
                }
            }

            if (messages.isEmpty()) {
                item {
                    Column {
                        SectionHeader(stringResource(R.string.try_saying), Modifier.padding(top = 12.dp))
                        val examples = stringArrayResource(R.array.ai_examples)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            examples.forEach { ex -> OrbitChip(ex, false, { vm.send(ex) }, icon = OrbitIcons.Spark) }
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(stringResource(R.string.ai_privacy_note), style = OrbitType.caption, color = c.textMuted)
                    }
                }
            }

            items(messages, key = { it.id }) { m ->
                when (m) {
                    is ChatMsg.User -> Bubble(m.text, mine = true)
                    is ChatMsg.Bot -> Bubble(m.text, mine = false)
                    is ChatMsg.Ai -> AiBubble(m)
                    is ChatMsg.Proposal -> ProposalCard(m, onConfirm = { vm.confirm(m) }, onCancel = { vm.cancel(m.id) })
                    is ChatMsg.Clarify -> ClarifyCard(m, onPick = { h, mm -> vm.answerClarify(m, h, mm) }, onCustom = { timeFor = m })
                    is ChatMsg.QuietProposal -> ActionCard(
                        title = stringResource(R.string.quiet_proposal, Fmt.minutesOfDay(ctx, m.startMinute), Fmt.minutesOfDay(ctx, m.endMinute)),
                        body = stringResource(R.string.quiet_proposal_body),
                        state = m.state, onConfirm = { vm.confirmQuiet(m) }, onCancel = { vm.cancel(m.id) },
                    )
                    is ChatMsg.FollowUpProposal -> ActionCard(
                        title = stringResource(R.string.followup_proposal, m.title, m.minutes),
                        body = stringResource(R.string.followup_proposal_body),
                        state = m.state, onConfirm = { vm.confirmFollowUp(m) }, onCancel = { vm.cancel(m.id) },
                    )
                    is ChatMsg.ReminderList -> GlassCard(Modifier.fillMaxWidth().padding(vertical = 6.dp), padding = PaddingValues(14.dp)) {
                        Text(stringResource(m.headerRes), style = OrbitType.label, color = c.textSecondary)
                        m.items.forEach { r ->
                            Row(Modifier.fillMaxWidth().pressable({ nav.navigate(Routes.editor(r.id)) }).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(categoryIcon(r.category), null, tint = c.category(r.category), modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(10.dp))
                                Text(r.title, style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(Fmt.schedule(ctx, r).substringAfterLast(" · "), style = OrbitType.caption, color = c.textMuted)
                            }
                        }
                    }
                    is ChatMsg.SignalDigest -> GlassCard(Modifier.fillMaxWidth().padding(vertical = 6.dp), padding = PaddingValues(14.dp), highlight = c.violet) {
                        Text(stringResource(R.string.ai_digest_header), style = OrbitType.label, color = c.violet)
                        m.items.forEach { s ->
                            Column(Modifier.padding(top = 10.dp)) {
                                Text(s.title, style = OrbitType.subtitle, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (s.summary.isNotBlank()) Text(s.summary, style = OrbitType.caption, color = c.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(s.sourceName + " · " + Fmt.ago(s.discoveredAt), style = OrbitType.caption, color = c.textMuted)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        SecondaryButton(stringResource(R.string.open_feed), { nav.navigate(Routes.SIGNALS) }, icon = OrbitIcons.Signal)
                    }
                }
            }
            if (thinking) item { Bubble(stringResource(R.string.thinking), mine = false, faded = true) }
        }

        // Input bar (floats above the bottom navigation; hugs the keyboard when it is open)
        Row(
            Modifier
                .fillMaxWidth()
                .imePadding()
                .then(if (imeVisible) Modifier.padding(bottom = 8.dp) else Modifier.navigationBarsPadding().padding(bottom = 12.dp))
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OrbitTextField(
                input, { input = it }, stringResource(R.string.assistant_placeholder),
                modifier = Modifier.weight(1f),
                singleLine = false,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" }),
                leading = OrbitIcons.Assistant,
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(52.dp).clip(CircleShape)
                    .background(if (input.isNotBlank()) c.auroraBrush else androidx.compose.ui.graphics.SolidColor(c.surfaceHigh))
                    .pressable({ if (input.isNotBlank()) { vm.send(input); input = "" } }),
                contentAlignment = Alignment.Center,
            ) { Icon(OrbitIcons.Send, stringResource(R.string.send), tint = if (input.isNotBlank()) c.onAccent else c.textMuted, modifier = Modifier.size(22.dp)) }
        }
    }

    timeFor?.let { m ->
        TimePickerDialog(m.draft.hour?.coerceIn(0, 23) ?: 9, m.draft.minute, { h, mm -> vm.answerClarify(m, h, mm); timeFor = null }, { timeFor = null })
    }
}

@Composable
private fun AssistantHeader(thinking: Boolean, aiLabel: String?, onClear: () -> Unit, canClear: Boolean, onBack: () -> Unit) {
    val c = Orbit.colors
    val cloud = aiLabel != null
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        IconCircle(OrbitIcons.Back, stringResource(R.string.back), onBack)
        Spacer(Modifier.width(10.dp))
        AiEmblem(size = 64.dp, active = thinking)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.tab_assistant), style = OrbitType.headline, color = c.text)
            Tag(aiLabel ?: stringResource(R.string.ai_mode_local), if (cloud) c.violet else c.green, icon = if (cloud) OrbitIcons.Spark else OrbitIcons.Lock)
        }
        if (canClear) IconCircle(OrbitIcons.Refresh, stringResource(R.string.clear_chat), onClear)
    }
}

@Composable
private fun Modifier.androidxHScroll(): Modifier = this.horizontalScroll(androidx.compose.foundation.rememberScrollState())

@Composable
private fun AiBubble(m: ChatMsg.Ai) {
    val c = Orbit.colors
    Column(
        Modifier.fillMaxWidth().padding(vertical = 4.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(c.violet.copy(alpha = 0.10f))
            .border(1.dp, c.violet.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(OrbitIcons.Spark, null, tint = c.violet, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(m.provider, style = OrbitType.caption, color = c.violet)
        }
        Spacer(Modifier.height(6.dp))
        Text(m.text, style = OrbitType.body, color = c.text)
    }
}

@Composable
private fun Bubble(text: String, mine: Boolean, faded: Boolean = false) {
    val c = Orbit.colors
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (mine) 20.dp else 6.dp, bottomEnd = if (mine) 6.dp else 20.dp))
                .background(if (mine) c.electric.copy(alpha = 0.22f) else c.surfaceHigh)
                .border(1.dp, if (mine) c.electric.copy(alpha = 0.4f) else c.stroke, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (mine) 20.dp else 6.dp, bottomEnd = if (mine) 6.dp else 20.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(text, style = OrbitType.body, color = if (faded) c.textMuted else c.text)
        }
    }
}

@Composable
private fun ProposalCard(m: ChatMsg.Proposal, onConfirm: () -> Unit, onCancel: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val d: ReminderDraft = m.draft
    GlassCard(Modifier.fillMaxWidth().padding(vertical = 6.dp), highlight = c.cyan, padding = PaddingValues(16.dp)) {
        Text(stringResource(R.string.proposal_header).uppercase(), style = OrbitType.overline, color = c.cyan)
        Spacer(Modifier.height(6.dp))
        Text(d.title, style = OrbitType.title, color = c.text)
        Spacer(Modifier.height(8.dp))
        val scheduleText = Fmt.schedule(ctx, d.repeat, d.hour ?: 9, d.minute, d.date, d.weekdays, d.interval, d.date.dayOfMonth)
        ProposalLine(OrbitIcons.Clock, scheduleText)
        if (d.repeat != RepeatType.ONCE) ProposalLine(OrbitIcons.Calendar, stringResource(R.string.starts, Fmt.dayLabel(ctx, maxOf(d.date, LocalDate.now()))))
        d.followUpMinutes?.let { ProposalLine(OrbitIcons.Repeat, stringResource(R.string.followup_every, it)) }
        if (d.important) ProposalLine(OrbitIcons.Flag, stringResource(R.string.important))
        if (d.note.isNotBlank()) ProposalLine(OrbitIcons.Edit, d.note)
        Spacer(Modifier.height(12.dp))
        when (m.state) {
            PState.OPEN -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(stringResource(R.string.confirm_schedule), onConfirm, Modifier.weight(1f), icon = OrbitIcons.Check)
                SecondaryButton(stringResource(R.string.cancel), onCancel)
            }
            PState.CONFIRMED -> Tag(stringResource(R.string.scheduled_ok), c.green, icon = OrbitIcons.Check)
            PState.CANCELLED -> Tag(stringResource(R.string.cancelled), c.textMuted)
        }
    }
}

@Composable
private fun ProposalLine(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    val c = Orbit.colors
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = c.textMuted, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = OrbitType.label, color = c.textSecondary)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ClarifyCard(m: ChatMsg.Clarify, onPick: (Int, Int) -> Unit, onCustom: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    GlassCard(Modifier.fillMaxWidth().padding(vertical = 6.dp), highlight = c.amber, padding = PaddingValues(16.dp)) {
        Text(
            if (m.kind == "meridiem") stringResource(R.string.ai_ask_meridiem, m.draft.title)
            else stringResource(R.string.ai_ask_time, m.draft.title),
            style = OrbitType.subtitle, color = c.text,
        )
        Spacer(Modifier.height(12.dp))
        AnimatedVisibility(!m.answered) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (m.kind == "meridiem") {
                    val h = (m.draft.hour ?: 8).coerceIn(1, 12)
                    val am = if (h == 12) 0 else h
                    val pm = if (h == 12) 12 else h + 12
                    OrbitChip(Fmt.time(ctx, am, m.draft.minute), false, { onPick(am, m.draft.minute) }, icon = OrbitIcons.Sun)
                    OrbitChip(Fmt.time(ctx, pm, m.draft.minute), false, { onPick(pm, m.draft.minute) }, icon = OrbitIcons.Moon)
                } else {
                    listOf(8 to 0, 13 to 0, 18 to 0, 21 to 0).forEach { (h, mm) ->
                        OrbitChip(Fmt.time(ctx, h, mm), false, { onPick(h, mm) }, icon = OrbitIcons.Clock)
                    }
                    OrbitChip(stringResource(R.string.pick_time), false, onCustom, icon = OrbitIcons.Edit)
                }
            }
        }
    }
}

@Composable
private fun ActionCard(title: String, body: String, state: PState, onConfirm: () -> Unit, onCancel: () -> Unit) {
    val c = Orbit.colors
    GlassCard(Modifier.fillMaxWidth().padding(vertical = 6.dp), highlight = c.violet, padding = PaddingValues(16.dp)) {
        Text(title, style = OrbitType.subtitle, color = c.text)
        Text(body, style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(12.dp))
        when (state) {
            PState.OPEN -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(stringResource(R.string.apply), onConfirm, Modifier.weight(1f), icon = OrbitIcons.Check)
                SecondaryButton(stringResource(R.string.cancel), onCancel)
            }
            PState.CONFIRMED -> Tag(stringResource(R.string.applied), c.green, icon = OrbitIcons.Check)
            PState.CANCELLED -> Tag(stringResource(R.string.cancelled), c.textMuted)
        }
    }
}

@Composable
private fun InsightCard(i: Insight, onAccept: () -> Unit, onDismiss: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val text = when (i.kind) {
        Insight.Kind.MOVE_LATER -> stringResource(R.string.insight_move_later, i.title, Fmt.time(ctx, i.suggestedHour, i.suggestedMinute))
        Insight.Kind.MOVE_TO_USUAL -> stringResource(R.string.insight_usual, i.title, Fmt.time(ctx, i.suggestedHour, i.suggestedMinute))
        Insight.Kind.SPLIT -> stringResource(R.string.insight_split, i.title)
    }
    GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), highlight = c.violet, padding = PaddingValues(16.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(OrbitIcons.Spark, null, tint = c.violet, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(text, style = OrbitType.body, color = c.text)
                Text(stringResource(R.string.insight_why, i.postpones), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 4.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PrimaryButton(stringResource(if (i.kind == Insight.Kind.SPLIT) R.string.create_first_step else R.string.move_it), onAccept, Modifier.weight(1f))
            SecondaryButton(stringResource(R.string.not_now), onDismiss)
        }
    }
}
