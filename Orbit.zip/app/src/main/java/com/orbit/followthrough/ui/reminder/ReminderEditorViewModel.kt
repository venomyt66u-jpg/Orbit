package com.orbit.followthrough.ui.reminder

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.domain.Recurrence
import com.orbit.followthrough.domain.ReminderCategory
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.domain.Schedule
import com.orbit.followthrough.domain.Weekdays
import com.orbit.followthrough.engine.SaveResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

data class EditorForm(
    val id: Long = 0,
    val loaded: Boolean = false,
    val title: String = "",
    val note: String = "",
    val category: ReminderCategory = ReminderCategory.GENERAL,
    val important: Boolean = false,
    val repeat: RepeatType = RepeatType.ONCE,
    val hour: Int = 9,
    val minute: Int = 0,
    val date: LocalDate = LocalDate.now(),
    val weekdays: Int = 0,
    val interval: Int = 2,
    val dayOfMonth: Int = LocalDate.now().dayOfMonth,
    val followUpMinutes: Int = 10,
    val maxFollowUps: Int = 3,
    val deadline: LocalDateTime? = null,
    val status: ReminderStatus? = null,
    val errorRes: Int? = null,
    val saved: Boolean = false,
    val deleted: Boolean = false,
) {
    val isEditing: Boolean get() = id != 0L

    fun schedule(): Schedule = Schedule(
        type = repeat, hour = hour, minute = minute, startDate = date,
        weekdays = if (repeat == RepeatType.WEEKLY && weekdays == 0) Weekdays.bit(date.dayOfWeek) else weekdays,
        interval = interval, dayOfMonth = dayOfMonth,
    )

    /** Live preview of the next occurrence (null = in the past / ended). */
    fun preview(zone: ZoneId = ZoneId.systemDefault()): Long? {
        val next = Recurrence.next(schedule(), Instant.now(), zone)?.toEpochMilli() ?: return null
        val dl = deadline?.atZone(zone)?.toInstant()?.toEpochMilli()
        return if (dl != null && next > dl) null else next
    }
}

class ReminderEditorViewModel(private val c: AppContainer, private val reminderId: Long) : ViewModel() {

    private val _form = MutableStateFlow(EditorForm())
    val form: StateFlow<EditorForm> = _form.asStateFlow()
    private var original: ReminderEntity? = null

    init {
        viewModelScope.launch {
            val s = c.settings.current()
            val existing = if (reminderId > 0) c.db.reminders().get(reminderId) else null
            original = existing
            _form.value = if (existing != null) {
                EditorForm(
                    id = existing.id, loaded = true, title = existing.title, note = existing.note,
                    category = existing.category, important = existing.important, repeat = existing.repeatType,
                    hour = existing.hour, minute = existing.minute,
                    date = LocalDate.ofEpochDay(existing.startEpochDay).let { if (existing.repeatType == RepeatType.ONCE) it else maxOf(it, LocalDate.now()) },
                    weekdays = existing.weekdays, interval = existing.interval.coerceAtLeast(2), dayOfMonth = existing.dayOfMonth,
                    followUpMinutes = existing.followUpMinutes, maxFollowUps = existing.maxFollowUps,
                    deadline = existing.deadlineAt?.let { Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDateTime() },
                    status = existing.status,
                )
            } else {
                val next = LocalDateTime.now().plusHours(1).withMinute(0)
                EditorForm(
                    loaded = true, hour = next.hour, minute = 0, date = next.toLocalDate(),
                    followUpMinutes = s.defaultFollowUpMinutes, maxFollowUps = s.defaultMaxFollowUps,
                    dayOfMonth = next.dayOfMonth,
                )
            }
        }
    }

    fun edit(block: EditorForm.() -> EditorForm) = _form.update { it.block().copy(errorRes = null) }

    fun save() = viewModelScope.launch {
        val f = _form.value
        if (f.title.isBlank()) { _form.update { it.copy(errorRes = R.string.error_title) }; return@launch }
        val zone = ZoneId.systemDefault()
        val base = original ?: ReminderEntity(title = f.title, hour = f.hour, minute = f.minute, startEpochDay = f.date.toEpochDay())
        val entity = base.copy(
            title = f.title, note = f.note, category = f.category, important = f.important,
            repeatType = f.repeat, hour = f.hour, minute = f.minute,
            startEpochDay = f.date.toEpochDay(),
            weekdays = f.schedule().weekdays, interval = f.interval, dayOfMonth = f.dayOfMonth,
            followUpMinutes = f.followUpMinutes, maxFollowUps = f.maxFollowUps.coerceIn(1, 10),
            deadlineAt = f.deadline?.atZone(zone)?.toInstant()?.toEpochMilli(),
        )
        when (c.reminderEngine.save(entity)) {
            is SaveResult.Saved -> _form.update { it.copy(saved = true) }
            SaveResult.InThePast -> _form.update { it.copy(errorRes = if (f.repeat == RepeatType.ONCE) R.string.error_past else R.string.error_deadline) }
            SaveResult.EmptyTitle -> _form.update { it.copy(errorRes = R.string.error_title) }
        }
    }

    fun delete() = viewModelScope.launch {
        if (reminderId > 0) c.reminderEngine.delete(reminderId)
        _form.update { it.copy(deleted = true) }
    }

    fun togglePause() = viewModelScope.launch {
        val f = _form.value
        if (!f.isEditing) return@launch
        if (f.status == ReminderStatus.PAUSED) {
            val ok = c.reminderEngine.resume(f.id)
            _form.update { it.copy(status = if (ok) ReminderStatus.SCHEDULED else it.status, errorRes = if (ok) null else R.string.error_past) }
        } else {
            c.reminderEngine.pause(f.id)
            _form.update { it.copy(status = ReminderStatus.PAUSED) }
        }
    }

    fun completeNow() = viewModelScope.launch {
        c.reminderEngine.complete(reminderId)
        _form.update { it.copy(saved = true) }
    }
}
