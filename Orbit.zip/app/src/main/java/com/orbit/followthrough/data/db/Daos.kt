package com.orbit.followthrough.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Insert
    suspend fun insert(reminder: ReminderEntity): Long

    @Update
    suspend fun update(reminder: ReminderEntity)

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun get(id: Long): ReminderEntity?

    @Query("SELECT * FROM reminders WHERE id = :id")
    fun observe(id: Long): Flow<ReminderEntity?>

    @Query("SELECT * FROM reminders WHERE status IN ('SCHEDULED','PENDING') ORDER BY COALESCE(followUpAt, pendingOccurrenceAt, nextOccurrenceAt) ASC")
    fun observeActive(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders ORDER BY CASE status WHEN 'PENDING' THEN 0 WHEN 'SCHEDULED' THEN 1 WHEN 'PAUSED' THEN 2 ELSE 3 END, COALESCE(nextOccurrenceAt, updatedAt) ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE status IN ('SCHEDULED','PENDING')")
    suspend fun schedulable(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE status IN ('SCHEDULED','PENDING')")
    suspend fun active(): List<ReminderEntity>

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM reminders")
    suspend fun deleteAll()
}

@Dao
interface ReminderEventDao {
    @Insert
    suspend fun insert(event: ReminderEventEntity)

    @Query("SELECT * FROM reminder_events WHERE at >= :since ORDER BY at DESC")
    suspend fun since(since: Long): List<ReminderEventEntity>

    @Query("SELECT * FROM reminder_events WHERE at >= :since ORDER BY at DESC")
    fun observeSince(since: Long): Flow<List<ReminderEventEntity>>

    @Query("SELECT * FROM reminder_events ORDER BY at DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<ReminderEventEntity>>

    @Query("DELETE FROM reminder_events WHERE reminderId = :reminderId")
    suspend fun deleteForReminder(reminderId: Long)

    @Query("DELETE FROM reminder_events WHERE at < :before")
    suspend fun deleteOlderThan(before: Long)

    @Query("DELETE FROM reminder_events")
    suspend fun deleteAll()
}

@Dao
interface HabitDao {
    @Query("SELECT * FROM habits WHERE archived = 0 ORDER BY sortOrder ASC, id ASC")
    fun observeHabits(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits WHERE archived = 0")
    suspend fun habits(): List<HabitEntity>

    @Query("SELECT * FROM habits WHERE id = :id")
    suspend fun get(id: Long): HabitEntity?

    @Query("SELECT * FROM habits WHERE id = :id")
    fun observe(id: Long): Flow<HabitEntity?>

    @Insert
    suspend fun insert(habit: HabitEntity): Long

    @Update
    suspend fun update(habit: HabitEntity)

    @Query("SELECT COUNT(*) FROM habits")
    suspend fun count(): Int

    @Query("SELECT * FROM habit_logs WHERE epochDay BETWEEN :fromDay AND :toDay")
    fun observeLogs(fromDay: Long, toDay: Long): Flow<List<HabitLogEntity>>

    @Query("SELECT * FROM habit_logs WHERE habitId = :habitId AND epochDay = :day")
    suspend fun log(habitId: Long, day: Long): HabitLogEntity?

    @Query("SELECT * FROM habit_logs WHERE habitId = :habitId AND epochDay = :day")
    fun observeLog(habitId: Long, day: Long): Flow<HabitLogEntity?>

    @Upsert
    suspend fun upsertLog(log: HabitLogEntity)

    @Query("DELETE FROM habit_logs WHERE habitId = :habitId")
    suspend fun deleteLogs(habitId: Long)

    @Query("DELETE FROM habits WHERE id = :habitId")
    suspend fun deleteHabitRow(habitId: Long)

    @Query("DELETE FROM habit_logs")
    suspend fun deleteAllLogs()

    @Query("DELETE FROM habits")
    suspend fun deleteAllHabits()
}

@Dao
interface SignalDao {
    @Query("SELECT * FROM signal_sources ORDER BY createdAt ASC")
    fun observeSources(): Flow<List<SignalSourceEntity>>

    @Query("SELECT * FROM signal_sources WHERE enabled = 1")
    suspend fun enabledSources(): List<SignalSourceEntity>

    @Query("SELECT COUNT(*) FROM signal_sources WHERE enabled = 1")
    suspend fun enabledCount(): Int

    @Query("SELECT * FROM signal_sources WHERE id = :id")
    suspend fun source(id: Long): SignalSourceEntity?

    @Insert
    suspend fun insertSource(source: SignalSourceEntity): Long

    @Update
    suspend fun updateSource(source: SignalSourceEntity)

    @Query("DELETE FROM signal_items WHERE sourceId = :sourceId")
    suspend fun deleteItemsOf(sourceId: Long)

    @Query("DELETE FROM signal_sources WHERE id = :sourceId")
    suspend fun deleteSourceRow(sourceId: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertItems(items: List<SignalItemEntity>): List<Long>

    @Query("SELECT COUNT(*) FROM signal_items WHERE titleKey = :titleKey AND sourceId != :sourceId AND discoveredAt >= :since")
    suspend fun similarElsewhere(titleKey: String, sourceId: Long, since: Long): Int

    @Query("SELECT COUNT(*) FROM signal_items WHERE sourceId = :sourceId")
    suspend fun countFor(sourceId: Long): Int

    @Query(
        """
        SELECT * FROM signal_items
        WHERE (:query = '' OR title LIKE '%' || :query || '%' OR summary LIKE '%' || :query || '%' OR sourceName LIKE '%' || :query || '%')
          AND importance >= :minImportance
          AND (:category = '' OR category = :category)
        ORDER BY discoveredAt DESC, COALESCE(publishedAt, 0) DESC
        LIMIT :limit
        """
    )
    fun observeItems(query: String, minImportance: Int, category: String, limit: Int): Flow<List<SignalItemEntity>>

    @Query("SELECT * FROM signal_items WHERE discoveredAt >= :since ORDER BY importance DESC, discoveredAt DESC LIMIT :limit")
    suspend fun recent(since: Long, limit: Int): List<SignalItemEntity>

    @Query("SELECT COUNT(*) FROM signal_items WHERE read = 0")
    fun observeUnread(): Flow<Int>

    @Query("UPDATE signal_items SET read = 1 WHERE id = :id")
    suspend fun markRead(id: Long)

    @Query("UPDATE signal_items SET read = 1")
    suspend fun markAllRead()

    @Query("DELETE FROM signal_items WHERE discoveredAt < :before")
    suspend fun deleteItemsOlderThan(before: Long)

    @Query("DELETE FROM signal_items")
    suspend fun deleteAllItems()

    @Query("DELETE FROM signal_sources")
    suspend fun deleteAllSources()
}

@Dao
interface NotificationLogDao {
    @Insert
    suspend fun insert(entry: NotificationLogEntity)

    @Query("SELECT * FROM notification_log ORDER BY at DESC LIMIT :limit")
    fun observe(limit: Int): Flow<List<NotificationLogEntity>>

    @Query("SELECT COUNT(*) FROM notification_log")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM notification_log WHERE at < :before")
    suspend fun deleteOlderThan(before: Long)

    @Query("DELETE FROM notification_log")
    suspend fun deleteAll()
}
