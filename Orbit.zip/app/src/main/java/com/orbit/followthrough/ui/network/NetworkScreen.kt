package com.orbit.followthrough.ui.network

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.NetDeviceEntity
import com.orbit.followthrough.data.db.NetUsageEntity
import com.orbit.followthrough.data.prefs.SecretStore
import com.orbit.followthrough.domain.Numbers
import com.orbit.followthrough.network.DeviceKind
import com.orbit.followthrough.network.GreenpacketD2Adapter
import com.orbit.followthrough.network.ScanState
import com.orbit.followthrough.ui.components.BarChart
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitSwitch
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.RadarSweep
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.SettingRow
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import com.orbit.followthrough.watch.WatchRunner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class NetworkViewModel(val c: AppContainer) : ViewModel() {
    val devices: StateFlow<List<NetDeviceEntity>?> = c.db.network().observeDevices().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val usage: StateFlow<List<NetUsageEntity>> = c.db.network().observeUsageSince(LocalDate.now().toEpochDay() - 60)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val scan: StateFlow<ScanState> = c.network.scan
    val routerStatus = MutableStateFlow<String?>(null)

    init { scanNow() }

    fun scanNow() = viewModelScope.launch { if (!c.network.scan.value.running) c.network.scanLan(notifyNew = false) }
    fun rename(key: String, alias: String?) = viewModelScope.launch { c.network.rename(key, alias) }
    fun forget(key: String) = viewModelScope.launch { c.network.forget(key) }
    fun setWatch(on: Boolean) = viewModelScope.launch { c.settings.update { watchNewDevices = on }; WatchRunner.reschedule(c) }

    fun saveRouter(type: String, host: String, user: String, password: String?) = viewModelScope.launch {
        c.settings.update { routerType = type; routerHost = host.trim(); routerUser = user.trim() }
        if (!password.isNullOrEmpty()) c.secrets.put(SecretStore.Key.ROUTER_PASSWORD, password)
        routerStatus.value = c.network.syncRouter()
    }

    fun syncRouter() = viewModelScope.launch { routerStatus.value = c.network.syncRouter() }
}

private enum class Period { DAY, WEEK, MONTH }

@Composable
fun NetworkScreen(nav: NavHostController) {
    val vm = orbitViewModel { NetworkViewModel(it) }
    val devices by vm.devices.collectAsStateWithLifecycle()
    val usage by vm.usage.collectAsStateWithLifecycle()
    val scan by vm.scan.collectAsStateWithLifecycle()
    val routerStatus by vm.routerStatus.collectAsStateWithLifecycle()
    val settings = LocalSettings.current
    val c = Orbit.colors
    var renameFor by remember { mutableStateOf<NetDeviceEntity?>(null) }
    var routerSheet by remember { mutableStateOf(false) }
    var period by remember { mutableStateOf(Period.DAY) }

    val online = devices.orEmpty().filter { it.online }
    val offline = devices.orEmpty().filter { !it.online }
    val info = scan.info

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 40.dp)) {
        item { TopBar(stringResource(R.string.home_network), { nav.popBackStack() }, stringResource(R.string.back)) }

        // ---------- hero: radar + count ----------
        item {
            GlassCard(Modifier.fillMaxWidth(), highlight = c.cyan) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center) {
                        RadarSweep(scan.running, c.cyan, Modifier.size(132.dp), blips = online.take(12).mapIndexed { i, _ -> 0.35f + (i % 4) * 0.17f })
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.devices_online), style = OrbitType.overline, color = c.textMuted)
                        Text("${online.size}", style = OrbitType.numeric.copy(fontSize = 64.sp), color = c.text)
                        Text(
                            when {
                                scan.running -> stringResource(R.string.scanning_pct, (scan.progress * 100).toInt())
                                scan.error == "not_on_wifi" -> stringResource(R.string.not_on_wifi)
                                scan.lastScanAt != null -> stringResource(R.string.updated_ago, Fmt.ago(scan.lastScanAt ?: 0L))
                                else -> ""
                            },
                            style = OrbitType.caption, color = if (scan.error != null) c.amber else c.textSecondary,
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    PrimaryButton(stringResource(if (scan.running) R.string.scanning else R.string.scan_now), { vm.scanNow() }, Modifier.weight(1f), icon = OrbitIcons.Radar, enabled = !scan.running)
                }
                if (info != null) {
                    Text(
                        stringResource(R.string.lan_info, info.gateway ?: "—", info.localIp, info.prefix),
                        style = OrbitType.caption.copy(fontFeatureSettings = "tnum"), color = c.textMuted, modifier = Modifier.padding(top = 10.dp),
                    )
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth().padding(top = 12.dp), padding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                SettingRow(stringResource(R.string.watch_new_devices), subtitle = stringResource(R.string.watch_new_devices_hint), icon = OrbitIcons.Shield, iconTint = c.green, onClick = { vm.setWatch(!settings.watchNewDevices) }) {
                    OrbitSwitch(settings.watchNewDevices) { vm.setWatch(it) }
                }
            }
        }

        // ---------- usage ----------
        item { SectionHeader(stringResource(R.string.data_usage), Modifier.padding(top = 18.dp)) }
        item {
            val connected = settings.routerType != "NONE"
            GlassCard(Modifier.fillMaxWidth()) {
                if (usage.isEmpty()) {
                    Row(verticalAlignment = Alignment.Top) {
                        GlyphBadge(OrbitIcons.Router, c.amber)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(if (connected) R.string.router_waiting_title else R.string.router_connect_title), style = OrbitType.subtitle, color = c.text)
                            Text(
                                stringResource(
                                    when (routerStatus) {
                                        "pending" -> R.string.router_pending_body
                                        "no_password" -> R.string.router_no_password
                                        else -> if (connected) R.string.router_pending_body else R.string.router_connect_body
                                    }
                                ),
                                style = OrbitType.caption, color = c.textSecondary,
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    PrimaryButton(stringResource(if (connected) R.string.router_settings else R.string.connect_router), { routerSheet = true }, Modifier.fillMaxWidth(), icon = OrbitIcons.Router)
                } else {
                    UsageView(usage, devices.orEmpty(), period) { period = it }
                }
            }
        }

        // ---------- devices ----------
        if (online.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.connected_now), Modifier.padding(top = 18.dp)) }
            items(online, key = { "on" + it.deviceKey }) { d -> DeviceRow(d, vm.c.network.kindOf(d, info), onClick = { renameFor = d }) }
        }
        if (offline.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.seen_before), Modifier.padding(top = 18.dp)) }
            items(offline.take(30), key = { "off" + it.deviceKey }) { d -> DeviceRow(d, vm.c.network.kindOf(d, info), onClick = { renameFor = d }) }
        }
        item {
            Text(stringResource(R.string.lan_note), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 18.dp).navigationBarsPadding())
        }
    }

    renameFor?.let { d ->
        var name by remember(d.deviceKey) { mutableStateOf(d.alias ?: d.hostname ?: "") }
        AlertDialog(
            onDismissRequest = { renameFor = null },
            containerColor = c.surface,
            title = { Text(stringResource(R.string.name_device), color = c.text) },
            text = {
                Column {
                    Text(d.ip + (d.hostname?.let { " · $it" } ?: ""), style = OrbitType.caption, color = c.textMuted)
                    Spacer(Modifier.height(10.dp))
                    OrbitTextField(name, { name = it.take(40) }, stringResource(R.string.device_name_placeholder), Modifier.fillMaxWidth())
                }
            },
            confirmButton = { TextButton(onClick = { vm.rename(d.deviceKey, name); renameFor = null }) { Text(stringResource(R.string.save), color = c.cyan) } },
            dismissButton = { TextButton(onClick = { vm.forget(d.deviceKey); renameFor = null }) { Text(stringResource(R.string.forget_device), color = c.rose) } },
        )
    }
    if (routerSheet) RouterDialog(vm, onDismiss = { routerSheet = false })
}

private fun kindIcon(k: DeviceKind): ImageVector = when (k) {
    DeviceKind.ROUTER -> OrbitIcons.Router
    DeviceKind.THIS_PHONE, DeviceKind.PHONE -> OrbitIcons.Phone
    DeviceKind.COMPUTER -> OrbitIcons.Laptop
    DeviceKind.TV -> OrbitIcons.Tv
    DeviceKind.PRINTER -> OrbitIcons.Printer
    DeviceKind.CONSOLE -> OrbitIcons.Gamepad
    DeviceKind.SPEAKER -> OrbitIcons.Speaker
    DeviceKind.UNKNOWN -> OrbitIcons.Radar
}

@Composable
private fun DeviceRow(d: NetDeviceEntity, kind: DeviceKind, onClick: () -> Unit) {
    val c = Orbit.colors
    val color = when (kind) {
        DeviceKind.ROUTER -> c.amber
        DeviceKind.THIS_PHONE -> c.green
        else -> if (d.online) c.cyan else c.textMuted
    }
    val isNew = System.currentTimeMillis() - d.firstSeen < 24 * 60 * 60_000L && kind != DeviceKind.THIS_PHONE && kind != DeviceKind.ROUTER
    Row(Modifier.fillMaxWidth().pressable(onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        GlyphBadge(kindIcon(kind), color)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            val title = d.alias ?: when (kind) {
                DeviceKind.ROUTER -> stringResource(R.string.the_router)
                DeviceKind.THIS_PHONE -> stringResource(R.string.this_phone)
                else -> d.hostname?.substringBefore('.') ?: stringResource(R.string.unknown_device)
            }
            Text(title, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(d.ip + (if (!d.online) " · " + Fmt.ago(d.lastSeen) else ""), style = OrbitType.caption.copy(fontFeatureSettings = "tnum"), color = c.textMuted)
        }
        if (isNew) Tag(stringResource(R.string.new_tag), c.green)
    }
}

@Composable
private fun UsageView(usage: List<NetUsageEntity>, devices: List<NetDeviceEntity>, period: Period, onPeriod: (Period) -> Unit) {
    val c = Orbit.colors
    val today = LocalDate.now().toEpochDay()
    val days = when (period) { Period.DAY -> 1; Period.WEEK -> 7; Period.MONTH -> 30 }
    val from = today - days + 1
    val inRange = usage.filter { it.epochDay in from..today }
    val total = inRange.sumOf { it.rxBytes + it.txBytes }
    val chartDays = if (period == Period.DAY) 7 else days
    val series = (today - chartDays + 1..today).map { d -> usage.filter { it.epochDay == d }.sumOf { it.rxBytes + it.txBytes }.toFloat() }
    val names = devices.associate { it.deviceKey to (it.alias ?: it.hostname ?: it.ip) }
    val perDevice = inRange.groupBy { it.deviceKey }.mapValues { (_, l) -> l.sumOf { it.rxBytes + it.txBytes } }.entries.sortedByDescending { it.value }

    Segmented(
        listOf(Period.DAY to stringResource(R.string.period_day), Period.WEEK to stringResource(R.string.period_week), Period.MONTH to stringResource(R.string.period_month)),
        period, onPeriod, Modifier.fillMaxWidth(),
    )
    Spacer(Modifier.height(14.dp))
    Text(Numbers.bytes(total), style = OrbitType.headline.copy(fontFeatureSettings = "tnum"), color = c.text)
    Text(stringResource(R.string.total_usage), style = OrbitType.caption, color = c.textMuted)
    Spacer(Modifier.height(12.dp))
    BarChart(series, Modifier.fillMaxWidth().height(110.dp))
    Spacer(Modifier.height(14.dp))
    perDevice.take(10).forEach { (key, bytes) ->
        val share = if (total > 0) bytes.toFloat() / total else 0f
        Column(Modifier.padding(vertical = 6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(names[key] ?: key.substringAfter(':'), style = OrbitType.body, color = c.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Numbers.bytes(bytes), style = OrbitType.numericSmall, color = c.textSecondary)
            }
            Spacer(Modifier.height(4.dp))
            Box(Modifier.fillMaxWidth().height(6.dp).clipPill().androidxBackground(c.stroke)) {
                Box(Modifier.fillMaxWidth(share.coerceIn(0.02f, 1f)).height(6.dp).clipPill().androidxBackground(c.cyan))
            }
        }
    }
}

private fun Modifier.clipPill(): Modifier = this.clip(RoundedCornerShape(50))
private fun Modifier.androidxBackground(color: androidx.compose.ui.graphics.Color): Modifier = this.background(color)

@Composable
private fun RouterDialog(vm: NetworkViewModel, onDismiss: () -> Unit) {
    val c = Orbit.colors
    val s = LocalSettings.current
    var host by remember { mutableStateOf(if (s.routerType == "NONE") "192.168.0.1" else s.routerHost) }
    var user by remember { mutableStateOf(s.routerUser) }
    var pass by remember { mutableStateOf("") }
    val hasPass = remember { vm.c.secrets.has(SecretStore.Key.ROUTER_PASSWORD) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        title = { Text(stringResource(R.string.connect_router), color = c.text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Tag("Greenpacket D2-220G1 · Vodafone", c.amber, icon = OrbitIcons.Router)
                OrbitTextField(host, { host = it.trim() }, "192.168.0.1", Modifier.fillMaxWidth(), leading = OrbitIcons.Link, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
                OrbitTextField(user, { user = it.trim() }, stringResource(R.string.router_username), Modifier.fillMaxWidth(), leading = OrbitIcons.Person)
                androidx.compose.foundation.text.BasicTextField(
                    value = pass, onValueChange = { pass = it }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    textStyle = OrbitType.body.copy(color = c.text),
                    cursorBrush = androidx.compose.ui.graphics.SolidColor(c.cyan),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Row(
                            Modifier.clipRounded().androidxBackground(c.surfaceHigh).padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(OrbitIcons.Lock, null, tint = c.textMuted, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f)) {
                                if (pass.isEmpty()) Text(stringResource(if (hasPass) R.string.password_saved else R.string.router_password), style = OrbitType.body, color = c.textMuted)
                                inner()
                            }
                        }
                    },
                )
                Text(stringResource(R.string.router_secure_note), style = OrbitType.caption, color = c.textMuted)
            }
        },
        confirmButton = { TextButton(onClick = { vm.saveRouter(GreenpacketD2Adapter.id, host, user, pass.ifEmpty { null }); onDismiss() }) { Text(stringResource(R.string.save), color = c.cyan) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
    )
}

private fun Modifier.clipRounded(): Modifier = this.clip(RoundedCornerShape(18.dp))
