package com.orbit.followthrough.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface DhikrDao {
    @Query("SELECT * FROM dhikr_log WHERE phrase = :phrase AND epochDay = :day")
    suspend fun get(phrase: String, day: Long): DhikrLogEntity?

    @Upsert
    suspend fun upsert(e: DhikrLogEntity)

    @Query("SELECT * FROM dhikr_log WHERE epochDay = :day ORDER BY taps DESC")
    fun observeDay(day: Long): Flow<List<DhikrLogEntity>>

    @Query("SELECT * FROM dhikr_log ORDER BY epochDay DESC, taps DESC LIMIT :limit")
    fun observeHistory(limit: Int): Flow<List<DhikrLogEntity>>

    @Query("SELECT COALESCE(SUM(taps), 0) FROM dhikr_log")
    fun observeAllTime(): Flow<Int>

    @Query("DELETE FROM dhikr_log")
    suspend fun deleteAll()
}

@Dao
interface MarketDao {
    @Query("SELECT * FROM coins ORDER BY sortOrder ASC, id ASC")
    fun observeCoins(): Flow<List<CoinEntity>>

    @Query("SELECT * FROM coins ORDER BY sortOrder ASC")
    suspend fun coins(): List<CoinEntity>

    @Query("SELECT * FROM coins WHERE id = :id")
    suspend fun coin(id: String): CoinEntity?

    @Upsert
    suspend fun upsert(coins: List<CoinEntity>)

    @Update
    suspend fun update(coin: CoinEntity)

    @Query("DELETE FROM coins WHERE id = :id")
    suspend fun delete(id: String)

    @Query("SELECT COUNT(*) FROM coins")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM coins WHERE alertAbove IS NOT NULL OR alertBelow IS NOT NULL")
    suspend fun alertCount(): Int
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets ORDER BY createdAt ASC")
    fun observeWallets(): Flow<List<WalletEntity>>

    @Query("SELECT * FROM wallets WHERE enabled = 1")
    suspend fun enabled(): List<WalletEntity>

    @Query("SELECT * FROM wallets WHERE id = :id")
    suspend fun get(id: Long): WalletEntity?

    @Query("SELECT * FROM wallets WHERE id = :id")
    fun observe(id: Long): Flow<WalletEntity?>

    @Insert
    suspend fun insert(w: WalletEntity): Long

    @Update
    suspend fun update(w: WalletEntity)

    @Query("DELETE FROM wallets WHERE id = :id")
    suspend fun deleteRow(id: Long)

    @Query("DELETE FROM wallet_activity WHERE walletId = :id")
    suspend fun deleteActivity(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertActivity(items: List<WalletActivityEntity>): List<Long>

    @Query("SELECT * FROM wallet_activity WHERE walletId = :walletId ORDER BY at DESC LIMIT :limit")
    fun observeActivity(walletId: Long, limit: Int): Flow<List<WalletActivityEntity>>

    @Query("SELECT * FROM wallet_activity ORDER BY at DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<WalletActivityEntity>>

    @Query("SELECT * FROM wallet_activity WHERE at >= :since ORDER BY at DESC LIMIT :limit")
    suspend fun recentSince(since: Long, limit: Int): List<WalletActivityEntity>

    @Query("SELECT * FROM wallet_activity WHERE id = :id")
    suspend fun activity(id: Long): WalletActivityEntity?

    @Query("SELECT COUNT(*) FROM wallet_activity WHERE walletId = :walletId AND read = 0")
    fun observeUnread(walletId: Long): Flow<Int>

    @Query("UPDATE wallet_activity SET read = 1 WHERE walletId = :walletId")
    suspend fun markRead(walletId: Long)

    @Query("SELECT COUNT(*) FROM wallets WHERE enabled = 1")
    suspend fun enabledCount(): Int
}

@Dao
interface NetworkDao {
    @Query("SELECT * FROM net_devices ORDER BY online DESC, lastSeen DESC")
    fun observeDevices(): Flow<List<NetDeviceEntity>>

    @Query("SELECT * FROM net_devices")
    suspend fun devices(): List<NetDeviceEntity>

    @Upsert
    suspend fun upsertDevices(d: List<NetDeviceEntity>)

    @Query("UPDATE net_devices SET alias = :alias WHERE deviceKey = :key")
    suspend fun setAlias(key: String, alias: String?)

    @Query("DELETE FROM net_devices WHERE deviceKey = :key")
    suspend fun deleteDevice(key: String)

    @Query("SELECT * FROM net_usage WHERE epochDay >= :fromDay")
    fun observeUsageSince(fromDay: Long): Flow<List<NetUsageEntity>>

    @Query("SELECT * FROM net_usage WHERE deviceKey = :key AND epochDay = :day")
    suspend fun usage(key: String, day: Long): NetUsageEntity?

    @Upsert
    suspend fun upsertUsage(u: NetUsageEntity)

    @Query("SELECT * FROM net_counters WHERE deviceKey = :key")
    suspend fun counter(key: String): NetCounterEntity?

    @Upsert
    suspend fun upsertCounter(c: NetCounterEntity)

    @Query("DELETE FROM net_usage")
    suspend fun deleteUsage()

    @Query("DELETE FROM net_devices")
    suspend fun deleteDevices()
}
