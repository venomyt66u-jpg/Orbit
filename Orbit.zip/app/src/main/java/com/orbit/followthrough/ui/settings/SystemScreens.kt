package com.orbit.followthrough.ui.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.domain.EventType
import com.orbit.followthrough.ui.components.Divider
import com.orbit.followthrough.ui.components.EmptyState
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt

// ------------------------------------------------------------------ Permissions

data class PermissionStatus(val notifications: Boolean, val exactAlarms: Boolean, val battery: Boolean, val overlay: Boolean)

fun readPermissions(ctx: android.content.Context, canExact: Boolean): PermissionStatus {
    val notif = (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) &&
        NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    val pm = ctx.getSystemService(PowerManager::class.java)
    return PermissionStatus(notif, canExact, pm?.isIgnoringBatteryOptimizations(ctx.packageName) == true, Settings.canDrawOverlays(ctx))
}

fun openAppNotificationSettings(ctx: android.content.Context) {
    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(i) }
}

fun openExactAlarmSettings(ctx: android.content.Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val i = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(i) }
    }
}

@Composable
fun PermissionsScreen(nav: NavHostController) {
    val vm = orbitViewModel { SettingsViewModel(it) }
    val c = Orbit.colors
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    val status = remember(tick) { readPermissions(ctx, vm.c.scheduler.canScheduleExact()) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        tick++
        if (!granted) openAppNotificationSettings(ctx)
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { TopBar(stringResource(R.string.permissions), { nav.popBackStack() }, stringResource(R.string.back)) }
        item { Text(stringResource(R.string.permissions_intro), style = OrbitType.body, color = c.textSecondary, modifier = Modifier.padding(bottom = 14.dp)) }
        item {
            PermissionCard(
                OrbitIcons.Bell, stringResource(R.string.perm_notifications), stringResource(R.string.perm_notifications_why), status.notifications, required = true,
            ) {
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else openAppNotificationSettings(ctx)
            }
        }
        item {
            PermissionCard(
                OrbitIcons.Alarm, stringResource(R.string.perm_exact), stringResource(R.string.perm_exact_why), status.exactAlarms, required = false,
            ) { openExactAlarmSettings(ctx) }
        }
        item {
            PermissionCard(
                OrbitIcons.Battery, stringResource(R.string.perm_battery), stringResource(R.string.perm_battery_why), status.battery, required = false,
            ) { runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
        }
        item {
            PermissionCard(
                OrbitIcons.Window, stringResource(R.string.perm_overlay), stringResource(R.string.perm_overlay_why), status.overlay, required = false,
            ) { runCatching { ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
        }
        item {
            GlassCard(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                Row(verticalAlignment = Alignment.Top) {
                    GlyphBadge(OrbitIcons.Info, c.amber, size = 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(stringResource(R.string.reliability_note), style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                SecondaryButton(stringResource(R.string.resync_reminders), { vm.rescheduleAll() }, icon = OrbitIcons.Refresh)
            }
        }
    }
}

@Composable
private fun PermissionCard(icon: ImageVector, title: String, why: String, granted: Boolean, required: Boolean, onFix: () -> Unit) {
    val c = Orbit.colors
    GlassCard(Modifier.fillMaxWidth().padding(bottom = 12.dp), highlight = if (!granted && required) c.amber else null, padding = PaddingValues(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlyphBadge(icon, if (granted) c.green else if (required) c.amber else c.textSecondary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = OrbitType.subtitle, color = c.text)
                Tag(
                    stringResource(if (granted) R.string.perm_granted else if (required) R.string.perm_needed else R.string.perm_optional),
                    if (granted) c.green else if (required) c.amber else c.textMuted,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
        Text(why, style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 10.dp))
        if (!granted) {
            Spacer(Modifier.height(10.dp))
            SecondaryButton(stringResource(R.string.grant), onFix, icon = OrbitIcons.Shield, tint = if (required) c.amber else null)
        }
    }
}

// ------------------------------------------------------------------ History

@Composable
fun HistoryScreen(nav: NavHostController) {
    val vm = orbitViewModel { SettingsViewModel(it) }
    val notifications by vm.notificationHistory.collectAsStateWithLifecycle()
    val events by vm.eventHistory.collectAsStateWithLifecycle()
    val limit by vm.historyLimit.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item {
            TopBar(stringResource(R.string.notification_history), { nav.popBackStack() }, stringResource(R.string.back)) {
                com.orbit.followthrough.ui.components.IconCircle(OrbitIcons.Trash, stringResource(R.string.clear_history), { vm.clearHistory() }, tint = c.rose)
            }
        }
        item {
            Segmented(listOf(0 to stringResource(R.string.history_notifications), 1 to stringResource(R.string.history_activity)), tab, { tab = it }, Modifier.fillMaxWidth().padding(bottom = 12.dp))
        }
        if (tab == 0) {
            val list = notifications.orEmpty()
            if (notifications != null && list.isEmpty()) item { EmptyState(stringResource(R.string.history_empty), stringResource(R.string.history_empty_body)) }
            items(list, key = { "n${it.id}" }) { n ->
                Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(n.title, style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(Fmt.ago(n.at), style = OrbitType.caption, color = c.textMuted)
                    }
                    Text(n.text, style = OrbitType.caption, color = c.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(10.dp))
                    Divider()
                }
            }
            if (list.size >= limit) item { SecondaryButton(stringResource(R.string.load_more), { vm.loadMoreHistory() }, Modifier.fillMaxWidth()) }
        } else {
            val list = events.orEmpty()
            if (events != null && list.isEmpty()) item { EmptyState(stringResource(R.string.history_empty), stringResource(R.string.history_empty_body)) }
            items(list, key = { "e${it.id}" }) { e ->
                val (label, color) = when (e.type) {
                    EventType.COMPLETED -> R.string.ev_completed to c.green
                    EventType.SKIPPED -> R.string.ev_skipped to c.textSecondary
                    EventType.SNOOZED -> R.string.ev_snoozed to c.cyan
                    EventType.DISMISSED -> R.string.ev_dismissed to c.textSecondary
                    EventType.FIRED -> R.string.ev_fired to c.electric
                    EventType.FOLLOW_UP -> R.string.ev_follow_up to c.violet
                    EventType.MISSED -> R.string.ev_missed to c.amber
                    EventType.CREATED -> R.string.ev_created to c.textMuted
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Tag(stringResource(label), color)
                    Spacer(Modifier.width(10.dp))
                    Text(e.title, style = OrbitType.body, color = c.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(Fmt.dayAndTime(ctx, e.at), style = OrbitType.caption, color = c.textMuted)
                }
            }
            if (list.size >= limit) item { SecondaryButton(stringResource(R.string.load_more), { vm.loadMoreHistory() }, Modifier.fillMaxWidth()) }
        }
    }
}

// ------------------------------------------------------------------ Privacy

@Composable
fun PrivacyScreen(nav: NavHostController) {
    val vm = orbitViewModel { SettingsViewModel(it) }
    val c = Orbit.colors
    var confirmAll by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf<Int?>(null) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp).navigationBarsPadding(), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { TopBar(stringResource(R.string.privacy_data), { nav.popBackStack() }, stringResource(R.string.back)) }
        item {
            GlassCard(Modifier.fillMaxWidth(), highlight = c.green) {
                DisclosureLine(OrbitIcons.Lock, c.green, stringResource(R.string.privacy_local_title), stringResource(R.string.privacy_local_body))
                Divider()
                DisclosureLine(OrbitIcons.Signal, c.violet, stringResource(R.string.privacy_network_title), stringResource(R.string.privacy_network_body))
                Divider()
                DisclosureLine(OrbitIcons.Spark, c.cyan, stringResource(R.string.privacy_ai_title), stringResource(R.string.privacy_ai_body))
                Divider()
                DisclosureLine(OrbitIcons.History, c.amber, stringResource(R.string.privacy_retention_title), stringResource(R.string.privacy_retention_body))
            }
        }
        item {
            Column(Modifier.padding(top = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton(stringResource(R.string.clear_history), { vm.clearHistory(); done = R.string.history_cleared }, Modifier.fillMaxWidth(), icon = OrbitIcons.History)
                SecondaryButton(stringResource(R.string.clear_signals), { vm.clearSignals(); done = R.string.signals_cleared }, Modifier.fillMaxWidth(), icon = OrbitIcons.Signal)
                PrimaryButton(stringResource(R.string.delete_all_data), { confirmAll = true }, Modifier.fillMaxWidth(), icon = OrbitIcons.Trash, brush = c.warmBrush)
                done?.let { Text(stringResource(it), style = OrbitType.label, color = c.green) }
            }
        }
    }

    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            containerColor = c.surface,
            title = { Text(stringResource(R.string.delete_all_q), color = c.text) },
            text = { Text(stringResource(R.string.delete_all_body), color = c.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    confirmAll = false
                    vm.deleteEverything { done = R.string.all_deleted }
                }) { Text(stringResource(R.string.delete), color = c.rose) }
            },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
        )
    }
}

@Composable
private fun DisclosureLine(icon: ImageVector, color: androidx.compose.ui.graphics.Color, title: String, body: String) {
    val c = Orbit.colors
    Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = OrbitType.subtitle, color = c.text)
            Text(body, style = OrbitType.caption, color = c.textSecondary)
        }
    }
}
