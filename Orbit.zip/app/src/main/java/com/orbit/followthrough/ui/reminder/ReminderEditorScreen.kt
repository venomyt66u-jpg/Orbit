package com.orbit.followthrough.ui.reminder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.domain.ReminderCategory
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.domain.Weekdays
import com.orbit.followthrough.ui.components.DatePickerSheet
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitSwitch
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.SettingRow
import com.orbit.followthrough.ui.components.Stepper
import com.orbit.followthrough.ui.components.TimePickerDialog
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReminderEditorScreen(nav: NavHostController, id: Long) {
    val vm = orbitViewModel(key = "editor$id") { ReminderEditorViewModel(it, id) }
    val f by vm.form.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val ctx = LocalContext.current
    val settings = LocalSettings.current

    var showTime by remember { mutableStateOf(false) }
    var showDate by remember { mutableStateOf(false) }
    var showDeadlineDate by remember { mutableStateOf(false) }
    var showDeadlineTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(f.saved, f.deleted) { if (f.saved || f.deleted) nav.popBackStack() }

    Column(Modifier.fillMaxSize().imePadding()) {
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            TopBar(
                title = stringResource(if (f.isEditing) R.string.edit_reminder else R.string.new_reminder),
                onBack = { nav.popBackStack() },
                backLabel = stringResource(R.string.back),
            ) {
                if (f.isEditing) IconCircle(OrbitIcons.Trash, stringResource(R.string.delete), { confirmDelete = true }, tint = c.rose)
            }
            if (f.loaded) {
            Spacer(Modifier.height(8.dp))
            OrbitTextField(
                value = f.title,
                onValueChange = { v -> vm.edit { copy(title = v.take(120)) } },
                placeholder = stringResource(R.string.title_placeholder),
                style = OrbitType.headline,
                boxed = false,
                singleLine = false,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(14.dp))
            OrbitTextField(
                value = f.note,
                onValueChange = { v -> vm.edit { copy(note = v.take(500)) } },
                placeholder = stringResource(R.string.note_placeholder),
                singleLine = false,
                leading = OrbitIcons.Edit,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
            )

            // ---------- WHEN ----------
            SectionHeader(stringResource(R.string.section_when), Modifier.padding(top = 18.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(
                        Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { showTime = true }
                            .padding(end = 12.dp, top = 4.dp, bottom = 4.dp)
                            .semantics { contentDescription = ctx.getString(R.string.change_time) }
                    ) {
                        Text(stringResource(R.string.time), style = OrbitType.caption, color = c.textMuted)
                        Text(Fmt.time(ctx, f.hour, f.minute), style = OrbitType.numeric.copy(fontSize = OrbitType.headline.fontSize * 1.5f), color = c.text)
                    }
                    Spacer(Modifier.weight(1f))
                    IconCircle(OrbitIcons.Clock, stringResource(R.string.change_time), { showTime = true }, tint = c.cyan)
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        RepeatType.ONCE to R.string.repeat_once,
                        RepeatType.DAILY to R.string.repeat_daily,
                        RepeatType.WEEKLY to R.string.repeat_weekly,
                        RepeatType.MONTHLY to R.string.repeat_monthly,
                        RepeatType.INTERVAL to R.string.repeat_interval,
                    ).forEach { (type, label) ->
                        OrbitChip(stringResource(label), f.repeat == type, { vm.edit { copy(repeat = type) } }, icon = if (type == RepeatType.ONCE) null else OrbitIcons.Repeat)
                    }
                }
                Spacer(Modifier.height(14.dp))

                when (f.repeat) {
                    RepeatType.ONCE -> FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val today = LocalDate.now()
                        OrbitChip(stringResource(R.string.today), f.date == today, { vm.edit { copy(date = today) } })
                        OrbitChip(stringResource(R.string.tomorrow), f.date == today.plusDays(1), { vm.edit { copy(date = today.plusDays(1)) } })
                        val custom = f.date != today && f.date != today.plusDays(1)
                        OrbitChip(if (custom) Fmt.dayLabel(ctx, f.date) else stringResource(R.string.pick_date), custom, { showDate = true }, icon = OrbitIcons.Calendar)
                    }
                    RepeatType.WEEKLY -> WeekdayPicker(
                        mask = if (f.weekdays == 0) Weekdays.bit(f.date.dayOfWeek) else f.weekdays,
                        startSaturday = settings.weekStartsSaturday,
                        onChange = { m -> vm.edit { copy(weekdays = m) } },
                    )
                    RepeatType.MONTHLY -> SettingRow(stringResource(R.string.day_of_month)) {
                        Stepper(f.dayOfMonth, { v -> vm.edit { copy(dayOfMonth = v) } }, 1..31, decLabel = stringResource(R.string.decrease), incLabel = stringResource(R.string.increase))
                    }
                    RepeatType.INTERVAL -> SettingRow(stringResource(R.string.every_n_days_label)) {
                        Stepper(f.interval, { v -> vm.edit { copy(interval = v) } }, 2..60, decLabel = stringResource(R.string.decrease), incLabel = stringResource(R.string.increase))
                    }
                    RepeatType.DAILY -> {}
                }
                if (f.repeat != RepeatType.ONCE) {
                    Spacer(Modifier.height(6.dp))
                    SettingRow(stringResource(R.string.starts_on), subtitle = Fmt.dayLabel(ctx, f.date), onClick = { showDate = true }) {
                        Icon(OrbitIcons.Calendar, null, tint = c.textMuted, modifier = Modifier.size(20.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                val preview = f.preview()
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(c.cyan.copy(alpha = 0.08f)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(OrbitIcons.Spark, null, tint = if (preview != null) c.cyan else c.amber, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (preview != null) stringResource(R.string.next_preview, Fmt.dayAndTime(ctx, preview), Fmt.countdown(ctx, preview))
                        else stringResource(R.string.error_past),
                        style = OrbitType.label, color = if (preview != null) c.text else c.amber,
                    )
                }
            }

            // ---------- FOLLOW-THROUGH ----------
            SectionHeader(stringResource(R.string.section_follow), Modifier.padding(top = 18.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.follow_explain), style = OrbitType.label, color = c.textSecondary)
                Spacer(Modifier.height(12.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OrbitChip(stringResource(R.string.off), f.followUpMinutes == 0, { vm.edit { copy(followUpMinutes = 0) } })
                    listOf(5, 10, 15, 30, 60).forEach { m ->
                        OrbitChip(stringResource(R.string.minutes_short, m), f.followUpMinutes == m, { vm.edit { copy(followUpMinutes = m) } })
                    }
                }
                AnimatedVisibility(f.followUpMinutes > 0, enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()) {
                    SettingRow(stringResource(R.string.max_followups), subtitle = stringResource(R.string.max_followups_hint), modifier = Modifier.padding(top = 8.dp)) {
                        Stepper(f.maxFollowUps, { v -> vm.edit { copy(maxFollowUps = v) } }, 1..10, decLabel = stringResource(R.string.decrease), incLabel = stringResource(R.string.increase))
                    }
                }
                SettingRow(
                    stringResource(R.string.deadline),
                    subtitle = f.deadline?.let { Fmt.dayLabel(ctx, it.toLocalDate()) + " · " + Fmt.time(ctx, it.hour, it.minute) } ?: stringResource(R.string.deadline_hint),
                    onClick = { if (f.deadline == null) showDeadlineDate = true },
                ) {
                    OrbitSwitch(f.deadline != null) { on ->
                        if (on) showDeadlineDate = true else vm.edit { copy(deadline = null) }
                    }
                }
            }

            // ---------- IDENTITY ----------
            SectionHeader(stringResource(R.string.section_identity), Modifier.padding(top = 18.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReminderCategory.entries.forEach { cat ->
                        OrbitChip(stringResource(categoryLabel(cat)), f.category == cat, { vm.edit { copy(category = cat) } }, icon = categoryIcon(cat), accent = c.category(cat))
                    }
                }
                Spacer(Modifier.height(10.dp))
                SettingRow(
                    stringResource(R.string.important),
                    subtitle = stringResource(R.string.important_hint),
                    icon = OrbitIcons.Flag,
                    iconTint = c.amber,
                    onClick = { vm.edit { copy(important = !important) } },
                ) { OrbitSwitch(f.important) { v -> vm.edit { copy(important = v) } } }
            }

            if (f.isEditing) {
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (f.status == ReminderStatus.PENDING || f.status == ReminderStatus.SCHEDULED) {
                        SecondaryButton(stringResource(R.string.mark_done_now), { vm.completeNow() }, icon = OrbitIcons.Check, tint = c.green)
                    }
                    SecondaryButton(
                        stringResource(if (f.status == ReminderStatus.PAUSED) R.string.resume else R.string.pause),
                        { vm.togglePause() },
                        icon = if (f.status == ReminderStatus.PAUSED) OrbitIcons.Play else OrbitIcons.Pause,
                    )
                }
            }
            }
            Spacer(Modifier.height(24.dp))
        }

        // sticky save bar
        Column(Modifier.fillMaxWidth().background(c.void.copy(alpha = 0.92f)).navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
            f.errorRes?.let { Text(stringResource(it), style = OrbitType.label, color = c.amber, modifier = Modifier.padding(bottom = 8.dp)) }
            PrimaryButton(stringResource(R.string.save), { vm.save() }, Modifier.fillMaxWidth(), icon = OrbitIcons.Check, enabled = f.title.isNotBlank())
        }
    }

    if (showTime) TimePickerDialog(f.hour, f.minute, { h, m -> vm.edit { copy(hour = h, minute = m) }; showTime = false }, { showTime = false })
    if (showDate) DatePickerSheet(f.date, { d -> vm.edit { copy(date = d, dayOfMonth = if (repeat == RepeatType.MONTHLY) dayOfMonth else d.dayOfMonth) }; showDate = false }, { showDate = false })
    if (showDeadlineDate) DatePickerSheet(f.deadline?.toLocalDate() ?: f.date.plusDays(7), { d ->
        vm.edit { copy(deadline = LocalDateTime.of(d, deadline?.toLocalTime() ?: LocalTime.of(23, 59))) }
        showDeadlineDate = false; showDeadlineTime = true
    }, { showDeadlineDate = false })
    if (showDeadlineTime) {
        val dl = f.deadline ?: LocalDateTime.now().withHour(23).withMinute(59)
        TimePickerDialog(dl.hour, dl.minute, { h, m -> vm.edit { copy(deadline = (deadline ?: dl).withHour(h).withMinute(m)) }; showDeadlineTime = false }, { showDeadlineTime = false })
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = c.surface,
            title = { Text(stringResource(R.string.delete_reminder_q), color = c.text) },
            text = { Text(stringResource(R.string.delete_reminder_body), color = c.textSecondary) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete() }) { Text(stringResource(R.string.delete), color = c.rose) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
        )
    }
}

@Composable
fun WeekdayPicker(mask: Int, startSaturday: Boolean, onChange: (Int) -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val order = if (startSaturday) listOf(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)
    else listOf(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        order.forEach { d ->
            val on = Weekdays.has(mask, d)
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (on) c.cyan.copy(alpha = 0.18f) else c.surface)
                    .border(1.dp, if (on) c.cyan else c.stroke, CircleShape)
                    .pressable({
                        val next = mask xor Weekdays.bit(d)
                        if (next != 0) onChange(next)
                    }, role = Role.Checkbox)
                    .semantics { selected = on; contentDescription = Fmt.weekdayShort(ctx, d) },
                contentAlignment = Alignment.Center,
            ) {
                Text(Fmt.weekdayNarrow(ctx, d), style = OrbitType.label, color = if (on) c.cyan else c.textSecondary)
            }
        }
    }
}
