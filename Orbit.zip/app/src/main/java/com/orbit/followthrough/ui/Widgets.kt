package com.orbit.followthrough.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.ui.components.BarChart
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.delay
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.min
import kotlin.math.sin

/** Fades and lifts an item in, slightly after the one before it. */
@Composable
fun Modifier.enter(index: Int): Modifier {
    val reduced = Orbit.reducedMotion
    val a = remember { Animatable(if (reduced) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!reduced) {
            delay(index * 60L)
            a.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
        }
    }
    return this.graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 36f
    }
}

/** Big usage number that counts up smoothly when it changes. */
@Composable
fun AnimatedBytes(bytes: Long, modifier: Modifier = Modifier, big: Boolean = true, color: Color = Orbit.colors.text) {
    val v by animateFloatAsState(
        bytes.toFloat(),
        if (Orbit.reducedMotion) tween(0) else tween(900, easing = FastOutSlowInEasing),
        label = "bytes",
    )
    BigBytes(v.toLong(), modifier, color, big)
}

/** A chevron drawn to point visually left or right (independent of RTL mirroring). */
@Composable
fun ChevronButton(pointsRight: Boolean, enabled: Boolean, label: String, onClick: () -> Unit) {
    val c = Orbit.colors
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(c.surfaceHigh)
            .border(1.dp, c.stroke, CircleShape)
            .clickable(enabled = enabled, onClickLabel = label, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        val tint = if (enabled) c.text else c.textMuted.copy(alpha = 0.5f)
        Canvas(Modifier.size(14.dp)) {
            val w = size.width
            val h = size.height
            val p = Path().apply {
                if (pointsRight) { moveTo(w * 0.32f, h * 0.1f); lineTo(w * 0.72f, h * 0.5f); lineTo(w * 0.32f, h * 0.9f) }
                else { moveTo(w * 0.68f, h * 0.1f); lineTo(w * 0.28f, h * 0.5f); lineTo(w * 0.68f, h * 0.9f) }
            }
            drawPath(p, tint, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

private val weekLetters = listOf("سبت", "حد", "اتنين", "تلات", "أربع", "خميس", "جمعة")

/**
 * Month calendar (week starts Saturday). Each day is tinted by how much was used, so heavy days
 * stand out; tap a day to see its details.
 */
@Composable
fun UsageCalendar(
    month: YearMonth,
    days: Map<String, Bytes>,
    selected: LocalDate?,
    accent: Color,
    onSelect: (LocalDate) -> Unit,
    onMonth: (YearMonth) -> Unit,
    modifier: Modifier = Modifier,
    earliest: YearMonth = YearMonth.now().minusMonths(12),
    past: Map<String, Bytes> = emptyMap(),
    marks: Set<String> = emptySet(),
) {
    val c = Orbit.colors
    val today = LocalDate.now()
    val current = YearMonth.from(today)
    var direction by remember { mutableIntStateOf(1) }

    GlassCard(modifier.fillMaxWidth()) {
        // In right-to-left layout the first child sits on the right: "previous" on the right, "next" on the left.
        Row(verticalAlignment = Alignment.CenterVertically) {
            ChevronButton(pointsRight = true, enabled = month > earliest, label = "الشهر اللي فات") {
                direction = -1; onMonth(month.minusMonths(1))
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(Ar.month(month.atDay(1)), style = OrbitType.title, color = c.text)
                val total = (1..month.lengthOfMonth()).sumOf { days[month.atDay(it).toString()]?.total ?: 0L }
                Text("إجمالي الشهر " + Fmt.bytes(total), style = OrbitType.caption, color = c.textSecondary)
            }
            ChevronButton(pointsRight = false, enabled = month < current, label = "الشهر اللي بعده") {
                direction = 1; onMonth(month.plusMonths(1))
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth()) {
            weekLetters.forEach {
                Text(it, style = OrbitType.caption.copy(fontSize = 10.sp), color = c.textMuted, textAlign = TextAlign.Center, modifier = Modifier.weight(1f), maxLines = 1)
            }
        }
        Spacer(Modifier.height(6.dp))
        AnimatedContent(
            targetState = month,
            transitionSpec = {
                val d = direction
                (slideInHorizontally(tween(320)) { w -> w * d / 3 } + fadeIn(tween(320))) togetherWith
                    (slideOutHorizontally(tween(260)) { w -> -w * d / 3 } + fadeOut(tween(200)))
            },
            label = "month",
        ) { m ->
            val first = m.atDay(1)
            val offset = (first.dayOfWeek.value - DayOfWeek.SATURDAY.value + 7) % 7
            val cells = offset + m.lengthOfMonth()
            val rows = (cells + 6) / 7
            val max = (1..m.lengthOfMonth()).maxOf { days[m.atDay(it).toString()]?.total ?: 0L }.coerceAtLeast(1L)
            Column {
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth()) {
                        for (col in 0 until 7) {
                            val dayNum = r * 7 + col - offset + 1
                            Box(Modifier.weight(1f).aspectRatio(0.86f).padding(2.dp)) {
                                if (dayNum in 1..m.lengthOfMonth()) {
                                    val date = m.atDay(dayNum)
                                    val v = days[date.toString()]?.total ?: 0L
                                    val pv = if (v == 0L) past[date.toString()]?.total ?: 0L else 0L
                                    DayCell(date, v, pv, max, date == today, date == selected, date.isAfter(today), accent, date.toString() in marks) { onSelect(date) }
                                }
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        // legend
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("أقل", style = OrbitType.caption, color = c.textMuted)
            listOf(0.12f, 0.3f, 0.5f, 0.7f, 0.9f).forEach { a ->
                Box(Modifier.size(12.dp).clip(RoundedCornerShape(3.dp)).background(accent.copy(alpha = a)))
            }
            Text("أكتر", style = OrbitType.caption, color = c.textMuted)
        }
        if (marks.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(c.amber))
                Text("يوم بداية باقة جديدة", style = OrbitType.caption, color = c.textMuted)
            }
        }
        if (past.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.size(12.dp).clip(RoundedCornerShape(3.dp)).border(1.dp, c.textMuted, RoundedCornerShape(3.dp)))
                Text("≈ قبل التطبيق: كل الواي فاي، مش ${com.orbit.followthrough.data.Config.TARGET_SSID} لوحدها", style = OrbitType.caption, color = c.textMuted)
            }
        }
    }
}

@Composable
private fun DayCell(date: LocalDate, value: Long, pastValue: Long, max: Long, isToday: Boolean, isSelected: Boolean, future: Boolean, accent: Color, marked: Boolean, onClick: () -> Unit) {
    val c = Orbit.colors
    val level = if (value > 0) 0.14f + 0.76f * (value.toFloat() / max).coerceIn(0f, 1f) else 0f
    val scale by animateFloatAsState(if (isSelected) 1.08f else 1f, spring(dampingRatio = 0.55f, stiffness = 500f), label = "cell")
    val shape = RoundedCornerShape(12.dp)
    val bg = when {
        future -> Color.Transparent
        value > 0 -> accent.copy(alpha = level)
        else -> c.surface.copy(alpha = 0.55f)
    }
    val strong = level > 0.55f
    Box(
        Modifier
            .fillMaxSize()
            .scale(scale)
            .clip(shape)
            .background(bg)
            .then(
                when {
                    isSelected -> Modifier.border(2.dp, c.text, shape)
                    isToday -> Modifier.border(1.5.dp, accent, shape)
                    pastValue > 0 -> Modifier.border(1.dp, c.textMuted.copy(alpha = 0.6f), shape)
                    else -> Modifier
                }
            )
            .clickable(enabled = !future, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (marked) {
            // A new package started on this day.
            Box(Modifier.align(Alignment.TopEnd).padding(4.dp).size(7.dp).clip(CircleShape).background(c.amber))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                date.dayOfMonth.toString(),
                style = OrbitType.label.copy(fontSize = 13.sp, lineHeight = 15.sp),
                color = when {
                    future -> c.textMuted.copy(alpha = 0.5f)
                    strong -> c.onAccent
                    else -> c.text
                },
            )
            if (value == 0L && pastValue > 0) {
                Text(
                    "≈" + Fmt.compact(pastValue),
                    style = OrbitType.caption.copy(fontSize = 9.sp, lineHeight = 11.sp, fontFeatureSettings = "tnum"),
                    color = c.textMuted,
                    maxLines = 1,
                )
            }
            if (value > 0) {
                Text(
                    Fmt.compact(value),
                    style = OrbitType.caption.copy(fontSize = 9.sp, lineHeight = 11.sp, fontFeatureSettings = "tnum"),
                    color = if (strong) c.onAccent.copy(alpha = 0.85f) else c.textSecondary,
                    maxLines = 1,
                )
            }
        }
    }
}

/** Details for one chosen day: total, download / upload, comparison and (when known) the hours. */
@Composable
fun DayDetail(
    date: LocalDate,
    bytes: Bytes,
    average: Long,
    accent: Color,
    hours: List<Long>? = null,
    modifier: Modifier = Modifier,
    past: Bytes? = null,
    note: String? = null,
    extra: @Composable () -> Unit = {},
) {
    val c = Orbit.colors
    GlassCard(modifier.fillMaxWidth(), highlight = accent) {
        if (note != null) {
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(c.amber.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(c.amber))
                Spacer(Modifier.width(6.dp))
                Text(note, style = OrbitType.caption, color = c.amber)
            }
            Spacer(Modifier.height(8.dp))
        }
        Text(Ar.dayLong(date), style = OrbitType.subtitle, color = c.textSecondary)
        Text("على شبكة ${com.orbit.followthrough.data.Config.TARGET_SSID}", style = OrbitType.caption, color = c.textMuted)
        Spacer(Modifier.height(2.dp))
        AnimatedBytes(bytes.total, big = false)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("تحميل ↓", bytes.rx, c.cyan, Modifier.weight(1f))
            StatTile("رفع ↑", bytes.tx, c.violet, Modifier.weight(1f))
        }
        if (average > 0 && bytes.total > 0) {
            Spacer(Modifier.height(10.dp))
            val pct = ((bytes.total - average) * 100 / average).toInt()
            val text = when {
                pct > 5 -> "أعلى من متوسطك اليومي بـ $pct٪"
                pct < -5 -> "أقل من متوسطك اليومي بـ ${-pct}٪"
                else -> "قريب من متوسطك اليومي"
            }
            Text(text, style = OrbitType.caption, color = if (pct > 5) c.amber else c.green)
        }
        if (hours != null && hours.any { it > 0 }) {
            Spacer(Modifier.height(14.dp))
            Text("على مدار اليوم", style = OrbitType.label, color = c.textSecondary)
            Spacer(Modifier.height(8.dp))
            HourBars(hours, accent)
        }
        if (past != null && past.total > 0) {
            Spacer(Modifier.height(14.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).border(1.dp, c.stroke, RoundedCornerShape(16.dp)).padding(12.dp),
            ) {
                Text(
                    if (bytes.total > 0) "قبل ما التطبيق يبدأ يعدّ في اليوم ده" else "قبل تثبيت التطبيق",
                    style = OrbitType.label, color = c.textSecondary,
                )
                Text("≈ " + Fmt.bytes(past.total) + " واي فاي", style = OrbitType.title, color = c.text)
                Text(
                    "من سجل أندرويد. ده كل الواي فاي على أي شبكة، لأن أندرويد مكانش بيفرّق بين الشبكات قبل التطبيق.",
                    style = OrbitType.caption, color = c.textMuted,
                )
            }
        }
        extra()
    }
}

@Composable
fun HourBars(hours: List<Long>, accent: Color, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    val peak = hours.indices.maxByOrNull { hours[it] } ?: 0
    Column(modifier.fillMaxWidth()) {
        BarChart(hours.map { it.toFloat() }, Modifier.fillMaxWidth().height(90.dp), highlight = peak, color = accent)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("12ص", "6ص", "12ظ", "6م", "11م").forEach { Text(it, style = OrbitType.caption.copy(fontSize = 10.sp), color = c.textMuted) }
        }
        if (hours[peak] > 0) {
            Spacer(Modifier.height(4.dp))
            Text("أكتر ساعة: ${Ar.hour(peak)} · ${Fmt.bytes(hours[peak])}", style = OrbitType.caption, color = c.textSecondary)
        }
    }
}

/**
 * Hero animation: luminous rings with particles that orbit faster while data is moving.
 * Freezes when the user prefers reduced motion.
 */
@Composable
fun LiveOrb(active: Boolean, bytesPerSec: Long, accent: Color, modifier: Modifier = Modifier, size: Dp = 230.dp, content: @Composable () -> Unit) {
    val c = Orbit.colors
    val reduced = Orbit.reducedMotion
    var phase by remember { mutableFloatStateOf(0f) }
    val speed = if (active) 0.06f + min(1f, (log10(1.0 + bytesPerSec / 2_000.0) / 3.5).toFloat()) * 0.5f else 0.02f
    val speedState = rememberUpdatedState(speed)
    LaunchedEffect(reduced) {
        if (reduced) return@LaunchedEffect
        var last = 0L
        while (true) {
            withFrameNanos { t ->
                if (last != 0L) phase = (phase + (t - last) / 1e9f * speedState.value) % 1000f
                last = t
            }
        }
    }
    val glow by animateFloatAsState(if (active) 1f else 0.35f, tween(800), label = "glow")
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val r = this.size.minDimension / 2
            val ctr = center
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.30f * glow), Color.Transparent), ctr, r), r, ctr)
            val rings = listOf(0.92f, 0.76f, 0.6f)
            rings.forEachIndexed { i, k ->
                drawCircle(c.strokeStrong.copy(alpha = 0.5f), r * k, ctr, style = Stroke(1.dp.toPx()))
                val dir = if (i % 2 == 0) 1f else -1f
                val count = 5 + i * 2
                for (j in 0 until count) {
                    val a = (j.toFloat() / count + dir * phase * (1f + i * 0.35f)) * 2f * PI.toFloat()
                    val p = Offset(ctr.x + cos(a) * r * k, ctr.y + sin(a) * r * k)
                    val dot = (2.2f - i * 0.4f).dp.toPx()
                    drawCircle(accent.copy(alpha = 0.18f * glow), dot * 3f, p)
                    drawCircle((if (j == 0) Color.White else accent).copy(alpha = 0.35f + 0.6f * glow), dot, p)
                }
            }
            // sweeping arc on the outer ring
            val sweepStart = (phase * 360f * 1.2f) % 360f
            drawArc(
                Brush.sweepGradient(listOf(Color.Transparent, accent.copy(alpha = 0.9f * glow), Color.Transparent), ctr),
                sweepStart, 110f, false,
                Offset(ctr.x - r * 0.92f, ctr.y - r * 0.92f), androidx.compose.ui.geometry.Size(r * 1.84f, r * 1.84f),
                style = Stroke(3.dp.toPx(), cap = StrokeCap.Round),
            )
            drawCircle(Brush.radialGradient(listOf(c.surfaceHigh, c.surface.copy(alpha = 0.9f)), ctr, r * 0.5f), r * 0.5f, ctr)
            drawCircle(c.strokeStrong, r * 0.5f, ctr, style = Stroke(1.dp.toPx()))
        }
        content()
    }
}
