package com.orbit.followthrough.ai

import com.orbit.followthrough.domain.EventType

/** Minimal view of a reminder for pattern analysis (keeps this logic pure and testable). */
data class InsightReminder(val id: Long, val title: String, val hour: Int, val minute: Int, val recurring: Boolean)

/** Minimal view of an event. */
data class InsightEvent(val reminderId: Long, val type: EventType, val hourOfDay: Int)

data class Insight(
    val kind: Kind,
    val reminderId: Long,
    val title: String,
    val currentHour: Int,
    val currentMinute: Int,
    val suggestedHour: Int,
    val suggestedMinute: Int,
    val postpones: Int,
) {
    enum class Kind { MOVE_TO_USUAL, MOVE_LATER, SPLIT }
    val key: String get() = "$kind:$reminderId:$suggestedHour"
}

/**
 * Transparent, on-device "smart follow-up" analysis.
 * Only uses the user's own completion history stored locally; every suggestion needs confirmation.
 */
object Insights {

    private val postponeTypes = setOf(EventType.SNOOZED, EventType.DISMISSED, EventType.MISSED)

    fun compute(reminders: List<InsightReminder>, events: List<InsightEvent>, dismissed: Set<String> = emptySet()): List<Insight> {
        val byReminder = events.groupBy { it.reminderId }
        val out = ArrayList<Insight>()
        for (r in reminders) {
            val ev = byReminder[r.id].orEmpty()
            val postpones = ev.filter { it.type in postponeTypes }
            val completions = ev.filter { it.type == EventType.COMPLETED }
            if (postpones.size < 3) continue

            val insight = when {
                // The user postpones it, but does finish it reliably at another time of day.
                completions.size >= 2 -> {
                    val usual = median(completions.map { it.hourOfDay })
                    if (kotlin.math.abs(usual - r.hour) >= 2) Insight(Insight.Kind.MOVE_TO_USUAL, r.id, r.title, r.hour, r.minute, usual, 0, postpones.size) else null
                }
                // Mostly postponed in the morning → offer the evening.
                r.recurring && r.hour < 12 && postpones.count { it.hourOfDay < 12 } * 2 >= postpones.size ->
                    Insight(Insight.Kind.MOVE_LATER, r.id, r.title, r.hour, r.minute, 19, 0, postpones.size)
                // Keeps slipping and never gets done → suggest a smaller first step.
                postpones.size >= 4 && completions.isEmpty() ->
                    Insight(Insight.Kind.SPLIT, r.id, r.title, r.hour, r.minute, r.hour, r.minute, postpones.size)
                else -> null
            }
            if (insight != null && insight.key !in dismissed) out += insight
        }
        return out.sortedByDescending { it.postpones }.take(5)
    }

    private fun median(values: List<Int>): Int {
        val s = values.sorted()
        return s[s.size / 2]
    }
}
