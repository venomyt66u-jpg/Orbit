package com.orbit.followthrough.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.domain.ThemeMode
import com.orbit.followthrough.meter.Background
import com.orbit.followthrough.ui.components.auroraBackground
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitTheme

private enum class Screen { PICK, SETUP, ADMIN, MEMBER }

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val profile = remember { Profile(ctx) }
    val version by DataVersion.flow.collectAsState()
    OrbitTheme(ThemeMode.SYSTEM) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            val c = Orbit.colors
            Box(
                Modifier
                    .fillMaxSize()
                    .drawBehind { auroraBackground(c.void, c.abyss, c.violet, c.cyan, c.isDark) },
            ) {
                val slot = remember(version) { profile.slot }
                val setupDone = remember(version) { profile.setupDone }
                var showSetup by rememberSaveable { mutableStateOf(false) }
                val screen = when {
                    slot == null -> Screen.PICK
                    !setupDone || showSetup -> Screen.SETUP
                    slot == Config.ADMIN_SLOT -> Screen.ADMIN
                    else -> Screen.MEMBER
                }
                AnimatedContent(
                    targetState = screen,
                    transitionSpec = { (fadeIn(tween(380)) + scaleIn(tween(380), initialScale = 0.97f)) togetherWith fadeOut(tween(200)) },
                    label = "screen",
                ) { s ->
                    when (s) {
                        Screen.PICK -> PickScreen(profile)
                        Screen.SETUP -> {
                            if (showSetup) BackHandler { showSetup = false }
                            SetupScreen(
                                again = setupDone,
                                onDone = {
                                    profile.setupDone = true
                                    showSetup = false
                                    runCatching {
                                        Background.schedule(ctx)
                                        Background.runNow(ctx)
                                    }
                                },
                            )
                        }
                        Screen.ADMIN -> AdminScreen(profile, onSettings = { showSetup = true })
                        Screen.MEMBER -> MemberScreen(profile, slot ?: "", onSettings = { showSetup = true })
                    }
                }
            }
        }
    }
}
