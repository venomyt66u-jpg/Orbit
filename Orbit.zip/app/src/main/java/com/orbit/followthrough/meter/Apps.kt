package com.orbit.followthrough.meter

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.os.Process
import androidx.core.graphics.drawable.toBitmap
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.AppShare
import com.orbit.followthrough.domain.Bytes
import java.time.LocalDateTime
import java.time.ZoneId
import java.util.concurrent.ConcurrentHashMap

/** One app's share of the usage on the target network. */
data class AppUse(val key: String, val label: String, val pkg: String?, val bytes: Bytes)

/**
 * Per-app usage on the target network (like GlassWire), built from Android's per-app Wi‑Fi
 * records and our exact per-hour count – see [AppShare]. Needs "usage access".
 */
object AppStats {
    /** Finished slots never change: cache them. */
    private val slotCache = ConcurrentHashMap<Long, Map<String, Bytes>>()
    private val labelCache = ConcurrentHashMap<Int, Pair<String, String?>>()
    private val iconCache = ConcurrentHashMap<String, Bitmap>()

    @Suppress("DEPRECATION")
    private fun appsInSlot(context: Context, slot: Long): Map<String, Bytes> {
        val now = System.currentTimeMillis()
        val finished = slot + AppShare.SLOT_MS < now - 5 * 60_000L
        if (finished) slotCache[slot]?.let { return it }
        val nsm = context.getSystemService(NetworkStatsManager::class.java) ?: return emptyMap()
        val out = HashMap<String, Bytes>()
        runCatching {
            val stats = nsm.querySummary(ConnectivityManager.TYPE_WIFI, null, slot, slot + AppShare.SLOT_MS)
            try {
                val b = NetworkStats.Bucket()
                while (stats.hasNextBucket()) {
                    stats.getNextBucket(b)
                    val key = "u" + b.uid
                    out[key] = (out[key] ?: Bytes.ZERO) + Bytes(b.rxBytes.coerceAtLeast(0), b.txBytes.coerceAtLeast(0))
                }
            } finally {
                stats.close()
            }
        }
        if (finished && out.isNotEmpty()) slotCache[slot] = out
        return out
    }

    private fun hourStart(key: String, zone: ZoneId): Long? =
        runCatching { LocalDateTime.parse("$key:00").atZone(zone).toInstant().toEpochMilli() }.getOrNull()

    /** Apps between [from] and [to] (millis), biggest first. Empty without usage access. */
    fun forRange(context: Context, from: Long, to: Long): List<AppUse> {
        if (!NetHistory.hasAccess(context)) return emptyList()
        val zone = ZoneId.systemDefault()
        val hourly = HashMap<Long, Bytes>()
        for ((k, v) in UsageStore(context).hours()) {
            val h = hourStart(k, zone) ?: continue
            if (h >= from && h < to) hourly[h] = v
        }
        val target = AppShare.slots(hourly)
        val apps = target.keys.associateWith { appsInSlot(context, it) }
        val split = AppShare.split(target, apps)
        val grouped = HashMap<String, AppUse>()
        for ((key, bytes) in split) {
            val (label, pkg) = if (key == AppShare.UNKNOWN) ("مش معروف لسه" to null) else labelOf(context, key.removePrefix("u").toIntOrNull() ?: -1)
            val g = pkg ?: label
            val cur = grouped[g]
            grouped[g] = if (cur == null) AppUse(g, label, pkg, bytes) else cur.copy(bytes = cur.bytes + bytes)
        }
        return grouped.values.sortedByDescending { it.bytes.total }
    }

    /** Friendly name and package for a uid. */
    fun labelOf(context: Context, uid: Int): Pair<String, String?> = labelCache.getOrPut(uid) {
        when (uid) {
            NetworkStats.Bucket.UID_REMOVED -> "تطبيقات اتمسحت" to null
            NetworkStats.Bucket.UID_TETHERING -> "مشاركة الإنترنت (Hotspot)" to null
            Process.SYSTEM_UID, 0 -> "نظام أندرويد" to null
            else -> {
                val pm = context.packageManager
                val pkgs = runCatching { pm.getPackagesForUid(uid) }.getOrNull().orEmpty()
                val pkg = pkgs.firstOrNull()
                if (pkg == null) "تطبيق نظام" to null
                else {
                    val label = runCatching {
                        pm.getApplicationLabel(pm.getApplicationInfo(pkg, PackageManager.GET_META_DATA)).toString()
                    }.getOrNull() ?: pkg
                    (if (pkgs.size > 1) "$label وغيره" else label) to pkg
                }
            }
        }
    }

    fun icon(context: Context, pkg: String): Bitmap? = iconCache[pkg] ?: runCatching {
        context.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).also { iconCache[pkg] = it }
    }.getOrNull()
}
