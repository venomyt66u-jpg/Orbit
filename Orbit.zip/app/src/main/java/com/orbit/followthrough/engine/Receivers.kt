package com.orbit.followthrough.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.orbit.followthrough.OrbitApp
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Runs [block] off the main thread while keeping the broadcast alive (goAsync, < 10 s budget). */
private fun BroadcastReceiver.work(context: Context, block: suspend (OrbitApp) -> Unit) {
    val app = context.applicationContext as OrbitApp
    val pending = goAsync()
    app.container.appScope.launch {
        try {
            withTimeoutOrNull(9_000) { block(app) }
        } finally {
            pending.finish()
        }
    }
}

/** Fires when a reminder occurrence / follow-up or a habit reminder is due. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(OrbitIntents.EXTRA_ID, -1L)
        if (id < 0) return
        when (intent.action) {
            OrbitIntents.ALARM_REMINDER -> work(context) { it.container.reminderEngine.onAlarm(id) }
            OrbitIntents.ALARM_HABIT -> work(context) { it.container.habitEngine.onAlarm(id) }
        }
    }
}

/** Notification actions: Complete / Later / Skip / dismissed, and habit quick actions. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(OrbitIntents.EXTRA_ID, -1L)
        if (id < 0) return
        val minutes = intent.getIntExtra(OrbitIntents.EXTRA_MINUTES, 10)
        when (intent.action) {
            OrbitIntents.COMPLETE -> work(context) { it.container.reminderEngine.complete(id) }
            OrbitIntents.SKIP -> work(context) { it.container.reminderEngine.skip(id) }
            OrbitIntents.SNOOZE -> work(context) { it.container.reminderEngine.snooze(id, minutes) }
            OrbitIntents.DISMISS -> work(context) { it.container.reminderEngine.onDismissed(id) }
            OrbitIntents.HABIT_PLUS -> work(context) {
                it.container.habitEngine.add(id, 1)
                it.container.notifier.cancelHabit(id)
            }
            OrbitIntents.HABIT_DONE -> work(context) { it.container.habitEngine.markDone(id) }
        }
    }
}

/** Reboot, clock / time-zone change, app update, exact-alarm permission change → reschedule. */
class SystemEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED" -> work(context) {
                it.container.reminderEngine.rescheduleAll()
                it.container.habitEngine.rescheduleAll()
                com.orbit.followthrough.watch.WatchRunner.reschedule(it.container)
            }
        }
    }
}
