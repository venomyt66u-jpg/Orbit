package com.orbit.followthrough.wallets

import com.orbit.followthrough.data.db.WalletActivityEntity
import com.orbit.followthrough.data.db.WalletDao
import com.orbit.followthrough.data.db.WalletEntity
import com.orbit.followthrough.data.prefs.SecretStore
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.market.MarketRepository
import com.orbit.followthrough.net.Http
import com.orbit.followthrough.notify.Notifier
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.util.Locale

enum class ChainKind { EVM, BITCOIN, SOLANA }

/** Which free explorer API serves a chain. Blockscout: one free key for many chains. Etherscan: free key, some chains paid. */
enum class ExplorerApi { BLOCKSCOUT, ETHERSCAN, NONE }

/**
 * Supported networks. [ALL_EVM] watches one 0x address on every EVM network at once
 * (the same address exists on all of them), so a mint on any chain is caught.
 */
enum class Chain(
    val label: String,
    val kind: ChainKind,
    val chainId: Int?,
    val native: String,
    val explorerTx: String,
    val explorerAddress: String,
    val api: ExplorerApi,
    val inAllEvm: Boolean,
) {
    ALL_EVM("All EVM networks", ChainKind.EVM, null, "ETH", "", "https://blockscan.com/address/", ExplorerApi.NONE, false),
    ETHEREUM("Ethereum", ChainKind.EVM, 1, "ETH", "https://etherscan.io/tx/", "https://etherscan.io/address/", ExplorerApi.BLOCKSCOUT, true),
    BASE("Base", ChainKind.EVM, 8453, "ETH", "https://basescan.org/tx/", "https://basescan.org/address/", ExplorerApi.BLOCKSCOUT, true),
    ROBINHOOD("Robinhood Chain", ChainKind.EVM, 4663, "ETH", "https://robinhoodchain.blockscout.com/tx/", "https://robinhoodchain.blockscout.com/address/", ExplorerApi.BLOCKSCOUT, true),
    ARBITRUM("Arbitrum", ChainKind.EVM, 42161, "ETH", "https://arbiscan.io/tx/", "https://arbiscan.io/address/", ExplorerApi.BLOCKSCOUT, true),
    OPTIMISM("Optimism", ChainKind.EVM, 10, "ETH", "https://optimistic.etherscan.io/tx/", "https://optimistic.etherscan.io/address/", ExplorerApi.BLOCKSCOUT, true),
    POLYGON("Polygon", ChainKind.EVM, 137, "POL", "https://polygonscan.com/tx/", "https://polygonscan.com/address/", ExplorerApi.BLOCKSCOUT, true),
    ZORA("Zora", ChainKind.EVM, 7777777, "ETH", "https://explorer.zora.energy/tx/", "https://explorer.zora.energy/address/", ExplorerApi.BLOCKSCOUT, true),
    SCROLL("Scroll", ChainKind.EVM, 534352, "ETH", "https://scrollscan.com/tx/", "https://scrollscan.com/address/", ExplorerApi.BLOCKSCOUT, true),
    BSC("BNB Chain", ChainKind.EVM, 56, "BNB", "https://bscscan.com/tx/", "https://bscscan.com/address/", ExplorerApi.ETHERSCAN, true),
    BITCOIN("Bitcoin", ChainKind.BITCOIN, null, "BTC", "https://mempool.space/tx/", "https://mempool.space/address/", ExplorerApi.NONE, false),
    SOLANA("Solana", ChainKind.SOLANA, null, "SOL", "https://solscan.io/tx/", "https://solscan.io/account/", ExplorerApi.NONE, false);

    val needsKey: Boolean get() = kind == ChainKind.EVM

    companion object {
        fun of(name: String): Chain = entries.firstOrNull { it.name == name } ?: ETHEREUM
        val evmNetworks: List<Chain> get() = entries.filter { it.inAllEvm }
    }
}

object AddressRules {
    private val evm = Regex("^0x[a-fA-F0-9]{40}$")
    private val btc = Regex("^(bc1[a-z0-9]{25,87}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$")
    private val sol = Regex("^[1-9A-HJ-NP-Za-km-z]{32,44}$")

    fun valid(chain: Chain, address: String): Boolean = when (chain.kind) {
        ChainKind.EVM -> evm.matches(address)
        ChainKind.BITCOIN -> btc.matches(address)
        ChainKind.SOLANA -> sol.matches(address)
    }

    /** Guess the chain family from an address the user pasted (0x → all EVM networks). */
    fun guess(address: String): Chain? = when {
        evm.matches(address) -> Chain.ALL_EVM
        btc.matches(address) -> Chain.BITCOIN
        sol.matches(address) -> Chain.SOLANA
        else -> null
    }
}

private data class RawTx(val hash: String, val at: Long, val transfers: List<Transfer>, val chain: Chain)

/** Progress marker for multi-network wallets, stored in WalletEntity.cursor. */
private data class MultiCursor(val ts: Long, val active: Set<Int>, val lastFullSweep: Long) {
    fun encode(): String = JSONObject().put("ts", ts).put("active", JSONArray(active.toList())).put("full", lastFullSweep).toString()

    companion object {
        fun decode(raw: String?): MultiCursor? {
            if (raw == null || !raw.startsWith("{")) return null
            return runCatching {
                val o = JSONObject(raw)
                val arr = o.optJSONArray("active") ?: JSONArray()
                MultiCursor(o.optLong("ts"), (0 until arr.length()).map { arr.getInt(it) }.toSet(), o.optLong("full"))
            }.getOrNull()
        }
    }
}

/**
 * Watches public wallets and explains what they did: minted, bought, sold, swapped, received, sent.
 * The first check stores recent history silently; only later activity notifies.
 */
class WalletRepository(
    private val dao: WalletDao,
    private val secrets: SecretStore,
    private val settings: SettingsRepository,
    private val market: MarketRepository,
    private val notifier: Notifier,
) {
    companion object {
        private const val ZERO = "0x0000000000000000000000000000000000000000"
        /** In live mode a multi-network wallet is checked at most this often (keeps within free API credits). */
        private const val MULTI_MIN_INTERVAL_MS = 4 * 60_000L
        /** Every 6 h all networks are swept to discover chains the wallet started using. */
        private const val FULL_SWEEP_MS = 6 * 60 * 60_000L
    }

    suspend fun add(name: String, chain: Chain, address: String, minUsd: Double): Long {
        val id = dao.insert(WalletEntity(name = name.trim(), address = address.trim(), chain = chain.name, minUsd = minUsd))
        dao.get(id)?.let { check(it, force = true) }
        return id
    }

    suspend fun update(w: WalletEntity) = dao.update(w)

    suspend fun delete(id: Long) {
        dao.deleteActivity(id)
        dao.deleteRow(id)
    }

    suspend fun checkAll(): Int {
        var fresh = 0
        for (w in dao.enabled()) fresh += check(w)
        return fresh
    }

    /** Networks usable right now for EVM tracking, given which free keys the user added. */
    fun availableEvm(): List<Chain> {
        val bs = secrets.has(SecretStore.Key.BLOCKSCOUT)
        val es = secrets.has(SecretStore.Key.ETHERSCAN)
        return Chain.evmNetworks.filter { c ->
            when (c.api) {
                ExplorerApi.BLOCKSCOUT -> bs || (es && c in setOf(Chain.ETHEREUM, Chain.ARBITRUM, Chain.POLYGON))
                ExplorerApi.ETHERSCAN -> es
                ExplorerApi.NONE -> false
            }
        }
    }

    /** @return number of NEW activities found. */
    suspend fun check(w: WalletEntity, force: Boolean = false): Int {
        val chain = Chain.of(w.chain)
        val now = System.currentTimeMillis()
        if (chain == Chain.ALL_EVM && !force && w.lastCheckedAt != null && now - w.lastCheckedAt < MULTI_MIN_INTERVAL_MS) return 0
        return try {
            val multi = MultiCursor.decode(w.cursor)
            val firstRun = w.cursor == null
            var nextCursor: String
            val txs: List<RawTx>
            val cursorTs: Long
            if (chain == Chain.ALL_EVM) {
                val networks = availableEvm()
                if (networks.isEmpty()) throw IllegalStateException("Add a free Blockscout API key")
                val fullSweep = multi == null || now - multi.lastFullSweep > FULL_SWEEP_MS
                val targets = if (fullSweep) networks else networks.filter { it.chainId in multi!!.active }
                val found = ArrayList<RawTx>()
                val active = HashSet<Int>(multi?.active ?: emptySet())
                for (n in targets) {
                    val r = runCatching { evm(n, w.address, light = true) }.getOrNull() ?: continue
                    if (r.isNotEmpty()) n.chainId?.let { active += it }
                    found += r
                }
                txs = found
                cursorTs = multi?.ts ?: 0L
                val newest = found.maxOfOrNull { it.at } ?: cursorTs
                nextCursor = MultiCursor(maxOf(newest, cursorTs), active, if (fullSweep) now else multi!!.lastFullSweep).encode()
            } else {
                txs = when (chain.kind) {
                    ChainKind.EVM -> evm(chain, w.address, light = false)
                    ChainKind.BITCOIN -> bitcoin(w.address)
                    ChainKind.SOLANA -> solana(w.address, w.cursor)
                }
                cursorTs = w.cursor?.toLongOrNull() ?: 0L
                nextCursor = (txs.maxOfOrNull { it.at } ?: cursorTs.takeIf { it > 0 } ?: now).toString()
            }

            val prices = runCatching { market.priceBySymbol() }.getOrDefault(emptyMap())
            val candidates = txs
                .filter { firstRun || it.at >= cursorTs }
                .sortedByDescending { it.at }
                .take(if (firstRun) 20 else 30)
                .map { tx ->
                    val c = ActivityClassifier.classify(tx.transfers)
                    WalletActivityEntity(
                        walletId = w.id, txHash = tx.hash, kind = c.kind.name,
                        inSymbol = c.inSymbol, inAmount = c.inAmount, outSymbol = c.outSymbol, outAmount = c.outAmount,
                        valueUsd = ActivityClassifier.estimateUsd(c) { prices[it] },
                        at = tx.at, discoveredAt = now, read = firstRun, explorerUrl = tx.chain.explorerTx + tx.hash,
                        chain = tx.chain.name,
                    )
                }
            val ids = dao.insertActivity(candidates)
            val inserted = candidates.zip(ids).filter { it.second != -1L }.map { it.first.copy(id = it.second) }
            val newest = txs.maxOfOrNull { it.at }
            dao.update(
                w.copy(
                    cursor = nextCursor,
                    lastCheckedAt = now,
                    lastActivityAt = maxOf(w.lastActivityAt ?: 0L, newest ?: 0L).takeIf { it > 0 },
                    status = "OK", lastError = null,
                )
            )
            if (!firstRun && w.notify) {
                val worth = inserted.filter { a -> a.kind != ActivityKind.CONTRACT.name }
                    // Mints always notify; other moves respect the minimum value.
                    .filter { a -> a.kind == ActivityKind.MINT.name || w.minUsd <= 0 || (a.valueUsd ?: Double.MAX_VALUE) >= w.minUsd }
                worth.sortedBy { it.at }.takeLast(5).forEach { a -> notifier.showWalletActivity(w, a, Chain.of(a.chain.ifBlank { w.chain }), settings.current()) }
            }
            if (firstRun) 0 else inserted.size
        } catch (e: Exception) {
            dao.update(w.copy(lastCheckedAt = now, status = "ERROR", lastError = Http.reason(e)))
            0
        }
    }

    // ---------------------------------------------------------------- EVM (Blockscout PRO API / Etherscan V2)

    private fun accountUrl(chain: Chain, action: String, address: String): String? {
        val q = "module=account&action=$action&address=$address&page=1&offset=40&sort=desc"
        val bs = secrets.get(SecretStore.Key.BLOCKSCOUT)
        val es = secrets.get(SecretStore.Key.ETHERSCAN)
        return when {
            chain.api == ExplorerApi.BLOCKSCOUT && bs != null ->
                "https://api.blockscout.com/v2/api?chain_id=${chain.chainId}&chainid=${chain.chainId}&$q&apikey=$bs"
            es != null -> "https://api.etherscan.io/v2/api?chainid=${chain.chainId}&$q&apikey=$es"
            else -> null
        }
    }

    /**
     * Collects native, internal, ERC-20, ERC-721 and ERC-1155 movements and groups them per transaction.
     * [light] skips internal transactions (used for multi-network sweeps to save API credits).
     */
    private suspend fun evm(chain: Chain, address: String, light: Boolean): List<RawTx> {
        if (accountUrl(chain, "txlist", address) == null) {
            throw IllegalStateException(if (chain.api == ExplorerApi.BLOCKSCOUT) "Add a free Blockscout API key" else "${chain.label} needs an Etherscan API key")
        }
        val me = address.lowercase(Locale.ROOT)
        suspend fun list(action: String, optional: Boolean): JSONArray {
            val url = accountUrl(chain, action, address) ?: return JSONArray()
            return if (optional) runCatching { explorerList(url) }.getOrDefault(JSONArray()) else explorerList(url)
        }
        val normal = list("txlist", optional = false)
        val tokens = list("tokentx", optional = true)
        val nfts = list("tokennfttx", optional = true)
        val multi = list("token1155tx", optional = true)
        val internal = if (light) JSONArray() else list("txlistinternal", optional = true)

        val grouped = LinkedHashMap<String, Pair<Long, MutableList<Transfer>>>()
        fun add(hash: String, ts: Long, t: Transfer?) {
            val entry = grouped.getOrPut(hash) { ts to mutableListOf() }
            if (t != null) entry.second += t
        }
        fun ts(o: JSONObject) = (o.optString("timeStamp").toLongOrNull() ?: 0L) * 1000
        val seenNft = HashSet<String>()

        for (i in 0 until nfts.length()) {
            val o = nfts.getJSONObject(i)
            val key = o.optString("hash") + ":" + o.optString("tokenID") + ":" + o.optString("contractAddress")
            seenNft += key
            val sym = o.optString("tokenSymbol").ifBlank { o.optString("tokenName").ifBlank { "NFT" } }
            add(o.getString("hash"), ts(o), Transfer(sym, 1.0, o.optString("to").lowercase(Locale.ROOT) == me, nft = true, fromZero = o.optString("from").lowercase(Locale.ROOT) == ZERO))
        }
        for (i in 0 until multi.length()) {
            val o = multi.getJSONObject(i)
            val sym = o.optString("tokenSymbol").ifBlank { o.optString("tokenName").ifBlank { "NFT" } }
            val qty = o.optString("tokenValue").toDoubleOrNull() ?: o.optString("value").toDoubleOrNull() ?: 1.0
            add(o.getString("hash"), ts(o), Transfer(sym, qty, o.optString("to").lowercase(Locale.ROOT) == me, nft = true, fromZero = o.optString("from").lowercase(Locale.ROOT) == ZERO))
        }
        for (i in 0 until tokens.length()) {
            val o = tokens.getJSONObject(i)
            val tokenId = o.optString("tokenID")
            val isNft = tokenId.isNotBlank() && o.optString("tokenDecimal").let { it.isBlank() || it == "0" }
            if (isNft && (o.optString("hash") + ":" + tokenId + ":" + o.optString("contractAddress")) in seenNft) continue
            val dec = o.optString("tokenDecimal").toIntOrNull() ?: 18
            val amount = if (isNft) 1.0 else runCatching { BigDecimal(o.optString("value", "0")).movePointLeft(dec).toDouble() }.getOrDefault(0.0)
            val sym = o.optString("tokenSymbol").ifBlank { "TOKEN" }
            add(o.getString("hash"), ts(o), Transfer(sym, amount, o.optString("to").lowercase(Locale.ROOT) == me, nft = isNft, fromZero = o.optString("from").lowercase(Locale.ROOT) == ZERO))
        }
        for (i in 0 until normal.length()) {
            val o = normal.getJSONObject(i)
            if (o.optString("isError") == "1") continue
            val wei = runCatching { BigDecimal(o.optString("value", "0")) }.getOrDefault(BigDecimal.ZERO)
            val t = if (wei.signum() > 0) Transfer(chain.native, wei.movePointLeft(18).toDouble(), o.optString("to").lowercase(Locale.ROOT) == me) else null
            add(o.getString("hash"), ts(o), t)
        }
        for (i in 0 until internal.length()) {
            val o = internal.getJSONObject(i)
            val wei = runCatching { BigDecimal(o.optString("value", "0")) }.getOrDefault(BigDecimal.ZERO)
            if (wei.signum() <= 0) continue
            add(o.getString("hash"), ts(o), Transfer(chain.native, wei.movePointLeft(18).toDouble(), o.optString("to").lowercase(Locale.ROOT) == me))
        }
        return grouped.map { (hash, v) -> RawTx(hash, v.first, v.second, chain) }
    }

    private suspend fun explorerList(url: String): JSONArray {
        val o = JSONObject(Http.get(url))
        val result = o.opt("result")
        if (o.optString("status") == "1" && result is JSONArray) return result
        val msg = o.optString("message")
        // "No transactions found" is a normal empty answer.
        if (msg.startsWith("No ", ignoreCase = true) || (result is JSONArray && result.length() == 0)) return JSONArray()
        throw IllegalStateException((result as? String)?.take(140) ?: msg.ifBlank { "explorer error" })
    }

    // ---------------------------------------------------------------- Bitcoin (mempool.space, no key)

    private suspend fun bitcoin(address: String): List<RawTx> {
        val arr = JSONArray(Http.get("https://mempool.space/api/address/$address/txs"))
        return (0 until arr.length()).map { i ->
            val tx = arr.getJSONObject(i)
            var delta = 0L
            val vin = tx.getJSONArray("vin")
            for (j in 0 until vin.length()) {
                val prev = vin.getJSONObject(j).optJSONObject("prevout") ?: continue
                if (prev.optString("scriptpubkey_address") == address) delta -= prev.optLong("value")
            }
            val vout = tx.getJSONArray("vout")
            for (j in 0 until vout.length()) {
                val o = vout.getJSONObject(j)
                if (o.optString("scriptpubkey_address") == address) delta += o.optLong("value")
            }
            val status = tx.optJSONObject("status")
            val at = status?.optLong("block_time")?.takeIf { it > 0 }?.times(1000) ?: System.currentTimeMillis()
            val transfers = if (delta == 0L) emptyList() else listOf(Transfer("BTC", kotlin.math.abs(delta) / 1e8, delta > 0))
            RawTx(tx.getString("txid"), at, transfers, Chain.BITCOIN)
        }
    }

    // ---------------------------------------------------------------- Solana (public RPC, no key)

    private val knownMints = mapOf(
        "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" to "USDC",
        "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB" to "USDT",
        "So11111111111111111111111111111111111111112" to "WSOL",
        "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" to "BONK",
        "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN" to "JUP",
        "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm" to "WIF",
    )

    private suspend fun rpc(method: String, params: JSONArray): JSONObject {
        val body = JSONObject().put("jsonrpc", "2.0").put("id", 1).put("method", method).put("params", params)
        val res = JSONObject(Http.postJson("https://api.mainnet-beta.solana.com", body.toString()))
        res.optJSONObject("error")?.let { throw IllegalStateException(it.optString("message")) }
        return res
    }

    private suspend fun solana(address: String, cursor: String?): List<RawTx> {
        val sigs = rpc("getSignaturesForAddress", JSONArray().put(address).put(JSONObject().put("limit", 10))).getJSONArray("result")
        val result = ArrayList<RawTx>()
        val since = cursor?.toLongOrNull() ?: 0L
        var details = 0
        for (i in 0 until sigs.length()) {
            val s = sigs.getJSONObject(i)
            if (!s.isNull("err")) continue
            val at = s.optLong("blockTime") * 1000
            val sig = s.getString("signature")
            // Parse at most 5 new transactions per check (public RPC is rate limited).
            if (since > 0 && at < since) continue
            if (details >= 5) { result += RawTx(sig, at, emptyList(), Chain.SOLANA); continue }
            details++
            val tx = runCatching {
                rpc("getTransaction", JSONArray().put(sig).put(JSONObject().put("encoding", "jsonParsed").put("maxSupportedTransactionVersion", 0)))
                    .optJSONObject("result")
            }.getOrNull()
            result += RawTx(sig, at, if (tx == null) emptyList() else solanaTransfers(tx, address), Chain.SOLANA)
        }
        return result
    }

    private fun solanaTransfers(tx: JSONObject, address: String): List<Transfer> {
        val meta = tx.optJSONObject("meta") ?: return emptyList()
        val keys = tx.optJSONObject("transaction")?.optJSONObject("message")?.optJSONArray("accountKeys") ?: return emptyList()
        val out = ArrayList<Transfer>()
        for (i in 0 until keys.length()) {
            val k = keys.get(i)
            val pub = if (k is JSONObject) k.optString("pubkey") else k.toString()
            if (pub == address) {
                val pre = meta.optJSONArray("preBalances")?.optLong(i) ?: 0L
                val post = meta.optJSONArray("postBalances")?.optLong(i) ?: 0L
                val fee = if (i == 0) meta.optLong("fee") else 0L
                val d = post - pre + fee
                if (kotlin.math.abs(d) > 10_000) out += Transfer("SOL", kotlin.math.abs(d) / 1e9, d > 0)
            }
        }
        fun balances(field: String): Map<String, Double> {
            val m = HashMap<String, Double>()
            val arr = meta.optJSONArray(field) ?: return m
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                if (b.optString("owner") != address) continue
                val ui = b.optJSONObject("uiTokenAmount")?.optDouble("uiAmount") ?: continue
                if (ui.isNaN()) continue
                m[b.getString("mint")] = (m[b.getString("mint")] ?: 0.0) + ui
            }
            return m
        }
        val pre = balances("preTokenBalances")
        val post = balances("postTokenBalances")
        for (mint in pre.keys + post.keys) {
            val d = (post[mint] ?: 0.0) - (pre[mint] ?: 0.0)
            if (kotlin.math.abs(d) < 1e-12) continue
            val sym = knownMints[mint] ?: (mint.take(4) + "…" + mint.takeLast(3))
            out += Transfer(sym, kotlin.math.abs(d), d > 0)
        }
        return out
    }

    /** Text for the AI explanation of a wallet's recent behaviour (public on-chain data only). */
    suspend fun aiContext(since: Long): String {
        val wallets = dao.enabled().associateBy { it.id }
        return dao.recentSince(since, 40).joinToString("\n") { a ->
            val w = wallets[a.walletId]
            "${w?.name ?: "wallet"} (${a.chain.ifBlank { w?.chain ?: "" }}): ${a.kind} in=${a.inAmount} ${a.inSymbol} out=${a.outAmount} ${a.outSymbol} usd=${a.valueUsd}"
        }
    }
}
