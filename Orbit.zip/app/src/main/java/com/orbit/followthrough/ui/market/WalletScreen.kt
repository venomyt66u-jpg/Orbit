package com.orbit.followthrough.ui.market

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.WalletActivityEntity
import com.orbit.followthrough.data.db.WalletEntity
import com.orbit.followthrough.domain.Numbers
import com.orbit.followthrough.net.Http
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitSwitch
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.SettingRow
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.nav.LocalAppContainer
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import com.orbit.followthrough.wallets.Chain
import com.orbit.followthrough.watch.WatchRunner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class WalletViewModel(val c: AppContainer, val id: Long) : ViewModel() {
    val wallet: StateFlow<WalletEntity?> = c.db.wallets().observe(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val activity: StateFlow<List<WalletActivityEntity>?> = c.db.wallets().observeActivity(id, 100).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val checking = MutableStateFlow(false)
    val explain = MutableStateFlow<AiBrief>(AiBrief())

    init { viewModelScope.launch { c.db.wallets().markRead(id) } }

    fun checkNow() = viewModelScope.launch {
        val w = c.db.wallets().get(id) ?: return@launch
        checking.value = true
        try { c.wallets.check(w, force = true) } finally { checking.value = false }
    }

    fun update(block: WalletEntity.() -> WalletEntity) = viewModelScope.launch {
        val w = c.db.wallets().get(id) ?: return@launch
        c.wallets.update(w.block())
        WatchRunner.reschedule(c)
    }

    fun delete(onDone: () -> Unit) = viewModelScope.launch {
        c.wallets.delete(id)
        WatchRunner.reschedule(c)
        onDone()
    }

    fun explainAi() = viewModelScope.launch {
        val s = c.settings.current()
        if (!c.ai.ready(s)) { explain.value = AiBrief(error = "connect"); return@launch }
        val w = c.db.wallets().get(id) ?: return@launch
        val acts = activity.value.orEmpty().take(30).joinToString("\n") { a ->
            "${a.kind} on ${a.chain} in=${a.inAmount} ${a.inSymbol} out=${a.outAmount} ${a.outSymbol} usd=${a.valueUsd} at=${a.at}"
        }
        if (acts.isBlank()) { explain.value = AiBrief(text = null, error = null); return@launch }
        explain.value = AiBrief(loading = true)
        c.ai.explainWallets(s, "Wallet \"${w.name}\" on ${Chain.of(w.chain).label}:\n$acts").fold(
            onSuccess = { explain.value = AiBrief(text = it) },
            onFailure = { explain.value = AiBrief(error = Http.reason(it)) },
        )
    }
}

@Composable
fun WalletScreen(nav: NavHostController, id: Long) {
    val vm = orbitViewModel(key = "wallet$id") { WalletViewModel(it, id) }
    val wallet by vm.wallet.collectAsStateWithLifecycle()
    val activity by vm.activity.collectAsStateWithLifecycle()
    val checking by vm.checking.collectAsStateWithLifecycle()
    val explain by vm.explain.collectAsStateWithLifecycle()
    val container = LocalAppContainer.current
    val highlight by container.highlight.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val ctx = LocalContext.current
    val listState = rememberLazyListState()
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var hlId by remember { mutableStateOf<Long?>(null) }

    // Notification tap → scroll to and highlight that exact transaction.
    LaunchedEffect(highlight, activity) {
        val h = highlight
        val list = activity
        if (h != null && h.first == "activity" && list != null) {
            val target = h.second.toLongOrNull()
            val index = list.indexOfFirst { it.id == target }
            if (index >= 0) {
                hlId = target
                listState.animateScrollToItem(index + 3)
                container.highlight.value = null
            }
        }
    }

    val w = wallet
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp), state = listState, contentPadding = PaddingValues(bottom = 40.dp)) {
        item {
            TopBar(w?.name ?: "", { nav.popBackStack() }, stringResource(R.string.back)) {
                IconCircle(OrbitIcons.Edit, stringResource(R.string.rename), { rename = true })
            }
        }
        if (w != null) {
            val chain = Chain.of(w.chain)
            item {
                GlassCard(Modifier.fillMaxWidth(), highlight = c.violet) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GlyphBadge(OrbitIcons.Wallet, c.violet, size = 48.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(w.name, style = OrbitType.title, color = c.text)
                            Tag(chainLabel(chain), if (chain == Chain.ALL_EVM) c.gold else c.violet)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(w.address, style = OrbitType.caption.copy(fontFeatureSettings = "tnum"), color = c.textSecondary)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OrbitChip(stringResource(R.string.copy), false, { copy(ctx, w.address) }, icon = OrbitIcons.Copy)
                        OrbitChip(stringResource(R.string.open_explorer), false, {
                            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(chain.explorerAddress + w.address)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        }, icon = OrbitIcons.External)
                        OrbitChip(stringResource(if (checking) R.string.checking else R.string.check_now), checking, { vm.checkNow() }, icon = OrbitIcons.Refresh)
                    }
                    Text(
                        if (w.status == "ERROR") stringResource(R.string.status_error, w.lastError ?: "?")
                        else w.lastCheckedAt?.let { stringResource(R.string.status_ok, Fmt.ago(it)) } ?: stringResource(R.string.status_never),
                        style = OrbitType.caption, color = if (w.status == "ERROR") c.amber else c.textMuted, modifier = Modifier.padding(top = 10.dp),
                    )
                }
            }
            item {
                GlassCard(Modifier.fillMaxWidth().padding(top = 14.dp)) {
                    SettingRow(stringResource(R.string.wallet_notify), subtitle = stringResource(R.string.wallet_notify_hint), icon = OrbitIcons.Bell, onClick = { vm.update { copy(notify = !notify) } }) {
                        OrbitSwitch(w.notify) { v -> vm.update { copy(notify = v) } }
                    }
                    Text(stringResource(R.string.notify_min_value), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.0, 100.0, 1_000.0, 10_000.0, 100_000.0).forEach { v ->
                            OrbitChip(if (v == 0.0) stringResource(R.string.any_amount) else Numbers.compact(v, "$") + "+", w.minUsd == v, { vm.update { copy(minUsd = v) } })
                        }
                    }
                    SettingRow(stringResource(R.string.wallet_enabled), icon = OrbitIcons.Radar, onClick = { vm.update { copy(enabled = !enabled) } }) {
                        OrbitSwitch(w.enabled) { v -> vm.update { copy(enabled = v) } }
                    }
                }
            }
            item {
                GlassCard(Modifier.fillMaxWidth().padding(top = 14.dp), highlight = c.violet) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.ai_wallet_title), style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f))
                        if (!explain.loading) OrbitChip(stringResource(R.string.generate), false, { vm.explainAi() }, icon = OrbitIcons.Spark, accent = c.violet)
                    }
                    when {
                        explain.loading -> Text(stringResource(R.string.thinking), style = OrbitType.body, color = c.textMuted, modifier = Modifier.padding(top = 8.dp))
                        explain.error == "connect" -> Text(stringResource(R.string.ai_connect_hint), style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp))
                        explain.error != null -> Text(stringResource(R.string.ai_error, explain.error ?: ""), style = OrbitType.caption, color = c.amber, modifier = Modifier.padding(top = 8.dp))
                        explain.text != null -> Text(explain.text ?: "", style = OrbitType.body, color = c.text, modifier = Modifier.padding(top = 8.dp))
                        else -> Text(stringResource(R.string.ai_wallet_hint), style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            item { SectionHeader(stringResource(R.string.activity), Modifier.padding(top = 18.dp)) }
            val list = activity.orEmpty()
            if (activity != null && list.isEmpty()) {
                item { Text(stringResource(R.string.no_activity_yet), style = OrbitType.body, color = c.textMuted) }
            }
            items(list, key = { it.id }) { a ->
                ActivityRow(a, null, onClick = {
                    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.explorerUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }, highlighted = a.id == hlId)
            }
            item {
                SecondaryButton(stringResource(R.string.stop_tracking), { confirmDelete = true }, Modifier.fillMaxWidth().padding(top = 18.dp).navigationBarsPadding(), icon = OrbitIcons.Trash, tint = c.rose)
            }
        }
    }

    if (rename && w != null) {
        var name by remember { mutableStateOf(w.name) }
        AlertDialog(
            onDismissRequest = { rename = false },
            containerColor = c.surface,
            title = { Text(stringResource(R.string.rename), color = c.text) },
            text = { OrbitTextField(name, { name = it.take(40) }, stringResource(R.string.wallet_name_placeholder), Modifier.fillMaxWidth()) },
            confirmButton = { TextButton(onClick = { if (name.isNotBlank()) vm.update { copy(name = name.trim()) }; rename = false }) { Text(stringResource(R.string.save), color = c.cyan) } },
            dismissButton = { TextButton(onClick = { rename = false }) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = c.surface,
            title = { Text(stringResource(R.string.stop_tracking_q), color = c.text) },
            text = { Text(stringResource(R.string.stop_tracking_body), color = c.textSecondary) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete { nav.popBackStack() } }) { Text(stringResource(R.string.stop_tracking), color = c.rose) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
        )
    }
}

fun copy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java) ?: return
    cm.setPrimaryClip(ClipData.newPlainText("address", text))
}
