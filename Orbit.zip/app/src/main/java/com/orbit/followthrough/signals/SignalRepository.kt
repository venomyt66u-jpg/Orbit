package com.orbit.followthrough.signals

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.orbit.followthrough.OrbitApp
import com.orbit.followthrough.data.db.SignalDao
import com.orbit.followthrough.data.db.SignalItemEntity
import com.orbit.followthrough.data.db.SignalSourceEntity
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.domain.NotifyMode
import com.orbit.followthrough.domain.SourceType
import com.orbit.followthrough.domain.SyncStatus
import com.orbit.followthrough.notify.Notifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

sealed interface SyncOutcome {
    data class Ok(val newItems: Int) : SyncOutcome
    data object NotModified : SyncOutcome
    data class Failed(val message: String) : SyncOutcome
}

/**
 * Signal Feed: authorised, public sources only (RSS/Atom feeds and GitHub release feeds).
 * Private APIs and webhooks require the backend in /backend so no secret is ever shipped in the app.
 */
class SignalRepository(
    private val context: Context,
    private val dao: SignalDao,
    private val settings: SettingsRepository,
    private val notifier: Notifier,
) {
    companion object {
        private const val MAX_BYTES = 2 * 1024 * 1024
        private const val DUPLICATE_WINDOW_MS = 72 * 60 * 60_000L
        const val PERIODIC_WORK = "orbit_signal_sync"

        /** Accepts "owner/repo" or any github.com/owner/repo URL. */
        fun normalizeGithub(input: String): String? {
            val cleaned = input.trim().removePrefix("https://").removePrefix("http://").removePrefix("www.")
                .removePrefix("github.com/").trimEnd('/')
            val parts = cleaned.split('/').filter { it.isNotBlank() }
            if (parts.size < 2) return null
            val ok = Regex("^[A-Za-z0-9_.-]+$")
            return if (parts[0].matches(ok) && parts[1].matches(ok)) "${parts[0]}/${parts[1].removeSuffix(".git")}" else null
        }

        fun feedUrl(source: SignalSourceEntity): String = when (source.type) {
            SourceType.GITHUB -> "https://github.com/${source.target}/releases.atom"
            SourceType.RSS, SourceType.ACCOUNT -> source.target
        }
    }

    suspend fun addSource(name: String, type: SourceType, target: String, notifyMode: NotifyMode): Long {
        val id = dao.insertSource(SignalSourceEntity(name = name.trim(), type = type, target = target.trim(), notifyMode = notifyMode))
        schedulePeriodic()
        return id
    }

    /** Follow a creator/profile link. Returns null on success, or a reason code. */
    suspend fun followAccount(profileUrl: String, displayName: String): String? {
        val (platform, feed, handle) = when (val r = AccountResolver.resolve(profileUrl)) {
            is Resolution.Feed -> Triple(r.platform, r.feedUrl, r.handle)
            is Resolution.NeedsLookup -> {
                val html = runCatching { fetch(r.pageUrl, null, null)?.body?.toString(Charsets.UTF_8) }.getOrNull()
                    ?: return "lookup"
                val id = AccountResolver.youtubeChannelId(html) ?: return "lookup"
                Triple(r.platform, "https://www.youtube.com/feeds/videos.xml?channel_id=$id", r.handle)
            }
            is Resolution.Unsupported -> return "unsupported:" + r.platform.label
            Resolution.Invalid -> return "invalid"
        }
        val name = displayName.trim().ifBlank { "$handle · ${platform.label}" }
        val id = dao.insertSource(SignalSourceEntity(name = name, type = SourceType.ACCOUNT, target = feed, notifyMode = NotifyMode.ALL))
        syncOne(id)
        schedulePeriodic()
        return null
    }

    suspend fun updateSource(s: SignalSourceEntity) {
        dao.updateSource(s)
        schedulePeriodic()
    }

    suspend fun deleteSource(id: Long) {
        dao.deleteItemsOf(id)
        dao.deleteSourceRow(id)
        schedulePeriodic()
    }

    suspend fun syncAll(onlyAccounts: Boolean = false): Map<Long, SyncOutcome> {
        val result = LinkedHashMap<Long, SyncOutcome>()
        val fresh = ArrayList<SignalItemEntity>()
        for (s in dao.enabledSources()) {
            if (onlyAccounts && s.type != SourceType.ACCOUNT) continue
            val (outcome, items) = syncSource(s)
            result[s.id] = outcome
            if (s.type == SourceType.ACCOUNT) {
                if (items.isNotEmpty()) notifier.showAccountPosts(s, items, settings.current())
            } else fresh += items
        }
        if (fresh.isNotEmpty()) notifier.showSignals(fresh, settings.current())
        // Retention: keep 90 days of history.
        dao.deleteItemsOlderThan(System.currentTimeMillis() - 90L * 24 * 60 * 60_000)
        return result
    }

    suspend fun syncOne(id: Long): SyncOutcome {
        val s = dao.source(id) ?: return SyncOutcome.Failed("missing")
        val (outcome, items) = syncSource(s)
        if (items.isNotEmpty()) {
            if (s.type == SourceType.ACCOUNT) notifier.showAccountPosts(s, items, settings.current())
            else notifier.showSignals(items, settings.current())
        }
        return outcome
    }

    /** @return the outcome and the newly discovered items that deserve a notification. */
    private suspend fun syncSource(source: SignalSourceEntity): Pair<SyncOutcome, List<SignalItemEntity>> {
        val now = System.currentTimeMillis()
        val firstSync = source.lastSuccessAt == null
        dao.updateSource(source.copy(status = SyncStatus.SYNCING, lastAttemptAt = now))
        return try {
            val response = fetch(feedUrl(source), source.etag, source.lastModified)
            if (response == null) {
                dao.updateSource(source.copy(status = SyncStatus.OK, lastAttemptAt = now, lastSuccessAt = now, lastError = null))
                return SyncOutcome.NotModified to emptyList<SignalItemEntity>()
            }
            val entries = FeedParser.parse(response.body)
            val keywords = settings.current().signalKeywords
            val candidates = entries.take(60).map { e ->
                val c = SignalClassifier.classify(e.title, e.summary, keywords, source.type == SourceType.GITHUB)
                    .let { if (source.type == SourceType.ACCOUNT) it.copy(importance = maxOf(it.importance, 1), category = SignalClassifier.CAT_POST) else it }
                SignalItemEntity(
                    sourceId = source.id,
                    sourceName = source.name,
                    guid = e.guid.take(500),
                    title = e.title.take(300),
                    titleKey = FeedParser.titleKey(e.title),
                    link = e.link,
                    summary = e.summary,
                    publishedAt = e.publishedAt,
                    discoveredAt = now,
                    importance = c.importance,
                    category = c.category,
                    matchedKeyword = c.matchedKeyword,
                    read = firstSync, // the initial backlog is not "new" to the user
                )
            }
            // Duplicate filter: the same announcement from another source within 72h is dropped.
            val unique = candidates.filter { dao.similarElsewhere(it.titleKey, source.id, now - DUPLICATE_WINDOW_MS) == 0 }
            val ids = dao.insertItems(unique)
            val inserted = unique.zip(ids).filter { it.second != -1L }.map { it.first.copy(id = it.second) }

            dao.updateSource(
                source.copy(
                    status = SyncStatus.OK, lastAttemptAt = now, lastSuccessAt = now, lastError = null,
                    etag = response.etag, lastModified = response.lastModified,
                    itemCount = dao.countFor(source.id),
                )
            )
            val notify: List<SignalItemEntity> = if (firstSync) emptyList() else when (source.notifyMode) {
                NotifyMode.ALL -> inserted
                NotifyMode.IMPORTANT -> inserted.filter { it.importance >= 2 }
                NotifyMode.NONE -> emptyList<SignalItemEntity>()
            }
            SyncOutcome.Ok(inserted.size) to notify
        } catch (e: Exception) {
            val msg = when (e) {
                is java.net.UnknownHostException -> "offline"
                is java.net.SocketTimeoutException -> "timeout"
                is HttpError -> "http ${e.code}"
                is org.xml.sax.SAXException -> "parse"
                is IOException -> "network"
                else -> e.javaClass.simpleName
            }
            dao.updateSource(source.copy(status = SyncStatus.ERROR, lastAttemptAt = now, lastError = msg))
            SyncOutcome.Failed(msg) to emptyList<SignalItemEntity>()
        }
    }

    private class HttpError(val code: Int) : IOException("HTTP $code")
    private class Response(val body: ByteArray, val etag: String?, val lastModified: String?)

    /** Conditional GET (ETag / Last-Modified) so unchanged feeds cost almost nothing. null = 304. */
    private suspend fun fetch(url: String, etag: String?, lastModified: String?): Response? = withContext(Dispatchers.IO) {
        require(url.startsWith("https://") || url.startsWith("http://")) { "bad url" }
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Orbit-Android/1.0 (+signal-feed)")
            setRequestProperty("Accept", "application/rss+xml, application/atom+xml, application/xml;q=0.9, text/xml;q=0.8, */*;q=0.5")
            if (etag != null) setRequestProperty("If-None-Match", etag)
            if (lastModified != null) setRequestProperty("If-Modified-Since", lastModified)
        }
        try {
            val code = conn.responseCode
            if (code == HttpURLConnection.HTTP_NOT_MODIFIED) return@withContext null
            if (code !in 200..299) throw HttpError(code)
            val out = ByteArrayOutputStream()
            conn.inputStream.use { input ->
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_BYTES) break
                }
            }
            Response(out.toByteArray(), conn.getHeaderField("ETag"), conn.getHeaderField("Last-Modified"))
        } finally {
            conn.disconnect()
        }
    }

    /** Background sync only exists while at least one source is enabled – no idle jobs. */
    suspend fun schedulePeriodic() {
        val wm = WorkManager.getInstance(context)
        if (dao.enabledCount() == 0) {
            wm.cancelUniqueWork(PERIODIC_WORK)
            return
        }
        val hours = settings.current().signalSyncHours.coerceIn(1, 24).toLong()
        val request = PeriodicWorkRequestBuilder<SignalSyncWorker>(hours, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).setRequiresBatteryNotLow(true).build())
            .build()
        wm.enqueueUniquePeriodicWork(PERIODIC_WORK, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}

class SignalSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as OrbitApp
        val results = app.container.signals.syncAll()
        val allOffline = results.isNotEmpty() && results.values.all { it is SyncOutcome.Failed && (it.message == "offline" || it.message == "timeout") }
        return if (allOffline && runAttemptCount < 2) Result.retry() else Result.success()
    }
}
