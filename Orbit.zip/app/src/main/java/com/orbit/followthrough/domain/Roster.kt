package com.orbit.followthrough.domain

import java.time.LocalDate

/** A person (slot) taken by a phone (device) at a time. The earliest claim for a slot wins. */
data class Claim(val slot: String, val device: String, val at: Long)

object Claims {

    private fun earlier(a: Claim, b: Claim): Claim = when {
        a.at != b.at -> if (a.at < b.at) a else b
        else -> if (a.device <= b.device) a else b
    }

    fun merge(known: Map<String, Claim>, incoming: Collection<Claim>): Map<String, Claim> {
        val out = LinkedHashMap(known)
        for (c in incoming) {
            if (c.slot.isBlank() || c.device.isBlank()) continue
            val cur = out[c.slot]
            out[c.slot] = if (cur == null) c else earlier(cur, c)
        }
        return out
    }

    /** Slot owned by [device], if any (e.g. after reinstalling on the same phone). */
    fun slotOf(device: String, claims: Map<String, Claim>): String? =
        claims.values.filter { it.device == device }.minByOrNull { it.at }?.slot

    fun takenByOthers(device: String, claims: Map<String, Claim>): Set<String> =
        claims.values.filter { it.device != device }.map { it.slot }.toSet()
}

/**
 * The admin's decision that a person now belongs to a (new) phone – e.g. after the app was
 * reinstalled and Android gave the phone a new identity. The latest decision wins over claims.
 */
data class Assign(val slot: String, val device: String, val at: Long)

object Owners {
    fun mergeAssigns(known: Map<String, Assign>, incoming: Collection<Assign>): Map<String, Assign> {
        val out = LinkedHashMap(known)
        for (a in incoming) {
            if (a.slot.isBlank() || a.device.isBlank()) continue
            val cur = out[a.slot]
            if (cur == null || a.at > cur.at) out[a.slot] = a
        }
        return out
    }

    /** Who owns a person: the admin's latest assignment, otherwise the earliest claim. */
    fun owner(slot: String, claims: Map<String, Claim>, assigns: Map<String, Assign>): String? =
        assigns[slot]?.device ?: claims[slot]?.device

    fun slotOf(device: String, claims: Map<String, Claim>, assigns: Map<String, Assign>): String? {
        val slots = (claims.keys + assigns.keys).distinct()
        return slots.firstOrNull { owner(it, claims, assigns) == device }
    }

    fun takenByOthers(device: String, claims: Map<String, Claim>, assigns: Map<String, Assign>): Set<String> =
        (claims.keys + assigns.keys).filter { val o = owner(it, claims, assigns); o != null && o != device }.toSet()
}

/**
 * Daily usage of one person on the target network, as last reported by their phone.
 * [past] = all Wi‑Fi used before the app was installed (Android does not split it per network).
 */
data class Snapshot(
    val slot: String,
    val device: String,
    val at: Long,
    val days: Map<String, Bytes>,
    val onTarget: Boolean,
    val past: Map<String, Bytes> = emptyMap(),
    /** The package start this phone used for [packageUse] (0 = none). */
    val packageStart: Long = 0,
    val packageUse: Bytes? = null,
    /** Permissions missing on that phone (keys), null = not reported (older version). */
    val missing: List<String>? = null,
    val model: String = "",
    val version: String = "",
    /** Today's usage per hour (24 values) on that phone. */
    val todayHours: List<Long> = emptyList(),
    /** Router looked like the target but the name wasn't readable (permission off), per day. */
    val unverified: Map<String, Bytes> = emptyMap(),
)

object Days {

    fun sum(days: Map<String, Bytes>, from: LocalDate, toExclusive: LocalDate): Bytes {
        var total = Bytes.ZERO
        for ((k, v) in days) {
            val d = runCatching { LocalDate.parse(k) }.getOrNull() ?: continue
            if (!d.isBefore(from) && d.isBefore(toExclusive)) total += v
        }
        return total
    }

    fun range(period: Period, today: LocalDate): Pair<LocalDate, LocalDate> = when (period) {
        Period.TODAY -> today to today.plusDays(1)
        Period.WEEK -> today.minusDays(6) to today.plusDays(1)
        Period.CYCLE, Period.PACKAGE -> today.withDayOfMonth(1) to today.withDayOfMonth(1).plusMonths(1)
    }

    /** Daily values for every day of [month] (zeros included), for charts. */
    fun monthSeries(days: Map<String, Bytes>, month: LocalDate): List<Long> {
        val first = month.withDayOfMonth(1)
        return (0 until first.lengthOfMonth()).map { i -> days[first.plusDays(i.toLong()).toString()]?.total ?: 0L }
    }

    /** Merges reports: for each day keep the value from the newer report (reports are cumulative per day). */
    fun mergeNewer(older: Map<String, Bytes>, newer: Map<String, Bytes>): Map<String, Bytes> {
        val out = LinkedHashMap(older)
        out.putAll(newer)
        return out
    }

    /** Daily totals only grow, so the larger value per day is the right one (survives a phone's data reset). */
    fun mergeMax(a: Map<String, Bytes>, b: Map<String, Bytes>): Map<String, Bytes> {
        val out = LinkedHashMap(a)
        for ((k, v) in b) {
            val cur = out[k]
            out[k] = if (cur == null || v.total >= cur.total) v else cur
        }
        return out
    }

    /** Keeps only the most recent [keep] days (by date) – keeps relay messages small. */
    fun recent(days: Map<String, Bytes>, today: LocalDate, keep: Int): Map<String, Bytes> {
        val cutoff = today.minusDays((keep - 1).toLong())
        return days.filter { (k, v) ->
            val d = runCatching { LocalDate.parse(k) }.getOrNull()
            d != null && !d.isBefore(cutoff) && v.total > 0
        }
    }
}
