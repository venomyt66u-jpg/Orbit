package com.orbit.followthrough.ui.signals

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.data.db.SignalItemEntity
import com.orbit.followthrough.data.db.SignalSourceEntity
import com.orbit.followthrough.domain.NotifyMode
import com.orbit.followthrough.domain.SourceType
import com.orbit.followthrough.signals.SignalRepository
import com.orbit.followthrough.signals.SyncOutcome
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class FeedQuery(val text: String = "", val filter: String = FILTER_ALL, val limit: Int = 40) {
    companion object {
        const val FILTER_ALL = "all"
        const val FILTER_IMPORTANT = "important"
    }
}

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class SignalsViewModel(private val c: AppContainer) : ViewModel() {

    val query = MutableStateFlow(FeedQuery())
    val syncing = MutableStateFlow(false)
    val lastResult = MutableStateFlow<Map<Long, SyncOutcome>?>(null)

    val sources: StateFlow<List<SignalSourceEntity>?> = c.db.signals().observeSources()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val items: StateFlow<List<SignalItemEntity>?> = query.debounce(150).flatMapLatest { q ->
        val minImportance = if (q.filter == FeedQuery.FILTER_IMPORTANT) 2 else 0
        val category = if (q.filter == FeedQuery.FILTER_ALL || q.filter == FeedQuery.FILTER_IMPORTANT) "" else q.filter
        c.db.signals().observeItems(q.text.trim(), minImportance, category, q.limit)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val keywords: StateFlow<Set<String>> = combine(c.settings.settings, query) { s, _ -> s.signalKeywords }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    fun setText(t: String) { query.value = query.value.copy(text = t, limit = 40) }
    fun setFilter(f: String) { query.value = query.value.copy(filter = f, limit = 40) }
    fun loadMore() { query.value = query.value.copy(limit = query.value.limit + 40) }

    fun syncAll() = viewModelScope.launch {
        if (syncing.value) return@launch
        syncing.value = true
        try { lastResult.value = c.signals.syncAll() } finally { syncing.value = false }
    }

    fun syncOne(id: Long) = viewModelScope.launch { c.signals.syncOne(id) }

    fun markRead(id: Long) = viewModelScope.launch { c.db.signals().markRead(id) }
    fun markAllRead() = viewModelScope.launch { c.db.signals().markAllRead() }

    /** @return error string resource, or null on success. */
    suspend fun addSource(type: SourceType, rawTarget: String, rawName: String, mode: NotifyMode): Int? {
        val target = when (type) {
            SourceType.GITHUB -> SignalRepository.normalizeGithub(rawTarget) ?: return com.orbit.followthrough.R.string.error_github
            SourceType.ACCOUNT -> return com.orbit.followthrough.R.string.error_url
            SourceType.RSS -> rawTarget.trim().let { if (it.startsWith("http://") || it.startsWith("https://")) it else "https://$it" }
                .takeIf { android.util.Patterns.WEB_URL.matcher(it).matches() } ?: return com.orbit.followthrough.R.string.error_url
        }
        val name = rawName.trim().ifBlank {
            if (type == SourceType.GITHUB) target else (android.net.Uri.parse(target).host ?: target).removePrefix("www.")
        }
        val id = c.signals.addSource(name, type, target, mode)
        c.signals.syncOne(id)
        return null
    }

    /** Follow a profile link. Returns null on success, or a code: invalid / lookup / unsupported:<platform>. */
    suspend fun followAccount(link: String, name: String): String? {
        val r = c.signals.followAccount(link, name)
        if (r == null) com.orbit.followthrough.watch.WatchRunner.reschedule(c)
        return r
    }

    fun toggleSource(s: SignalSourceEntity) = viewModelScope.launch { c.signals.updateSource(s.copy(enabled = !s.enabled)) }
    fun setMode(s: SignalSourceEntity, mode: NotifyMode) = viewModelScope.launch { c.signals.updateSource(s.copy(notifyMode = mode)) }
    fun deleteSource(id: Long) = viewModelScope.launch { c.signals.deleteSource(id) }

    fun addKeyword(k: String) = viewModelScope.launch {
        val v = k.trim().lowercase()
        if (v.isEmpty()) return@launch
        val cur = c.settings.current().signalKeywords
        c.settings.update { signalKeywords = cur + v }
    }

    fun removeKeyword(k: String) = viewModelScope.launch {
        val cur = c.settings.current().signalKeywords
        c.settings.update { signalKeywords = cur - k }
    }
}
