package com.orbit.followthrough.meter

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.orbit.followthrough.MainActivity
import com.orbit.followthrough.R
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.CounterReading
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Meter
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.domain.Ssid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/** Where the phone is right now. */
data class WifiNow(val onWifi: Boolean, val ssid: String?) {
    val onTarget: Boolean get() = onWifi && ssid == Config.TARGET_SSID
}

object WifiProbe {
    /** Latest name seen by the service's network callback (Android 12+ hides it elsewhere). */
    @Volatile var callbackSsid: String? = null

    @Suppress("DEPRECATION")
    fun read(context: Context): WifiNow {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return WifiNow(false, null)
        val onWifi = runCatching {
            cm.allNetworks.any { n -> cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
        }.getOrDefault(false)
        if (!onWifi) return WifiNow(false, null)
        val wm = context.applicationContext.getSystemService(WifiManager::class.java)
        val name = runCatching { Ssid.clean(wm?.connectionInfo?.ssid) }.getOrNull()
        return WifiNow(true, name ?: callbackSsid)
    }

    fun hasLocation(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackgroundLocation(context: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun locationServicesOn(context: Context): Boolean {
        val lm = context.getSystemService(android.location.LocationManager::class.java) ?: return true
        return if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else runCatching { lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER) || lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) }.getOrDefault(true)
    }
}

/** Reads traffic counters and books Wi‑Fi bytes to the target network. */
object Recorder {
    private val lock = Any()

    private fun read(): CounterReading? {
        val trx = TrafficStats.getTotalRxBytes()
        val ttx = TrafficStats.getTotalTxBytes()
        if (trx == TrafficStats.UNSUPPORTED.toLong() || ttx == TrafficStats.UNSUPPORTED.toLong()) return null
        val mrx = TrafficStats.getMobileRxBytes().coerceAtLeast(0)
        val mtx = TrafficStats.getMobileTxBytes().coerceAtLeast(0)
        return CounterReading(trx, ttx, mrx, mtx, SystemClock.elapsedRealtime(), System.currentTimeMillis())
    }

    /** One measurement step. Returns where we are now. */
    fun sample(context: Context): WifiNow {
        val now = WifiProbe.read(context)
        synchronized(lock) {
            val store = UsageStore(context)
            val cur = read() ?: return now
            val prev = store.lastReading()
            val prevSsid = store.lastSsid()
            if (prev != null) {
                val gap = cur.wall - prev.wall
                if (Meter.attribute(prevSsid, now.ssid, gap, Config.TARGET_SSID)) {
                    val d = Meter.wifiDelta(prev, cur)
                    if (d != null && d.total > 0) store.add(Meter.splitByDay(prev.wall, cur.wall, d))
                }
            }
            store.saveReading(cur, if (now.onWifi) now.ssid else null)
        }
        return now
    }

    fun today(context: Context): Bytes {
        val (f, t) = Days.range(Period.TODAY, LocalDate.now())
        return Days.sum(UsageStore(context).days(), f, t)
    }

    fun month(context: Context): Bytes {
        val (f, t) = Days.range(Period.CYCLE, LocalDate.now())
        return Days.sum(UsageStore(context).days(), f, t)
    }
}

object Notifications {
    const val CHANNEL_METER = "meter_v1"
    const val METER_ID = 4_001

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        // Remove channels left over from the previous version of the app.
        runCatching { nm.notificationChannels.filter { it.id != CHANNEL_METER }.forEach { nm.deleteNotificationChannel(it.id) } }
        val ch = NotificationChannel(CHANNEL_METER, context.getString(R.string.channel_meter), NotificationManager.IMPORTANCE_LOW).apply {
            description = context.getString(R.string.channel_meter_desc)
            setShowBadge(false)
        }
        nm.createNotificationChannel(ch)
    }

    fun meter(context: Context, now: WifiNow?): Notification {
        val title = when {
            now == null -> context.getString(R.string.meter_starting)
            now.onTarget -> context.getString(R.string.meter_on_target, Config.TARGET_SSID)
            else -> context.getString(R.string.meter_off_target, Config.TARGET_SSID)
        }
        val text = context.getString(R.string.meter_summary, Fmt.bytes(Recorder.today(context).total), Fmt.bytes(Recorder.month(context).total))
        val open = PendingIntent.getActivity(
            context, 1, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(context, CHANNEL_METER)
            .setSmallIcon(R.drawable.ic_stat_wifi)
            .setColor(0xFF3BE3FF.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(open)
            .build()
    }
}

/**
 * Keeps counting in the background. Android requires a visible notification for this;
 * it is silent and shows today's and this month's usage on the target network.
 */
class MeterService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var callback: ConnectivityManager.NetworkCallback? = null

    companion object {
        fun start(context: Context) {
            val p = Profile(context)
            if (p.slot == null || !p.setupDone) return
            runCatching { ContextCompat.startForegroundService(context, Intent(context, MeterService::class.java)) }
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, MeterService::class.java)) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifications.ensureChannels(this)
        try {
            ServiceCompat.startForeground(
                this, Notifications.METER_ID, Notifications.meter(this, null),
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
            )
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        registerCallback()
        if (loop?.isActive != true) {
            loop = scope.launch {
                var lastSync = 0L
                while (isActive) {
                    val now = runCatching { Recorder.sample(this@MeterService) }.getOrNull()
                    update(now)
                    val t = System.currentTimeMillis()
                    if (t - lastSync > 10 * 60_000L) {
                        lastSync = t
                        runCatching { SyncEngine.sync(this@MeterService, onTarget = now?.onTarget == true) }
                    }
                    delay(60_000)
                }
            }
        }
        return START_STICKY
    }

    private fun update(now: WifiNow?) {
        val nm = NotificationManagerCompat.from(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        runCatching { nm.notify(Notifications.METER_ID, Notifications.meter(this, now)) }
    }

    private fun onNetworkChange() {
        scope.launch { update(runCatching { Recorder.sample(this@MeterService) }.getOrNull()) }
    }

    private fun registerCallback() {
        if (callback != null) return
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val cb = if (Build.VERSION.SDK_INT >= 31) WifiCallbackS { onNetworkChange() } else WifiCallbackLegacy { onNetworkChange() }
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
        if (runCatching { cm.registerNetworkCallback(req, cb) }.isSuccess) callback = cb
    }

    override fun onDestroy() {
        callback?.let { cb -> runCatching { getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) } }
        callback = null
        scope.cancel()
        super.onDestroy()
    }
}

@RequiresApi(31)
private class WifiCallbackS(private val changed: () -> Unit) : ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO) {
    override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
        val info = caps.transportInfo as? WifiInfo
        val name = Ssid.clean(info?.ssid)
        if (name != null && name != WifiProbe.callbackSsid) {
            WifiProbe.callbackSsid = name
            changed()
        }
    }

    override fun onLost(network: Network) {
        WifiProbe.callbackSsid = null
        changed()
    }
}

private class WifiCallbackLegacy(private val changed: () -> Unit) : ConnectivityManager.NetworkCallback() {
    override fun onAvailable(network: Network) = changed()
    override fun onLost(network: Network) = changed()
}

/** Safety net: measures and reports every 30 minutes even if the service was stopped. */
class MeterWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    companion object {
        const val NAME = "wifi_meter"

        fun schedule(context: Context) {
            val req = PeriodicWorkRequestBuilder<MeterWorker>(30, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.NOT_REQUIRED).build())
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }

    override suspend fun doWork(): Result {
        val p = Profile(applicationContext)
        if (p.slot == null) return Result.success()
        val now = runCatching { Recorder.sample(applicationContext) }.getOrNull()
        runCatching { SyncEngine.sync(applicationContext, onTarget = now?.onTarget == true) }
        return Result.success()
    }
}

/** Restart counting after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                MeterService.start(context)
                runCatching { MeterWorker.schedule(context) }
            }
        }
    }
}
