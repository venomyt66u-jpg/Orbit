package com.orbit.followthrough.meter

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.os.Build
import android.os.SystemClock
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.CounterReading
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Meter
import com.orbit.followthrough.domain.NetPrint
import com.orbit.followthrough.domain.Period
import java.net.Inet4Address
import java.net.Inet6Address
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/** Where the phone is right now. [print] identifies the Wi‑Fi router (null when not on Wi‑Fi). */
data class WifiNow(val onWifi: Boolean, val print: NetPrint?, val onTarget: Boolean)

/**
 * Recognises the target network by its router instead of its name, so no location permission
 * is needed: Android shares router addresses with every app.
 */
object WifiProbe {

    @Suppress("DEPRECATION")
    fun read(context: Context): WifiNow {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return WifiNow(false, null, false)
        val wifi = runCatching {
            cm.allNetworks.firstOrNull { n -> cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
        }.getOrNull() ?: return WifiNow(false, null, false)
        val print = runCatching { cm.getLinkProperties(wifi)?.let { printOf(it) } }.getOrNull()
        val known = UsageStore(context).knownNetworks()
        return WifiNow(true, print, NetPrint.matchesAny(print, known))
    }

    private fun printOf(lp: LinkProperties): NetPrint? {
        var gw4: String? = null
        var gw6: String? = null
        for (r in lp.routes) {
            if (!r.isDefaultRoute) continue
            when (val g = r.gateway) {
                is Inet4Address -> if (gw4 == null && !g.isAnyLocalAddress) gw4 = g.hostAddress
                is Inet6Address -> if (gw6 == null && g.isLinkLocalAddress) gw6 = g.hostAddress?.substringBefore('%')
            }
        }
        val addr = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
        val subnet = NetPrint.subnetOf(addr.address.hostAddress ?: return null, addr.prefixLength) ?: return null
        return NetPrint(gw4 ?: return null, subnet, gw6)
    }
}

/** Reads traffic counters and books Wi‑Fi bytes to the target network. */
object Recorder {
    private val lock = Any()
    private const val ANOTHER_WIFI = "~"

    private fun read(): CounterReading? {
        val trx = TrafficStats.getTotalRxBytes()
        val ttx = TrafficStats.getTotalTxBytes()
        if (trx == TrafficStats.UNSUPPORTED.toLong() || ttx == TrafficStats.UNSUPPORTED.toLong()) return null
        val mrx = TrafficStats.getMobileRxBytes().coerceAtLeast(0)
        val mtx = TrafficStats.getMobileTxBytes().coerceAtLeast(0)
        return CounterReading(trx, ttx, mrx, mtx, SystemClock.elapsedRealtime(), System.currentTimeMillis())
    }

    /**
     * One measurement step: everything moved over Wi‑Fi since the previous step is booked to the
     * target network when we were on it at the previous step (see [Meter.attribute]).
     */
    fun sample(context: Context): WifiNow {
        val now = WifiProbe.read(context)
        val place = when {
            now.onTarget -> Config.TARGET_SSID
            now.onWifi -> ANOTHER_WIFI
            else -> null
        }
        synchronized(lock) {
            val store = UsageStore(context)
            val cur = read() ?: return now
            val prev = store.lastReading()
            if (prev != null) {
                val gap = cur.wall - prev.wall
                if (Meter.attribute(store.lastPlace(), place, gap, Config.TARGET_SSID)) {
                    val d = Meter.wifiDelta(prev, cur)
                    if (d != null && d.total > 0) store.add(Meter.splitByHour(prev.wall, cur.wall, d))
                }
            }
            store.saveReading(cur, place)
        }
        return now
    }

    fun today(context: Context): Bytes {
        val (f, t) = Days.range(Period.TODAY, LocalDate.now())
        return Days.sum(UsageStore(context).days(), f, t)
    }
}

object Background {
    private const val PERIODIC = "wifi_meter"
    private const val ON_CHANGE = "wifi_meter_now"

    /** Every 15 minutes (Android's minimum), plus right after the phone joins a Wi‑Fi network. */
    fun schedule(context: Context) {
        val wm = WorkManager.getInstance(context)
        val req = PeriodicWorkRequestBuilder<MeterWorker>(15, TimeUnit.MINUTES).build()
        wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.UPDATE, req)
        watchNetworks(context)
    }

    fun runNow(context: Context) {
        WorkManager.getInstance(context)
            .enqueueUniqueWork(ON_CHANGE, ExistingWorkPolicy.REPLACE, OneTimeWorkRequestBuilder<MeterWorker>().build())
    }

    /** The system wakes [NetworkReceiver] when a Wi‑Fi network becomes available, even if the app is closed. */
    private fun watchNetworks(context: Context) {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(context, 7, Intent(context, NetworkReceiver::class.java), flags)
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
        runCatching { cm.unregisterNetworkCallback(pi) }
        runCatching { cm.registerNetworkCallback(req, pi) }
    }

    /** Version 2.0 used a foreground service and a notification channel; clean them up. */
    fun removeOldNotifications(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        runCatching { nm.cancelAll() }
        if (Build.VERSION.SDK_INT >= 26) runCatching { nm.notificationChannels.forEach { nm.deleteNotificationChannel(it.id) } }
    }
}

class NetworkReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Profile(context).slot != null) runCatching { Background.runNow(context) }
    }
}

class MeterWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val p = Profile(applicationContext)
        if (p.slot == null) return Result.success()
        val now = runCatching { Recorder.sample(applicationContext) }.getOrNull()
        runCatching { SyncEngine.sync(applicationContext, onTarget = now?.onTarget == true) }
        return Result.success()
    }
}

/** Restart counting after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                if (Profile(context).slot != null) runCatching {
                    Background.schedule(context)
                    Background.runNow(context)
                }
            }
        }
    }
}
