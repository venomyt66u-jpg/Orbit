package com.orbit.followthrough.meter

import android.Manifest
import android.app.NotificationManager
import android.app.AppOpsManager
import android.app.usage.NetworkStatsManager
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Process
import androidx.core.content.ContextCompat
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.os.Build
import android.os.SystemClock
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.CounterReading
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Meter
import com.orbit.followthrough.domain.NetPrint
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.domain.Ssid
import java.net.Inet4Address
import java.net.Inet6Address
import java.time.LocalDate
import java.util.concurrent.TimeUnit

/**
 * Where the phone is right now. [print] identifies the Wi‑Fi router (null when not on Wi‑Fi);
 * [name] is the Wi‑Fi name when Android lets us read it (location permission), otherwise null.
 */
data class WifiNow(
    val onWifi: Boolean,
    val print: NetPrint?,
    /** On the target network, confirmed by its Wi‑Fi name. */
    val onTarget: Boolean,
    val name: String? = null,
    /** Router matches the target but the name couldn't be read – counted apart as "unverified". */
    val maybeTarget: Boolean = false,
    /** A VPN is running (the phone's counters would count Wi‑Fi traffic twice). */
    val vpn: Boolean = false,
) {
    val place: String?
        get() = when {
            onTarget -> Meter.Place.TARGET
            maybeTarget -> Meter.Place.MAYBE
            onWifi -> Meter.Place.OTHER
            else -> null
        }
}

/**
 * Recognises the target network. With location permission the Wi‑Fi name decides (and teaches the
 * app the router); without it, the router's identity decides – so revoking permissions never
 * stops the counting.
 */
object WifiProbe {
    /** Latest Wi‑Fi name reported to the running service (Android 12+ hides it elsewhere). */
    @Volatile var callbackName: String? = null

    fun hasLocation(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun hasBackgroundLocation(context: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    fun read(context: Context): WifiNow {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return WifiNow(false, null, false)
        val wifi = runCatching {
            cm.allNetworks.firstOrNull { n -> cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true }
        }.getOrNull() ?: return WifiNow(false, null, false, vpn = runCatching {
            cm.allNetworks.any { n -> cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
        }.getOrDefault(false))
        val print = runCatching { cm.getLinkProperties(wifi)?.let { printOf(it) } }.getOrNull()
        val name = if (hasLocation(context)) {
            runCatching {
                Ssid.clean(context.applicationContext.getSystemService(WifiManager::class.java)?.connectionInfo?.ssid)
            }.getOrNull() ?: callbackName
        } else null
        val store = UsageStore(context)
        val vpn = runCatching {
            cm.allNetworks.any { n -> cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
        }.getOrDefault(false)
        return if (name != null) {
            val yes = name == Config.TARGET_SSID
            // Seen by name: remember this router (used by phones that can't read names).
            if (yes && print != null) store.learnNetwork(print.encode())
            WifiNow(true, print, yes, name, maybeTarget = false, vpn = vpn)
        } else {
            WifiNow(true, print, false, null, maybeTarget = NetPrint.matchesAny(print, store.knownNetworks()), vpn = vpn)
        }
    }

    /** Location access that lets Android reveal the Wi‑Fi name, also while the app is closed. */
    fun canReadNameAlways(context: Context): Boolean =
        hasLocation(context) && hasBackgroundLocation(context) && locationServicesOn(context)

    fun locationServicesOn(context: Context): Boolean {
        val lm = context.getSystemService(android.location.LocationManager::class.java) ?: return true
        return if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else runCatching {
            lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER) || lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)
        }.getOrDefault(true)
    }

    private fun printOf(lp: LinkProperties): NetPrint? {
        var gw4: String? = null
        var gw6: String? = null
        for (r in lp.routes) {
            if (!r.isDefaultRoute) continue
            when (val g = r.gateway) {
                is Inet4Address -> if (gw4 == null && !g.isAnyLocalAddress) gw4 = g.hostAddress
                is Inet6Address -> if (gw6 == null && g.isLinkLocalAddress) gw6 = g.hostAddress?.substringBefore('%')
            }
        }
        val addr = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
        val subnet = NetPrint.subnetOf(addr.address.hostAddress ?: return null, addr.prefixLength) ?: return null
        return NetPrint(gw4 ?: return null, subnet, gw6)
    }
}

/** Reads traffic counters and books Wi‑Fi bytes to the target network. */
object Recorder {
    private val lock = Any()
    private const val ANOTHER_WIFI = "~"

    private fun read(): CounterReading? {
        val trx = TrafficStats.getTotalRxBytes()
        val ttx = TrafficStats.getTotalTxBytes()
        if (trx == TrafficStats.UNSUPPORTED.toLong() || ttx == TrafficStats.UNSUPPORTED.toLong()) return null
        val mrx = TrafficStats.getMobileRxBytes().coerceAtLeast(0)
        val mtx = TrafficStats.getMobileTxBytes().coerceAtLeast(0)
        return CounterReading(trx, ttx, mrx, mtx, SystemClock.elapsedRealtime(), System.currentTimeMillis())
    }

    /**
     * One measurement step. Wi‑Fi bytes since the previous step go to the target network only when
     * [Meter.bucketFor] is sure they were used there. [atSwitch] = this reading was taken the moment
     * the phone joined a Wi‑Fi network.
     */
    fun sample(context: Context, atSwitch: Boolean = false): WifiNow {
        val now = WifiProbe.read(context)
        val place = now.place
        synchronized(lock) {
            val store = UsageStore(context)
            val cur = read() ?: return now
            val prev = store.lastReading()
            if (prev != null) {
                val gap = cur.wall - prev.wall
                val bucket = Meter.bucketFor(store.lastPlace(), place, gap, atSwitch)
                if (bucket != null) {
                    val vpn = now.vpn || store.lastVpn()
                    val d = when {
                        // With a VPN the phone's counters see each byte twice; Android's own record doesn't.
                        vpn -> NetHistory.wifiBetween(context, prev.wall, cur.wall)
                            ?: Meter.wifiDelta(prev, cur)?.let { Bytes(it.rx / 2, it.tx / 2) }
                        // Counters reset (phone restarted)? Use Android's own record for that window.
                        else -> Meter.wifiDelta(prev, cur) ?: NetHistory.wifiBetween(context, prev.wall, cur.wall)
                    }
                    if (d != null && d.total > 0) {
                        val chunks = Meter.splitByHour(prev.wall, cur.wall, d)
                        when (bucket) {
                            Meter.Bucket.VERIFIED -> store.add(chunks)
                            Meter.Bucket.UNVERIFIED -> store.addUnverified(chunks)
                        }
                    }
                }
            }
            store.saveReading(cur, place, now.vpn)
        }
        return now
    }

    fun today(context: Context): Bytes {
        val (f, t) = Days.range(Period.TODAY, LocalDate.now())
        return Days.sum(UsageStore(context).days(), f, t)
    }
}

/**
 * Android's own record of Wi‑Fi usage (needs "usage access", optional). Used to repair the gap
 * around a restart and to show what was used before the app was installed.
 */
object NetHistory {
    private const val PAST_DAYS = 90

    fun hasAccess(context: Context): Boolean {
        val ops = context.getSystemService(AppOpsManager::class.java) ?: return false
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        return if (mode == AppOpsManager.MODE_DEFAULT) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED
        } else mode == AppOpsManager.MODE_ALLOWED
    }

    /** All Wi‑Fi bytes between two times (every network – Android does not keep them apart). */
    @Suppress("DEPRECATION")
    fun wifiBetween(context: Context, start: Long, end: Long): Bytes? {
        if (end <= start || !hasAccess(context)) return null
        val nsm = context.getSystemService(NetworkStatsManager::class.java) ?: return null
        return runCatching {
            val b = nsm.querySummaryForDevice(ConnectivityManager.TYPE_WIFI, null, start, end)
            Bytes(b.rxBytes.coerceAtLeast(0), b.txBytes.coerceAtLeast(0))
        }.getOrNull()
    }

    /**
     * Fills "before the app" history: each day before counting started (and the morning of the first
     * day). Days the app already counted are left out so nothing is shown twice.
     */
    fun importPast(context: Context) {
        if (!hasAccess(context)) return
        val store = UsageStore(context)
        val since = store.countingSince().takeIf { it > 0 } ?: return
        val zone = java.time.ZoneId.systemDefault()
        val firstDay = java.time.Instant.ofEpochMilli(since).atZone(zone).toLocalDate()
        val counted = store.days()
        val out = LinkedHashMap<String, Bytes>()
        for (i in 0 until PAST_DAYS) {
            val day = firstDay.minusDays(i.toLong())
            val start = day.atStartOfDay(zone).toInstant().toEpochMilli()
            val end = minOf(day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli(), since)
            val b = wifiBetween(context, start, end) ?: continue
            val alreadyCounted = (counted[day.toString()]?.total ?: 0L) > 0 && day != firstDay
            if (b.total > 0 && !alreadyCounted) out[day.toString()] = b
        }
        store.setPast(out)
    }

    fun importIfDue(context: Context) {
        val store = UsageStore(context)
        if (System.currentTimeMillis() - store.pastImportedAt() > 12 * 60 * 60_000L) {
            runCatching { importPast(context) }
        }
    }
}

object Background {
    private const val PERIODIC = "wifi_meter"
    private const val ON_CHANGE = "wifi_meter_now"

    /** Every 15 minutes (Android's minimum), plus right after the phone joins a Wi‑Fi network. */
    fun schedule(context: Context) {
        val wm = WorkManager.getInstance(context)
        val req = PeriodicWorkRequestBuilder<MeterWorker>(15, TimeUnit.MINUTES).build()
        wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.UPDATE, req)
        watchNetworks(context)
    }

    fun runNow(context: Context) {
        WorkManager.getInstance(context)
            .enqueueUniqueWork(ON_CHANGE, ExistingWorkPolicy.REPLACE, OneTimeWorkRequestBuilder<MeterWorker>().build())
    }

    /** The system wakes [NetworkReceiver] when a Wi‑Fi network becomes available, even if the app is closed. */
    fun watchNetworks(context: Context) {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val pi = PendingIntent.getBroadcast(context, 7, Intent(context, NetworkReceiver::class.java), flags)
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
        runCatching { cm.unregisterNetworkCallback(pi) }
        runCatching { cm.registerNetworkCallback(req, pi) }
    }

    /** Version 2.0 used a foreground service and a notification channel; clean them up. */
    fun removeOldNotifications(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        runCatching { nm.cancelAll() }
        if (Build.VERSION.SDK_INT >= 26) runCatching { nm.notificationChannels.forEach { nm.deleteNotificationChannel(it.id) } }
    }
}

/**
 * Woken by Android the moment the phone joins a Wi‑Fi network. The reading is taken right here
 * (not deferred), so the switch moment is exact and another network's bytes never mix in.
 */
class NetworkReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        if (Profile(app).slot == null) return
        MeterService.start(app)
        val pending = goAsync()
        Thread {
            try {
                runCatching { Recorder.sample(app, atSwitch = true) }
                runCatching { Background.runNow(app) } // report to the admin when convenient
            } finally {
                pending.finish()
            }
        }.start()
    }
}

class MeterWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val p = Profile(applicationContext)
        if (p.slot == null) return Result.success()
        val now = runCatching { Recorder.sample(applicationContext) }.getOrNull()
        runCatching { Background.watchNetworks(applicationContext) } // keep the join trigger registered
        MeterService.start(applicationContext) // restart the live counter if Android stopped it
        NetHistory.importIfDue(applicationContext)
        runCatching { SyncEngine.sync(applicationContext, onTarget = now?.onTarget == true) }
        return Result.success()
    }
}

/** Restart counting after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                if (Profile(context).slot != null) runCatching {
                    MeterService.start(context)
                    Background.schedule(context)
                    Background.runNow(context)
                }
            }
        }
    }
}
