package com.orbit.followthrough.ui.assistant

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.ai.Command
import com.orbit.followthrough.ai.Insight
import com.orbit.followthrough.ai.InsightEvent
import com.orbit.followthrough.ai.InsightReminder
import com.orbit.followthrough.ai.Insights
import com.orbit.followthrough.ai.ReminderDraft
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.data.db.SignalItemEntity
import com.orbit.followthrough.data.db.isRecurring
import com.orbit.followthrough.domain.EventType
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.engine.SaveResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.atomic.AtomicLong

sealed interface ChatMsg {
    val id: Long
    data class User(override val id: Long, val text: String) : ChatMsg
    data class Bot(override val id: Long, val text: String) : ChatMsg
    /** A reminder proposal awaiting explicit confirmation. */
    data class Proposal(override val id: Long, val draft: ReminderDraft, val state: PState = PState.OPEN) : ChatMsg
    /** Missing info: [kind] = "time" or "meridiem". */
    data class Clarify(override val id: Long, val draft: ReminderDraft, val kind: String, val answered: Boolean = false) : ChatMsg
    data class QuietProposal(override val id: Long, val startMinute: Int, val endMinute: Int, val state: PState = PState.OPEN) : ChatMsg
    data class FollowUpProposal(override val id: Long, val reminderId: Long, val title: String, val minutes: Int, val state: PState = PState.OPEN) : ChatMsg
    data class ReminderList(override val id: Long, val headerRes: Int, val items: List<ReminderEntity>) : ChatMsg
    data class SignalDigest(override val id: Long, val items: List<SignalItemEntity>) : ChatMsg
    /** Answer written by the connected AI model. */
    data class Ai(override val id: Long, val text: String, val provider: String) : ChatMsg
}

enum class PState { OPEN, CONFIRMED, CANCELLED }

class AssistantViewModel(private val c: AppContainer, private val appContext: Context) : ViewModel() {

    private val ids = AtomicLong(1)
    private fun nextId() = ids.getAndIncrement()
    private val prefs = appContext.getSharedPreferences("orbit_insights", Context.MODE_PRIVATE)
    private val dismissed = MutableStateFlow(prefs.getStringSet("dismissed", emptySet()).orEmpty().toSet())
    private var lastCreatedId: Long? = null

    val messages = MutableStateFlow<List<ChatMsg>>(emptyList())
    val thinking = MutableStateFlow(false)

    private val since = System.currentTimeMillis() - 21L * 24 * 60 * 60_000

    val insights: StateFlow<List<Insight>> = combine(
        c.db.reminders().observeActive(),
        c.db.events().observeSince(since),
        dismissed,
        c.settings.settings,
    ) { reminders, events, dis, s ->
        if (!s.aiEnabled) emptyList()
        else Insights.compute(
            reminders.map { InsightReminder(it.id, it.title, it.hour, it.minute, it.isRecurring()) },
            events.map { InsightEvent(it.reminderId, it.type, it.hourOfDay) },
            dis,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private fun push(m: ChatMsg) = messages.update { it + m }
    private fun replace(id: Long, f: (ChatMsg) -> ChatMsg) = messages.update { list -> list.map { if (it.id == id) f(it) else it } }
    private fun str(res: Int, vararg args: Any): String = appContext.getString(res, *args)

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        push(ChatMsg.User(nextId(), t))
        viewModelScope.launch {
            thinking.value = true
            try {
                val s = c.settings.current()
                val cmd = c.aiProvider(s).parse(t, ZonedDateTime.now())
                handle(cmd)
            } finally {
                thinking.value = false
            }
        }
    }

    private suspend fun handle(cmd: Command) {
        when (cmd) {
            is Command.Create -> {
                val d = cmd.draft
                when {
                    d.missingTitle -> push(ChatMsg.Bot(nextId(), str(R.string.ai_need_title)))
                    d.needsMeridiem -> push(ChatMsg.Clarify(nextId(), d, "meridiem"))
                    d.missingTime -> push(ChatMsg.Clarify(nextId(), d, "time"))
                    else -> push(ChatMsg.Proposal(nextId(), fixDate(d)))
                }
            }
            Command.ShowPostponed -> {
                val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val ids = c.db.events().since(start).filter { it.type == EventType.SNOOZED || it.type == EventType.DISMISSED }.map { it.reminderId }.distinct()
                val items = ids.mapNotNull { c.db.reminders().get(it) }
                if (items.isEmpty()) push(ChatMsg.Bot(nextId(), str(R.string.ai_no_postponed)))
                else push(ChatMsg.ReminderList(nextId(), R.string.ai_postponed_header, items))
            }
            Command.ShowToday -> {
                val end = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val items = c.db.reminders().active().filter { it.status == ReminderStatus.PENDING || (it.nextOccurrenceAt ?: Long.MAX_VALUE) < end }
                    .sortedBy { it.followUpAt ?: it.pendingOccurrenceAt ?: it.nextOccurrenceAt }
                if (items.isEmpty()) push(ChatMsg.Bot(nextId(), str(R.string.ai_today_clear)))
                else push(ChatMsg.ReminderList(nextId(), R.string.ai_today_header, items))
            }
            Command.Summarize -> {
                val items = c.db.signals().recent(System.currentTimeMillis() - 48L * 60 * 60_000, 6)
                if (items.isEmpty()) push(ChatMsg.Bot(nextId(), str(R.string.ai_no_updates)))
                else push(ChatMsg.SignalDigest(nextId(), items))
            }
            is Command.QuietAfter -> {
                val s = c.settings.current()
                push(ChatMsg.QuietProposal(nextId(), cmd.startMinute, cmd.endMinute ?: s.quietEnd))
            }
            is Command.SetFollowUp -> {
                val target = lastCreatedId?.let { c.db.reminders().get(it) }
                    ?: c.db.reminders().active().minByOrNull { it.followUpAt ?: it.pendingOccurrenceAt ?: it.nextOccurrenceAt ?: Long.MAX_VALUE }
                if (target == null) push(ChatMsg.Bot(nextId(), str(R.string.ai_no_target)))
                else push(ChatMsg.FollowUpProposal(nextId(), target.id, target.title, cmd.minutes))
            }
            is Command.Unknown -> askAi(cmd.text)
        }
    }

    /** Free-form question → the user's AI provider (only when connected). */
    private suspend fun askAi(question: String) {
        val s = c.settings.current()
        if (!c.ai.ready(s)) { push(ChatMsg.Bot(nextId(), str(R.string.ai_unknown_connect))); return }
        val end = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val today = c.db.reminders().active().filter { (it.nextOccurrenceAt ?: 0) < end || it.status == ReminderStatus.PENDING }
            .joinToString("\n") { "- ${it.title} (${it.hour}:${"%02d".format(it.minute)})" }
        val context = buildString {
            if (today.isNotBlank()) appendLine("Today's tasks:\n$today")
            appendLine(c.market.briefContext())
            val w = c.wallets.aiContext(System.currentTimeMillis() - 24L * 60 * 60_000)
            if (w.isNotBlank()) appendLine("Tracked wallets (last 24h):\n$w")
        }
        val label = c.ai.config(s).provider.label
        c.ai.ask(s, question, context).fold(
            onSuccess = { a ->
                when (a) {
                    is com.orbit.followthrough.ai.AiHub.Answer.Text -> push(ChatMsg.Ai(nextId(), a.text, label))
                    is com.orbit.followthrough.ai.AiHub.Answer.Reminder -> {
                        if (a.text.isNotBlank()) push(ChatMsg.Ai(nextId(), a.text, label))
                        handle(Command.Create(a.draft))
                    }
                }
            },
            onFailure = { e -> push(ChatMsg.Bot(nextId(), str(R.string.ai_error, com.orbit.followthrough.net.Http.reason(e)))) },
        )
    }

    /** One-tap AI actions. kind = "market" | "wallets" | "feed". */
    fun quickAi(kind: String) {
        viewModelScope.launch {
            val s = c.settings.current()
            if (!c.ai.ready(s)) { push(ChatMsg.Bot(nextId(), str(R.string.ai_unknown_connect))); return@launch }
            thinking.value = true
            try {
                val label = c.ai.config(s).provider.label
                val result = when (kind) {
                    "market" -> {
                        push(ChatMsg.User(nextId(), str(R.string.quick_market)))
                        runCatching { c.market.refreshAll() }
                        c.ai.marketBrief(s, c.market.briefContext())
                    }
                    "wallets" -> {
                        push(ChatMsg.User(nextId(), str(R.string.quick_wallets)))
                        val ctx = c.wallets.aiContext(System.currentTimeMillis() - 3L * 24 * 60 * 60_000)
                        if (ctx.isBlank()) Result.success(str(R.string.ai_no_wallet_activity)) else c.ai.explainWallets(s, ctx)
                    }
                    else -> {
                        push(ChatMsg.User(nextId(), str(R.string.quick_feed)))
                        val items = c.db.signals().recent(System.currentTimeMillis() - 48L * 60 * 60_000, 25)
                        if (items.isEmpty()) Result.success(str(R.string.ai_no_updates))
                        else c.ai.summarizeFeed(s, items.joinToString("\n") { "- [${it.sourceName}] ${it.title}: ${it.summary.take(200)}" })
                    }
                }
                result.fold(
                    onSuccess = { push(ChatMsg.Ai(nextId(), it, label)) },
                    onFailure = { e -> push(ChatMsg.Bot(nextId(), str(R.string.ai_error, com.orbit.followthrough.net.Http.reason(e)))) },
                )
            } finally {
                thinking.value = false
            }
        }
    }

    /** One-time drafts whose time already passed today move to tomorrow. */
    private fun fixDate(d: ReminderDraft): ReminderDraft {
        val h = d.hour ?: return d
        if (d.repeat != RepeatType.ONCE) return d
        val at = d.date.atTime(h, d.minute).atZone(ZoneId.systemDefault())
        return if (at.isAfter(ZonedDateTime.now())) d else d.copy(date = d.date.plusDays(1))
    }

    fun answerClarify(msg: ChatMsg.Clarify, hour: Int, minute: Int) {
        replace(msg.id) { (it as ChatMsg.Clarify).copy(answered = true) }
        push(ChatMsg.Proposal(nextId(), fixDate(msg.draft.copy(hour = hour, minute = minute, needsMeridiem = false))))
    }

    fun confirm(msg: ChatMsg.Proposal) = viewModelScope.launch {
        val d = msg.draft
        val s = c.settings.current()
        val entity = ReminderEntity(
            title = d.title, note = d.note, important = d.important, repeatType = d.repeat,
            hour = d.hour ?: 9, minute = d.minute, startEpochDay = d.date.toEpochDay(),
            weekdays = d.weekdays, interval = d.interval, dayOfMonth = d.date.dayOfMonth,
            followUpMinutes = d.followUpMinutes ?: s.defaultFollowUpMinutes, maxFollowUps = s.defaultMaxFollowUps,
        )
        when (val r = c.reminderEngine.save(entity)) {
            is SaveResult.Saved -> {
                lastCreatedId = r.id
                replace(msg.id) { (it as ChatMsg.Proposal).copy(state = PState.CONFIRMED) }
            }
            else -> push(ChatMsg.Bot(nextId(), str(R.string.error_past)))
        }
    }

    fun cancel(msgId: Long) = replace(msgId) { m ->
        when (m) {
            is ChatMsg.Proposal -> m.copy(state = PState.CANCELLED)
            is ChatMsg.QuietProposal -> m.copy(state = PState.CANCELLED)
            is ChatMsg.FollowUpProposal -> m.copy(state = PState.CANCELLED)
            else -> m
        }
    }

    fun confirmQuiet(msg: ChatMsg.QuietProposal) = viewModelScope.launch {
        c.settings.update { quietEnabled = true; quietStart = msg.startMinute; quietEnd = msg.endMinute }
        replace(msg.id) { (it as ChatMsg.QuietProposal).copy(state = PState.CONFIRMED) }
    }

    fun confirmFollowUp(msg: ChatMsg.FollowUpProposal) = viewModelScope.launch {
        val r = c.db.reminders().get(msg.reminderId) ?: return@launch
        // Only the follow-up setting changes; the schedule is kept as is.
        c.db.reminders().update(r.copy(followUpMinutes = msg.minutes, maxFollowUps = r.maxFollowUps.coerceAtLeast(1), updatedAt = System.currentTimeMillis()))
        replace(msg.id) { (it as ChatMsg.FollowUpProposal).copy(state = PState.CONFIRMED) }
    }

    fun acceptInsight(i: Insight) = viewModelScope.launch {
        when (i.kind) {
            Insight.Kind.SPLIT -> {
                // Create a small, concrete first step 30 minutes from now (user-confirmed by tapping Accept).
                val now = ZonedDateTime.now().plusMinutes(30)
                c.reminderEngine.save(
                    ReminderEntity(
                        title = str(R.string.first_step_title, i.title), hour = now.hour, minute = now.minute,
                        startEpochDay = now.toLocalDate().toEpochDay(), followUpMinutes = 10, maxFollowUps = 2,
                    )
                )
            }
            else -> c.reminderEngine.reschedule(i.reminderId, i.suggestedHour, i.suggestedMinute)
        }
        dismissInsight(i)
        push(ChatMsg.Bot(nextId(), str(R.string.ai_insight_applied)))
    }

    fun dismissInsight(i: Insight) {
        val next = dismissed.value + i.key
        dismissed.value = next
        prefs.edit().putStringSet("dismissed", next).apply()
    }

    fun clearChat() { messages.value = emptyList() }
}
