package com.orbit.followthrough.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.ClaimResult
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.domain.Claims
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.launch

@Composable
fun PickScreen(profile: Profile) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    val scope = rememberCoroutineScope()

    var loading by remember { mutableStateOf(true) }
    var online by remember { mutableStateOf(true) }
    var taken by remember { mutableStateOf(emptySet<String>()) }
    var reload by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf<Person?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var adminDialog by remember { mutableStateOf(false) }
    val lost = remember { profile.lostSlot?.let { personOf(it) } }

    LaunchedEffect(reload) {
        loading = true
        online = SyncEngine.refresh(ctx)
        val claims = profile.claims()
        // Same phone as before (app reinstalled)? Give the person back.
        val mine = Claims.slotOf(profile.deviceId, claims)
        if (mine != null && mine != lost?.slot) {
            profile.slot = mine
            return@LaunchedEffect
        }
        taken = Claims.takenByOthers(profile.deviceId, claims)
        loading = false
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(28.dp))
        // Long-press the emblem to open the admin login.
        Box(
            Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(c.accentBrush)
                .pointerInput(Unit) { detectTapGestures(onLongPress = { adminDialog = true }) },
            contentAlignment = Alignment.Center,
        ) { Icon(OrbitIcons.Signal, null, tint = c.onAccent, modifier = Modifier.size(32.dp)) }
        Spacer(Modifier.height(18.dp))
        Text("مين انت؟", style = OrbitType.display, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "اختار شخصيتك. أي شخصية تتاخد بتتقفل، ومحدش تاني يقدر يختارها.",
            style = OrbitType.body, color = c.textSecondary, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(18.dp))

        if (lost != null) {
            NoticeCard(OrbitIcons.Info, "شخصية ${lost.name} طلعت محجوزة", "حد اختارها قبلك بثواني. اختار شخصيتك تاني.", c.amber)
            Spacer(Modifier.height(14.dp))
        }
        if (!loading && !online) {
            NoticeCard(
                OrbitIcons.Info, "مفيش إنترنت",
                "لازم تكون متصل بالنت علشان نتأكد إن الشخصية مش محجوزة.", c.rose,
                action = { SecondaryButton("جرّب تاني", { reload++ }, icon = OrbitIcons.Refresh) },
            )
            Spacer(Modifier.height(14.dp))
        }

        if (loading) {
            Spacer(Modifier.height(40.dp))
            CircularProgressIndicator(color = c.cyan)
            Spacer(Modifier.height(12.dp))
            Text("بشوف مين اختار قبل كده…", style = OrbitType.label, color = c.textSecondary)
        } else {
            People.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)) {
                    row.forEach { person ->
                        PersonCard(
                            person = person,
                            taken = person.slot in taken,
                            modifier = Modifier.weight(1f, fill = row.size > 1).then(if (row.size == 1) Modifier.width(170.dp) else Modifier),
                            onClick = {
                                if (person.slot in taken) message = "${person.name} محجوز لحد تاني."
                                else confirm = person
                            },
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    confirm?.let { person ->
        AlertDialog(
            onDismissRequest = { if (!busy) confirm = null },
            containerColor = c.surfaceHigh,
            icon = { Avatar(person, 72.dp) },
            title = { Text("انت ${person.name}؟", style = OrbitType.title, color = c.text) },
            text = { Text("بعد ما تختار مش هتقدر تغيّر الشخصية، ومحدش تاني هيقدر ياخدها.", style = OrbitType.body, color = c.textSecondary) },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        when (SyncEngine.claim(ctx, person.slot)) {
                            ClaimResult.Ok -> Unit
                            ClaimResult.Taken -> { message = "للأسف حد سبقك واختار ${person.name}."; reload++ }
                            ClaimResult.Offline -> message = "مفيش إنترنت دلوقتي. اتصل بالنت وجرّب تاني."
                        }
                        busy = false
                        confirm = null
                    }
                }) { Text(if (busy) "لحظة…" else "أيوه أنا", color = c.cyan) }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { confirm = null }) { Text("رجوع", color = c.textSecondary) } },
        )
    }

    message?.let { m ->
        AlertDialog(
            onDismissRequest = { message = null },
            containerColor = c.surfaceHigh,
            text = { Text(m, style = OrbitType.body, color = c.text) },
            confirmButton = { TextButton(onClick = { message = null }) { Text("تمام", color = c.cyan) } },
        )
    }

    if (adminDialog) AdminLoginDialog(onDismiss = { adminDialog = false }, onOk = {
        adminDialog = false
        SyncEngine.becomeAdmin(ctx)
    })
}

@Composable
private fun PersonCard(person: Person, taken: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = Orbit.colors
    GlassCard(
        modifier.alpha(if (taken) 0.45f else 1f),
        highlight = if (taken) null else person.accent,
        onClick = onClick,
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.BottomEnd) {
                Avatar(person, 96.dp)
                if (taken) {
                    Box(
                        Modifier.size(30.dp).clip(CircleShape).background(c.surfaceHigh).border(1.dp, c.strokeStrong, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) { Icon(OrbitIcons.Lock, null, tint = c.textSecondary, modifier = Modifier.size(16.dp)) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(person.name, style = OrbitType.title, color = c.text, maxLines = 1)
            Spacer(Modifier.height(6.dp))
            if (taken) Tag("محجوزة", c.textMuted, icon = OrbitIcons.Lock) else Tag("متاحة", person.accent)
        }
    }
}

@Composable
fun AdminLoginDialog(onDismiss: () -> Unit, onOk: () -> Unit) {
    val c = Orbit.colors
    var code by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surfaceHigh,
        title = { Text("دخول الأدمن", style = OrbitType.title, color = c.text) },
        text = {
            Column {
                OrbitTextField(
                    value = code,
                    onValueChange = { code = it; wrong = false },
                    placeholder = "الكود",
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leading = OrbitIcons.Lock,
                )
                if (wrong) {
                    Spacer(Modifier.height(8.dp))
                    Text("الكود غلط", style = OrbitType.caption, color = c.rose)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (Config.isAdminCode(code)) onOk() else wrong = true }) { Text("دخول", color = c.cyan) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = c.textSecondary) } },
    )
}
