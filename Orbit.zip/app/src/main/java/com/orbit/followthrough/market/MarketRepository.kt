package com.orbit.followthrough.market

import com.orbit.followthrough.data.db.CoinEntity
import com.orbit.followthrough.data.db.MarketDao
import com.orbit.followthrough.data.prefs.SecretStore
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.net.Http
import com.orbit.followthrough.notify.Notifier
import com.orbit.followthrough.signals.FeedParser
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

data class GlobalMarket(val totalCap: Double, val capChange24h: Double, val btcDominance: Double, val volume24h: Double)
data class FearGreed(val value: Int, val label: String)
data class MarketNews(val title: String, val source: String, val link: String, val publishedAt: Long?)
data class CoinHit(val id: String, val name: String, val symbol: String, val rank: Int?)

data class MarketSnapshot(
    val global: GlobalMarket? = null,
    val fearGreed: FearGreed? = null,
    val news: List<MarketNews> = emptyList(),
    val updatedAt: Long? = null,
    val error: String? = null,
    val loading: Boolean = false,
)

/**
 * Market data from free, public endpoints (no account needed):
 * CoinGecko (prices, 7-day sparkline, global stats), alternative.me (Fear & Greed), and public news RSS.
 * An optional CoinGecko demo key raises rate limits; it is stored encrypted on the device.
 */
class MarketRepository(
    private val dao: MarketDao,
    private val settings: SettingsRepository,
    private val secrets: SecretStore,
    private val notifier: Notifier,
) {
    private val _snapshot = MutableStateFlow(MarketSnapshot())
    val snapshot: StateFlow<MarketSnapshot> = _snapshot.asStateFlow()

    companion object {
        private const val CG = "https://api.coingecko.com/api/v3"
        val defaultWatchlist = listOf(
            CoinEntity("bitcoin", "BTC", "Bitcoin", 0),
            CoinEntity("ethereum", "ETH", "Ethereum", 1),
            CoinEntity("solana", "SOL", "Solana", 2),
            CoinEntity("binancecoin", "BNB", "BNB", 3),
            CoinEntity("ripple", "XRP", "XRP", 4),
            CoinEntity("the-open-network", "TON", "Toncoin", 5),
        )
        val newsFeeds = listOf(
            "CoinDesk" to "https://www.coindesk.com/arc/outboundfeeds/rss/",
            "Cointelegraph" to "https://cointelegraph.com/rss",
        )
    }

    private fun headers(): Map<String, String> =
        secrets.get(SecretStore.Key.COINGECKO)?.let { mapOf("x-cg-demo-api-key" to it) } ?: emptyMap()

    suspend fun seedIfNeeded() {
        val s = settings.current()
        if (s.marketSeeded) return
        if (dao.count() == 0) dao.upsert(defaultWatchlist)
        settings.update { marketSeeded = true }
    }

    /** Prices for the watchlist + alert checks. Cheap: one request for all coins. */
    suspend fun refreshPrices(): String? {
        val coins = dao.coins()
        if (coins.isEmpty()) return null
        return try {
            val ids = coins.joinToString(",") { it.id }
            val json = JSONArray(
                Http.get("$CG/coins/markets?vs_currency=usd&ids=${URLEncoder.encode(ids, "UTF-8")}&sparkline=true&price_change_percentage=24h", headers())
            )
            val byId = coins.associateBy { it.id }
            val now = System.currentTimeMillis()
            val updated = ArrayList<CoinEntity>()
            for (i in 0 until json.length()) {
                val o = json.getJSONObject(i)
                val old = byId[o.getString("id")] ?: continue
                val spark = o.optJSONObject("sparkline_in_7d")?.optJSONArray("price")
                val points = if (spark == null) "" else (0 until spark.length() step 2).joinToString(",") { idx ->
                    String.format(Locale.US, "%.8g", spark.getDouble(idx))
                }
                val price = o.optDouble("current_price").takeIf { !it.isNaN() }
                var next = old.copy(
                    price = price,
                    change24h = o.optDouble("price_change_percentage_24h").takeIf { !it.isNaN() },
                    marketCap = o.optDouble("market_cap").takeIf { !it.isNaN() },
                    high24h = o.optDouble("high_24h").takeIf { !it.isNaN() },
                    low24h = o.optDouble("low_24h").takeIf { !it.isNaN() },
                    sparkline = points.ifBlank { old.sparkline },
                    updatedAt = now,
                )
                // One-shot price alerts: fire when the price crosses the level, then clear it.
                if (price != null) {
                    val above = old.alertAbove
                    val below = old.alertBelow
                    if (above != null && price >= above) {
                        notifier.showPriceAlert(next, above, up = true, settings.current())
                        next = next.copy(alertAbove = null)
                    }
                    if (below != null && price <= below) {
                        notifier.showPriceAlert(next, below, up = false, settings.current())
                        next = next.copy(alertBelow = null)
                    }
                }
                updated += next
            }
            dao.upsert(updated)
            null
        } catch (e: Exception) {
            Http.reason(e)
        }
    }

    /** Full refresh used by the Market screen: prices + global stats + sentiment + headlines. */
    suspend fun refreshAll() = coroutineScope {
        _snapshot.value = _snapshot.value.copy(loading = true, error = null)
        val prices = async { refreshPrices() }
        val global = async { runCatching { fetchGlobal() }.getOrNull() }
        val fg = async { runCatching { fetchFearGreed() }.getOrNull() }
        val news = async { runCatching { fetchNews() }.getOrDefault(emptyList()) }
        val err = prices.await()
        _snapshot.value = MarketSnapshot(
            global = global.await() ?: _snapshot.value.global,
            fearGreed = fg.await() ?: _snapshot.value.fearGreed,
            news = news.await().ifEmpty { _snapshot.value.news },
            updatedAt = System.currentTimeMillis(),
            error = err,
            loading = false,
        )
    }

    private suspend fun fetchGlobal(): GlobalMarket {
        val d = JSONObject(Http.get("$CG/global", headers())).getJSONObject("data")
        return GlobalMarket(
            totalCap = d.getJSONObject("total_market_cap").optDouble("usd"),
            capChange24h = d.optDouble("market_cap_change_percentage_24h_usd"),
            btcDominance = d.getJSONObject("market_cap_percentage").optDouble("btc"),
            volume24h = d.getJSONObject("total_volume").optDouble("usd"),
        )
    }

    private suspend fun fetchFearGreed(): FearGreed {
        val o = JSONObject(Http.get("https://api.alternative.me/fng/?limit=1")).getJSONArray("data").getJSONObject(0)
        return FearGreed(o.getString("value").toInt(), o.optString("value_classification"))
    }

    private suspend fun fetchNews(): List<MarketNews> = coroutineScope {
        newsFeeds.map { (name, url) ->
            async {
                runCatching {
                    FeedParser.parse(Http.get(url, mapOf("Accept" to "application/rss+xml, application/xml")).toByteArray())
                        .take(8).map { MarketNews(it.title, name, it.link, it.publishedAt) }
                }.getOrDefault(emptyList())
            }
        }.flatMap { it.await() }.sortedByDescending { it.publishedAt ?: 0 }.take(8)
    }

    suspend fun search(query: String): List<CoinHit> {
        if (query.isBlank()) return emptyList()
        val coins = JSONObject(Http.get("$CG/search?query=${URLEncoder.encode(query.trim(), "UTF-8")}", headers())).getJSONArray("coins")
        return (0 until minOf(coins.length(), 15)).map { i ->
            val o = coins.getJSONObject(i)
            CoinHit(o.getString("id"), o.optString("name"), o.optString("symbol").uppercase(Locale.ROOT), o.optInt("market_cap_rank").takeIf { it > 0 })
        }
    }

    suspend fun add(hit: CoinHit) {
        val order = dao.count()
        dao.upsert(listOf(CoinEntity(hit.id, hit.symbol, hit.name, order)))
        refreshPrices()
    }

    suspend fun remove(id: String) = dao.delete(id)

    suspend fun setAlerts(id: String, above: Double?, below: Double?) {
        val c = dao.coin(id) ?: return
        dao.update(c.copy(alertAbove = above, alertBelow = below))
    }

    /** Price lookup by symbol for wallet USD estimates (BTC, ETH, SOL, BNB, POL…). */
    suspend fun priceBySymbol(): Map<String, Double> =
        dao.coins().mapNotNull { c -> c.price?.let { c.symbol.uppercase(Locale.ROOT) to it } }.toMap()

    /** Compact text for the AI market brief (public market data only). */
    suspend fun briefContext(): String {
        val s = _snapshot.value
        val coins = dao.coins()
        return buildString {
            s.global?.let { appendLine("Total market cap: ${it.totalCap.toLong()} USD (${"%.2f".format(Locale.US, it.capChange24h)}% 24h), BTC dominance ${"%.1f".format(Locale.US, it.btcDominance)}%") }
            s.fearGreed?.let { appendLine("Fear & Greed: ${it.value} (${it.label})") }
            coins.forEach { c -> appendLine("${c.symbol}: price ${c.price} USD, 24h ${c.change24h?.let { "%.2f".format(Locale.US, it) }}%") }
            if (s.news.isNotEmpty()) {
                appendLine("Headlines:")
                s.news.take(6).forEach { appendLine("- ${it.title} (${it.source})") }
            }
        }
    }
}
