package com.orbit.followthrough.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.ui.theme.Orbit
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Living background: deep night gradient, slow drifting aurora, faint Wi‑Fi waves rising from the
 * bottom and a field of quiet stars. Very cheap to draw; frozen when reduced motion is on.
 */
@Composable
fun AnimatedBackdrop(modifier: Modifier = Modifier) {
    val c = Orbit.colors
    val reduced = Orbit.reducedMotion
    val t = rememberInfiniteTransition(label = "bg")
    val drift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(46_000, easing = LinearEasing), RepeatMode.Restart), label = "drift")
    val wave by t.animateFloat(0f, 1f, infiniteRepeatable(tween(6_500, easing = LinearEasing), RepeatMode.Restart), label = "wave")
    val ph = if (reduced) 0.2f else drift
    val wv = if (reduced) 0.5f else wave
    val stars = remember {
        val r = Random(7)
        List(46) { Triple(r.nextFloat(), r.nextFloat() * 0.75f, r.nextFloat()) }
    }
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(c.abyss, c.void, c.void)))

        val a = if (c.isDark) 1f else 0.45f
        val tau = 2f * PI.toFloat()
        fun blob(color: Color, cx: Float, cy: Float, r: Float, alpha: Float) {
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = alpha * a), Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
        }
        blob(c.violet, w * (0.18f + 0.10f * sin(ph * tau)), h * (0.10f + 0.04f * cos(ph * tau)), w * 0.95f, 0.30f)
        blob(c.cyan, w * (0.95f + 0.08f * cos(ph * tau * 2f)), h * (0.32f + 0.05f * sin(ph * tau)), w * 0.75f, 0.18f)
        blob(c.electric, w * (0.35f + 0.15f * cos(ph * tau)), h * (0.78f + 0.04f * sin(ph * tau * 2f)), w * 0.9f, 0.16f)

        // stars
        stars.forEachIndexed { i, (x, y, s) ->
            val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin((ph * 9f + s) * tau + i))
            drawCircle(Color.White.copy(alpha = (if (c.isDark) 0.28f else 0.10f) * tw), (0.6f + s * 1.3f).dp.toPx(), Offset(x * w, y * h))
        }

        // Wi‑Fi waves rising from below the screen
        val origin = Offset(w * 0.5f, h * 1.08f)
        for (k in 0 until 4) {
            val p = ((wv + k / 4f) % 1f)
            val r = h * (0.18f + p * 0.75f)
            val alpha = (1f - p) * (if (c.isDark) 0.10f else 0.06f)
            drawArc(
                c.cyan.copy(alpha = alpha), 220f, 100f, false,
                Offset(origin.x - r, origin.y - r), Size(r * 2, r * 2),
                style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round),
            )
        }
    }
}
