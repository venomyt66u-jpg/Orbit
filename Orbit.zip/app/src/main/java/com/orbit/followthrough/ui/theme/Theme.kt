package com.orbit.followthrough.ui.theme

import android.provider.Settings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.orbit.followthrough.R
import com.orbit.followthrough.domain.ThemeMode

/** Orbit design tokens. Dark Premium is the primary identity; light is a calm daylight variant. */
@Immutable
data class OrbitColors(
    val isDark: Boolean,
    val void: Color,
    val abyss: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val stroke: Color,
    val strokeStrong: Color,
    val text: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val cyan: Color,
    val electric: Color,
    val violet: Color,
    val amber: Color,
    val green: Color,
    val rose: Color,
    val gold: Color,
    val onAccent: Color,
) {
    val accentBrush: Brush get() = Brush.linearGradient(listOf(electric, cyan))
    val auroraBrush: Brush get() = Brush.linearGradient(listOf(violet, electric, cyan))
    val warmBrush: Brush get() = Brush.linearGradient(listOf(amber, rose))


    /** Palette for user habits (index stored in DB). */
    val habitPalette: List<Color> get() = listOf(electric, cyan, green, gold, violet, rose, amber)
    fun habit(index: Int): Color = habitPalette[((index % habitPalette.size) + habitPalette.size) % habitPalette.size]
}

val DarkOrbit = OrbitColors(
    isDark = true,
    void = Color(0xFF070A12),
    abyss = Color(0xFF0B1020),
    surface = Color(0xFF111830),
    surfaceHigh = Color(0xFF18213D),
    stroke = Color(0x1FB4C6FF),
    strokeStrong = Color(0x40B4C6FF),
    text = Color(0xFFEAF0FF),
    textSecondary = Color(0xFFA3AECB),
    textMuted = Color(0xFF6B7796),
    cyan = Color(0xFF3BE3FF),
    electric = Color(0xFF4D7CFF),
    violet = Color(0xFF8B5CFF),
    amber = Color(0xFFFFB547),
    green = Color(0xFF3DDC97),
    rose = Color(0xFFFF7AA8),
    gold = Color(0xFFFFC266),
    onAccent = Color(0xFF060914),
)

val LightOrbit = OrbitColors(
    isDark = false,
    void = Color(0xFFF4F6FC),
    abyss = Color(0xFFEAEEF9),
    surface = Color(0xFFFFFFFF),
    surfaceHigh = Color(0xFFF1F4FD),
    stroke = Color(0x1A1B2A55),
    strokeStrong = Color(0x331B2A55),
    text = Color(0xFF0D1430),
    textSecondary = Color(0xFF4A5577),
    textMuted = Color(0xFF7D87A6),
    cyan = Color(0xFF0098B8),
    electric = Color(0xFF3358E0),
    violet = Color(0xFF6A3FE0),
    amber = Color(0xFFC77700),
    green = Color(0xFF0F9A62),
    rose = Color(0xFFD43F78),
    gold = Color(0xFFB07A00),
    onAccent = Color(0xFFFFFFFF),
)

/** IBM Plex Sans Arabic (bundled, SIL Open Font License) – clean Arabic and Latin with good digits. */
val Plex = FontFamily(
    Font(R.font.plex_arabic_regular, FontWeight.Normal),
    Font(R.font.plex_arabic_medium, FontWeight.Medium),
    Font(R.font.plex_arabic_semibold, FontWeight.SemiBold),
    Font(R.font.plex_arabic_bold, FontWeight.Bold),
)

/** Type scale. Arabic needs a little more line height than Latin. */
object OrbitType {
    val display = TextStyle(fontFamily = Plex, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 44.sp)
    val headline = TextStyle(fontFamily = Plex, fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 34.sp)
    val title = TextStyle(fontFamily = Plex, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 27.sp)
    val subtitle = TextStyle(fontFamily = Plex, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 23.sp)
    val body = TextStyle(fontFamily = Plex, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 23.sp)
    val label = TextStyle(fontFamily = Plex, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 20.sp)
    val caption = TextStyle(fontFamily = Plex, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp)
    val overline = TextStyle(fontFamily = Plex, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, lineHeight = 16.sp, letterSpacing = 0.6.sp)
    val numeric = TextStyle(fontFamily = Plex, fontWeight = FontWeight.SemiBold, fontSize = 54.sp, lineHeight = 60.sp, letterSpacing = (-1).sp, fontFeatureSettings = "tnum")
    val numericSmall = TextStyle(fontFamily = Plex, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 22.sp, fontFeatureSettings = "tnum")
}

private val PlexTypography: Typography = Typography().let { t ->
    t.copy(
        displayLarge = t.displayLarge.copy(fontFamily = Plex), displayMedium = t.displayMedium.copy(fontFamily = Plex), displaySmall = t.displaySmall.copy(fontFamily = Plex),
        headlineLarge = t.headlineLarge.copy(fontFamily = Plex), headlineMedium = t.headlineMedium.copy(fontFamily = Plex), headlineSmall = t.headlineSmall.copy(fontFamily = Plex),
        titleLarge = t.titleLarge.copy(fontFamily = Plex), titleMedium = t.titleMedium.copy(fontFamily = Plex), titleSmall = t.titleSmall.copy(fontFamily = Plex),
        bodyLarge = t.bodyLarge.copy(fontFamily = Plex), bodyMedium = t.bodyMedium.copy(fontFamily = Plex), bodySmall = t.bodySmall.copy(fontFamily = Plex),
        labelLarge = t.labelLarge.copy(fontFamily = Plex), labelMedium = t.labelMedium.copy(fontFamily = Plex), labelSmall = t.labelSmall.copy(fontFamily = Plex),
    )
}

val LocalOrbitColors = staticCompositionLocalOf { DarkOrbit }
/** True when the user disabled animations system-wide (Settings ▸ Accessibility ▸ Remove animations). */
val LocalReducedMotion = staticCompositionLocalOf { false }

object Orbit {
    val colors: OrbitColors @Composable get() = LocalOrbitColors.current
    val reducedMotion: Boolean @Composable get() = LocalReducedMotion.current
}

@Composable
fun OrbitTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val colors = if (dark) DarkOrbit else LightOrbit
    val context = LocalContext.current
    val reduced = remember {
        runCatching { Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    val scheme = if (dark) darkColorScheme(
        primary = colors.cyan, onPrimary = colors.onAccent, secondary = colors.violet,
        background = colors.void, surface = colors.surface, onSurface = colors.text, onBackground = colors.text,
        surfaceVariant = colors.surfaceHigh, onSurfaceVariant = colors.textSecondary, outline = colors.strokeStrong,
        primaryContainer = colors.surfaceHigh, onPrimaryContainer = colors.text, tertiary = colors.amber,
        surfaceContainerHigh = colors.surfaceHigh, surfaceContainerHighest = colors.surfaceHigh, surfaceContainer = colors.surface,
    ) else lightColorScheme(
        primary = colors.electric, onPrimary = colors.onAccent, secondary = colors.violet,
        background = colors.void, surface = colors.surface, onSurface = colors.text, onBackground = colors.text,
        surfaceVariant = colors.surfaceHigh, onSurfaceVariant = colors.textSecondary, outline = colors.strokeStrong,
        primaryContainer = colors.surfaceHigh, onPrimaryContainer = colors.text, tertiary = colors.amber,
        surfaceContainerHigh = colors.surfaceHigh, surfaceContainerHighest = colors.surfaceHigh, surfaceContainer = colors.surface,
    )
    CompositionLocalProvider(LocalOrbitColors provides colors, LocalReducedMotion provides reduced) {
        MaterialTheme(colorScheme = scheme, typography = PlexTypography, content = content)
    }
}
