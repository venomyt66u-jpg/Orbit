package com.orbit.followthrough.ui.theme

import android.provider.Settings
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.orbit.followthrough.domain.ThemeMode

/** Orbit design tokens. Dark Premium is the primary identity; light is a calm daylight variant. */
@Immutable
data class OrbitColors(
    val isDark: Boolean,
    val void: Color,
    val abyss: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val stroke: Color,
    val strokeStrong: Color,
    val text: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val cyan: Color,
    val electric: Color,
    val violet: Color,
    val amber: Color,
    val green: Color,
    val rose: Color,
    val gold: Color,
    val onAccent: Color,
) {
    val accentBrush: Brush get() = Brush.linearGradient(listOf(electric, cyan))
    val auroraBrush: Brush get() = Brush.linearGradient(listOf(violet, electric, cyan))
    val warmBrush: Brush get() = Brush.linearGradient(listOf(amber, rose))


    /** Palette for user habits (index stored in DB). */
    val habitPalette: List<Color> get() = listOf(electric, cyan, green, gold, violet, rose, amber)
    fun habit(index: Int): Color = habitPalette[((index % habitPalette.size) + habitPalette.size) % habitPalette.size]
}

val DarkOrbit = OrbitColors(
    isDark = true,
    void = Color(0xFF070A12),
    abyss = Color(0xFF0B1020),
    surface = Color(0xFF111830),
    surfaceHigh = Color(0xFF18213D),
    stroke = Color(0x1FB4C6FF),
    strokeStrong = Color(0x40B4C6FF),
    text = Color(0xFFEAF0FF),
    textSecondary = Color(0xFFA3AECB),
    textMuted = Color(0xFF6B7796),
    cyan = Color(0xFF3BE3FF),
    electric = Color(0xFF4D7CFF),
    violet = Color(0xFF8B5CFF),
    amber = Color(0xFFFFB547),
    green = Color(0xFF3DDC97),
    rose = Color(0xFFFF7AA8),
    gold = Color(0xFFFFC266),
    onAccent = Color(0xFF060914),
)

val LightOrbit = OrbitColors(
    isDark = false,
    void = Color(0xFFF4F6FC),
    abyss = Color(0xFFEAEEF9),
    surface = Color(0xFFFFFFFF),
    surfaceHigh = Color(0xFFF1F4FD),
    stroke = Color(0x1A1B2A55),
    strokeStrong = Color(0x331B2A55),
    text = Color(0xFF0D1430),
    textSecondary = Color(0xFF4A5577),
    textMuted = Color(0xFF7D87A6),
    cyan = Color(0xFF0098B8),
    electric = Color(0xFF3358E0),
    violet = Color(0xFF6A3FE0),
    amber = Color(0xFFC77700),
    green = Color(0xFF0F9A62),
    rose = Color(0xFFD43F78),
    gold = Color(0xFFB07A00),
    onAccent = Color(0xFFFFFFFF),
)

/** Typography: system sans with tuned weights, tracking and tabular figures for times/counters. */
object OrbitType {
    val display = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 34.sp, lineHeight = 40.sp, letterSpacing = (-0.6).sp)
    val headline = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 26.sp, lineHeight = 32.sp, letterSpacing = (-0.4).sp)
    val title = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 19.sp, lineHeight = 25.sp, letterSpacing = (-0.2).sp)
    val subtitle = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp)
    val body = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp)
    val label = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp, letterSpacing = 0.1.sp)
    val caption = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.2.sp)
    val overline = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 1.4.sp)
    val numeric = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Light, fontSize = 56.sp, lineHeight = 60.sp, letterSpacing = (-1.5).sp, fontFeatureSettings = "tnum")
    val numericSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 15.sp, fontFeatureSettings = "tnum")
}

val LocalOrbitColors = staticCompositionLocalOf { DarkOrbit }
/** True when the user disabled animations system-wide (Settings ▸ Accessibility ▸ Remove animations). */
val LocalReducedMotion = staticCompositionLocalOf { false }

object Orbit {
    val colors: OrbitColors @Composable get() = LocalOrbitColors.current
    val reducedMotion: Boolean @Composable get() = LocalReducedMotion.current
}

@Composable
fun OrbitTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
    }
    val colors = if (dark) DarkOrbit else LightOrbit
    val context = LocalContext.current
    val reduced = remember {
        runCatching { Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }.getOrDefault(false)
    }
    val scheme = if (dark) darkColorScheme(
        primary = colors.cyan, onPrimary = colors.onAccent, secondary = colors.violet,
        background = colors.void, surface = colors.surface, onSurface = colors.text, onBackground = colors.text,
        surfaceVariant = colors.surfaceHigh, onSurfaceVariant = colors.textSecondary, outline = colors.strokeStrong,
        primaryContainer = colors.surfaceHigh, onPrimaryContainer = colors.text, tertiary = colors.amber,
        surfaceContainerHigh = colors.surfaceHigh, surfaceContainerHighest = colors.surfaceHigh, surfaceContainer = colors.surface,
    ) else lightColorScheme(
        primary = colors.electric, onPrimary = colors.onAccent, secondary = colors.violet,
        background = colors.void, surface = colors.surface, onSurface = colors.text, onBackground = colors.text,
        surfaceVariant = colors.surfaceHigh, onSurfaceVariant = colors.textSecondary, outline = colors.strokeStrong,
        primaryContainer = colors.surfaceHigh, onPrimaryContainer = colors.text, tertiary = colors.amber,
        surfaceContainerHigh = colors.surfaceHigh, surfaceContainerHighest = colors.surfaceHigh, surfaceContainer = colors.surface,
    )
    CompositionLocalProvider(LocalOrbitColors provides colors, LocalReducedMotion provides reduced) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
