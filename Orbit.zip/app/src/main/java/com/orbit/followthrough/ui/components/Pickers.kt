package com.orbit.followthrough.ui.components

import android.text.format.DateFormat
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.orbit.followthrough.R
import com.orbit.followthrough.ui.theme.Orbit
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerDialog(hour: Int, minute: Int, onConfirm: (Int, Int) -> Unit, onDismiss: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val state = rememberTimePickerState(initialHour = hour, initialMinute = minute, is24Hour = DateFormat.is24HourFormat(ctx))
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        text = {
            TimePicker(
                state = state,
                colors = TimePickerDefaults.colors(
                    clockDialColor = c.surfaceHigh,
                    selectorColor = c.cyan,
                    clockDialSelectedContentColor = c.onAccent,
                    clockDialUnselectedContentColor = c.text,
                    timeSelectorSelectedContainerColor = c.cyan.copy(alpha = 0.18f),
                    timeSelectorUnselectedContainerColor = c.surfaceHigh,
                    timeSelectorSelectedContentColor = c.cyan,
                    timeSelectorUnselectedContentColor = c.text,
                    periodSelectorSelectedContainerColor = c.cyan.copy(alpha = 0.18f),
                    periodSelectorSelectedContentColor = c.cyan,
                    periodSelectorUnselectedContentColor = c.textSecondary,
                    periodSelectorBorderColor = c.strokeStrong,
                ),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(state.hour, state.minute) }) { Text(stringResource(R.string.ok), color = c.cyan) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePickerSheet(initial: LocalDate, onConfirm: (LocalDate) -> Unit, onDismiss: () -> Unit, allowPast: Boolean = false) {
    val c = Orbit.colors
    val todayUtc = LocalDate.now().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    val state = rememberDatePickerState(
        initialSelectedDateMillis = initial.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean = allowPast || utcTimeMillis >= todayUtc
        },
    )
    val colors = DatePickerDefaults.colors(
        containerColor = c.surface,
        selectedDayContainerColor = c.cyan,
        selectedDayContentColor = c.onAccent,
        todayDateBorderColor = c.cyan,
        todayContentColor = c.cyan,
        dayContentColor = c.text,
        weekdayContentColor = c.textMuted,
        titleContentColor = c.textSecondary,
        headlineContentColor = c.text,
        navigationContentColor = c.text,
        yearContentColor = c.text,
        selectedYearContainerColor = c.cyan,
        selectedYearContentColor = c.onAccent,
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                val ms = state.selectedDateMillis
                if (ms != null) onConfirm(Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()) else onDismiss()
            }) { Text(stringResource(R.string.ok), color = c.cyan) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
        colors = colors,
    ) {
        DatePicker(state = state, colors = colors)
    }
}
