package com.orbit.followthrough.domain

import java.time.Instant
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Quiet hours expressed as minutes of the day. Supports ranges that cross midnight. */
data class QuietHours(val enabled: Boolean, val startMinute: Int, val endMinute: Int) {

    fun isQuiet(epochMillis: Long, zone: ZoneId): Boolean {
        if (!enabled || startMinute == endMinute) return false
        val z = Instant.ofEpochMilli(epochMillis).atZone(zone)
        val m = z.hour * 60 + z.minute
        return if (startMinute < endMinute) m in startMinute until endMinute
        else m >= startMinute || m < endMinute
    }

    /** If [epochMillis] falls inside quiet hours, move it to the end of the quiet window. */
    fun deferIfQuiet(epochMillis: Long, zone: ZoneId): Long {
        if (!isQuiet(epochMillis, zone)) return epochMillis
        val z = Instant.ofEpochMilli(epochMillis).atZone(zone)
        val m = z.hour * 60 + z.minute
        var endDate = z.toLocalDate()
        if (startMinute > endMinute && m >= startMinute) endDate = endDate.plusDays(1)
        val end = ZonedDateTime.of(endDate, LocalTime.of(endMinute / 60, endMinute % 60), zone)
        return end.toInstant().toEpochMilli()
    }

    companion object {
        val OFF = QuietHours(false, 22 * 60, 7 * 60)
    }
}

/**
 * Decides when (if ever) a dismissed reminder comes back.
 * The policy never loops forever: it respects the follow-up limit, the deadline and quiet hours.
 */
object FollowUpPolicy {

    val ALLOWED_MINUTES = listOf(5, 10, 15, 30, 60)

    fun nextFollowUp(
        nowMillis: Long,
        followUpMinutes: Int,
        followUpsUsed: Int,
        maxFollowUps: Int,
        deadlineMillis: Long?,
        nextOccurrenceMillis: Long?,
        quiet: QuietHours,
        bypassQuiet: Boolean,
        zone: ZoneId,
    ): Long? {
        if (followUpMinutes <= 0) return null
        if (followUpsUsed >= maxFollowUps) return null
        var t = nowMillis + followUpMinutes * 60_000L
        if (!bypassQuiet) t = quiet.deferIfQuiet(t, zone)
        if (deadlineMillis != null && t > deadlineMillis) return null
        // Never let a follow-up collide with (or pass) the next real occurrence.
        if (nextOccurrenceMillis != null && t >= nextOccurrenceMillis) return null
        return t
    }
}
