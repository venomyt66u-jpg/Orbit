package com.orbit.followthrough.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Package
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.delay

/**
 * The current package: when it started (date and time, shown to everyone so a reset can't be
 * hidden), when it ends, how much was used since. The admin can start a new one.
 */
@Composable
fun PackageCard(
    start: Long,
    usage: Bytes?,
    approximate: Boolean,
    usageLabel: String,
    history: List<Long>,
    modifier: Modifier = Modifier,
    onNewPackage: (() -> Unit)? = null,
) {
    val c = Orbit.colors
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(60_000); now = System.currentTimeMillis() } }

    if (start <= 0L) {
        GlassCard(modifier.fillMaxWidth(), highlight = c.amber) {
            Text("الباقة", style = OrbitType.label, color = c.textSecondary)
            Text(
                if (onNewPackage != null) "لسه مفيش باقة متسجلة" else "الأدمن لسه مبدأش باقة",
                style = OrbitType.title, color = c.text,
            )
            Text(
                if (onNewPackage != null) "أول ما تجدد باقة الراوتر دوس الزرار. العدّ هيبدأ من اللحظة دي ولمدة شهر."
                else "أول ما الأدمن يبدأ باقة، استهلاكك فيها هيظهر هنا.",
                style = OrbitType.caption, color = c.textSecondary,
            )
            if (onNewPackage != null) {
                Spacer(Modifier.height(12.dp))
                PrimaryButton("ابدأ باقة جديدة دلوقتي", onNewPackage, Modifier.fillMaxWidth(), icon = OrbitIcons.Repeat)
            }
        }
    } else {
        ActivePackage(start, now, usage, approximate, usageLabel, history, modifier, onNewPackage)
    }
}

@Composable
private fun ActivePackage(
    start: Long,
    now: Long,
    usage: Bytes?,
    approximate: Boolean,
    usageLabel: String,
    history: List<Long>,
    modifier: Modifier,
    onNewPackage: (() -> Unit)?,
) {
    val c = Orbit.colors
    val end = Package.endOf(start)
    val left = Package.daysLeft(start, now)
    val elapsed = ((now - start).toFloat() / (end - start).coerceAtLeast(1L)).coerceIn(0f, 1f)
    val bar by animateFloatAsState(elapsed, tween(1000, easing = FastOutSlowInEasing), label = "pkg")

    GlassCard(modifier.fillMaxWidth(), highlight = if (left == 0) c.amber else c.cyan) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الباقة الحالية", style = OrbitType.label, color = c.textSecondary, modifier = Modifier.weight(1f))
            if (left == 0) Tag("خلصت · جدّد الباقة", c.amber) else Tag("فاضل $left يوم", c.cyan)
        }
        Spacer(Modifier.height(10.dp))
        // The start stamp – the same date and time on every phone.
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface.copy(alpha = 0.7f)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(c.amber.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Icon(OrbitIcons.Repeat, null, tint = c.amber, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("بدأت", style = OrbitType.caption, color = c.textMuted)
                Text(Ar.dateTime(start), style = OrbitType.subtitle, color = c.text)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(usageLabel, style = OrbitType.label, color = c.textSecondary)
        Row(verticalAlignment = Alignment.Bottom) {
            if (approximate) Text("≈ ", style = OrbitType.headline, color = c.textSecondary)
            AnimatedBytes(usage?.total ?: 0L, big = false)
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
            if (bar > 0f) Box(Modifier.fillMaxWidth(bar).fillMaxHeight().clip(RoundedCornerShape(50)).background(c.accentBrush))
        }
        Spacer(Modifier.height(6.dp))
        Row {
            Text(Ar.dateShort(start), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.weight(1f))
            Text("بتخلص " + Ar.dateShort(end) + " · " + Ar.time(end), style = OrbitType.caption, color = c.textMuted)
        }
        val previous = history.filter { it < start }.takeLast(3).reversed()
        if (previous.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("الباقات اللي قبلها", style = OrbitType.caption, color = c.textMuted)
            previous.forEach { Text("• " + Ar.dateTime(it), style = OrbitType.caption, color = c.textSecondary) }
        }
        if (onNewPackage != null) {
            Spacer(Modifier.height(12.dp))
            SecondaryButton("جدّدت الباقة؟ ابدأ باقة جديدة", onNewPackage, icon = OrbitIcons.Repeat, tint = c.amber)
        }
    }
}

/** Confirmation that shows exactly what will be recorded. */
@Composable
fun NewPackageDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = Orbit.colors
    val now = remember { System.currentTimeMillis() }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surfaceHigh,
        icon = { Icon(OrbitIcons.Repeat, null, tint = c.amber) },
        title = { Text("باقة جديدة؟", style = OrbitType.title, color = c.text) },
        text = {
            Column {
                Text("هيتسجل إن الباقة بدأت:", style = OrbitType.body, color = c.textSecondary)
                Spacer(Modifier.height(4.dp))
                Text(Ar.dateTime(now), style = OrbitType.subtitle, color = c.text)
                Spacer(Modifier.height(10.dp))
                Text(
                    "العدّ هيبدأ من اللحظة دي لمدة شهر. التاريخ والساعة دول هيظهروا عند الكل ومش هيتغيروا. " +
                        "الاستهلاك القديم مش هيتمسح وهيفضل في التقويم.",
                    style = OrbitType.caption, color = c.textSecondary,
                )
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("ابدأ الباقة", color = c.amber) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = c.textSecondary) } },
    )
}
