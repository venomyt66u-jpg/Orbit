package com.orbit.followthrough.ui.util

import android.content.Context
import android.text.format.DateFormat
import android.text.format.DateUtils
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.domain.Weekdays
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

object Fmt {

    private fun locale(context: Context): Locale = context.resources.configuration.locales[0] ?: Locale.getDefault()

    fun time(context: Context, hour: Int, minute: Int): String {
        val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm a"
        return LocalTime.of(hour, minute).format(DateTimeFormatter.ofPattern(pattern, locale(context)))
    }

    fun time(context: Context, millis: Long): String {
        val t = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
        return time(context, t.hour, t.minute)
    }

    fun dayLabel(context: Context, date: LocalDate): String {
        val today = LocalDate.now()
        return when (date) {
            today -> context.getString(R.string.today)
            today.plusDays(1) -> context.getString(R.string.tomorrow)
            today.minusDays(1) -> context.getString(R.string.yesterday)
            else -> date.format(DateTimeFormatter.ofPattern("EEE d MMM", locale(context)))
        }
    }

    fun dayAndTime(context: Context, millis: Long): String {
        val z = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
        return context.getString(R.string.day_at_time, dayLabel(context, z.toLocalDate()), time(context, z.hour, z.minute))
    }

    /** "in 2 h 15 min" / "now". */
    fun countdown(context: Context, targetMillis: Long, now: Long = System.currentTimeMillis()): String {
        val diff = targetMillis - now
        if (diff <= 60_000) return context.getString(R.string.now)
        return context.getString(R.string.in_duration, duration(context, diff))
    }

    fun duration(context: Context, millis: Long): String {
        val totalMin = (millis / 60_000).coerceAtLeast(1)
        val days = totalMin / (60 * 24)
        val hours = (totalMin % (60 * 24)) / 60
        val mins = totalMin % 60
        return when {
            days > 0 -> context.getString(R.string.duration_dh, days, hours)
            hours > 0 && mins > 0 -> context.getString(R.string.duration_hm, hours, mins)
            hours > 0 -> context.getString(R.string.duration_h, hours)
            else -> context.getString(R.string.duration_m, mins)
        }
    }

    fun ago(millis: Long, now: Long = System.currentTimeMillis()): String =
        DateUtils.getRelativeTimeSpanString(millis, now, DateUtils.MINUTE_IN_MILLIS, DateUtils.FORMAT_ABBREV_RELATIVE).toString()

    fun minutesOfDay(context: Context, minuteOfDay: Int): String = time(context, (minuteOfDay / 60) % 24, minuteOfDay % 60)

    fun weekdayShort(context: Context, dow: DayOfWeek): String = dow.getDisplayName(TextStyle.SHORT, locale(context))
    fun weekdayNarrow(context: Context, dow: DayOfWeek): String = dow.getDisplayName(TextStyle.NARROW_STANDALONE, locale(context))

    fun weekdaysLabel(context: Context, mask: Int): String = when (mask) {
        Weekdays.ALL -> context.getString(R.string.every_day)
        Weekdays.WORKWEEK_MON_FRI -> context.getString(R.string.weekdays_mon_fri)
        Weekdays.WORKWEEK_SUN_THU -> context.getString(R.string.weekdays_sun_thu)
        Weekdays.WEEKEND_SAT_SUN, Weekdays.WEEKEND_FRI_SAT -> context.getString(R.string.weekends)
        else -> DayOfWeek.values().filter { Weekdays.has(mask, it) }.joinToString(" · ") { weekdayShort(context, it) }
    }

    /** Human description of a schedule: "Every day · 9:00 AM". */
    fun schedule(context: Context, type: RepeatType, hour: Int, minute: Int, date: LocalDate, weekdays: Int, interval: Int, dayOfMonth: Int): String {
        val t = time(context, hour, minute)
        val what = when (type) {
            RepeatType.ONCE -> dayLabel(context, date)
            RepeatType.DAILY -> context.getString(R.string.every_day)
            RepeatType.WEEKLY -> weekdaysLabel(context, if (weekdays == 0) Weekdays.bit(date.dayOfWeek) else weekdays)
            RepeatType.MONTHLY -> context.getString(R.string.monthly_on, dayOfMonth)
            RepeatType.INTERVAL -> context.resources.getQuantityString(R.plurals.every_n_days, interval, interval)
        }
        return "$what · $t"
    }

    fun schedule(context: Context, r: ReminderEntity): String =
        schedule(context, r.repeatType, r.hour, r.minute, LocalDate.ofEpochDay(r.startEpochDay), r.weekdays, r.interval, r.dayOfMonth)
}
