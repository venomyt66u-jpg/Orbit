package com.orbit.followthrough.ui.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.data.prefs.AppSettings

object Routes {
    const val HOME = "home"
    const val HABITS = "habits"
    const val SIGNALS = "signals"
    const val ASSISTANT = "assistant"
    const val SETTINGS = "settings"

    const val EDITOR = "editor?id={id}"
    fun editor(id: Long = -1L) = "editor?id=$id"
    const val REMINDERS = "reminders"
    const val TASBIH = "tasbih/{id}"
    fun tasbih(id: Long) = "tasbih/$id"
    const val HABIT_EDIT = "habit?id={id}"
    fun habitEdit(id: Long = -1L) = "habit?id=$id"
    const val SOURCES = "sources"
    const val HISTORY = "history"
    const val SOUNDS = "sounds"
    const val PERMISSIONS = "permissions"
    const val PRIVACY = "privacy"
    const val HELP = "help"
    const val TUTORIAL = "tutorial/{key}"
    fun tutorial(key: String) = "tutorial/$key"
    const val ONBOARDING = "onboarding"
    const val MARKET = "market"
    const val MORE = "more"
    const val NETWORK = "network"
    const val KEYS = "keys"
    const val WALLET = "wallet/{id}"
    fun wallet(id: Long) = "wallet/$id"

    /** Bottom navigation. Assistant & Settings live in "More" and in the Home header. */
    val topLevel = listOf(HOME, HABITS, MARKET, SIGNALS, MORE)
}

val LocalAppContainer = staticCompositionLocalOf<AppContainer> { error("AppContainer not provided") }
val LocalSettings = staticCompositionLocalOf { AppSettings() }

/** ViewModel factory backed by the app container (no DI framework needed). */
@Composable
inline fun <reified VM : ViewModel> orbitViewModel(key: String? = null, crossinline create: (AppContainer) -> VM): VM {
    val container = LocalAppContainer.current
    return viewModel(key = key, factory = viewModelFactory { initializer { create(container) } })
}
