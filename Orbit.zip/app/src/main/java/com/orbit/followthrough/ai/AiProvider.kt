package com.orbit.followthrough.ai

import com.orbit.followthrough.domain.RepeatType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZonedDateTime

/**
 * Pluggable AI layer. The default provider is fully on-device ([CommandParser]).
 * An optional cloud provider talks ONLY to the user's own backend (see /backend), which holds the
 * LLM API key server-side. No secret is ever embedded in the app.
 */
interface AiProvider {
    suspend fun parse(text: String, now: ZonedDateTime): Command
}

class LocalAiProvider : AiProvider {
    override suspend fun parse(text: String, now: ZonedDateTime): Command = CommandParser.parse(text, now)
}

/**
 * Sends the command text (and nothing else) to `<backendUrl>/parse`. The response is treated as
 * untrusted: it is validated field by field, and on any failure we fall back to the local parser.
 * Expected JSON: {"intent":"create","title":"…","repeat":"DAILY","hour":9,"minute":0,"date":"2026-10-11","weekdays":0}
 */
class RemoteAiProvider(private val backendUrl: String, private val fallback: AiProvider = LocalAiProvider()) : AiProvider {

    override suspend fun parse(text: String, now: ZonedDateTime): Command {
        if (!backendUrl.startsWith("https://")) return fallback.parse(text, now)
        return runCatching { remote(text, now) }.getOrNull() ?: fallback.parse(text, now)
    }

    private suspend fun remote(text: String, now: ZonedDateTime): Command? = withContext(Dispatchers.IO) {
        val conn = (URL(backendUrl.trimEnd('/') + "/parse").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8_000
            readTimeout = 12_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            val body = JSONObject().put("text", text.take(500)).put("now", now.toString()).toString()
            conn.outputStream.use { it.write(body.toByteArray()) }
            if (conn.responseCode !in 200..299) return@withContext null
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            when (json.optString("intent")) {
                "create" -> {
                    val title = json.optString("title").trim().take(120)
                    val repeat = RepeatType.entries.firstOrNull { it.name == json.optString("repeat") } ?: RepeatType.ONCE
                    val hour = if (json.has("hour")) json.optInt("hour", -1).takeIf { it in 0..23 } else null
                    val minute = json.optInt("minute", 0).coerceIn(0, 59)
                    val date = runCatching { LocalDate.parse(json.optString("date")) }.getOrNull() ?: now.toLocalDate()
                    val weekdays = json.optInt("weekdays", 0).coerceIn(0, 127)
                    Command.Create(ReminderDraft(title = title, repeat = repeat, hour = hour, minute = minute, date = date, weekdays = weekdays))
                }
                "postponed" -> Command.ShowPostponed
                "summarize" -> Command.Summarize
                else -> null
            }
        } finally {
            conn.disconnect()
        }
    }
}
