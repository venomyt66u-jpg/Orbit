package com.orbit.followthrough.notify

import android.content.ContentResolver
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import androidx.annotation.RawRes
import androidx.annotation.StringRes
import com.orbit.followthrough.R

/** Orbit's original, built-in sound library (synthesised by tools/generate_sounds.py). */
data class BuiltInSound(val key: String, @RawRes val res: Int, @StringRes val nameRes: Int, @StringRes val moodRes: Int)

object SoundLibrary {
    val sounds = listOf(
        BuiltInSound("chime_soft", R.raw.chime_soft, R.string.sound_chime_soft, R.string.mood_calm),
        BuiltInSound("zen_bowl", R.raw.zen_bowl, R.string.sound_zen_bowl, R.string.mood_calm),
        BuiltInSound("ping_bright", R.raw.ping_bright, R.string.sound_ping_bright, R.string.mood_clear),
        BuiltInSound("bell_warm", R.raw.bell_warm, R.string.sound_bell_warm, R.string.mood_clear),
        BuiltInSound("pulse_alert", R.raw.pulse_alert, R.string.sound_pulse_alert, R.string.mood_distinct),
        BuiltInSound("orbit_glide", R.raw.orbit_glide, R.string.sound_orbit_glide, R.string.mood_distinct),
        BuiltInSound("crystal", R.raw.crystal, R.string.sound_crystal, R.string.mood_bright),
        BuiltInSound("droplet", R.raw.droplet, R.string.sound_droplet, R.string.mood_subtle),
    )

    fun builtIn(soundId: String): BuiltInSound? =
        if (soundId.startsWith("raw:")) sounds.firstOrNull { it.key == soundId.removePrefix("raw:") } else null

    /** Resolve a stored sound id into a channel-usable URI. null = silent. */
    fun uriFor(context: Context, soundId: String): Uri? = when {
        soundId == "silent" -> null
        soundId == "system" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        soundId.startsWith("uri:") -> runCatching { Uri.parse(soundId.removePrefix("uri:")) }.getOrNull()
        else -> {
            val s = builtIn(soundId) ?: sounds.first()
            Uri.Builder()
                .scheme(ContentResolver.SCHEME_ANDROID_RESOURCE)
                .authority(context.packageName)
                .appendPath(s.res.toString())
                .build()
        }
    }

    fun audioAttributes(): AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()
}

/** Plays a short preview of a sound. Always release() when the screen goes away. */
class SoundPreviewPlayer(private val context: Context) {
    private var player: MediaPlayer? = null
    private var ringtone: Ringtone? = null

    fun play(soundId: String, onDone: () -> Unit = {}) {
        stop()
        try {
            when {
                soundId == "silent" -> onDone()
                soundId == "system" || soundId.startsWith("uri:") -> {
                    val uri = SoundLibrary.uriFor(context, soundId) ?: return onDone()
                    ringtone = RingtoneManager.getRingtone(context, uri)?.also { it.play() }
                    onDone()
                }
                else -> {
                    val s = SoundLibrary.builtIn(soundId) ?: return onDone()
                    player = MediaPlayer.create(context, s.res)?.apply {
                        setOnCompletionListener {
                            it.release()
                            if (player === it) player = null
                            onDone()
                        }
                        start()
                    }
                    if (player == null) onDone()
                }
            }
        } catch (_: Exception) {
            onDone()
        }
    }

    fun stop() {
        runCatching { player?.stop() }
        runCatching { player?.release() }
        player = null
        runCatching { ringtone?.stop() }
        ringtone = null
    }
}
