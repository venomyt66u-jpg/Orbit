package com.orbit.followthrough.engine

import android.app.AlarmManager
import android.content.Context
import android.os.Build
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.data.db.nextAlarmAt

/**
 * Thin wrapper around AlarmManager. Every reminder owns at most ONE pending alarm, so there are
 * never duplicate scheduled jobs. When exact-alarm access is unavailable we fall back to a
 * battery-friendly inexact alarm instead of failing.
 */
class AlarmScheduler(private val context: Context) {

    private val am = context.getSystemService(AlarmManager::class.java)

    fun canScheduleExact(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()

    fun syncReminder(r: ReminderEntity) {
        val at = r.nextAlarmAt()
        if (at == null) cancel(OrbitIntents.ALARM_REMINDER, r.id)
        else set(OrbitIntents.ALARM_REMINDER, r.id, at)
    }

    fun cancelReminder(id: Long) = cancel(OrbitIntents.ALARM_REMINDER, id)

    fun setHabit(habitId: Long, at: Long) = set(OrbitIntents.ALARM_HABIT, habitId, at)
    fun cancelHabit(habitId: Long) = cancel(OrbitIntents.ALARM_HABIT, habitId)

    private fun set(action: String, id: Long, atMillis: Long) {
        val pi = OrbitIntents.alarm(context, action, id) ?: return
        val at = atMillis.coerceAtLeast(System.currentTimeMillis() + 1_000)
        try {
            if (canScheduleExact()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancel(action: String, id: Long) {
        val pi = OrbitIntents.alarm(context, action, id, create = false) ?: return
        am.cancel(pi)
        pi.cancel()
    }
}
