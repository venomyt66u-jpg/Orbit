package com.orbit.followthrough.data.prefs

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores the user's OWN API keys (AI provider, Etherscan, CoinGecko, router password) encrypted with
 * an AES-256-GCM key that lives in the Android Keystore and never leaves the device.
 * Nothing here is bundled in the APK. Excluded from backups (see backup rules).
 */
class SecretStore(context: Context) {

    enum class Key(val id: String) { LLM("llm_api_key"), ETHERSCAN("etherscan_key"), BLOCKSCOUT("blockscout_key"), COINGECKO("coingecko_key"), ROUTER_PASSWORD("router_password") }

    private val prefs = context.getSharedPreferences("orbit_secure", Context.MODE_PRIVATE)
    private val alias = "orbit_secret_key_v1"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(alias, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun put(key: Key, value: String?) {
        if (value.isNullOrBlank()) { prefs.edit().remove(key.id).apply(); return }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val enc = cipher.doFinal(value.trim().toByteArray(Charsets.UTF_8))
        val packed = cipher.iv + enc
        prefs.edit().putString(key.id, Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
    }

    fun get(key: Key): String? {
        val stored = prefs.getString(key.id, null) ?: return null
        return runCatching {
            val bytes = Base64.decode(stored, Base64.NO_WRAP)
            val iv = bytes.copyOfRange(0, 12)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
        }.getOrNull()
    }

    fun has(key: Key): Boolean = prefs.contains(key.id)

    /** "sk-…a1b2" for display; never shows the full key. */
    fun masked(key: Key): String? = get(key)?.let { if (it.length <= 8) "••••" else it.take(4) + "…" + it.takeLast(4) }

    fun clearAll() { prefs.edit().clear().apply() }
}
