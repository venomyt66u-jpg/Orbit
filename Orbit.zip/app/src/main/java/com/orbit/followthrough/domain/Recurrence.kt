package com.orbit.followthrough.domain

import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.min

/**
 * A wall-clock schedule. Times are stored as local hour/minute + a start date so
 * that recurring reminders stay at "9:00" across time-zone changes and DST transitions.
 */
data class Schedule(
    val type: RepeatType,
    val hour: Int,
    val minute: Int,
    val startDate: LocalDate,
    val weekdays: Int = 0,
    val interval: Int = 1,
    val dayOfMonth: Int = startDate.dayOfMonth,
)

object Recurrence {

    /**
     * Returns the first occurrence strictly after [after], or null when the schedule has ended
     * (a one-time reminder in the past).
     *
     * DST: ZonedDateTime.of() moves times that fall into a spring-forward gap forward by the
     * gap length and picks the earlier offset during a fall-back overlap, so a reminder never
     * disappears or fires twice.
     */
    fun next(schedule: Schedule, after: Instant, zone: ZoneId): Instant? {
        val time = LocalTime.of(schedule.hour.coerceIn(0, 23), schedule.minute.coerceIn(0, 59))
        fun at(date: LocalDate): Instant = ZonedDateTime.of(date, time, zone).toInstant()

        val afterDate = after.atZone(zone).toLocalDate()
        val from = if (afterDate.isBefore(schedule.startDate)) schedule.startDate else afterDate

        return when (schedule.type) {
            RepeatType.ONCE -> {
                val t = at(schedule.startDate)
                return if (t.isAfter(after)) t else null
            }

            RepeatType.DAILY -> {
                var d = from
                repeat(3) {
                    val t = at(d)
                    if (t.isAfter(after)) return t
                    d = d.plusDays(1)
                }
                return null
            }

            RepeatType.WEEKLY -> {
                val mask = if (schedule.weekdays == 0) Weekdays.bit(schedule.startDate.dayOfWeek) else schedule.weekdays
                var d = from
                repeat(15) {
                    if (Weekdays.has(mask, d.dayOfWeek)) {
                        val t = at(d)
                        if (t.isAfter(after)) return t
                    }
                    d = d.plusDays(1)
                }
                return null
            }

            RepeatType.MONTHLY -> {
                var ym = YearMonth.from(from)
                repeat(15) {
                    val dom = min(max(1, schedule.dayOfMonth), ym.lengthOfMonth())
                    val d = ym.atDay(dom)
                    if (!d.isBefore(schedule.startDate)) {
                        val t = at(d)
                        if (t.isAfter(after)) return t
                    }
                    ym = ym.plusMonths(1)
                }
                return null
            }

            RepeatType.INTERVAL -> {
                val n = max(1, schedule.interval).toLong()
                val elapsed = ChronoUnit.DAYS.between(schedule.startDate, from).coerceAtLeast(0)
                val k = (elapsed + n - 1) / n
                var d = schedule.startDate.plusDays(k * n)
                repeat(3) {
                    val t = at(d)
                    if (t.isAfter(after)) return t
                    d = d.plusDays(n)
                }
                return null
            }
        }
    }

    /** All occurrences in [fromInclusive, toExclusive) – used for the "today" timeline. */
    fun occurrencesBetween(schedule: Schedule, fromInclusive: Instant, toExclusive: Instant, zone: ZoneId, limit: Int = 24): List<Instant> {
        val result = ArrayList<Instant>()
        var cursor = fromInclusive.minusMillis(1)
        while (result.size < limit) {
            val n = next(schedule, cursor, zone) ?: break
            if (!n.isBefore(toExclusive)) break
            result += n
            cursor = n
        }
        return result
    }
}
