package com.orbit.followthrough.wallets

import java.util.Locale
import kotlin.math.abs

/** A single asset movement inside one transaction, relative to the tracked wallet. */
data class Transfer(
    val symbol: String,
    val amount: Double,
    val incoming: Boolean,
    /** ERC-721 / ERC-1155 (or other non-fungible) transfer. */
    val nft: Boolean = false,
    /** Sent from the zero address = freshly minted. */
    val fromZero: Boolean = false,
)

enum class ActivityKind { MINT, BUY, SELL, SWAP, RECEIVE, SEND, CONTRACT }

data class Classified(
    val kind: ActivityKind,
    /** What the wallet got. */
    val inSymbol: String? = null,
    val inAmount: Double? = null,
    /** What the wallet gave. */
    val outSymbol: String? = null,
    val outAmount: Double? = null,
)

/**
 * Explains a transaction the way a person would: "bought PEPE with ETH", "sold SOL for USDC".
 * Pure logic, unit tested. Base assets are native coins, wrapped natives and stablecoins.
 */
object ActivityClassifier {

    val stablecoins = setOf("USDT", "USDC", "DAI", "BUSD", "FDUSD", "TUSD", "USDE", "PYUSD", "USDS", "USDC.E", "USDT0")
    val natives = setOf("ETH", "WETH", "BNB", "WBNB", "SOL", "WSOL", "POL", "MATIC", "WMATIC", "WPOL", "BTC", "WBTC", "AVAX", "WAVAX")

    fun isBase(symbol: String): Boolean = symbol.uppercase(Locale.ROOT).let { it in stablecoins || it in natives }

    fun classify(transfers: List<Transfer>): Classified {
        // Mint: something arrived from the zero address (NFT mints, token claims). What was paid is the base outflow.
        val minted = transfers.filter { it.incoming && it.fromZero }
        if (minted.isNotEmpty()) {
            val preferred = minted.filter { it.nft }.ifEmpty { minted }
            val bySymbol = preferred.groupBy { it.symbol.uppercase(Locale.ROOT) }.mapValues { (_, l) -> l.sumOf { it.amount } }
            val (sym, amt) = bySymbol.maxByOrNull { it.value }!!.toPair()
            val paid = transfers.filter { !it.incoming && isBase(it.symbol) }
                .groupBy { it.symbol.uppercase(Locale.ROOT) }.mapValues { (_, l) -> l.sumOf { it.amount } }.maxByOrNull { it.value }
            return Classified(ActivityKind.MINT, sym, amt, paid?.key, paid?.value)
        }
        // Net movement per asset (a swap may route through several hops).
        val net = LinkedHashMap<String, Double>()
        for (t in transfers) {
            val key = t.symbol.uppercase(Locale.ROOT)
            net[key] = (net[key] ?: 0.0) + if (t.incoming) t.amount else -t.amount
        }
        val ins = net.filter { it.value > 1e-12 }
        val outs = net.filter { it.value < -1e-12 }.mapValues { abs(it.value) }

        if (ins.isEmpty() && outs.isEmpty()) return Classified(ActivityKind.CONTRACT)
        if (outs.isEmpty()) {
            val (s, a) = ins.maxByOrNull { it.value }!!.toPair()
            return Classified(ActivityKind.RECEIVE, inSymbol = s, inAmount = a)
        }
        if (ins.isEmpty()) {
            val (s, a) = pickMain(outs)
            return Classified(ActivityKind.SEND, outSymbol = s, outAmount = a)
        }
        val (inS, inA) = pickMain(ins)
        val (outS, outA) = pickMain(outs)
        val kind = when {
            !isBase(inS) && isBase(outS) -> ActivityKind.BUY
            isBase(inS) && !isBase(outS) -> ActivityKind.SELL
            else -> ActivityKind.SWAP
        }
        return Classified(kind, inS, inA, outS, outA)
    }

    /** Prefer the non-base asset (the "interesting" token); otherwise the largest amount. */
    private fun pickMain(m: Map<String, Double>): Pair<String, Double> {
        val nonBase = m.filterKeys { !isBase(it) }
        val pool = nonBase.ifEmpty { m }
        return pool.maxByOrNull { it.value }!!.toPair()
    }

    /** USD estimate using the base side (stablecoin = $1, native = market price). */
    fun estimateUsd(c: Classified, priceOf: (String) -> Double?): Double? {
        fun v(sym: String?, amt: Double?): Double? {
            if (sym == null || amt == null) return null
            val s = sym.uppercase(Locale.ROOT)
            if (s in stablecoins) return amt
            val key = when (s) {
                "WETH" -> "ETH"; "WBNB" -> "BNB"; "WSOL" -> "SOL"; "WBTC" -> "BTC"; "WMATIC", "MATIC", "WPOL" -> "POL"; "WAVAX" -> "AVAX"
                else -> s
            }
            return priceOf(key)?.let { it * amt }
        }
        return when (c.kind) {
            ActivityKind.BUY, ActivityKind.MINT -> v(c.outSymbol, c.outAmount)
            ActivityKind.SELL -> v(c.inSymbol, c.inAmount)
            ActivityKind.SWAP -> v(c.outSymbol, c.outAmount) ?: v(c.inSymbol, c.inAmount)
            ActivityKind.RECEIVE -> v(c.inSymbol, c.inAmount)
            ActivityKind.SEND -> v(c.outSymbol, c.outAmount)
            ActivityKind.CONTRACT -> null
        }
    }
}
