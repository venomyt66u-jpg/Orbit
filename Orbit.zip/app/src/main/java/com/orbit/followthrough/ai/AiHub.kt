package com.orbit.followthrough.ai

import android.content.Context
import com.orbit.followthrough.data.prefs.AppSettings
import com.orbit.followthrough.data.prefs.SecretStore
import org.json.JSONObject
import java.time.ZonedDateTime

/**
 * Everything "smart" that needs a large language model goes through here.
 * Sends only the minimum text needed for the task; personal reminder text is sent only when the user
 * asks the assistant directly. Religious text is never generated.
 */
class AiHub(private val context: Context, private val secrets: SecretStore) {

    fun config(s: AppSettings): LlmConfig {
        val p = LlmProvider.entries.firstOrNull { it.name == s.llmProvider } ?: LlmProvider.NONE
        return LlmConfig(p, s.llmModel, secrets.get(SecretStore.Key.LLM), s.aiBackendUrl)
    }

    fun ready(s: AppSettings): Boolean = s.aiEnabled && config(s).ready

    private fun language(): String =
        if (context.resources.configuration.locales[0].language == "ar") "Arabic (friendly Egyptian Arabic is welcome)" else "English"

    private fun baseRules() = """
        You are Orbit, a calm, precise personal assistant inside an Android app.
        Reply in ${language()}. Be concise and concrete. Use short paragraphs or bullets.
        Never invent Quranic verses, hadith or religious quotations.
        Never present market commentary as financial advice; say it is information, not advice, when relevant.
    """.trimIndent()

    sealed interface Answer {
        data class Text(val text: String) : Answer
        data class Reminder(val draft: ReminderDraft, val text: String) : Answer
    }

    /** General question or a command the offline parser couldn't understand. */
    suspend fun ask(s: AppSettings, question: String, context: String): Result<Answer> {
        val now = ZonedDateTime.now()
        val system = baseRules() + "\n" + """
            Current local time: $now.
            If the user wants a reminder, reply ONLY with JSON:
            {"type":"reminder","title":"...","repeat":"ONCE|DAILY|WEEKLY|MONTHLY","hour":0-23,"minute":0-59,"date":"YYYY-MM-DD","weekdays":0,"say":"one short confirmation sentence"}
            Otherwise reply ONLY with JSON: {"type":"answer","text":"..."}
            Context from the app (may be empty):
            $context
        """.trimIndent()
        return LlmClient(config(s)).complete(system, question.take(1500), 800).map { raw -> parse(raw, now) }
    }

    private fun parse(raw: String, now: ZonedDateTime): Answer {
        val json = raw.substringAfter("```json", raw).substringAfter("```", raw).substringBeforeLast("```").trim()
        val start = json.indexOf('{')
        val end = json.lastIndexOf('}')
        if (start < 0 || end <= start) return Answer.Text(raw)
        return runCatching {
            val o = JSONObject(json.substring(start, end + 1))
            if (o.optString("type") == "reminder") {
                val title = o.optString("title").trim().take(120)
                val hour = if (o.has("hour")) o.optInt("hour", -1).takeIf { it in 0..23 } else null
                val repeat = com.orbit.followthrough.domain.RepeatType.entries.firstOrNull { it.name == o.optString("repeat") }
                    ?: com.orbit.followthrough.domain.RepeatType.ONCE
                val date = runCatching { java.time.LocalDate.parse(o.optString("date")) }.getOrNull() ?: now.toLocalDate()
                if (title.isBlank()) Answer.Text(o.optString("say", raw))
                else Answer.Reminder(
                    ReminderDraft(title = title, repeat = repeat, hour = hour, minute = o.optInt("minute", 0).coerceIn(0, 59), date = date, weekdays = o.optInt("weekdays", 0).coerceIn(0, 127)),
                    o.optString("say"),
                )
            } else Answer.Text(o.optString("text", raw))
        }.getOrDefault(Answer.Text(raw))
    }

    suspend fun marketBrief(s: AppSettings, marketContext: String): Result<String> = LlmClient(config(s)).complete(
        baseRules() + "\nYou summarise crypto market conditions for a busy person.",
        "Give a 4-bullet market brief from this data, then one line 'What to watch'. Data:\n$marketContext",
        500,
    )

    suspend fun explainWallets(s: AppSettings, activity: String): Result<String> = LlmClient(config(s)).complete(
        baseRules() + "\nYou explain on-chain wallet behaviour in plain language.",
        "Explain what these tracked wallets did recently, patterns you notice (accumulating, taking profit, rotating), in max 6 bullets:\n$activity",
        500,
    )

    suspend fun summarizeFeed(s: AppSettings, items: String): Result<String> = LlmClient(config(s)).complete(
        baseRules() + "\nYou summarise news and posts.",
        "Summarise the most important points from these updates in max 6 bullets, grouped by topic:\n$items",
        500,
    )

    suspend fun test(s: AppSettings): Result<String> = LlmClient(config(s)).complete(baseRules(), "Reply with: OK", 20)
}
