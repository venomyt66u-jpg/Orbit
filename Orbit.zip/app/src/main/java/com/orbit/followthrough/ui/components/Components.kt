package com.orbit.followthrough.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType

val CardShape = RoundedCornerShape(24.dp)
val PillShape = RoundedCornerShape(50)

/** Glassy surface with a hairline gradient border – the base of every grouped element. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = CardShape,
    padding: PaddingValues = PaddingValues(18.dp),
    highlight: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = Orbit.colors
    val border = Brush.linearGradient(
        listOf((highlight ?: c.strokeStrong).copy(alpha = if (highlight != null) 0.55f else 1f), c.stroke, c.stroke)
    )
    val base = modifier
        .clip(shape)
        .background(Brush.verticalGradient(listOf(c.surfaceHigh.copy(alpha = if (c.isDark) 0.72f else 1f), c.surface.copy(alpha = if (c.isDark) 0.62f else 1f))))
        .border(BorderStroke(1.dp, border), shape)
    Column(
        (if (onClick != null) base.pressable(onClick) else base).padding(padding),
        content = content,
    )
}

/** Clickable with a subtle press-scale – feels physical without being bouncy. */
@Composable
fun Modifier.pressable(onClick: () -> Unit, role: Role = Role.Button, enabled: Boolean = true): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && !Orbit.reducedMotion) 0.97f else 1f, spring(stiffness = 900f), label = "press")
    return this
        .scale(scale)
        .clickable(interactionSource = source, indication = androidx.compose.material3.ripple(), enabled = enabled, role = role, onClick = onClick)
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    brush: Brush? = null,
) {
    val c = Orbit.colors
    Row(
        modifier
            .heightIn(min = 52.dp)
            .clip(PillShape)
            .background(if (enabled) (brush ?: c.accentBrush) else SolidColor(c.stroke))
            .pressable(onClick, enabled = enabled)
            .padding(horizontal = 22.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = if (enabled) c.onAccent else c.textMuted, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = OrbitType.subtitle, color = if (enabled) c.onAccent else c.textMuted, maxLines = 1)
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, tint: Color? = null) {
    val c = Orbit.colors
    val color = tint ?: c.text
    Row(
        modifier
            .heightIn(min = 48.dp)
            .clip(PillShape)
            .border(1.dp, (tint ?: c.strokeStrong).copy(alpha = if (tint != null) 0.5f else 1f), PillShape)
            .pressable(onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = OrbitType.label, color = color, maxLines = 1)
    }
}

/** Round icon button with a 48dp touch target. */
@Composable
fun IconCircle(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = Orbit.colors.text,
    background: Color = Orbit.colors.surfaceHigh,
    size: Dp = 44.dp,
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(background)
            .border(1.dp, Orbit.colors.stroke, CircleShape)
            .pressable(onClick)
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.46f))
    }
}

@Composable
fun OrbitChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    accent: Color = Orbit.colors.cyan,
) {
    val c = Orbit.colors
    val bg by animateColorAsState(if (selected) accent.copy(alpha = 0.16f) else Color.Transparent, label = "chipBg")
    val fg by animateColorAsState(if (selected) accent else c.textSecondary, label = "chipFg")
    Row(
        modifier
            .heightIn(min = 40.dp)
            .clip(PillShape)
            .background(bg)
            .border(1.dp, if (selected) accent.copy(alpha = 0.6f) else c.stroke, PillShape)
            .pressable(onClick, role = Role.Tab)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = fg, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = OrbitType.label, color = fg, maxLines = 1)
    }
}

/** Segmented control with a sliding feel (all segments equal width). */
@Composable
fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    Row(
        modifier
            .clip(PillShape)
            .background(c.surface)
            .border(1.dp, c.stroke, PillShape)
            .padding(4.dp),
    ) {
        options.forEach { (value, label) ->
            val isSel = value == selected
            val bg by animateColorAsState(if (isSel) c.surfaceHigh else Color.Transparent, label = "seg")
            Box(
                Modifier
                    .weight(1f)
                    .heightIn(min = 40.dp)
                    .clip(PillShape)
                    .background(bg)
                    .then(if (isSel) Modifier.border(1.dp, c.strokeStrong, PillShape) else Modifier)
                    .clickable(role = Role.Tab) { onSelect(value) }
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = OrbitType.label, color = if (isSel) c.text else c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: (() -> Unit)? = null) {
    val c = Orbit.colors
    Row(modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title.uppercase(), style = OrbitType.overline, color = c.textMuted, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) {
            Text(
                action,
                style = OrbitType.label,
                color = c.cyan,
                modifier = Modifier.clip(PillShape).clickable(onClick = onAction).padding(horizontal = 10.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, modifier: Modifier = Modifier, trailing: @Composable RowScope.() -> Unit = {}) {
    val c = Orbit.colors
    Row(modifier.fillMaxWidth().statusBarsPadding().padding(top = 12.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            if (subtitle != null) Text(subtitle, style = OrbitType.label, color = c.textSecondary)
            Text(title, style = OrbitType.headline, color = c.text)
        }
        trailing()
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, backLabel: String, modifier: Modifier = Modifier, trailing: @Composable RowScope.() -> Unit = {}) {
    val c = Orbit.colors
    Row(
        modifier.fillMaxWidth().statusBarsPadding().padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconCircle(OrbitIcons.Back, backLabel, onBack)
        Spacer(Modifier.width(14.dp))
        Text(title, style = OrbitType.title, color = c.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        trailing()
    }
}

/** A settings-style row. Whole row is the touch target. */
@Composable
fun SettingRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    iconTint: Color = Orbit.colors.cyan,
    onClick: (() -> Unit)? = null,
    trailing: @Composable RowScope.() -> Unit = {},
) {
    val c = Orbit.colors
    Row(
        modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clip(RoundedCornerShape(16.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 4.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(iconTint.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) { Icon(icon, null, tint = iconTint, modifier = Modifier.size(20.dp)) }
            Spacer(Modifier.width(14.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = OrbitType.subtitle, color = c.text)
            if (subtitle != null) Text(subtitle, style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 2.dp))
        }
        Spacer(Modifier.width(10.dp))
        trailing()
    }
}

@Composable
fun OrbitSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = Orbit.colors
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = c.onAccent,
            checkedTrackColor = c.cyan,
            checkedBorderColor = c.cyan,
            uncheckedThumbColor = c.textSecondary,
            uncheckedTrackColor = c.surface,
            uncheckedBorderColor = c.strokeStrong,
        ),
    )
}

@Composable
fun Stepper(value: Int, onChange: (Int) -> Unit, range: IntRange, modifier: Modifier = Modifier, format: (Int) -> String = { it.toString() }, decLabel: String, incLabel: String) {
    val c = Orbit.colors
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        IconCircle(OrbitIcons.Minus, decLabel, { if (value > range.first) onChange(value - 1) }, size = 40.dp, tint = if (value > range.first) c.text else c.textMuted)
        Text(format(value), style = OrbitType.numericSmall, color = c.text, modifier = Modifier.widthIn(min = 56.dp).padding(horizontal = 8.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        IconCircle(OrbitIcons.Plus, incLabel, { if (value < range.last) onChange(value + 1) }, size = 40.dp, tint = if (value < range.last) c.text else c.textMuted)
    }
}

/** Borderless large text field, used for titles and inputs. */
@Composable
fun OrbitTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    style: TextStyle = OrbitType.body,
    singleLine: Boolean = true,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    leading: ImageVector? = null,
    boxed: Boolean = true,
) {
    val c = Orbit.colors
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        textStyle = style.copy(color = c.text),
        cursorBrush = SolidColor(c.cyan),
        singleLine = singleLine,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        modifier = modifier,
        decorationBox = { inner ->
            Row(
                (if (boxed) Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(c.surface)
                    .border(1.dp, c.stroke, RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp) else Modifier),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (leading != null) {
                    Icon(leading, null, tint = c.textMuted, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                }
                Box(Modifier.weight(1f)) {
                    if (value.isEmpty()) Text(placeholder, style = style, color = c.textMuted, maxLines = if (singleLine) 1 else 3)
                    inner()
                }
            }
        },
    )
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier, art: @Composable () -> Unit = {}) {
    val c = Orbit.colors
    Column(modifier.fillMaxWidth().padding(vertical = 28.dp, horizontal = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        art()
        Spacer(Modifier.height(16.dp))
        Text(title, style = OrbitType.title, color = c.text, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(body, style = OrbitType.body, color = c.textSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

/** Small colored pill used for status and metadata. */
@Composable
fun Tag(text: String, color: Color, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    Row(
        modifier.clip(PillShape).background(color.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = color, modifier = Modifier.size(12.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(text, style = OrbitType.caption, color = color, maxLines = 1)
    }
}

/** Glyph inside a soft tinted squircle – the category identity. */
@Composable
fun GlyphBadge(icon: ImageVector, color: Color, modifier: Modifier = Modifier, size: Dp = 40.dp) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.32f))
            .background(Brush.linearGradient(listOf(color.copy(alpha = 0.26f), color.copy(alpha = 0.08f))))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(size * 0.32f)),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = color, modifier = Modifier.size(size * 0.5f)) }
}

@Composable
fun Divider(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(Orbit.colors.stroke))
}

@Composable
fun StatusDot(color: Color, modifier: Modifier = Modifier, size: Dp = 8.dp) {
    Box(modifier.size(size).clip(CircleShape).background(color))
}
