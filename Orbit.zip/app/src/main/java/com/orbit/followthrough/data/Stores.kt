package com.orbit.followthrough.data

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Claim
import com.orbit.followthrough.domain.Claims
import com.orbit.followthrough.domain.CounterReading
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Meter
import com.orbit.followthrough.domain.Snapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.time.Instant
import java.time.ZoneId

object Config {
    /** The only Wi‑Fi network that is counted. */
    const val TARGET_SSID = "G"

    /** Private relay channel for this group (ntfy.sh). */
    const val RELAY_TOPIC = "orbitg_QuSMxTdfvV6xekZ6Jcl95ztq"

    /** SHA‑256 of the admin code – the code itself is not stored in the app. */
    private const val ADMIN_HASH = "6a15d3d3c236f99e6ab86919452208736f043539985bd7140bb1206e64ad52ce"

    const val ADMIN_SLOT = "admin"

    fun isAdminCode(code: String): Boolean = sha256(code.trim()) == ADMIN_HASH

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

/** Display names for alerts (the drawings live in the UI). */
object PeopleNames {
    private val names = mapOf(
        "ghareeb" to "غريب", "abo_masry" to "اب المصري", "moaz" to "معاذ حسان", "dahab" to "دهب", "waleed" to "وليد",
        Config.ADMIN_SLOT to "الأدمن",
    )
    fun of(slot: String): String = names[slot] ?: slot
}

/** Bumped on every write so the UI can recompose with fresh numbers. */
object DataVersion {
    private val _v = MutableStateFlow(0L)
    val flow: StateFlow<Long> = _v
    fun bump() { _v.value = _v.value + 1 }
}

internal object Json {
    fun daysToJson(days: Map<String, Bytes>): JSONObject {
        val o = JSONObject()
        for ((k, v) in days) o.put(k, JSONArray().put(v.rx).put(v.tx))
        return o
    }

    fun daysFromJson(o: JSONObject?): Map<String, Bytes> {
        if (o == null) return emptyMap()
        val out = LinkedHashMap<String, Bytes>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val a = o.optJSONArray(k) ?: continue
            out[k] = Bytes(a.optLong(0), a.optLong(1))
        }
        return out
    }

    /** Report fields shared by the relay message and the admin's stored copy. */
    fun snapshotFromJson(slot: String, device: String, o: JSONObject): Snapshot {
        val pm = o.optJSONArray("pm")?.let { a -> (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() } }
        val h = o.optJSONArray("h")?.let { a -> (0 until a.length()).map { a.optLong(it) } } ?: emptyList()
        return Snapshot(
            slot = slot, device = device, at = o.optLong("at"),
            days = daysFromJson(o.optJSONObject("u")), onTarget = o.optBoolean("on"),
            past = daysFromJson(o.optJSONObject("p")),
            packageStart = o.optLong("cs"), packageUse = o.optJSONArray("cu")?.let { Bytes(it.optLong(0), it.optLong(1)) },
            missing = pm, model = o.optString("m"), version = o.optString("ver"),
            todayHours = h, unverified = daysFromJson(o.optJSONObject("x")),
        )
    }

    fun snapshotToJson(s: Snapshot): JSONObject = JSONObject()
        .put("d", s.device).put("at", s.at).put("on", s.onTarget)
        .put("u", daysToJson(s.days)).put("p", daysToJson(s.past)).put("x", daysToJson(s.unverified))
        .put("cs", s.packageStart)
        .put("m", s.model).put("ver", s.version)
        .put("h", JSONArray(s.todayHours))
        .apply {
            s.packageUse?.let { put("cu", JSONArray().put(it.rx).put(it.tx)) }
            s.missing?.let { put("pm", JSONArray(it)) }
        }

    fun claimsToJson(claims: Collection<Claim>): JSONArray {
        val a = JSONArray()
        for (c in claims) a.put(JSONArray().put(c.slot).put(c.device).put(c.at))
        return a
    }

    fun claimsFromJson(a: JSONArray?): List<Claim> {
        if (a == null) return emptyList()
        val out = ArrayList<Claim>()
        for (i in 0 until a.length()) {
            val e = a.optJSONArray(i) ?: continue
            val slot = e.optString(0)
            val dev = e.optString(1)
            if (slot.isNotBlank() && dev.isNotBlank()) out += Claim(slot, dev, e.optLong(2))
        }
        return out
    }
}

/** This phone's own usage on the target network (per day and per hour), plus the meter's last reading. */
class UsageStore(context: Context) {
    private val p: SharedPreferences = context.applicationContext.getSharedPreferences("usage", Context.MODE_PRIVATE)

    private companion object {
        /** One lock for every instance: the worker, the receiver and the UI all write here. */
        val LOCK = Any()
        const val KEEP_DAYS = 400
        const val KEEP_HOURS = 40 * 24
    }

    private fun readMap(key: String): Map<String, Bytes> =
        Json.daysFromJson(runCatching { JSONObject(p.getString(key, "{}") ?: "{}") }.getOrNull())

    fun days(): Map<String, Bytes> = synchronized(LOCK) { readMap("days") }

    /** Keys like "2026-10-29T13" (local time). */
    fun hours(): Map<String, Bytes> = synchronized(LOCK) { readMap("hours") }

    fun add(chunks: List<Meter.HourChunk>, zone: ZoneId = ZoneId.systemDefault()) {
        if (chunks.isEmpty()) return
        synchronized(LOCK) {
            val days = LinkedHashMap(readMap("days"))
            val hours = LinkedHashMap(readMap("hours"))
            for (c in chunks) {
                val t = Instant.ofEpochMilli(c.hourStart).atZone(zone)
                val day = t.toLocalDate().toString()
                val hour = day + "T" + (if (t.hour < 10) "0" else "") + t.hour
                days[day] = (days[day] ?: Bytes.ZERO) + c.bytes
                hours[hour] = (hours[hour] ?: Bytes.ZERO) + c.bytes
            }
            p.edit()
                .putString("days", Json.daysToJson(keepLast(days, KEEP_DAYS)).toString())
                .putString("hours", Json.daysToJson(keepLast(hours, KEEP_HOURS)).toString())
                .commit()
        }
        DataVersion.bump()
    }

    /** Router looked like the target but the Wi‑Fi name wasn't readable: kept apart, per day. */
    fun unverified(): Map<String, Bytes> = synchronized(LOCK) { readMap("udays") }

    fun addUnverified(chunks: List<Meter.HourChunk>, zone: ZoneId = ZoneId.systemDefault()) {
        if (chunks.isEmpty()) return
        synchronized(LOCK) {
            val days = LinkedHashMap(readMap("udays"))
            for (c in chunks) {
                val day = Instant.ofEpochMilli(c.hourStart).atZone(zone).toLocalDate().toString()
                days[day] = (days[day] ?: Bytes.ZERO) + c.bytes
            }
            p.edit().putString("udays", Json.daysToJson(keepLast(days, KEEP_DAYS)).toString()).commit()
        }
        DataVersion.bump()
    }

    /** Forget where the last reading was taken (used once after an update that changed the rules). */
    fun resetPlace() {
        synchronized(LOCK) { p.edit().remove("r_ssid").commit() }
    }

    fun lastVpn(): Boolean = synchronized(LOCK) { p.getBoolean("r_vpn", false) }

    private fun keepLast(m: Map<String, Bytes>, n: Int): Map<String, Bytes> =
        if (m.size <= n) m else m.toSortedMap().entries.toList().takeLast(n).associate { it.key to it.value }

    /** Restores days from our own last report (after "clear data"); per day the larger total wins. */
    fun restoreIfEmpty(days: Map<String, Bytes>) {
        if (days.isEmpty()) return
        val changed = synchronized(LOCK) {
            val local = readMap("days")
            val merged = Days.mergeMax(local, days)
            if (merged == local) false
            else { p.edit().putString("days", Json.daysToJson(merged).toString()).commit(); true }
        }
        if (changed) DataVersion.bump()
    }

    /** Wi‑Fi used before the app started counting (all networks), per day. Replaced as a whole. */
    fun past(): Map<String, Bytes> = synchronized(LOCK) { readMap("past") }

    fun setPast(m: Map<String, Bytes>) {
        synchronized(LOCK) { p.edit().putString("past", Json.daysToJson(m).toString()).putLong("past_at", System.currentTimeMillis()).commit() }
        DataVersion.bump()
    }

    fun pastImportedAt(): Long = synchronized(LOCK) { p.getLong("past_at", 0) }

    /** When this phone started counting (first reading). Everything before belongs to [past]. */
    fun countingSince(): Long = synchronized(LOCK) { p.getLong("since", 0) }

    /** Fingerprints of the target network's router. */
    fun knownNetworks(): Set<String> = synchronized(LOCK) { p.getStringSet("nets", emptySet())?.toSet() ?: emptySet() }

    fun learnNetwork(fp: String) {
        val added = synchronized(LOCK) {
            val cur = p.getStringSet("nets", emptySet())?.toSet() ?: emptySet()
            if (fp in cur) false else { p.edit().putStringSet("nets", cur + fp).commit(); true }
        }
        if (added) DataVersion.bump()
    }

    fun forgetNetworks() {
        synchronized(LOCK) { p.edit().remove("nets").commit() }
        DataVersion.bump()
    }

    fun lastReading(): CounterReading? = synchronized(LOCK) {
        if (!p.contains("r_wall")) null
        else CounterReading(
            p.getLong("r_trx", 0), p.getLong("r_ttx", 0), p.getLong("r_mrx", 0), p.getLong("r_mtx", 0),
            p.getLong("r_el", 0), p.getLong("r_wall", 0),
        )
    }

    /** Where we were at the last reading: target name, "~" for another Wi‑Fi, null for no Wi‑Fi. */
    fun lastPlace(): String? = synchronized(LOCK) { p.getString("r_ssid", null) }

    fun saveReading(r: CounterReading, place: String?, vpn: Boolean = false) {
        synchronized(LOCK) {
            if (!p.contains("since")) p.edit().putLong("since", r.wall).commit()
            p.edit()
                .putLong("r_trx", r.totalRx).putLong("r_ttx", r.totalTx)
                .putLong("r_mrx", r.mobileRx).putLong("r_mtx", r.mobileTx)
                .putLong("r_el", r.elapsed).putLong("r_wall", r.wall)
                .putString("r_ssid", place)
                .putBoolean("r_vpn", vpn)
                .commit()
        }
    }
}

/** Who this phone is, what the group looks like, and (for the admin) everyone's latest reports. */
private val PROFILE_LOCK = Any()

class Profile(context: Context) {
    private val app = context.applicationContext
    val appContext: Context get() = app
    private val p: SharedPreferences = app.getSharedPreferences("profile", Context.MODE_PRIVATE)

    /** Stable per phone; survives reinstalling the app (changes only on factory reset). */
    @SuppressLint("HardwareIds")
    val deviceId: String =
        (runCatching { Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID) }.getOrNull() ?: "")
            .ifBlank { p.getString("fallback_id", null) ?: java.util.UUID.randomUUID().toString().also { p.edit().putString("fallback_id", it).apply() } }

    var slot: String?
        get() = p.getString("slot", null)
        set(v) { p.edit().putString("slot", v).commit(); DataVersion.bump() }

    val isAdmin: Boolean get() = slot == Config.ADMIN_SLOT

    var setupDone: Boolean
        get() = p.getBoolean("setup_done", false)
        set(v) { p.edit().putBoolean("setup_done", v).commit(); DataVersion.bump() }

    var lastSync: Long
        get() = p.getLong("last_sync", 0)
        set(v) { p.edit().putLong("last_sync", v).apply(); DataVersion.bump() }

    var lastPublish: Long
        get() = p.getLong("last_publish", 0)
        set(v) { p.edit().putLong("last_publish", v).apply() }

    var lastPublishedKey: String
        get() = p.getString("last_pub_key", "") ?: ""
        set(v) { p.edit().putString("last_pub_key", v).apply() }

    /** Set when another phone turned out to own our person (earlier claim). */
    var lostSlot: String?
        get() = p.getString("lost_slot", null)
        set(v) { p.edit().putString("lost_slot", v).commit(); DataVersion.bump() }

    fun claims(): Map<String, Claim> = synchronized(PROFILE_LOCK) {
        val list = Json.claimsFromJson(runCatching { JSONArray(p.getString("claims", "[]") ?: "[]") }.getOrNull())
        Claims.merge(emptyMap(), list)
    }

    fun mergeClaims(incoming: Collection<Claim>): Map<String, Claim> {
        val merged = synchronized(PROFILE_LOCK) {
            val m = Claims.merge(claims(), incoming)
            p.edit().putString("claims", Json.claimsToJson(m.values).toString()).commit()
            m
        }
        DataVersion.bump()
        return merged
    }

    /** Admin only: newest report per person. */
    fun reports(): Map<String, Snapshot> = synchronized(PROFILE_LOCK) { readReports() }

    private fun readReports(): Map<String, Snapshot> {
        val o = runCatching { JSONObject(p.getString("reports", "{}") ?: "{}") }.getOrNull() ?: return emptyMap()
        val out = LinkedHashMap<String, Snapshot>()
        val it = o.keys()
        while (it.hasNext()) {
            val slot = it.next()
            val r = o.optJSONObject(slot) ?: continue
            out[slot] = Json.snapshotFromJson(slot, r.optString("d"), r)
        }
        return out
    }

    fun mergeReports(incoming: Collection<Snapshot>) {
        if (incoming.isEmpty()) return
        synchronized(PROFILE_LOCK) { writeReports(incoming) }
        DataVersion.bump()
    }

    private fun writeReports(incoming: Collection<Snapshot>) {
        val cur = LinkedHashMap(readReports())
        for (s in incoming.sortedBy { it.at }) {
            val old = cur[s.slot]
            cur[s.slot] = when {
                old == null -> s
                s.at >= old.at -> s.copy(
                    days = Days.mergeMax(old.days, s.days),
                    unverified = Days.mergeMax(old.unverified, s.unverified),
                    past = if (s.past.isNotEmpty()) s.past else old.past,
                    packageStart = if (s.packageUse != null) s.packageStart else old.packageStart,
                    packageUse = s.packageUse ?: old.packageUse,
                    missing = s.missing ?: old.missing,
                )
                else -> old.copy(
                    days = Days.mergeMax(old.days, s.days),
                    unverified = Days.mergeMax(old.unverified, s.unverified),
                    past = if (old.past.isNotEmpty()) old.past else s.past,
                )
            }
        }
        val o = JSONObject()
        for ((slot, snap) in cur) o.put(slot, Json.snapshotToJson(snap))
        p.edit().putString("reports", o.toString()).commit()
    }

    /** Admin: what was last alerted per person ("missing keys" / silent), so each alert fires once. */
    fun alertState(key: String): String = p.getString("alert_$key", "") ?: ""
    fun setAlertState(key: String, v: String) { p.edit().putString("alert_$key", v).apply() }

    /** Member: permissions missing at the last report, to report changes right away. */
    var lastMissing: String
        get() = p.getString("last_missing", "") ?: ""
        set(v) { p.edit().putString("last_missing", v).apply() }

    /** Every "new package" press, oldest first. Only the admin creates them; everyone else learns them. */
    fun packageStarts(): List<Long> = synchronized(PROFILE_LOCK) {
        val a = runCatching { JSONArray(p.getString("pkg", "[]") ?: "[]") }.getOrNull() ?: JSONArray()
        (0 until a.length()).map { a.optLong(it) }.filter { it > 0 }.distinct().sorted()
    }

    fun mergePackageStarts(incoming: Collection<Long>) {
        val changed = synchronized(PROFILE_LOCK) {
            val cur = packageStarts()
            val now = System.currentTimeMillis()
            // Never accept a start in the future (wrong clock) – it could hide usage.
            val merged = (cur + incoming.filter { it in 1..(now + 5 * 60_000L) }).distinct().sorted()
            if (merged == cur) false
            else { p.edit().putString("pkg", JSONArray(merged).toString()).commit(); true }
        }
        if (changed) DataVersion.bump()
    }

    /** Current package start, or 0 when the admin hasn't started one yet. */
    val packageStart: Long get() = packageStarts().lastOrNull() ?: 0L

    fun clearAll() {
        p.edit().clear().commit()
        DataVersion.bump()
    }
}
