package com.orbit.followthrough.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.abs

/** Number formatting tuned for prices, token amounts and data usage. Locale-neutral digits. */
object Numbers {

    fun price(v: Double): String = when {
        v >= 1000 -> "$" + String.format(Locale.US, "%,.0f", v)
        v >= 1 -> "$" + String.format(Locale.US, "%,.2f", v)
        v <= 0 -> "$0"
        else -> "$" + BigDecimal.valueOf(v).round(java.math.MathContext(4, RoundingMode.HALF_UP)).stripTrailingZeros().toPlainString()
    }

    fun compact(v: Double, prefix: String = ""): String {
        val a = abs(v)
        val sign = if (v < 0) "-" else ""
        val (n, s) = when {
            a >= 1e12 -> a / 1e12 to "T"
            a >= 1e9 -> a / 1e9 to "B"
            a >= 1e6 -> a / 1e6 to "M"
            a >= 1e4 -> a / 1e3 to "K"
            else -> a to ""
        }
        val body = when {
            s.isEmpty() && a >= 1 -> String.format(Locale.US, "%,.2f", n).removeSuffix(".00")
            s.isEmpty() -> BigDecimal.valueOf(n).round(java.math.MathContext(4, RoundingMode.HALF_UP)).stripTrailingZeros().toPlainString()
            else -> String.format(Locale.US, "%.2f", n).trimEnd('0').trimEnd('.') + s
        }
        return sign + prefix + body
    }

    fun percent(v: Double): String = (if (v >= 0) "+" else "") + String.format(Locale.US, "%.2f%%", v)

    /** Bytes → "1.24 GB" / "820 MB". */
    fun bytes(b: Long): String {
        val a = b.toDouble()
        return when {
            a >= 1e12 -> String.format(Locale.US, "%.2f TB", a / 1e12)
            a >= 1e9 -> String.format(Locale.US, "%.2f GB", a / 1e9)
            a >= 1e6 -> String.format(Locale.US, "%.0f MB", a / 1e6)
            a >= 1e3 -> String.format(Locale.US, "%.0f KB", a / 1e3)
            else -> "$b B"
        }
    }

    fun shortAddress(a: String): String = if (a.length <= 12) a else a.take(6) + "…" + a.takeLast(4)
}

/**
 * Converts cumulative per-device router counters into daily usage.
 * Handles counter resets (router reboot) by treating the new value as fresh traffic.
 */
object UsageMath {
    data class Counter(val rx: Long, val tx: Long)

    fun delta(previous: Counter?, current: Counter): Counter {
        if (previous == null) return Counter(0, 0)
        val rx = if (current.rx >= previous.rx) current.rx - previous.rx else current.rx
        val tx = if (current.tx >= previous.tx) current.tx - previous.tx else current.tx
        return Counter(rx, tx)
    }

    /** Sum a day → bytes map over [fromDay, toDay]. */
    fun total(daily: Map<Long, Long>, fromDay: Long, toDay: Long): Long =
        daily.filterKeys { it in fromDay..toDay }.values.sum()
}
