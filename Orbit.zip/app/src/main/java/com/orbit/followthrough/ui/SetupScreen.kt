package com.orbit.followthrough.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.meter.WifiProbe
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType

private fun granted(ctx: Context, perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

private fun notificationsOk(ctx: Context) = Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)

private fun batteryOk(ctx: Context): Boolean {
    val pm = ctx.getSystemService(PowerManager::class.java) ?: return true
    return pm.isIgnoringBatteryOptimizations(ctx.packageName)
}

@SuppressLint("BatteryLife")
private fun askBattery(ctx: Context) {
    runCatching {
        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
    }.onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
}

private fun openAppSettings(ctx: Context) {
    runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))) }
}

@Composable
fun SetupScreen(again: Boolean, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    val location = remember(tick) { WifiProbe.hasLocation(ctx) }
    val background = remember(tick) { WifiProbe.hasBackgroundLocation(ctx) }
    val gps = remember(tick) { WifiProbe.locationServicesOn(ctx) }
    val notifications = remember(tick) { notificationsOk(ctx) }
    val battery = remember(tick) { batteryOk(ctx) }

    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val singleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        tick++
        if (!ok) openAppSettings(ctx)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(24.dp))
        Text(if (again) "الأذونات" else "خطوة أخيرة", style = OrbitType.display, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "علشان التطبيق يعرف إنك على شبكة ${Config.TARGET_SSID} ويعدّ استهلاكك حتى وهو مقفول، محتاج الأذونات دي.",
            style = OrbitType.body, color = c.textSecondary,
        )
        Spacer(Modifier.height(20.dp))

        Step(
            icon = OrbitIcons.Signal, accent = c.cyan, done = location,
            title = "اسم الشبكة",
            body = "أندرويد مش بيقول اسم الواي فاي غير للتطبيقات اللي معاها إذن الموقع. التطبيق مش بيقرا مكانك ولا بيبعته.",
            button = "اسمح",
            onClick = {
                locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            },
        )
        if (Build.VERSION.SDK_INT >= 29) {
            Step(
                icon = OrbitIcons.Clock, accent = c.violet, done = background, enabled = location,
                title = "العد في الخلفية",
                body = "اختار «السماح طوال الوقت» علشان العد يكمل وانت مش فاتح التطبيق.",
                button = "اسمح طول الوقت",
                onClick = { singleLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION) },
            )
        }
        Step(
            icon = OrbitIcons.Target, accent = c.green, done = gps,
            title = "الموقع (GPS) شغال",
            body = "لازم زرار الموقع في الموبايل يكون شغال، غير كده اسم الشبكة بيختفي.",
            button = "افتح الإعدادات",
            onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } },
        )
        if (Build.VERSION.SDK_INT >= 33) {
            Step(
                icon = OrbitIcons.Bell, accent = c.amber, done = notifications,
                title = "الإشعارات",
                body = "إشعار هادي وثابت بيوريك استهلاك النهارده. من غيره أندرويد ممكن يوقف العد.",
                button = "اسمح",
                onClick = { singleLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
            )
        }
        Step(
            icon = OrbitIcons.Battery, accent = c.rose, done = battery,
            title = "توفير البطارية",
            body = "خلي التطبيق «غير مقيد» علشان الموبايل ما يقفلوش. استهلاكه للبطارية ضعيف جداً.",
            button = "اسمح",
            onClick = { askBattery(ctx) },
        )

        Spacer(Modifier.height(16.dp))
        PrimaryButton(
            text = if (location) "يلا نبدأ" else "لازم إذن اسم الشبكة الأول",
            onClick = onDone,
            enabled = location,
            modifier = Modifier.fillMaxWidth(),
            icon = OrbitIcons.Check,
        )
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun Step(
    icon: ImageVector,
    accent: Color,
    done: Boolean,
    title: String,
    body: String,
    button: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
) {
    val c = Orbit.colors
    GlassCard(Modifier.fillMaxWidth().padding(bottom = 12.dp), highlight = if (done) c.green else null) {
        Row(verticalAlignment = Alignment.Top) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(accent.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = OrbitType.subtitle, color = c.text)
                Spacer(Modifier.height(3.dp))
                Text(body, style = OrbitType.caption, color = c.textSecondary)
                if (!done) {
                    Spacer(Modifier.height(10.dp))
                    SecondaryButton(button, { if (enabled) onClick() }, tint = if (enabled) accent else c.textMuted)
                }
            }
            if (done) {
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(28.dp).clip(CircleShape).background(c.green.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                    Icon(OrbitIcons.Check, null, tint = c.green, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
