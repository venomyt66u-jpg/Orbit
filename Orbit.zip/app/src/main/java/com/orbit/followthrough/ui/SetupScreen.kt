package com.orbit.followthrough.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.meter.NetHistory
import com.orbit.followthrough.meter.Need
import com.orbit.followthrough.meter.Perms
import com.orbit.followthrough.meter.WifiProbe
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@SuppressLint("BatteryLife")
fun askBattery(ctx: Context) {
    runCatching {
        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
    }.onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
}

fun openUsageAccess(ctx: Context) {
    runCatching {
        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    }.onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } }
}

fun openAppSettings(ctx: Context) {
    runCatching { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))) }
}

private class NeedText(val icon: ImageVector, val title: String, val why: String, val how: String)

private fun needText(n: Need): NeedText = when (n) {
    Need.LOCATION -> NeedText(OrbitIcons.Signal, "الموقع",
        "أندرويد مش بيقول اسم الواي فاي غير بالإذن ده، وبيه التطبيق يتأكد إنها ${Config.TARGET_SSID} بالظبط. مكانك نفسه مش بيتقري ولا بيتبعت.",
        "اختار «أثناء استخدام التطبيق».")
    Need.LOCATION_ALWAYS -> NeedText(OrbitIcons.Clock, "الموقع طول الوقت",
        "علشان العدّ يفضل متأكد من اسم الشبكة والتطبيق مقفول.",
        "هتفتح صفحة الإذن: اختار «السماح طوال الوقت».")
    Need.GPS -> NeedText(OrbitIcons.Target, "زرار الموقع شغال",
        "لو زرار الموقع في الموبايل مقفول، اسم الشبكة بيختفي.",
        "شغّل «الموقع» من الإعدادات أو من الشريط اللي فوق.")
    Need.NOTIFICATIONS -> NeedText(OrbitIcons.Bell, "الإشعارات",
        "إشعار هادي وثابت بيوضح استهلاك النهارده، وبيخلي أندرويد يسيب العداد شغال على طول.",
        "اختار «سماح».")
    Need.USAGE -> NeedText(OrbitIcons.History, "سجل الاستهلاك",
        "بيصلّح الحساب لو الموبايل اتقفل وفتح أو فيه VPN، وبيجيب استهلاك الواي فاي اللي قبل التطبيق.",
        "هتفتح قايمة: دوس على Orbit وفعّل «السماح بالوصول».")
    Need.BATTERY -> NeedText(OrbitIcons.Battery, "البطارية بدون قيود",
        "من غيرها بعض الموبايلات بتقفل العداد في الخلفية. استهلاكه للبطارية ضعيف جداً.",
        "اختار «سماح» أو «غير مقيد».")
}

@Composable
private fun needColor(n: Need): Color {
    val c = Orbit.colors
    return when (n) {
        Need.LOCATION -> c.cyan
        Need.LOCATION_ALWAYS -> c.violet
        Need.GPS -> c.green
        Need.NOTIFICATIONS -> c.amber
        Need.USAGE -> c.electric
        Need.BATTERY -> c.rose
    }
}

/**
 * Required permissions. The app can't be used until all are on; if one is turned off later this
 * screen comes back (and the admin is told). Counting itself never stops.
 */
@Composable
fun SetupScreen(again: Boolean, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }

    val missing = remember(tick) { Perms.missing(ctx) }
    val all = Need.entries
    val done = all.size - missing.size
    val now = remember(tick) { WifiProbe.read(ctx) }
    val usageOk = Need.USAGE !in missing
    LaunchedEffect(usageOk) {
        if (usageOk) withContext(Dispatchers.IO) { runCatching { NetHistory.importPast(ctx) } }
    }

    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        tick++
        if (res.values.none { it }) openAppSettings(ctx)
    }
    val singleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        tick++
        if (!ok) openAppSettings(ctx)
    }

    val ask: (Need) -> Unit = { n ->
        when (n) {
            Need.LOCATION -> locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            Need.LOCATION_ALWAYS -> if (Build.VERSION.SDK_INT >= 29) singleLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            Need.GPS -> runCatching { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) }
            Need.NOTIFICATIONS -> if (Build.VERSION.SDK_INT >= 33) singleLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            Need.USAGE -> openUsageAccess(ctx)
            Need.BATTERY -> askBattery(ctx)
        }
        Unit
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(18.dp))
        LiveOrb(active = missing.isEmpty(), bytesPerSec = 0, accent = if (missing.isEmpty()) c.green else c.amber, size = 160.dp) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$done/${all.size}", style = OrbitType.headline, color = c.text)
                Text("أذونات", style = OrbitType.caption, color = c.textSecondary)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            if (again && missing.isNotEmpty()) "إذن اتقفل" else "الأذونات",
            style = OrbitType.display, color = c.text, modifier = Modifier.enter(0),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (again && missing.isNotEmpty()) "رجّع الإذن علشان العدّ يفضل مظبوط. الأدمن بيوصله إشعار لما أي إذن يتقفل."
            else "كلهم لازم يكونوا شغالين علشان التطبيق يعدّ استهلاك ${Config.TARGET_SSID} بالظبط وعلى طول.",
            style = OrbitType.body, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.enter(1),
        )
        Spacer(Modifier.height(14.dp))
        PermProgress(done.toFloat() / all.size)
        Spacer(Modifier.height(16.dp))

        all.forEachIndexed { i, n ->
            val t = needText(n)
            val ok = n !in missing
            // "All the time" can only be asked after normal location is on.
            val blocked = n == Need.LOCATION_ALWAYS && Need.LOCATION in missing
            PermRow(t.icon, needColor(n), ok, t.title, t.why, if (ok) null else t.how, Modifier.enter(2 + i), enabled = !blocked) { ask(n) }
        }

        Spacer(Modifier.height(6.dp))
        if (missing.isEmpty()) {
            NoticeCard(
                OrbitIcons.Check,
                if (now.onTarget) "انت على ${Config.TARGET_SSID} دلوقتي" else "كله تمام",
                if (now.onTarget) "العدّ شغال. أي استهلاك على ${Config.TARGET_SSID} بيتحسب أول بأول." else "أول ما تتصل بـ${Config.TARGET_SSID} العدّ هيبدأ لوحده.",
                c.green,
            )
        }
        Spacer(Modifier.height(16.dp))
        PrimaryButton(
            text = if (missing.isEmpty()) "يلا بينا" else "فاضل ${missing.size}",
            onClick = {
                val left = Perms.missing(ctx)
                if (left.isEmpty()) onDone() else ask(left.first())
            },
            modifier = Modifier.fillMaxWidth(),
            icon = if (missing.isEmpty()) OrbitIcons.Check else OrbitIcons.Shield,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "شاومي وأوبو وريلمي وهواوي: فعّل كمان «التشغيل التلقائي» للتطبيق، واقفله في قايمة التطبيقات الأخيرة.",
            style = OrbitType.caption, color = c.textMuted, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun PermProgress(fraction: Float) {
    val c = Orbit.colors
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(600), label = "perm")
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
        if (f > 0f) {
            Box(
                Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(50))
                    .background(if (f >= 1f) SolidColor(c.green) else c.accentBrush),
            )
        }
    }
}

@Composable
private fun PermRow(
    icon: ImageVector,
    accent: Color,
    done: Boolean,
    title: String,
    body: String,
    how: String?,
    modifier: Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val c = Orbit.colors
    val tone by animateColorAsState(if (done) c.green else accent, label = "perm")
    GlassCard(modifier.fillMaxWidth().padding(bottom = 10.dp), highlight = tone, padding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(tone.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(if (done) OrbitIcons.Check else icon, null, tint = tone, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = OrbitType.subtitle, color = c.text)
                Text(body, style = OrbitType.caption, color = c.textSecondary)
                if (how != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(if (enabled) how else "فعّل «الموقع» الأول.", style = OrbitType.caption, color = accent)
                    Spacer(Modifier.height(8.dp))
                    SecondaryButton(if (enabled) "فعّل" else "مستني الموقع", { if (enabled) onClick() }, tint = if (enabled) accent else c.textMuted)
                }
            }
        }
    }
}
