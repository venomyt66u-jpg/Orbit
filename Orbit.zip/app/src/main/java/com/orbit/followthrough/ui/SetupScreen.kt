package com.orbit.followthrough.ui

import android.Manifest
import android.annotation.SuppressLint
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.orbit.followthrough.meter.NetHistory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.meter.WifiProbe
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.delay

fun batteryUnrestricted(ctx: Context): Boolean {
    val pm = ctx.getSystemService(PowerManager::class.java) ?: return true
    return pm.isIgnoringBatteryOptimizations(ctx.packageName)
}

@SuppressLint("BatteryLife")
fun askBattery(ctx: Context) {
    runCatching {
        ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
    }.onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
}

fun openUsageAccess(ctx: Context) {
    runCatching {
        ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
    }.onFailure { runCatching { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } }
}

@Composable
private fun PermRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: androidx.compose.ui.graphics.Color,
    done: Boolean,
    title: String,
    body: String,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val c = Orbit.colors
    GlassCard(modifier.fillMaxWidth().padding(bottom = 10.dp), highlight = if (done) c.green else null, padding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(accent.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = OrbitType.subtitle, color = c.text)
                Text(body, style = OrbitType.caption, color = c.textSecondary)
            }
            Spacer(Modifier.width(8.dp))
            if (done) {
                Box(Modifier.size(28.dp).clip(CircleShape).background(c.green.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                    Icon(OrbitIcons.Check, null, tint = c.green, modifier = Modifier.size(16.dp))
                }
            } else {
                SecondaryButton("اسمح", onClick, tint = accent)
            }
        }
    }
}

/**
 * One-time setup: teach the app which router is G (or receive it from the admin automatically).
 * No permissions are needed.
 */
@Composable
fun SetupScreen(again: Boolean, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    val version by DataVersion.flow.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { tick++ }

    // Re-check the Wi‑Fi every couple of seconds while this screen is open.
    LaunchedEffect(Unit) {
        SyncEngine.refresh(ctx) // may bring the router identity from the admin
        while (true) { delay(2000); tick++ }
    }
    val store = remember { UsageStore(ctx) }
    val known = remember(version, tick) { store.knownNetworks() }
    val now = remember(version, tick) { WifiProbe.read(ctx) }
    val battery = remember(tick) { batteryUnrestricted(ctx) }
    val location = remember(tick) { WifiProbe.hasLocation(ctx) }
    val background = remember(tick) { WifiProbe.hasBackgroundLocation(ctx) }
    val usage = remember(tick) { NetHistory.hasAccess(ctx) }
    // Pull "before the app" history as soon as usage access is granted.
    LaunchedEffect(usage) { if (usage) withContext(Dispatchers.IO) { runCatching { NetHistory.importPast(ctx) } } }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }
    val backgroundLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    var justLearned by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        LiveOrb(active = now.onTarget, bytesPerSec = 0, accent = if (now.onTarget) c.green else c.cyan, size = 180.dp) {
            Icon(OrbitIcons.Signal, null, tint = if (now.onTarget) c.green else c.cyan, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(if (again) "شبكة ${Config.TARGET_SSID}" else "خطوة واحدة", style = OrbitType.display, color = c.text, modifier = Modifier.enter(0))
        Spacer(Modifier.height(6.dp))
        Text(
            "التطبيق بيتعرف على شبكة ${Config.TARGET_SSID} من الراوتر نفسه، فبيعدّ حتى من غير أي أذونات.",
            style = OrbitType.body, color = c.textSecondary, textAlign = TextAlign.Center, modifier = Modifier.enter(1),
        )
        Spacer(Modifier.height(22.dp))

        AnimatedContent(
            targetState = when {
                now.onTarget -> 0
                known.isNotEmpty() && !now.onWifi -> 1
                now.onWifi -> 2
                else -> 3
            },
            transitionSpec = { (fadeIn() + scaleIn(initialScale = 0.96f)) togetherWith fadeOut() },
            label = "state",
        ) { state ->
            when (state) {
                0 -> NoticeCard(
                    OrbitIcons.Check, if (justLearned) "تمام! اتعرفنا على ${Config.TARGET_SSID}" else "انت على ${Config.TARGET_SSID} دلوقتي",
                    "أي استهلاك على الشبكة دي هيتحسب لوحده، حتى والتطبيق مقفول.", c.green,
                )
                1 -> NoticeCard(
                    OrbitIcons.Check, "التطبيق عارف ${Config.TARGET_SSID}",
                    "أول ما تتصل بيها العدّ هيبدأ لوحده.", c.green,
                )
                2 -> NoticeCard(
                    OrbitIcons.Signal, "انت متصل بواي فاي دلوقتي",
                    "لو دي شبكة ${Config.TARGET_SSID} دوس الزرار. لو مش هي، اتصل بـ${Config.TARGET_SSID} الأول.",
                    c.cyan,
                    action = {
                        PrimaryButton("أيوه، دي ${Config.TARGET_SSID}", {
                            now.print?.let { store.learnNetwork(it.encode()); justLearned = true; tick++ }
                        }, icon = OrbitIcons.Check, enabled = now.print != null)
                    },
                )
                else -> NoticeCard(
                    OrbitIcons.Info, "اتصل بشبكة ${Config.TARGET_SSID}",
                    "افتح الواي فاي واتصل بـ${Config.TARGET_SSID}، وارجع هنا. الشاشة هتتحدث لوحدها.", c.amber,
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        Text(
            "أذونات اختيارية بتخلي العدّ أدق. لو اترفضت أو اتلغت بعدين، العدّ بيكمل عادي.",
            style = OrbitType.caption, color = c.textMuted, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        )
        PermRow(
            OrbitIcons.Signal, c.cyan, location,
            "تأكيد اسم الشبكة",
            "يتأكد إنها ${Config.TARGET_SSID} بالاسم، مش بالراوتر بس. التطبيق مش بيقرا مكانك.",
            Modifier.enter(2),
        ) { locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }
        if (Build.VERSION.SDK_INT >= 29 && location) {
            PermRow(
                OrbitIcons.Clock, c.violet, background,
                "الاسم وهو مقفول",
                "اختار «السماح طوال الوقت» علشان التأكيد بالاسم يشتغل في الخلفية كمان.",
                Modifier.enter(3),
            ) { backgroundLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION) }
        }
        PermRow(
            OrbitIcons.History, c.green, usage,
            "سجل أندرويد للاستهلاك",
            "بيصلّح الحساب لو الموبايل اتقفل وفتح، وبيجيب استهلاك الواي فاي اللي قبل التطبيق.",
            Modifier.enter(4),
        ) { openUsageAccess(ctx) }
        PermRow(
            OrbitIcons.Battery, c.rose, battery,
            "البطارية",
            "علشان الموبايل ما يأخرش التحديثات. العدّ نفسه مش بيتأثر.",
            Modifier.enter(5),
        ) { askBattery(ctx) }
        if (again && known.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            SecondaryButton("الراوتر اتغيّر؟ امسح تعريف ${Config.TARGET_SSID}", { store.forgetNetworks(); justLearned = false }, tint = c.textSecondary)
        }
        Spacer(Modifier.height(20.dp))
        val ready = known.isNotEmpty()
        PrimaryButton(
            text = if (ready) "يلا بينا" else "كمّل وبعدين أعرّفه",
            onClick = onDone,
            modifier = Modifier.fillMaxWidth().enter(3),
            icon = OrbitIcons.Check,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "على شاومي وأوبو وريلمي: فعّل «التشغيل التلقائي» للتطبيق من الإعدادات علشان الأرقام توصل في وقتها.",
            style = OrbitType.caption, color = c.textMuted, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))
    }
}
