package com.orbit.followthrough.ui.market

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.CoinEntity
import com.orbit.followthrough.domain.Numbers
import com.orbit.followthrough.ui.components.AreaChart
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.ScreenHeader
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.SentimentGauge
import com.orbit.followthrough.ui.components.StatusDot
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.parseSpark
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.home.BOTTOM_SPACE
import com.orbit.followthrough.ui.nav.LocalAppContainer
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import com.orbit.followthrough.wallets.AddressRules
import com.orbit.followthrough.wallets.Chain
import kotlinx.coroutines.launch

@Composable
fun MarketScreen(nav: NavHostController) {
    val vm = orbitViewModel { MarketViewModel(it) }
    val coins by vm.coins.collectAsStateWithLifecycle()
    val wallets by vm.wallets.collectAsStateWithLifecycle()
    val recent by vm.recentActivity.collectAsStateWithLifecycle()
    val snap by vm.snapshot.collectAsStateWithLifecycle()
    val brief by vm.brief.collectAsStateWithLifecycle()
    val settings = LocalSettings.current
    val container = LocalAppContainer.current
    val highlight by container.highlight.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val ctx = LocalContext.current

    var openCoin by remember { mutableStateOf<CoinEntity?>(null) }
    var addCoin by remember { mutableStateOf(false) }
    var addWallet by remember { mutableStateOf(false) }

    // Deep link from a price alert → open that coin.
    LaunchedEffect(highlight, coins) {
        val h = highlight
        if (h != null && h.first == "coin") {
            coins?.firstOrNull { it.id == h.second }?.let { openCoin = it; container.highlight.value = null }
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = BOTTOM_SPACE.dp)) {
        item {
            ScreenHeader(stringResource(R.string.tab_market), subtitle = stringResource(R.string.market_subtitle)) {
                OrbitChip(
                    stringResource(if (settings.liveMode) R.string.live_on else R.string.live_off), settings.liveMode,
                    { vm.toggleLive(!settings.liveMode) }, icon = OrbitIcons.Bolt, accent = c.green,
                )
                Spacer(Modifier.width(8.dp))
                IconCircle(OrbitIcons.Refresh, stringResource(R.string.sync_now), { vm.refresh() }, tint = c.cyan)
            }
        }

        // ---------- overview ----------
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.total_market_cap), style = OrbitType.overline, color = c.textMuted)
                        Text(snap.global?.let { Numbers.compact(it.totalCap, "$") } ?: "—", style = OrbitType.headline.copy(fontFeatureSettings = "tnum"), color = c.text)
                        snap.global?.let {
                            Tag(Numbers.percent(it.capChange24h) + " · 24h", if (it.capChange24h >= 0) c.green else c.rose, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                    snap.fearGreed?.let { fg ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            SentimentGauge(fg.value, size = 110.dp)
                            Text("${fg.value}", style = OrbitType.subtitle.copy(fontFeatureSettings = "tnum"), color = c.text)
                            Text(stringResource(fearLabel(fg.value)), style = OrbitType.caption, color = c.textSecondary)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatPill(stringResource(R.string.btc_dominance), snap.global?.let { String.format(java.util.Locale.US, "%.1f%%", it.btcDominance) } ?: "—", c.amber, Modifier.weight(1f))
                    StatPill(stringResource(R.string.volume_24h), snap.global?.let { Numbers.compact(it.volume24h, "$") } ?: "—", c.cyan, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    when {
                        snap.loading -> stringResource(R.string.updating)
                        snap.error != null -> stringResource(R.string.market_error, snap.error ?: "")
                        snap.updatedAt != null -> stringResource(R.string.updated_ago, Fmt.ago(snap.updatedAt ?: 0L))
                        else -> ""
                    },
                    style = OrbitType.caption, color = if (snap.error != null) c.amber else c.textMuted,
                )
            }
        }

        // ---------- AI brief ----------
        item {
            GlassCard(Modifier.fillMaxWidth().padding(top = 14.dp), highlight = c.violet) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(OrbitIcons.Spark, null, tint = c.violet, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(stringResource(R.string.ai_brief_title), style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f))
                    if (!brief.loading) {
                        OrbitChip(stringResource(if (brief.text == null) R.string.generate else R.string.regenerate), false, { vm.aiBrief() }, accent = c.violet)
                    }
                }
                when {
                    brief.loading -> Text(stringResource(R.string.thinking), style = OrbitType.body, color = c.textMuted, modifier = Modifier.padding(top = 10.dp))
                    brief.error == "connect" -> Column(Modifier.padding(top = 10.dp)) {
                        Text(stringResource(R.string.ai_connect_hint), style = OrbitType.caption, color = c.textSecondary)
                        Spacer(Modifier.height(8.dp))
                        SecondaryButton(stringResource(R.string.connect_ai), { nav.navigate(Routes.KEYS) }, icon = OrbitIcons.Key)
                    }
                    brief.error != null -> Text(stringResource(R.string.ai_error, brief.error ?: ""), style = OrbitType.caption, color = c.amber, modifier = Modifier.padding(top = 10.dp))
                    brief.text != null -> Text(brief.text ?: "", style = OrbitType.body, color = c.text, modifier = Modifier.padding(top = 10.dp))
                    else -> Text(stringResource(R.string.ai_brief_hint), style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }

        // ---------- watchlist ----------
        item { SectionHeader(stringResource(R.string.watchlist), Modifier.padding(top = 18.dp), action = stringResource(R.string.add), onAction = { addCoin = true }) }
        items(coins.orEmpty(), key = { "c" + it.id }) { coin -> CoinRow(coin, { openCoin = coin }) }

        // ---------- wallets ----------
        item { SectionHeader(stringResource(R.string.tracked_wallets), Modifier.padding(top = 18.dp), action = stringResource(R.string.track_wallet), onAction = { addWallet = true }) }
        val ws = wallets.orEmpty()
        if (wallets != null && ws.isEmpty()) {
            item {
                GlassCard(Modifier.fillMaxWidth(), onClick = { addWallet = true }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GlyphBadge(OrbitIcons.Wallet, c.violet)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.wallets_empty_title), style = OrbitType.subtitle, color = c.text)
                            Text(stringResource(R.string.wallets_empty_body), style = OrbitType.caption, color = c.textSecondary)
                        }
                    }
                }
            }
        }
        items(ws, key = { "w" + it.id }) { w ->
            val chain = Chain.of(w.chain)
            GlassCard(Modifier.fillMaxWidth().padding(bottom = 10.dp), onClick = { nav.navigate(Routes.wallet(w.id)) }, padding = PaddingValues(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphBadge(OrbitIcons.Wallet, if (w.enabled) c.violet else c.textMuted)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(w.name, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(chainLabel(chain) + " · " + Numbers.shortAddress(w.address), style = OrbitType.caption, color = c.textMuted)
                    }
                    StatusDot(if (w.status == "ERROR") c.rose else if (w.status == "OK") c.green else c.textMuted)
                }
                if (w.status == "ERROR" && w.lastError != null) {
                    Text(w.lastError, style = OrbitType.caption, color = c.amber, modifier = Modifier.padding(top = 8.dp), maxLines = 2)
                } else {
                    Text(
                        w.lastActivityAt?.let { stringResource(R.string.last_activity, Fmt.ago(it)) } ?: stringResource(R.string.watching_since, Fmt.ago(w.createdAt)),
                        style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        }
        if (recent.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.latest_moves), Modifier.padding(top = 10.dp)) }
            items(recent, key = { "a" + it.id }) { a ->
                ActivityRow(a, ws.firstOrNull { it.id == a.walletId }?.name, onClick = { nav.navigate(Routes.wallet(a.walletId)) })
            }
        }

        // ---------- news ----------
        if (snap.news.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.market_news), Modifier.padding(top = 18.dp)) }
            items(snap.news, key = { "n" + it.link }) { n ->
                Row(
                    Modifier.fillMaxWidth().pressable({ runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }).padding(vertical = 10.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(n.title, style = OrbitType.subtitle, color = c.text, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(n.source + (n.publishedAt?.let { " · " + Fmt.ago(it) } ?: ""), style = OrbitType.caption, color = c.textMuted)
                    }
                    Spacer(Modifier.width(10.dp))
                    Icon(OrbitIcons.External, null, tint = c.textMuted, modifier = Modifier.size(16.dp))
                }
            }
        }
        item {
            Text(stringResource(R.string.market_disclaimer), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 18.dp))
        }
    }

    openCoin?.let { coin ->
        val live = coins?.firstOrNull { it.id == coin.id } ?: coin
        CoinSheet(live, onDismiss = { openCoin = null }, onSave = { a, b -> vm.setAlerts(live.id, a, b); openCoin = null }, onRemove = { vm.removeCoin(live.id); openCoin = null })
    }
    if (addCoin) AddCoinSheet(vm, onDismiss = { addCoin = false })
    if (addWallet) AddWalletSheet(vm, onDismiss = { addWallet = false }, onNeedKey = { addWallet = false; nav.navigate(Routes.KEYS) })
}

fun fearLabel(v: Int): Int = when {
    v < 25 -> R.string.fg_extreme_fear
    v < 45 -> R.string.fg_fear
    v < 56 -> R.string.fg_neutral
    v < 76 -> R.string.fg_greed
    else -> R.string.fg_extreme_greed
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CoinSheet(coin: CoinEntity, onDismiss: () -> Unit, onSave: (Double?, Double?) -> Unit, onRemove: () -> Unit) {
    val c = Orbit.colors
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var above by remember(coin.id) { mutableStateOf(coin.alertAbove?.toString() ?: "") }
    var below by remember(coin.id) { mutableStateOf(coin.alertBelow?.toString() ?: "") }
    val up = (coin.change24h ?: 0.0) >= 0
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = c.surface, contentColor = c.text) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp).imePadding().navigationBarsPadding().padding(bottom = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CoinMark(coin.symbol, coinColor(coin.symbol), 48.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(coin.name, style = OrbitType.title, color = c.text)
                    Text(coin.symbol, style = OrbitType.caption, color = c.textMuted)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(coin.price?.let { Numbers.price(it) } ?: "—", style = OrbitType.title.copy(fontFeatureSettings = "tnum"), color = c.text)
                    coin.change24h?.let { Text(Numbers.percent(it), style = OrbitType.label, color = if (up) c.green else c.rose) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(stringResource(R.string.seven_days), style = OrbitType.overline, color = c.textMuted)
            AreaChart(parseSpark(coin.sparkline), if (up) c.green else c.rose, Modifier.fillMaxWidth().height(170.dp))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatPill(stringResource(R.string.high_24h), coin.high24h?.let { Numbers.price(it) } ?: "—", c.green, Modifier.weight(1f))
                StatPill(stringResource(R.string.low_24h), coin.low24h?.let { Numbers.price(it) } ?: "—", c.rose, Modifier.weight(1f))
                StatPill(stringResource(R.string.market_cap), coin.marketCap?.let { Numbers.compact(it, "$") } ?: "—", c.cyan, Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.price_alerts), style = OrbitType.subtitle, color = c.text)
            Text(stringResource(R.string.price_alerts_hint), style = OrbitType.caption, color = c.textSecondary)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OrbitTextField(above, { above = it.filter { ch -> ch.isDigit() || ch == '.' } }, stringResource(R.string.alert_above), Modifier.weight(1f), leading = OrbitIcons.ArrowUp, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OrbitTextField(below, { below = it.filter { ch -> ch.isDigit() || ch == '.' } }, stringResource(R.string.alert_below), Modifier.weight(1f), leading = OrbitIcons.ArrowDown, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(stringResource(R.string.save_alerts), { onSave(above.toDoubleOrNull(), below.toDoubleOrNull()) }, Modifier.weight(1f), icon = OrbitIcons.Bell)
                SecondaryButton(stringResource(R.string.remove), onRemove, icon = OrbitIcons.Trash, tint = c.rose)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddCoinSheet(vm: MarketViewModel, onDismiss: () -> Unit) {
    val c = Orbit.colors
    val results by vm.searchResults.collectAsStateWithLifecycle()
    val searching by vm.searching.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = c.surface, contentColor = c.text) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp).imePadding().navigationBarsPadding().padding(bottom = 20.dp)) {
            Text(stringResource(R.string.add_coin), style = OrbitType.title, color = c.text)
            Spacer(Modifier.height(12.dp))
            OrbitTextField(q, { q = it; vm.search(it) }, stringResource(R.string.search_coins), Modifier.fillMaxWidth(), leading = OrbitIcons.Search)
            Spacer(Modifier.height(8.dp))
            if (searching) Text(stringResource(R.string.searching), style = OrbitType.caption, color = c.textMuted)
            results.forEach { hit ->
                Row(
                    Modifier.fillMaxWidth().pressable({ vm.addCoin(hit); onDismiss() }).padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CoinMark(hit.symbol, coinColor(hit.symbol), 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(hit.name, style = OrbitType.subtitle, color = c.text)
                        Text(hit.symbol + (hit.rank?.let { " · #$it" } ?: ""), style = OrbitType.caption, color = c.textMuted)
                    }
                    Icon(OrbitIcons.Plus, null, tint = c.cyan, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun AddWalletSheet(vm: MarketViewModel, onDismiss: () -> Unit, onNeedKey: () -> Unit) {
    val c = Orbit.colors
    val scope = rememberCoroutineScope()
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var chain by remember { mutableStateOf(Chain.ALL_EVM) }
    var minUsd by remember { mutableStateOf(0.0) }
    var error by remember { mutableStateOf<Int?>(null) }
    var busy by remember { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = c.surface, contentColor = c.text) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp).imePadding().navigationBarsPadding().padding(bottom = 20.dp)) {
            Text(stringResource(R.string.track_wallet), style = OrbitType.title, color = c.text)
            Text(stringResource(R.string.track_wallet_hint), style = OrbitType.caption, color = c.textSecondary)
            Spacer(Modifier.height(14.dp))
            OrbitTextField(name, { name = it.take(40); error = null }, stringResource(R.string.wallet_name_placeholder), Modifier.fillMaxWidth(), leading = OrbitIcons.Edit)
            Spacer(Modifier.height(10.dp))
            OrbitTextField(
                address,
                { v -> address = v.trim(); error = null; AddressRules.guess(address)?.let { g -> if (g.kind != chain.kind) chain = g } },
                stringResource(R.string.wallet_address_placeholder), Modifier.fillMaxWidth(), leading = OrbitIcons.Wallet,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
            )
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.network_label), style = OrbitType.caption, color = c.textMuted)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Chain.entries.forEach { ch -> OrbitChip(chainLabel(ch), chain == ch, { chain = ch; error = null }, accent = if (ch == Chain.ALL_EVM) c.gold else c.violet) }
            }
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.notify_min_value), style = OrbitType.caption, color = c.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.0, 100.0, 1_000.0, 10_000.0, 100_000.0).forEach { v ->
                    OrbitChip(if (v == 0.0) stringResource(R.string.any_amount) else Numbers.compact(v, "$") + "+", minUsd == v, { minUsd = v })
                }
            }
            AnimatedVisibility(chain == Chain.ALL_EVM) {
                Text(stringResource(R.string.all_networks_note), style = OrbitType.caption, color = c.gold, modifier = Modifier.padding(top = 10.dp))
            }
            AnimatedVisibility(chain.needsKey) {
                Text(stringResource(R.string.evm_key_note), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 10.dp))
            }
            error?.let {
                Spacer(Modifier.height(10.dp))
                Text(stringResource(it), style = OrbitType.label, color = c.amber)
                if (it == R.string.error_wallet_key || it == R.string.error_wallet_key_bsc) {
                    Spacer(Modifier.height(8.dp))
                    SecondaryButton(stringResource(R.string.add_key), onNeedKey, icon = OrbitIcons.Key)
                }
            }
            Spacer(Modifier.height(16.dp))
            PrimaryButton(
                stringResource(if (busy) R.string.connecting else R.string.start_tracking),
                {
                    if (!busy) {
                        busy = true
                        scope.launch {
                            error = vm.addWallet(name, chain, address, minUsd)
                            busy = false
                            if (error == null) onDismiss()
                        }
                    }
                },
                Modifier.fillMaxWidth(), icon = OrbitIcons.Radar, enabled = name.isNotBlank() && address.isNotBlank() && !busy,
            )
        }
    }
}
