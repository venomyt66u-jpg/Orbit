package com.orbit.followthrough.ui.habits

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.data.db.HabitEntity
import com.orbit.followthrough.data.db.HabitLogEntity
import com.orbit.followthrough.domain.HabitKind
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class HabitView(
    val habit: HabitEntity,
    val today: Int,
    val streak: Int,
    /** Last 7 days (oldest → today), each 0..1. */
    val week: List<Float>,
) {
    val progress: Float get() = if (habit.target <= 0) 0f else (today.toFloat() / habit.target).coerceIn(0f, 1f)
    val done: Boolean get() = today >= habit.target
}

data class HabitsState(
    val loading: Boolean = true,
    val habits: List<HabitView> = emptyList(),
    /** Overall completion per day for the last 7 days. */
    val week: List<Float> = List(7) { 0f },
    val weekDates: List<LocalDate> = emptyList(),
) {
    val todayProgress: Float get() = if (habits.isEmpty()) 0f else habits.map { it.progress }.average().toFloat()
    val weekAverage: Float get() = if (week.isEmpty()) 0f else week.average().toFloat()
    val bestStreak: Int get() = habits.maxOfOrNull { it.streak } ?: 0
    val tasbih: HabitView? get() = habits.firstOrNull { it.habit.kind == HabitKind.TASBIH }
}

object HabitStats {
    fun streak(target: Int, counts: Map<Long, Int>, today: Long): Int {
        var day = if ((counts[today] ?: 0) >= target) today else today - 1
        var n = 0
        while ((counts[day] ?: 0) >= target && n < 3650) { n++; day-- }
        return n
    }

    fun ratio(count: Int, target: Int): Float = if (target <= 0) 0f else (count.toFloat() / target).coerceIn(0f, 1f)
}

class HabitsViewModel(private val c: AppContainer) : ViewModel() {
    private val today = LocalDate.now().toEpochDay()

    val state: StateFlow<HabitsState> = combine(
        c.db.habits().observeHabits(),
        c.db.habits().observeLogs(today - 90, today),
    ) { habits, logs -> build(habits, logs) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HabitsState())

    private fun build(habits: List<HabitEntity>, logs: List<HabitLogEntity>): HabitsState {
        val byHabit = logs.groupBy { it.habitId }.mapValues { (_, l) -> l.associate { it.epochDay to it.count } }
        val days = (6 downTo 0).map { today - it }
        val views = habits.map { h ->
            val counts = byHabit[h.id].orEmpty()
            HabitView(
                habit = h,
                today = counts[today] ?: 0,
                streak = HabitStats.streak(h.target, counts, today),
                week = days.map { d -> HabitStats.ratio(counts[d] ?: 0, h.target) },
            )
        }
        val week = days.indices.map { i -> if (views.isEmpty()) 0f else views.map { it.week[i] }.average().toFloat() }
        return HabitsState(false, views, week, days.map { LocalDate.ofEpochDay(it) })
    }

    fun plus(id: Long) = viewModelScope.launch { c.habitEngine.add(id, 1) }
    fun minus(id: Long) = viewModelScope.launch { c.habitEngine.add(id, -1) }
    fun done(id: Long) = viewModelScope.launch { c.habitEngine.markDone(id) }
}
