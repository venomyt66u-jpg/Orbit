package com.orbit.followthrough.domain

/**
 * Identity of a Wi‑Fi network taken from its router settings (no location permission needed):
 * the router's address, the local subnet and, when the router offers IPv6, its link‑local address
 * (usually derived from the router's hardware address, so it differs between two routers).
 */
data class NetPrint(val gateway: String, val subnet: String, val gateway6: String?) {

    fun encode(): String = listOf("v1", gateway, subnet, gateway6 ?: "").joinToString("|")

    /** Same router? Gateway and subnet must match; the IPv6 router address too when both sides know it. */
    fun sameAs(o: NetPrint): Boolean =
        gateway == o.gateway && subnet == o.subnet && (gateway6 == null || o.gateway6 == null || gateway6 == o.gateway6)

    companion object {
        fun decode(s: String): NetPrint? {
            val p = s.split('|')
            if (p.size < 4 || p[0] != "v1" || p[1].isBlank() || p[2].isBlank()) return null
            return NetPrint(p[1], p[2], p[3].ifBlank { null })
        }

        /** "192.168.0.37" + 24 → "192.168.0.0/24". */
        fun subnetOf(ipv4: String, prefix: Int): String? {
            val parts = ipv4.split('.').mapNotNull { it.toIntOrNull() }
            if (parts.size != 4 || prefix !in 0..32) return null
            val ip = parts.fold(0L) { acc, b -> (acc shl 8) or (b.toLong() and 0xFF) }
            val mask = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
            val net = ip and mask
            return listOf(24, 16, 8, 0).joinToString(".") { ((net shr it) and 0xFF).toString() } + "/" + prefix
        }

        fun matchesAny(cur: NetPrint?, known: Collection<String>): Boolean =
            cur != null && known.any { k -> decode(k)?.sameAs(cur) == true }
    }
}
