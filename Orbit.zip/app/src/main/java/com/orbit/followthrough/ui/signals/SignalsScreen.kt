package com.orbit.followthrough.ui.signals

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.SignalItemEntity
import com.orbit.followthrough.signals.SignalClassifier
import com.orbit.followthrough.ui.components.EmptyState
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.ScreenHeader
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SignalIllustration
import com.orbit.followthrough.ui.components.StatusDot
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.home.BOTTOM_SPACE
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt

fun categoryLabelRes(cat: String): Int = when (cat) {
    SignalClassifier.CAT_RELEASE -> R.string.cat_release
    SignalClassifier.CAT_ANNOUNCEMENT -> R.string.cat_announcement
    SignalClassifier.CAT_WEB3 -> R.string.cat_web3
    SignalClassifier.CAT_SECURITY -> R.string.cat_security
    SignalClassifier.CAT_POST -> R.string.cat_post
    else -> R.string.cat_news
}

@Composable
fun SignalsScreen(nav: NavHostController) {
    val vm = orbitViewModel { SignalsViewModel(it) }
    val feed by vm.items.collectAsStateWithLifecycle()
    val sources by vm.sources.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val syncing by vm.syncing.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val ctx = LocalContext.current
    val container = com.orbit.followthrough.ui.nav.LocalAppContainer.current
    val highlight by container.highlight.collectAsStateWithLifecycle()
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    var hlId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Long?>(null) }
    androidx.compose.runtime.LaunchedEffect(highlight, feed) {
        val h = highlight
        val list = feed
        if (h != null && h.first == "signal" && list != null) {
            val id = h.second.toLongOrNull()
            val idx = list.indexOfFirst { it.id == id }
            if (idx >= 0) {
                hlId = id
                listState.animateScrollToItem(idx + 2)
                vm.markRead(id ?: 0L)
                container.highlight.value = null
            }
        }
    }

    val spin = if (syncing) {
        val t = rememberInfiniteTransition(label = "sync")
        t.animateFloat(0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart), label = "spin").value
    } else 0f

    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = BOTTOM_SPACE.dp)) {
        item {
            ScreenHeader(stringResource(R.string.tab_signals), subtitle = stringResource(R.string.signals_subtitle)) {
                IconCircle(OrbitIcons.Refresh, stringResource(R.string.sync_now), { vm.syncAll() }, Modifier.rotate(spin), tint = c.cyan)
                Spacer(Modifier.width(8.dp))
                IconCircle(OrbitIcons.Layers, stringResource(R.string.sources), { nav.navigate(Routes.SOURCES) })
            }
        }

        val noSources = sources?.isEmpty() == true
        if (noSources) {
            item {
                GlassCard(Modifier.fillMaxWidth().padding(top = 8.dp), highlight = c.violet) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SignalIllustration(size = 96.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.signals_empty_title), style = OrbitType.title, color = c.text)
                            Text(stringResource(R.string.signals_empty_body), style = OrbitType.label, color = c.textSecondary)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton(stringResource(R.string.add_source), { nav.navigate(Routes.SOURCES) }, Modifier.fillMaxWidth(), icon = OrbitIcons.Plus)
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.signals_honesty), style = OrbitType.caption, color = c.textMuted)
                }
            }
        } else {
            item {
                Column {
                    OrbitTextField(query.text, vm::setText, stringResource(R.string.search_updates), leading = OrbitIcons.Search, modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OrbitChip(stringResource(R.string.filter_all), query.filter == FeedQuery.FILTER_ALL, { vm.setFilter(FeedQuery.FILTER_ALL) })
                        OrbitChip(stringResource(R.string.filter_important), query.filter == FeedQuery.FILTER_IMPORTANT, { vm.setFilter(FeedQuery.FILTER_IMPORTANT) }, icon = OrbitIcons.Flag, accent = c.amber)
                        SignalClassifier.categories.forEach { cat ->
                            OrbitChip(stringResource(categoryLabelRes(cat)), query.filter == cat, { vm.setFilter(cat) })
                        }
                    }
                }
            }
            val list = feed
            if (list != null && list.isEmpty()) {
                item {
                    EmptyState(
                        stringResource(if (query.text.isNotBlank()) R.string.no_results else R.string.feed_quiet_title),
                        stringResource(if (query.text.isNotBlank()) R.string.no_results_body else R.string.feed_quiet_body),
                        art = { SignalIllustration(size = 110.dp) },
                    )
                }
            }
            if (list != null) {
                items(list, key = { it.id }) { item ->
                    SignalCard(item, highlighted = item.id == hlId, onOpen = {
                        vm.markRead(item.id)
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    })
                }
                if (list.size >= query.limit) {
                    item { SecondaryButton(stringResource(R.string.load_more), { vm.loadMore() }, Modifier.fillMaxWidth().padding(top = 8.dp)) }
                }
            }
        }
    }
}

@Composable
private fun SignalCard(item: SignalItemEntity, highlighted: Boolean = false, onOpen: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val accent = when (item.importance) {
        2 -> c.amber
        1 -> c.cyan
        else -> c.textMuted
    }
    GlassCard(
        Modifier.fillMaxWidth().padding(bottom = 12.dp),
        highlight = if (highlighted) c.cyan else if (item.importance >= 2) c.amber else null, onClick = onOpen, padding = PaddingValues(16.dp),
    ) {
        if (highlighted) com.orbit.followthrough.ui.components.Tag(stringResource(R.string.from_notification), c.cyan, modifier = Modifier.padding(bottom = 8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!item.read) { StatusDot(c.cyan); Spacer(Modifier.width(8.dp)) }
            Text(item.sourceName, style = OrbitType.label, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Tag(stringResource(categoryLabelRes(item.category)), accent)
        }
        Spacer(Modifier.height(8.dp))
        Text(item.title, style = OrbitType.subtitle, color = c.text, maxLines = 3, overflow = TextOverflow.Ellipsis)
        if (item.summary.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(item.summary, style = OrbitType.body, color = c.textSecondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        item.matchedKeyword?.let {
            Spacer(Modifier.height(8.dp))
            Tag(stringResource(R.string.matched_keyword, it), c.amber, icon = OrbitIcons.Target)
        }
        Spacer(Modifier.height(10.dp))
        // Event time vs. detection time are always shown separately.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.published_at, item.publishedAt?.let { Fmt.dayAndTime(ctx, it) } ?: stringResource(R.string.unknown)),
                    style = OrbitType.caption, color = c.textMuted,
                )
                Text(stringResource(R.string.detected_at, Fmt.ago(item.discoveredAt)), style = OrbitType.caption, color = c.textMuted)
            }
            Icon(OrbitIcons.External, stringResource(R.string.open_original), tint = c.cyan, modifier = Modifier.size(20.dp))
        }
    }
}
