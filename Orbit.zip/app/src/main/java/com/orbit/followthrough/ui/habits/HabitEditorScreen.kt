package com.orbit.followthrough.ui.habits

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.HabitEntity
import com.orbit.followthrough.domain.HabitKind
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitSwitch
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.SettingRow
import com.orbit.followthrough.ui.components.Stepper
import com.orbit.followthrough.ui.components.TimePickerDialog
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Starter templates. Spiritual ones are names only – Orbit never generates religious text. */
data class HabitPreset(val nameRes: Int, val glyph: String, val color: Int, val target: Int, val unitRes: Int? = null, val spiritual: Boolean = false, val kind: HabitKind = HabitKind.STANDARD)

val habitPresets = listOf(
    HabitPreset(R.string.preset_water, "drop", 1, 8, R.string.unit_cups),
    HabitPreset(R.string.preset_reading, "book", 0, 20, R.string.unit_pages),
    HabitPreset(R.string.preset_walk, "walk", 2, 1),
    HabitPreset(R.string.preset_exercise, "dumbbell", 5, 1),
    HabitPreset(R.string.preset_journal, "pen", 4, 1),
    HabitPreset(R.string.preset_sleep, "bed", 4, 1),
    HabitPreset(R.string.preset_prayers, "crescent", 3, 5, spiritual = true),
    HabitPreset(R.string.preset_morning_adhkar, "sun", 3, 1, spiritual = true),
    HabitPreset(R.string.preset_evening_adhkar, "moon", 3, 1, spiritual = true),
    HabitPreset(R.string.preset_quran, "book", 3, 5, R.string.unit_pages, spiritual = true),
    HabitPreset(R.string.preset_tasbih, "beads", 3, 100, spiritual = true, kind = HabitKind.TASBIH),
)

data class HabitForm(
    val loaded: Boolean = false,
    val habit: HabitEntity = HabitEntity(name = "", glyph = "target"),
    val saved: Boolean = false,
)

class HabitEditorViewModel(private val c: AppContainer, private val id: Long) : ViewModel() {
    private val _form = MutableStateFlow(HabitForm())
    val form: StateFlow<HabitForm> = _form

    init {
        viewModelScope.launch {
            val h = if (id > 0) c.db.habits().get(id) else null
            _form.value = HabitForm(true, h ?: HabitEntity(name = "", glyph = "target", sortOrder = (c.db.habits().count())))
        }
    }

    fun edit(block: HabitEntity.() -> HabitEntity) = _form.update { it.copy(habit = it.habit.block()) }

    fun save() = viewModelScope.launch {
        val h = _form.value.habit
        if (h.name.isBlank()) return@launch
        c.habitEngine.save(h.copy(name = h.name.trim(), target = h.target.coerceAtLeast(1)))
        _form.update { it.copy(saved = true) }
    }

    fun delete() = viewModelScope.launch {
        if (id > 0) c.habitEngine.delete(id)
        _form.update { it.copy(saved = true) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HabitEditorScreen(nav: NavHostController, id: Long) {
    val vm = orbitViewModel(key = "habit$id") { HabitEditorViewModel(it, id) }
    val form by vm.form.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val ctx = LocalContext.current
    val h = form.habit
    var showTime by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(form.saved) { if (form.saved) nav.popBackStack() }

    Column(Modifier.fillMaxSize().imePadding()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            TopBar(stringResource(if (id > 0) R.string.edit_habit else R.string.new_habit), { nav.popBackStack() }, stringResource(R.string.back)) {
                if (id > 0) IconCircle(OrbitIcons.Trash, stringResource(R.string.delete), { confirmDelete = true }, tint = c.rose)
            }
            if (form.loaded) {
                if (id <= 0) {
                    SectionHeader(stringResource(R.string.start_from_template))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        habitPresets.forEach { p ->
                            OrbitChip(stringResource(p.nameRes), false, {
                                vm.edit {
                                    copy(
                                        name = ctx.getString(p.nameRes), glyph = p.glyph, colorIndex = p.color, target = p.target,
                                        unit = p.unitRes?.let { ctx.getString(it) } ?: "", spiritual = p.spiritual, kind = p.kind,
                                        phrase = if (p.kind == HabitKind.TASBIH) Dhikr.presets.first().arabic else "",
                                    )
                                }
                            }, icon = OrbitIcons.habit(p.glyph), accent = c.habit(p.color))
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                Spacer(Modifier.height(6.dp))
                OrbitTextField(
                    h.name, { v -> vm.edit { copy(name = v.take(60)) } },
                    placeholder = stringResource(R.string.habit_name_placeholder),
                    style = OrbitType.headline, boxed = false,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    modifier = Modifier.fillMaxWidth(),
                )

                SectionHeader(stringResource(R.string.look), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OrbitIcons.habitGlyphs.forEach { (key, icon) ->
                            val sel = h.glyph == key
                            val color = c.habit(h.colorIndex)
                            Box(
                                Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                                    .background(if (sel) color.copy(alpha = 0.18f) else c.surface)
                                    .border(1.dp, if (sel) color else c.stroke, RoundedCornerShape(14.dp))
                                    .pressable({ vm.edit { copy(glyph = key) } }, role = Role.RadioButton)
                                    .semantics { selected = sel; contentDescription = key },
                                contentAlignment = Alignment.Center,
                            ) { Icon(icon, null, tint = if (sel) color else c.textSecondary, modifier = Modifier.size(22.dp)) }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        c.habitPalette.forEachIndexed { i, col ->
                            val sel = h.colorIndex == i
                            Box(
                                Modifier.size(34.dp).clip(CircleShape).background(col)
                                    .border(3.dp, if (sel) c.text else col, CircleShape)
                                    .pressable({ vm.edit { copy(colorIndex = i) } }, role = Role.RadioButton)
                                    .semantics { selected = sel; contentDescription = ctx.getString(R.string.color_n, i + 1) }
                            )
                        }
                    }
                }

                SectionHeader(stringResource(R.string.daily_goal), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    SettingRow(stringResource(R.string.target_per_day)) {
                        Stepper(h.target, { v -> vm.edit { copy(target = v) } }, 1..1000, decLabel = stringResource(R.string.decrease), incLabel = stringResource(R.string.increase))
                    }
                    if (h.kind != HabitKind.TASBIH) {
                        OrbitTextField(h.unit, { v -> vm.edit { copy(unit = v.take(20)) } }, placeholder = stringResource(R.string.unit_placeholder), modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    } else {
                        Spacer(Modifier.height(8.dp))
                        OrbitTextField(h.phrase, { v -> vm.edit { copy(phrase = v.take(80)) } }, placeholder = stringResource(R.string.custom_phrase), modifier = Modifier.fillMaxWidth())
                        Text(stringResource(R.string.dhikr_note), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 6.dp))
                    }
                }

                SectionHeader(stringResource(R.string.reminder), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    SettingRow(
                        stringResource(R.string.habit_reminder),
                        subtitle = if (h.reminderEnabled) Fmt.time(ctx, h.reminderHour, h.reminderMinute) else stringResource(R.string.habit_reminder_hint),
                        icon = OrbitIcons.Bell,
                        onClick = { if (h.reminderEnabled) showTime = true else vm.edit { copy(reminderEnabled = true) } },
                    ) { OrbitSwitch(h.reminderEnabled) { v -> vm.edit { copy(reminderEnabled = v) } } }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
        Column(Modifier.fillMaxWidth().background(c.void.copy(alpha = 0.92f)).navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
            PrimaryButton(stringResource(R.string.save), { vm.save() }, Modifier.fillMaxWidth(), icon = OrbitIcons.Check, enabled = h.name.isNotBlank())
        }
    }

    if (showTime) TimePickerDialog(h.reminderHour, h.reminderMinute, { hh, mm -> vm.edit { copy(reminderHour = hh, reminderMinute = mm) }; showTime = false }, { showTime = false })
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = c.surface,
            title = { Text(stringResource(R.string.delete_habit_q), color = c.text) },
            text = { Text(stringResource(R.string.delete_habit_body), color = c.textSecondary) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete() }) { Text(stringResource(R.string.delete), color = c.rose) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
        )
    }
}
