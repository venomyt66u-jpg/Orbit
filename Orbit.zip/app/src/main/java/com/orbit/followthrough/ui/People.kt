package com.orbit.followthrough.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.Config
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class Look { HOOD, FEZ, CURLY, GOLD, CAP, HEADSET }

data class Person(
    val slot: String,
    val name: String,
    val look: Look,
    val bgA: Color,
    val bgB: Color,
    val skin: Color,
    val hair: Color,
    val shirt: Color,
) {
    val accent: Color get() = bgA
}

/** The group. Order = order on the pick screen. */
val People: List<Person> = listOf(
    Person("ghareeb", "غريب", Look.HOOD, Color(0xFF8B5CFF), Color(0xFF2B1B6B), Color(0xFFC99A78), Color(0xFF1B1530), Color(0xFF241C45)),
    Person("abo_masry", "اب المصري", Look.FEZ, Color(0xFFFFB547), Color(0xFF8A3B12), Color(0xFFD9A47F), Color(0xFF2A1A12), Color(0xFF3B5BA8)),
    Person("moaz", "معاذ حسان", Look.CURLY, Color(0xFF3BE3FF), Color(0xFF0B4C78), Color(0xFFB98563), Color(0xFF20140E), Color(0xFF1E2E52)),
    Person("dahab", "دهب", Look.GOLD, Color(0xFFFFD36B), Color(0xFF9A6A08), Color(0xFFE3B48F), Color(0xFF2B1D10), Color(0xFF1A1A22)),
    Person("waleed", "وليد", Look.CAP, Color(0xFF3DDC97), Color(0xFF0E5A45), Color(0xFFC08D69), Color(0xFF24170F), Color(0xFFE85D4A)),
)

val AdminPerson = Person(Config.ADMIN_SLOT, "الأدمن", Look.HEADSET, Color(0xFF4D7CFF), Color(0xFF14204F), Color(0xFFD2A07C), Color(0xFF1C1612), Color(0xFF2A3354))

fun personOf(slot: String?): Person? = if (slot == Config.ADMIN_SLOT) AdminPerson else People.firstOrNull { it.slot == slot }

/** Original illustrated avatar for each person, drawn as vectors (crisp at any size). */
@Composable
fun Avatar(person: Person, size: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) { drawAvatar(person) }
}

private fun DrawScope.drawAvatar(p: Person) {
    val s = size.minDimension
    fun o(x: Float, y: Float) = Offset(x * s, y * s)
    fun sz(w: Float, h: Float) = Size(w * s, h * s)
    val dark = Color(0xFF1A1110)
    val skinShade = Color(
        red = p.skin.red * 0.82f, green = p.skin.green * 0.8f, blue = p.skin.blue * 0.8f, alpha = 1f,
    )

    drawCircle(Brush.linearGradient(listOf(p.bgA, p.bgB), o(0.1f, 0.05f), o(0.95f, 1f)), s / 2, o(0.5f, 0.5f))
    // soft light behind the head
    drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.22f), Color.Transparent), o(0.5f, 0.42f), s * 0.42f), s * 0.42f, o(0.5f, 0.42f))

    val clip = Path().apply { addOval(Rect(0f, 0f, s, s)) }
    clipPath(clip) {
        // --- behind the head ---
        when (p.look) {
            Look.HOOD -> drawOval(p.hair, o(0.19f, 0.13f), sz(0.62f, 0.78f))
            Look.CURLY -> {
                for (i in 0..8) {
                    val a = (PI + i * PI / 8).toFloat()
                    drawCircle(p.hair, s * 0.075f, Offset(s * 0.5f + cos(a) * s * 0.2f, s * 0.43f + sin(a) * s * 0.22f))
                }
            }
            else -> Unit
        }

        // shoulders + neck
        drawRoundRect(p.shirt, o(0.16f, 0.75f), sz(0.68f, 0.5f), CornerRadius(s * 0.3f))
        if (p.look == Look.HOOD) drawRoundRect(p.hair, o(0.16f, 0.75f), sz(0.68f, 0.5f), CornerRadius(s * 0.3f))
        drawRoundRect(skinShade, o(0.43f, 0.6f), sz(0.14f, 0.2f), CornerRadius(s * 0.05f))
        // collar
        drawArc(p.shirt.copy(alpha = 1f), 0f, 180f, true, o(0.38f, 0.7f), sz(0.24f, 0.12f))

        // ears + head
        if (p.look != Look.HOOD) {
            drawCircle(skinShade, s * 0.05f, o(0.3f, 0.48f))
            drawCircle(skinShade, s * 0.05f, o(0.7f, 0.48f))
        }
        val faceW = if (p.look == Look.FEZ) 0.44f else 0.4f
        drawOval(p.skin, o(0.5f - faceW / 2, 0.27f), sz(faceW, 0.45f))

        // beard sits under the features
        if (p.look == Look.CAP) {
            drawArc(p.hair, 0f, 180f, true, o(0.3f, 0.36f), sz(0.4f, 0.36f))
            drawOval(p.skin, o(0.38f, 0.4f), sz(0.24f, 0.13f))
        }

        // eyes
        if (p.look == Look.HOOD) {
            // sunglasses
            drawRoundRect(dark, o(0.355f, 0.435f), sz(0.13f, 0.075f), CornerRadius(s * 0.03f))
            drawRoundRect(dark, o(0.515f, 0.435f), sz(0.13f, 0.075f), CornerRadius(s * 0.03f))
            drawLine(dark, o(0.48f, 0.455f), o(0.52f, 0.455f), s * 0.018f)
            drawLine(Color.White.copy(alpha = 0.5f), o(0.375f, 0.45f), o(0.41f, 0.45f), s * 0.012f, cap = StrokeCap.Round)
        } else {
            drawCircle(dark, s * 0.026f, o(0.42f, 0.47f))
            drawCircle(dark, s * 0.026f, o(0.58f, 0.47f))
            drawCircle(Color.White, s * 0.009f, o(0.428f, 0.462f))
            drawCircle(Color.White, s * 0.009f, o(0.588f, 0.462f))
            // brows
            drawLine(p.hair, o(0.385f, 0.415f), o(0.45f, 0.405f), s * 0.016f, cap = StrokeCap.Round)
            drawLine(p.hair, o(0.55f, 0.405f), o(0.615f, 0.415f), s * 0.016f, cap = StrokeCap.Round)
        }

        // mouth
        val mouthColor = if (p.look == Look.CAP) Color(0xFFF2C4B4) else dark.copy(alpha = 0.8f)
        val mouthY = if (p.look == Look.FEZ) 0.565f else 0.54f
        drawArc(mouthColor, 20f, 140f, false, o(0.44f, mouthY), sz(0.12f, 0.07f), style = Stroke(s * 0.018f, cap = StrokeCap.Round))
        // cheeks
        drawCircle(Color(0xFFFF7A7A).copy(alpha = 0.18f), s * 0.035f, o(0.38f, 0.54f))
        drawCircle(Color(0xFFFF7A7A).copy(alpha = 0.18f), s * 0.035f, o(0.62f, 0.54f))

        // --- in front ---
        when (p.look) {
            Look.HOOD -> {
                // hood rim over the forehead
                drawArc(p.hair, 180f, 180f, true, o(0.27f, 0.2f), sz(0.46f, 0.28f))
                drawArc(p.bgA.copy(alpha = 0.55f), 190f, 160f, false, o(0.27f, 0.2f), sz(0.46f, 0.28f), style = Stroke(s * 0.012f))
            }
            Look.FEZ -> {
                // short hair on the sides
                drawArc(p.hair, 160f, 60f, false, o(0.28f, 0.28f), sz(0.44f, 0.4f), style = Stroke(s * 0.04f))
                drawArc(p.hair, -40f, 60f, false, o(0.28f, 0.28f), sz(0.44f, 0.4f), style = Stroke(s * 0.04f))
                // moustache
                drawOval(p.hair, o(0.4f, 0.525f), sz(0.105f, 0.05f))
                drawOval(p.hair, o(0.495f, 0.525f), sz(0.105f, 0.05f))
                // fez
                val fez = Path().apply {
                    moveTo(0.35f * s, 0.32f * s); lineTo(0.65f * s, 0.32f * s)
                    lineTo(0.61f * s, 0.13f * s); lineTo(0.39f * s, 0.13f * s); close()
                }
                drawPath(fez, Color(0xFFC62828))
                drawOval(Color(0xFF8E1B1B), o(0.39f, 0.115f), sz(0.22f, 0.04f))
                drawRoundRect(Color(0xFF8E1B1B), o(0.35f, 0.29f), sz(0.3f, 0.035f), CornerRadius(s * 0.01f))
                drawLine(dark, o(0.5f, 0.13f), o(0.63f, 0.2f), s * 0.012f)
                drawLine(dark, o(0.63f, 0.2f), o(0.64f, 0.27f), s * 0.016f, cap = StrokeCap.Round)
            }
            Look.CURLY -> {
                for (i in 0..5) drawCircle(p.hair, s * 0.06f, o(0.33f + i * 0.068f, 0.27f + if (i % 2 == 0) 0f else -0.025f))
                // round glasses
                val g = Color(0xFFEAF0FF)
                drawCircle(g, s * 0.055f, o(0.42f, 0.47f), style = Stroke(s * 0.014f))
                drawCircle(g, s * 0.055f, o(0.58f, 0.47f), style = Stroke(s * 0.014f))
                drawLine(g, o(0.475f, 0.465f), o(0.525f, 0.465f), s * 0.012f)
            }
            Look.GOLD -> {
                drawArc(p.hair, 180f, 180f, true, o(0.3f, 0.245f), sz(0.4f, 0.2f))
                // crown
                val gold = Color(0xFFFFC94A)
                val crown = Path().apply {
                    moveTo(0.36f * s, 0.27f * s)
                    lineTo(0.36f * s, 0.17f * s); lineTo(0.41f * s, 0.22f * s)
                    lineTo(0.5f * s, 0.13f * s); lineTo(0.59f * s, 0.22f * s)
                    lineTo(0.64f * s, 0.17f * s); lineTo(0.64f * s, 0.27f * s); close()
                }
                drawPath(crown, gold)
                drawCircle(Color(0xFFFF5D8F), s * 0.017f, o(0.5f, 0.225f))
                drawCircle(Color(0xFF3BE3FF), s * 0.013f, o(0.4f, 0.245f))
                drawCircle(Color(0xFF3BE3FF), s * 0.013f, o(0.6f, 0.245f))
                // chain
                drawArc(gold, 20f, 140f, false, o(0.37f, 0.64f), sz(0.26f, 0.2f), style = Stroke(s * 0.018f))
                drawCircle(gold, s * 0.03f, o(0.5f, 0.84f))
            }
            Look.CAP -> {
                val cap = Color(0xFF1F2A44)
                drawArc(cap, 180f, 180f, true, o(0.29f, 0.2f), sz(0.42f, 0.3f))
                // brim turned backwards
                drawRoundRect(cap, o(0.62f, 0.31f), sz(0.17f, 0.045f), CornerRadius(s * 0.02f))
                drawCircle(p.bgA, s * 0.02f, o(0.5f, 0.27f))
            }
            Look.HEADSET -> {
                drawArc(p.hair, 180f, 180f, true, o(0.3f, 0.25f), sz(0.4f, 0.19f))
                val hs = Color(0xFF0E1426)
                drawArc(hs, 180f, 180f, false, o(0.27f, 0.22f), sz(0.46f, 0.44f), style = Stroke(s * 0.03f))
                drawRoundRect(hs, o(0.245f, 0.41f), sz(0.075f, 0.13f), CornerRadius(s * 0.03f))
                drawRoundRect(hs, o(0.68f, 0.41f), sz(0.075f, 0.13f), CornerRadius(s * 0.03f))
                drawLine(hs, o(0.29f, 0.53f), o(0.4f, 0.585f), s * 0.016f, cap = StrokeCap.Round)
                drawCircle(Color(0xFF3BE3FF), s * 0.022f, o(0.41f, 0.588f))
            }
        }
    }
    // rim
    drawCircle(Color.White.copy(alpha = 0.18f), s / 2 - s * 0.01f, o(0.5f, 0.5f), style = Stroke(s * 0.02f))
}
