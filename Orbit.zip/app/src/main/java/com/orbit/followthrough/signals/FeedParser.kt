package com.orbit.followthrough.signals

import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.time.Instant
import java.time.OffsetDateTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory

data class FeedEntry(
    val guid: String,
    val title: String,
    val link: String,
    val summary: String,
    val publishedAt: Long?,
)

/** Parses RSS 2.0 and Atom feeds (RSS sites, blogs, GitHub releases.atom). Pure JVM – unit tested. */
object FeedParser {

    fun parse(bytes: ByteArray): List<FeedEntry> {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = false
            isExpandEntityReferences = false
            // Harden against XXE where the platform parser supports it.
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        }
        val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
        val root = doc.documentElement ?: return emptyList()
        return if (root.nodeName.equals("feed", ignoreCase = true) || root.nodeName.endsWith(":feed")) parseAtom(root) else parseRss(root)
    }

    private fun parseRss(root: Element): List<FeedEntry> {
        val items = root.getElementsByTagName("item")
        return (0 until items.length).mapNotNull { i ->
            val e = items.item(i) as? Element ?: return@mapNotNull null
            val title = text(e, "title").cleanText()
            val link = text(e, "link").trim()
            val guid = text(e, "guid").trim().ifBlank { link.ifBlank { title } }
            val body = text(e, "content:encoded").ifBlank { text(e, "description") }
            val date = parseDate(text(e, "pubDate").ifBlank { text(e, "dc:date") })
            if (title.isBlank() && link.isBlank()) null
            else FeedEntry(guid, title.ifBlank { link }, link, summarize(body), date)
        }
    }

    private fun parseAtom(root: Element): List<FeedEntry> {
        val entries = root.getElementsByTagName("entry")
        return (0 until entries.length).mapNotNull { i ->
            val e = entries.item(i) as? Element ?: return@mapNotNull null
            val title = text(e, "title").cleanText()
            val link = atomLink(e)
            val guid = text(e, "id").trim().ifBlank { link.ifBlank { title } }
            val body = text(e, "content").ifBlank { text(e, "summary") }
            val date = parseDate(text(e, "published").ifBlank { text(e, "updated") })
            if (title.isBlank() && link.isBlank()) null
            else FeedEntry(guid, title.ifBlank { link }, link, summarize(body), date)
        }
    }

    private fun atomLink(e: Element): String {
        val links = e.getElementsByTagName("link")
        var fallback = ""
        for (i in 0 until links.length) {
            val l = links.item(i) as? Element ?: continue
            if (l.parentNode != e) continue
            val href = l.getAttribute("href")
            val rel = l.getAttribute("rel")
            if (rel.isBlank() || rel == "alternate") return href
            if (fallback.isBlank()) fallback = href
        }
        return fallback
    }

    /** Direct-child text only, so nested elements with the same name are ignored. */
    private fun text(parent: Element, tag: String): String {
        val children = parent.childNodes
        for (i in 0 until children.length) {
            val n = children.item(i)
            if (n.nodeType == Node.ELEMENT_NODE && n.nodeName.equals(tag, ignoreCase = true)) return n.textContent ?: ""
        }
        return ""
    }

    fun parseDate(raw: String): Long? {
        val s = raw.trim()
        if (s.isEmpty()) return null
        runCatching { return Instant.parse(s).toEpochMilli() }
        runCatching { return OffsetDateTime.parse(s).toInstant().toEpochMilli() }
        runCatching { return ZonedDateTime.parse(s, DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli() }
        runCatching {
            return ZonedDateTime.parse(s, DateTimeFormatter.ofPattern("EEE, d MMM yyyy HH:mm:ss z", Locale.ENGLISH)).toInstant().toEpochMilli()
        }
        runCatching {
            return ZonedDateTime.parse(s, DateTimeFormatter.ofPattern("EEE, d MMM yyyy HH:mm z", Locale.ENGLISH)).toInstant().toEpochMilli()
        }
        return null
    }

    private val tagRegex = Regex("<[^>]+>")
    private val spaceRegex = Regex("\\s+")
    private val sentenceEnd = Regex("(?<=[.!?؟])\\s+")

    /** Extractive summary: strip HTML, keep the first sentences up to ~220 characters. */
    fun summarize(html: String, maxChars: Int = 220): String {
        val text = decodeEntities(html.replace(tagRegex, " ")).replace(spaceRegex, " ").trim()
        if (text.length <= maxChars) return text
        val sb = StringBuilder()
        for (sentence in text.split(sentenceEnd)) {
            if (sb.length + sentence.length > maxChars) break
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(sentence)
        }
        return if (sb.isNotEmpty()) sb.toString() else text.take(maxChars - 1).trimEnd() + "…"
    }

    private fun String.cleanText(): String = decodeEntities(replace(tagRegex, " ")).replace(spaceRegex, " ").trim()

    private fun decodeEntities(s: String): String = s
        .replace("&nbsp;", " ")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&#039;", "'")
        .replace("&apos;", "'")
        .replace("&amp;", "&")

    /** Normalised key used to detect the same announcement published by several sources. */
    fun titleKey(title: String): String =
        title.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().replace(spaceRegex, " ").take(120)
}
