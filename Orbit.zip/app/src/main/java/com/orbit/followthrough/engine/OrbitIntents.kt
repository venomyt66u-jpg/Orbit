package com.orbit.followthrough.engine

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.orbit.followthrough.MainActivity

object OrbitIntents {
    private const val P = "com.orbit.followthrough"
    const val ALARM_REMINDER = "$P.ALARM_REMINDER"
    const val ALARM_HABIT = "$P.ALARM_HABIT"

    const val COMPLETE = "$P.COMPLETE"
    const val SNOOZE = "$P.SNOOZE"
    const val SKIP = "$P.SKIP"
    const val DISMISS = "$P.DISMISS"
    const val HABIT_PLUS = "$P.HABIT_PLUS"
    const val HABIT_DONE = "$P.HABIT_DONE"

    const val EXTRA_ID = "id"
    const val EXTRA_MINUTES = "minutes"
    const val EXTRA_ROUTE = "route"

    private val actionCodes = listOf(COMPLETE, SNOOZE, SKIP, DISMISS, HABIT_PLUS, HABIT_DONE)

    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    fun alarmIntent(context: Context, action: String, id: Long): Intent =
        Intent(context, AlarmReceiver::class.java)
            .setAction(action)
            .setData(Uri.parse("orbit://alarm/${action.substringAfterLast('.')}/$id"))
            .putExtra(EXTRA_ID, id)

    fun alarm(context: Context, action: String, id: Long, create: Boolean = true): PendingIntent? {
        val flags = if (create) FLAGS else (PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(context, requestCode(id, if (action == ALARM_HABIT) 7 else 6), alarmIntent(context, action, id), flags)
    }

    fun action(context: Context, action: String, id: Long, minutes: Int = 0): PendingIntent {
        val intent = Intent(context, ActionReceiver::class.java)
            .setAction(action)
            .setData(Uri.parse("orbit://action/${action.substringAfterLast('.')}/$id/$minutes"))
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_MINUTES, minutes)
        return PendingIntent.getBroadcast(context, requestCode(id, actionCodes.indexOf(action).coerceAtLeast(0)), intent, FLAGS)
    }

    fun openApp(context: Context, route: String? = null, requestCode: Int = 0): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (route != null) intent.putExtra(EXTRA_ROUTE, route).setData(Uri.parse("orbit://open/$route/$requestCode"))
        return PendingIntent.getActivity(context, requestCode, intent, FLAGS)
    }

    private fun requestCode(id: Long, slot: Int): Int = ((id % 100_000_000L).toInt() * 16) + slot
}
