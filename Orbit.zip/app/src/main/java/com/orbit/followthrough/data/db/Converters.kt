package com.orbit.followthrough.data.db

import androidx.room.TypeConverter
import com.orbit.followthrough.domain.EventType
import com.orbit.followthrough.domain.HabitKind
import com.orbit.followthrough.domain.NotifyMode
import com.orbit.followthrough.domain.ReminderCategory
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.domain.SourceType
import com.orbit.followthrough.domain.SyncStatus

/** Enums are stored by name so that re-ordering enum constants never corrupts data. */
class Converters {
    @TypeConverter fun repeatToString(v: RepeatType): String = v.name
    @TypeConverter fun stringToRepeat(v: String): RepeatType = enumOr(v, RepeatType.ONCE)

    @TypeConverter fun statusToString(v: ReminderStatus): String = v.name
    @TypeConverter fun stringToStatus(v: String): ReminderStatus = enumOr(v, ReminderStatus.SCHEDULED)

    @TypeConverter fun categoryToString(v: ReminderCategory): String = v.name
    @TypeConverter fun stringToCategory(v: String): ReminderCategory = enumOr(v, ReminderCategory.GENERAL)

    @TypeConverter fun eventToString(v: EventType): String = v.name
    @TypeConverter fun stringToEvent(v: String): EventType = enumOr(v, EventType.FIRED)

    @TypeConverter fun habitKindToString(v: HabitKind): String = v.name
    @TypeConverter fun stringToHabitKind(v: String): HabitKind = enumOr(v, HabitKind.STANDARD)

    @TypeConverter fun sourceTypeToString(v: SourceType): String = v.name
    @TypeConverter fun stringToSourceType(v: String): SourceType = enumOr(v, SourceType.RSS)

    @TypeConverter fun notifyModeToString(v: NotifyMode): String = v.name
    @TypeConverter fun stringToNotifyMode(v: String): NotifyMode = enumOr(v, NotifyMode.IMPORTANT)

    @TypeConverter fun syncStatusToString(v: SyncStatus): String = v.name
    @TypeConverter fun stringToSyncStatus(v: String): SyncStatus = enumOr(v, SyncStatus.NEVER)

    private inline fun <reified T : Enum<T>> enumOr(value: String, fallback: T): T =
        enumValues<T>().firstOrNull { it.name == value } ?: fallback
}
