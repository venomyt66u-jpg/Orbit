package com.orbit.followthrough.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.ui.theme.Orbit
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

fun parseSpark(s: String): List<Float> = if (s.isBlank()) emptyList() else s.split(',').mapNotNull { it.toFloatOrNull() }

/** Compact sparkline with an end dot – used in watchlist rows. */
@Composable
fun Sparkline(values: List<Float>, color: Color, modifier: Modifier = Modifier, fill: Boolean = true) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val min = values.min(); val max = values.max()
        val range = (max - min).takeIf { it > 0f } ?: 1f
        val stepX = size.width / (values.size - 1)
        fun y(v: Float) = size.height - (v - min) / range * size.height * 0.9f - size.height * 0.05f
        val line = Path()
        values.forEachIndexed { i, v -> if (i == 0) line.moveTo(0f, y(v)) else line.lineTo(i * stepX, y(v)) }
        if (fill) {
            val area = Path().apply { addPath(line); lineTo(size.width, size.height); lineTo(0f, size.height); close() }
            drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.28f), Color.Transparent)))
        }
        drawPath(line, color, style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(color, 2.6.dp.toPx(), Offset(size.width, y(values.last())))
    }
}

/** Larger chart with faint grid, min/max guides and an emphasized last point. */
@Composable
fun AreaChart(values: List<Float>, color: Color, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    val reveal by animateFloatAsState(if (values.size > 1) 1f else 0f, tween(if (Orbit.reducedMotion) 0 else 900, easing = FastOutSlowInEasing), label = "reveal")
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val min = values.min(); val max = values.max()
        val range = (max - min).takeIf { it > 0f } ?: 1f
        val pad = size.height * 0.08f
        val h = size.height - pad * 2
        for (g in 0..3) {
            val gy = pad + h * g / 3f
            drawLine(c.stroke, Offset(0f, gy), Offset(size.width, gy), 1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 8f)))
        }
        val n = max(2, (values.size * reveal).toInt())
        val stepX = size.width / (values.size - 1)
        fun y(v: Float) = pad + h - (v - min) / range * h
        val line = Path()
        for (i in 0 until n) { val p = Offset(i * stepX, y(values[i])); if (i == 0) line.moveTo(p.x, p.y) else line.lineTo(p.x, p.y) }
        val area = Path().apply { addPath(line); lineTo((n - 1) * stepX, size.height); lineTo(0f, size.height); close() }
        drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.32f), Color.Transparent)))
        drawPath(line, color, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        val last = Offset((n - 1) * stepX, y(values[n - 1]))
        drawCircle(color.copy(alpha = 0.25f), 8.dp.toPx(), last)
        drawCircle(color, 4.dp.toPx(), last)
    }
}

/** Vertical bars (daily usage etc.); the highlighted index uses the accent. */
@Composable
fun BarChart(values: List<Float>, modifier: Modifier = Modifier, highlight: Int = values.lastIndex, color: Color = Orbit.colors.cyan) {
    val c = Orbit.colors
    Canvas(modifier) {
        if (values.isEmpty()) return@Canvas
        val maxV = values.max().takeIf { it > 0f } ?: 1f
        val slot = size.width / values.size
        val w = slot * 0.56f
        values.forEachIndexed { i, v ->
            val x = i * slot + (slot - w) / 2
            drawRoundRect(c.stroke, Offset(x, 0f), Size(w, size.height), CornerRadius(w / 2))
            val bh = size.height * (v / maxV)
            if (bh > 0f) drawRoundRect(
                if (i == highlight) Brush.verticalGradient(listOf(color, c.electric)) else Brush.verticalGradient(listOf(color.copy(alpha = 0.55f), c.electric.copy(alpha = 0.45f))),
                Offset(x, size.height - bh), Size(w, bh), CornerRadius(w / 2),
            )
        }
    }
}

/** Fear & Greed semicircle gauge, 0..100. */
@Composable
fun SentimentGauge(value: Int, modifier: Modifier = Modifier, size: Dp = 120.dp) {
    val c = Orbit.colors
    val v by animateFloatAsState(value.coerceIn(0, 100) / 100f, tween(1000, easing = FastOutSlowInEasing), label = "gauge")
    val stops = remember(c) { listOf(c.rose, c.amber, c.gold, c.green, c.cyan) }
    Box(modifier.size(size, size * 0.62f), contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.size(size, size * 0.62f)) {
            val sw = this.size.width * 0.09f
            val r = this.size.width / 2 - sw
            val center = Offset(this.size.width / 2, this.size.height - sw * 0.4f)
            val tl = Offset(center.x - r, center.y - r)
            drawArc(c.stroke, 180f, 180f, false, tl, Size(r * 2, r * 2), style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(Brush.sweepGradient(stops + stops.first(), center), 180f, 180f * v, false, tl, Size(r * 2, r * 2), style = Stroke(sw, cap = StrokeCap.Round))
            val a = PI.toFloat() * (1f + v)
            val needle = Offset(center.x + cos(a) * r * 0.78f, center.y + sin(a) * r * 0.78f)
            drawLine(c.text, center, needle, sw * 0.28f, cap = StrokeCap.Round)
            drawCircle(c.text, sw * 0.38f, center)
        }
    }
}

/** Radar sweep used by the network scan hero. */
@Composable
fun RadarSweep(active: Boolean, color: Color, modifier: Modifier = Modifier, blips: List<Float> = emptyList()) {
    val phase = ambientPhase(2400, enabled = active)
    val c = Orbit.colors
    Canvas(modifier) {
        val r = kotlin.math.min(size.width, size.height) / 2
        for (k in 1..3) drawCircle(c.stroke, r * k / 3f, style = Stroke(1.dp.toPx()))
        drawLine(c.stroke, Offset(center.x - r, center.y), Offset(center.x + r, center.y), 1f)
        drawLine(c.stroke, Offset(center.x, center.y - r), Offset(center.x, center.y + r), 1f)
        if (active) {
            val start = phase * 360f
            drawArc(Brush.sweepGradient(listOf(Color.Transparent, color.copy(alpha = 0.35f), Color.Transparent), center), start, 70f, true, Offset(center.x - r, center.y - r), Size(r * 2, r * 2))
        }
        blips.forEachIndexed { i, b ->
            val ang = (i * 137.5f) * (PI.toFloat() / 180f)
            val p = Offset(center.x + cos(ang) * r * b, center.y + sin(ang) * r * b)
            drawCircle(color.copy(alpha = 0.3f), 6.dp.toPx(), p)
            drawCircle(color, 3.dp.toPx(), p)
        }
        drawCircle(color, 4.dp.toPx(), center)
    }
}
