package com.orbit.followthrough.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.data.db.HabitEntity
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.domain.EventType
import com.orbit.followthrough.domain.ReminderStatus
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

data class HabitChip(val habit: HabitEntity, val count: Int) {
    val progress: Float get() = if (habit.target <= 0) 0f else (count.toFloat() / habit.target).coerceIn(0f, 1f)
}

data class HomeState(
    val loading: Boolean = true,
    val needsYou: List<ReminderEntity> = emptyList(),
    val today: List<ReminderEntity> = emptyList(),
    val later: List<ReminderEntity> = emptyList(),
    val resolvedToday: Int = 0,
    val dueToday: Int = 0,
    val habits: List<HabitChip> = emptyList(),
    val unreadSignals: Int = 0,
) {
    val hero: ReminderEntity? get() = needsYou.firstOrNull() ?: today.firstOrNull() ?: later.firstOrNull()
    val taskProgress: Float get() = if (dueToday == 0) 0f else resolvedToday.toFloat() / dueToday
    val habitProgress: Float get() = if (habits.isEmpty()) 0f else habits.map { it.progress }.average().toFloat()
}

@OptIn(ExperimentalCoroutinesApi::class)
class HomeViewModel(private val c: AppContainer) : ViewModel() {

    private val zone get() = ZoneId.systemDefault()
    private val todayStart = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    private val todayEnd = LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    private val todayEpoch = LocalDate.now().toEpochDay()

    val state: StateFlow<HomeState> = combine(
        c.db.reminders().observeActive(),
        c.db.events().observeSince(todayStart),
        c.db.habits().observeHabits(),
        c.db.habits().observeLogs(todayEpoch, todayEpoch),
        c.db.signals().observeUnread(),
    ) { reminders, events, habits, logs, unread ->
        val pending = reminders.filter { it.status == ReminderStatus.PENDING }
            .sortedWith(compareByDescending<ReminderEntity> { it.important }.thenBy { it.pendingOccurrenceAt ?: Long.MAX_VALUE })
        val scheduled = reminders.filter { it.status == ReminderStatus.SCHEDULED && it.nextOccurrenceAt != null }
            .sortedBy { it.nextOccurrenceAt }
        val today = scheduled.filter { (it.nextOccurrenceAt ?: 0) < todayEnd }
        val later = scheduled.filter { (it.nextOccurrenceAt ?: 0) >= todayEnd }.take(6)
        val resolved = events.count { it.type == EventType.COMPLETED || it.type == EventType.SKIPPED }
        val logMap = logs.associate { it.habitId to it.count }
        HomeState(
            loading = false,
            needsYou = pending,
            today = today,
            later = later,
            resolvedToday = resolved,
            dueToday = resolved + pending.size + today.size,
            habits = habits.map { HabitChip(it, logMap[it.id] ?: 0) },
            unreadSignals = unread,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun complete(id: Long) = viewModelScope.launch { c.reminderEngine.complete(id) }
    fun skip(id: Long) = viewModelScope.launch { c.reminderEngine.skip(id) }
    fun snooze(id: Long, minutes: Int) = viewModelScope.launch { c.reminderEngine.snooze(id, minutes) }
    fun habitPlus(id: Long) = viewModelScope.launch { c.habitEngine.add(id, 1) }
}
