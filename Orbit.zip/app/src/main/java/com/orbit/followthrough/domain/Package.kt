package com.orbit.followthrough.domain

import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * The router's data package. The admin presses "new package" when it is renewed; the package then
 * runs one month from that exact moment. Usage is counted from the press, to the hour (and the
 * pressed hour is split by time), so nothing used before the press slips in.
 */
object Package {

    fun endOf(start: Long, zone: ZoneId = ZoneId.systemDefault()): Long =
        Instant.ofEpochMilli(start).atZone(zone).plusMonths(1).toInstant().toEpochMilli()

    /** Whole days left, counted on the wall clock (daylight-saving changes don't add a day). */
    fun daysLeft(start: Long, now: Long, zone: ZoneId = ZoneId.systemDefault()): Int {
        val end = Instant.ofEpochMilli(start).atZone(zone).toLocalDateTime().plusMonths(1)
        val cur = Instant.ofEpochMilli(now).atZone(zone).toLocalDateTime()
        if (!cur.isBefore(end)) return 0
        val minutes = java.time.Duration.between(cur, end).toMinutes()
        return ((minutes + 24 * 60 - 1) / (24 * 60)).toInt()
    }

    private fun hourKeyStart(key: String, zone: ZoneId): Long? =
        runCatching { LocalDateTime.parse("$key:00").atZone(zone).toInstant().toEpochMilli() }.getOrNull()

    /**
     * Usage since [start]. Uses hourly records when they reach back far enough; otherwise daily
     * records (the first day then counts only the part after the press, by time).
     * @return usage and whether it is exact (hourly) or estimated (daily).
     */
    fun usageSince(start: Long, hours: Map<String, Bytes>, days: Map<String, Bytes>, zone: ZoneId = ZoneId.systemDefault()): Pair<Bytes, Boolean> {
        val startHour = Meter.hourStart(start, zone)
        val hourStarts = hours.keys.mapNotNull { hourKeyStart(it, zone) }
        val oldest = hourStarts.minOrNull()
        val startDay = Instant.ofEpochMilli(start).atZone(zone).toLocalDate()
        // Hourly records are complete if they reach back to the press, or to the very first day anything was recorded.
        val firstDay = days.keys.mapNotNull { runCatching { LocalDate.parse(it) }.getOrNull() }.minOrNull()
        val hoursCover = oldest != null && (
            oldest <= startHour ||
                (firstDay != null && !Instant.ofEpochMilli(oldest).atZone(zone).toLocalDate().isAfter(firstDay))
            )
        if (hoursCover) {
            var total = Bytes.ZERO
            for ((k, v) in hours) {
                val h = hourKeyStart(k, zone) ?: continue
                when {
                    h > startHour -> total += v
                    h == startHour -> {
                        val f = 1.0 - (start - startHour) / 3_600_000.0
                        total += Bytes((v.rx * f).toLong(), (v.tx * f).toLong())
                    }
                }
            }
            return total to true
        }
        var total = Bytes.ZERO
        val dayStart = startDay.atStartOfDay(zone).toInstant().toEpochMilli()
        val dayLen = startDay.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli() - dayStart
        for ((k, v) in days) {
            val d = runCatching { LocalDate.parse(k) }.getOrNull() ?: continue
            when {
                d.isAfter(startDay) -> total += v
                d == startDay -> {
                    val f = 1.0 - (start - dayStart).toDouble() / dayLen
                    total += Bytes((v.rx * f).toLong(), (v.tx * f).toLong())
                }
            }
        }
        return total to false
    }
}
