package com.orbit.followthrough.watch

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.OrbitApp
import com.orbit.followthrough.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

/** One pass over everything that is "watched": price alerts, wallets, followed accounts, new LAN devices. */
object WatchRunner {
    private var lastAccounts = 0L
    private var lastLan = 0L

    suspend fun runOnce(c: AppContainer, live: Boolean): String {
        val s = c.settings.current()
        var walletsNew = 0
        runCatching { if (c.db.market().count() > 0) c.market.refreshPrices() }
        runCatching { walletsNew = c.wallets.checkAll() }
        val now = System.currentTimeMillis()
        // Account feeds change less often; respect the sources (every 3 min live, every run otherwise).
        if (!live || now - lastAccounts > 3 * 60_000) {
            lastAccounts = now
            runCatching { c.signals.syncAll(onlyAccounts = live) }
        }
        if (s.watchNewDevices && now - lastLan > 30 * 60_000) {
            lastLan = now
            runCatching { c.network.scanLan(notifyNew = true) }
        }
        return c.app.getString(R.string.live_summary, c.db.wallets().enabledCount(), walletsNew)
    }

    /** Schedules / cancels background work to match what the user is watching. */
    suspend fun reschedule(c: AppContainer) {
        val s = c.settings.current()
        val needed = c.db.wallets().enabledCount() > 0 || c.db.market().alertCount() > 0 || s.watchNewDevices
        val wm = WorkManager.getInstance(c.app)
        if (!needed && !s.liveMode) {
            wm.cancelUniqueWork(WatchWorker.NAME)
        } else {
            val req = PeriodicWorkRequestBuilder<WatchWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(WatchWorker.NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        }
        if (s.liveMode) LiveWatchService.start(c.app) else LiveWatchService.stop(c.app)
    }
}

/** Battery-friendly fallback: every 15 minutes (Android's minimum for periodic work). */
class WatchWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    companion object { const val NAME = "orbit_watch" }

    override suspend fun doWork(): Result {
        val c = (applicationContext as OrbitApp).container
        if (c.settings.current().liveMode) return Result.success() // the live service already covers it
        WatchRunner.runOnce(c, live = false)
        return Result.success()
    }
}

/**
 * Live mode: near-real-time checks every 60 s while the user explicitly keeps it on.
 * Android requires a visible ongoing notification for this; the user can stop it any time.
 */
class LiveWatchService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null

    companion object {
        private const val ID = 800_100
        fun start(context: Context) {
            runCatching { ContextCompat.startForegroundService(context, Intent(context, LiveWatchService::class.java)) }
        }
        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, LiveWatchService::class.java)) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val c = (application as OrbitApp).container
        val notification = c.notifier.liveNotification(com.orbit.followthrough.data.prefs.AppSettings(), getString(R.string.live_starting))
        try {
            ServiceCompat.startForeground(
                this, ID, notification,
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
            )
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (loop?.isActive != true) {
            loop = scope.launch {
                while (isActive) {
                    val s = c.settings.current()
                    if (!s.liveMode) { stopSelf(); break }
                    val summary = runCatching { WatchRunner.runOnce(c, live = true) }.getOrDefault(getString(R.string.live_starting))
                    runCatching {
                        androidx.core.app.NotificationManagerCompat.from(this@LiveWatchService).notify(ID, c.notifier.liveNotification(s, summary))
                    }
                    delay(60_000)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
