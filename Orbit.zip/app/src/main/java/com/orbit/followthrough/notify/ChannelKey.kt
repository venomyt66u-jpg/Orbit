package com.orbit.followthrough.notify

import android.app.NotificationManager
import androidx.annotation.StringRes
import com.orbit.followthrough.R

/**
 * Notification categories. Each one has its own Android channel, sound and vibration identity.
 * Users can still override everything from Android's system settings – we never fight that.
 */
enum class ChannelKey(
    val id: String,
    @StringRes val nameRes: Int,
    @StringRes val descRes: Int,
    val importance: Int,
    val defaultSound: String,
    val defaultVibe: VibePattern,
    val userConfigurable: Boolean = true,
) {
    REMINDER("reminders", R.string.channel_reminders, R.string.channel_reminders_desc, NotificationManager.IMPORTANCE_HIGH, "raw:ping_bright", VibePattern.DOUBLE),
    URGENT("urgent", R.string.channel_urgent, R.string.channel_urgent_desc, NotificationManager.IMPORTANCE_HIGH, "raw:pulse_alert", VibePattern.HEARTBEAT),
    HABIT("habits", R.string.channel_habits, R.string.channel_habits_desc, NotificationManager.IMPORTANCE_DEFAULT, "raw:chime_soft", VibePattern.GENTLE),
    SIGNAL_ALERT("signals_alert", R.string.channel_signal_alert, R.string.channel_signal_alert_desc, NotificationManager.IMPORTANCE_DEFAULT, "raw:droplet", VibePattern.NONE),
    SIGNAL_QUIET("signals_quiet", R.string.channel_signal_quiet, R.string.channel_signal_quiet_desc, NotificationManager.IMPORTANCE_LOW, "silent", VibePattern.NONE, userConfigurable = false),
    ASSISTANT("assistant", R.string.channel_assistant, R.string.channel_assistant_desc, NotificationManager.IMPORTANCE_DEFAULT, "raw:crystal", VibePattern.GENTLE),
    WALLET("wallets", R.string.channel_wallets, R.string.channel_wallets_desc, NotificationManager.IMPORTANCE_HIGH, "raw:orbit_glide", VibePattern.RIPPLE),
    MARKET("market", R.string.channel_market, R.string.channel_market_desc, NotificationManager.IMPORTANCE_HIGH, "raw:bell_warm", VibePattern.DOUBLE),
    SOCIAL("social", R.string.channel_social, R.string.channel_social_desc, NotificationManager.IMPORTANCE_DEFAULT, "raw:droplet", VibePattern.GENTLE),
    NETWORK("network", R.string.channel_network, R.string.channel_network_desc, NotificationManager.IMPORTANCE_DEFAULT, "raw:crystal", VibePattern.GENTLE),
    LIVE("live", R.string.channel_live, R.string.channel_live_desc, NotificationManager.IMPORTANCE_LOW, "silent", VibePattern.NONE, userConfigurable = false),
    QUIET("quiet", R.string.channel_quiet, R.string.channel_quiet_desc, NotificationManager.IMPORTANCE_LOW, "silent", VibePattern.NONE, userConfigurable = false),
}

enum class VibePattern(@StringRes val nameRes: Int, val pattern: LongArray) {
    NONE(R.string.vibe_none, longArrayOf()),
    GENTLE(R.string.vibe_gentle, longArrayOf(0, 120)),
    DOUBLE(R.string.vibe_double, longArrayOf(0, 90, 120, 90)),
    HEARTBEAT(R.string.vibe_heartbeat, longArrayOf(0, 60, 100, 140, 420, 60, 100, 140)),
    RIPPLE(R.string.vibe_ripple, longArrayOf(0, 40, 60, 40, 60, 40, 60, 160)),
    LONG(R.string.vibe_long, longArrayOf(0, 450)),
}
