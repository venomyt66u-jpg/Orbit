package com.orbit.followthrough.ui.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.ui.components.CardShape
import com.orbit.followthrough.ui.components.EmptyState
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitHero
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.ProgressRing
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.navigateTopLevel
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.reminder.LaterSheet
import com.orbit.followthrough.ui.reminder.ReminderRow
import com.orbit.followthrough.ui.reminder.categoryIcon
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import com.orbit.followthrough.domain.HabitKind
import kotlinx.coroutines.delay
import java.time.LocalTime

const val BOTTOM_SPACE = 120

@Composable
fun HomeScreen(nav: NavHostController) {
    val vm = orbitViewModel { HomeViewModel(it) }
    val state by vm.state.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = System.currentTimeMillis() } }
    var laterFor by remember { mutableStateOf<ReminderEntity?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = BOTTOM_SPACE.dp),
        ) {
            item { Greeting(state, onAi = { nav.navigate(Routes.ASSISTANT) }) }
            item { MarketStrip(onOpen = { nav.navigateTopLevel(Routes.MARKET) }) }
            item {
                AnimatedContent(targetState = state.hero?.id, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "hero") { heroId ->
                    val hero = (state.needsYou + state.today + state.later).firstOrNull { it.id == heroId }
                    if (hero == null) {
                        if (!state.loading) ClearOrbit(onAdd = { nav.navigate(Routes.editor()) }, onAssistant = { nav.navigateTopLevel(Routes.ASSISTANT) })
                        else Spacer(Modifier.height(220.dp))
                    } else {
                        HeroCard(
                            r = hero,
                            now = now,
                            onDone = { vm.complete(hero.id) },
                            onLater = { laterFor = hero },
                            onSkip = { vm.skip(hero.id) },
                            onOpen = { nav.navigate(Routes.editor(hero.id)) },
                        )
                    }
                }
            }

            val restPending = state.needsYou.drop(if (state.hero?.status == ReminderStatus.PENDING) 1 else 0)
            if (restPending.isNotEmpty()) {
                item { SectionHeader(stringResource(R.string.needs_you), Modifier.padding(top = 18.dp)) }
                items(restPending, key = { "p${it.id}" }) { r ->
                    ReminderRow(r, onOpen = { nav.navigate(Routes.editor(r.id)) }, onDone = { vm.complete(r.id) }, onLater = { laterFor = r }, now = now)
                }
            }

            val heroScheduled = if (state.hero?.status == ReminderStatus.SCHEDULED) state.hero?.id else null
            val todayRest = state.today.filter { it.id != heroScheduled }
            if (todayRest.isNotEmpty()) {
                item { SectionHeader(stringResource(R.string.today_timeline), Modifier.padding(top = 18.dp)) }
                items(todayRest, key = { "t${it.id}" }) { r ->
                    TimelineItem(r, isLast = r == todayRest.last(), now = now, onOpen = { nav.navigate(Routes.editor(r.id)) })
                }
            }

            if (state.habits.isNotEmpty()) {
                item {
                    Column {
                        SectionHeader(stringResource(R.string.habits_today), Modifier.padding(top = 18.dp), action = stringResource(R.string.open), onAction = { nav.navigateTopLevel(Routes.HABITS) })
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(state.habits, key = { it.habit.id }) { h ->
                                HabitMini(h, onClick = {
                                    if (h.habit.kind == HabitKind.TASBIH) nav.navigate(Routes.tasbih(h.habit.id)) else vm.habitPlus(h.habit.id)
                                })
                            }
                        }
                    }
                }
            }

            val laterList = state.later.filter { it.id != heroScheduled }
            if (laterList.isNotEmpty()) {
                item { SectionHeader(stringResource(R.string.coming_up), Modifier.padding(top = 18.dp), action = stringResource(R.string.see_all), onAction = { nav.navigate(Routes.REMINDERS) }) }
                items(laterList, key = { "l${it.id}" }) { r -> ReminderRow(r, onOpen = { nav.navigate(Routes.editor(r.id)) }, now = now) }
            }

            if (state.unreadSignals > 0) {
                item {
                    GlassCard(Modifier.padding(top = 18.dp), onClick = { nav.navigateTopLevel(Routes.SIGNALS) }, padding = PaddingValues(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(OrbitIcons.Signal, null, tint = c.violet, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(ctx.resources.getQuantityString(R.plurals.signals_unread, state.unreadSignals, state.unreadSignals), style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f))
                            Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        // Floating "new reminder" action
        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 22.dp, bottom = 96.dp)
                .size(60.dp)
                .clip(CircleShape)
                .background(c.auroraBrush)
                .pressable({ nav.navigate(Routes.editor()) })
                .semantics { contentDescription = ctx.getString(R.string.new_reminder) },
            contentAlignment = Alignment.Center,
        ) { Icon(OrbitIcons.Plus, null, tint = c.onAccent, modifier = Modifier.size(28.dp)) }
    }

    laterFor?.let { r ->
        LaterSheet(r.title, onPick = { m -> vm.snooze(r.id, m); laterFor = null }, onDismiss = { laterFor = null })
    }
}

@Composable
private fun Greeting(state: HomeState, onAi: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val hour = LocalTime.now().hour
    val greet = stringResource(
        when (hour) {
            in 5..11 -> R.string.greeting_morning
            in 12..16 -> R.string.greeting_afternoon
            in 17..21 -> R.string.greeting_evening
            else -> R.string.greeting_night
        }
    )
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, bottom = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(Fmt.dayLabel(ctx, java.time.LocalDate.now()) + " · " + java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("d MMMM", ctx.resources.configuration.locales[0])), style = OrbitType.label, color = c.textSecondary)
            Text(greet, style = OrbitType.headline, color = c.text)
        }
        Box(
            Modifier.size(52.dp).clip(CircleShape).pressable(onAi)
                .semantics { contentDescription = ctx.getString(R.string.tab_assistant) },
            contentAlignment = Alignment.Center,
        ) { com.orbit.followthrough.ui.components.AiEmblem(size = 52.dp) }
        Spacer(Modifier.width(10.dp))
        // Today at a glance: tasks (outer) + habits (inner)
        Box(contentAlignment = Alignment.Center, modifier = Modifier.semantics {
            contentDescription = ctx.getString(R.string.progress_cd, state.resolvedToday, state.dueToday)
        }) {
            ProgressRing(state.taskProgress, size = 58.dp, stroke = 5.dp)
            ProgressRing(state.habitProgress, size = 38.dp, stroke = 4.dp, colors = listOf(c.green, c.cyan), glow = false)
        }
    }
}

@Composable
private fun HeroCard(r: ReminderEntity, now: Long, onDone: () -> Unit, onLater: () -> Unit, onSkip: () -> Unit, onOpen: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val pending = r.status == ReminderStatus.PENDING
    val accent = if (pending) c.amber else c.category(r.category)
    val target = if (pending) (r.pendingOccurrenceAt ?: now) else (r.nextOccurrenceAt ?: now)
    val window = 12 * 60 * 60_000f
    val progress = if (pending) 1f else (1f - ((target - now) / window)).coerceIn(0.04f, 1f)

    GlassCard(highlight = accent, padding = PaddingValues(20.dp), onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                OrbitHero(progress, accent, size = 118.dp, urgent = pending)
                Icon(categoryIcon(r.category), null, tint = accent, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(if (pending) R.string.needs_you else R.string.next_up).uppercase(),
                    style = OrbitType.overline, color = accent,
                )
                Spacer(Modifier.height(6.dp))
                Text(r.title, style = OrbitType.title, color = c.text, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (pending) stringResource(R.string.waiting_since, Fmt.time(ctx, target))
                    else Fmt.dayAndTime(ctx, target),
                    style = OrbitType.label, color = c.textSecondary,
                )
                if (!pending) Text(Fmt.countdown(ctx, target, now), style = OrbitType.numericSmall, color = accent)
                if (pending && r.followUpAt != null) {
                    Text(stringResource(R.string.returns_at, Fmt.time(ctx, r.followUpAt)), style = OrbitType.caption, color = c.textMuted)
                }
            }
        }
        if (r.note.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(r.note, style = OrbitType.body, color = c.textSecondary, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        if (pending) {
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                PrimaryButton(stringResource(R.string.action_done), onDone, Modifier.weight(1f), icon = OrbitIcons.Check)
                SecondaryButton(stringResource(R.string.action_later), onLater, icon = OrbitIcons.Later)
                IconCircle(OrbitIcons.Skip, stringResource(R.string.action_skip), onSkip, size = 48.dp, tint = c.textSecondary)
            }
        } else if (r.important) {
            Spacer(Modifier.height(12.dp))
            Tag(stringResource(R.string.important), c.amber, icon = OrbitIcons.Flag)
        }
    }
}

@Composable
private fun TimelineItem(r: ReminderEntity, isLast: Boolean, now: Long, onOpen: () -> Unit) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val color = c.category(r.category)
    val at = r.nextOccurrenceAt ?: return
    Row(Modifier.fillMaxWidth().pressable(onOpen)) {
        Text(Fmt.time(ctx, at), style = OrbitType.numericSmall, color = c.textSecondary, modifier = Modifier.width(76.dp).padding(top = 12.dp))
        Box(Modifier.width(24.dp).height(64.dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val x = size.width / 2
                if (!isLast) drawLine(c.stroke, Offset(x, 26.dp.toPx()), Offset(x, size.height), strokeWidth = 2.dp.toPx())
                drawCircle(color.copy(alpha = 0.25f), 9.dp.toPx(), Offset(x, 20.dp.toPx()))
                drawCircle(color, 4.5.dp.toPx(), Offset(x, 20.dp.toPx()))
            }
        }
        Column(Modifier.weight(1f).padding(start = 8.dp, top = 9.dp)) {
            Text(r.title, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(Fmt.countdown(ctx, at, now) + (if (r.isRecurringSafe()) " · " + Fmt.schedule(ctx, r).substringBefore(" · ") else ""), style = OrbitType.caption, color = c.textMuted, maxLines = 1)
        }
    }
}

private fun ReminderEntity.isRecurringSafe() = repeatType != com.orbit.followthrough.domain.RepeatType.ONCE

@Composable
private fun HabitMini(h: HabitChip, onClick: () -> Unit) {
    val c = Orbit.colors
    val color = c.habit(h.habit.colorIndex)
    Column(
        Modifier
            .width(88.dp)
            .clip(CardShape)
            .background(c.surface.copy(alpha = 0.7f))
            .border(1.dp, c.stroke, CardShape)
            .pressable(onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        ProgressRing(h.progress, size = 50.dp, stroke = 4.dp, colors = listOf(color, color.copy(alpha = 0.6f))) {
            Icon(com.orbit.followthrough.ui.components.OrbitIcons.habit(h.habit.glyph), null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text(h.habit.name, style = OrbitType.caption, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${h.count}/${h.habit.target}", style = OrbitType.caption, color = c.textMuted)
    }
}

@Composable
private fun ClearOrbit(onAdd: () -> Unit, onAssistant: () -> Unit) {
    val c = Orbit.colors
    GlassCard(padding = PaddingValues(22.dp)) {
        EmptyState(
            title = stringResource(R.string.clear_orbit_title),
            body = stringResource(R.string.clear_orbit_body),
            art = { OrbitHero(0.35f, c.cyan, size = 120.dp) },
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PrimaryButton(stringResource(R.string.new_reminder), onAdd, Modifier.weight(1f), icon = OrbitIcons.Plus)
            SecondaryButton(stringResource(R.string.ask_assistant), onAssistant, icon = OrbitIcons.Assistant)
        }
    }
}

/** Compact live ticker of the first watch-listed coins. */
@Composable
private fun MarketStrip(onOpen: () -> Unit) {
    val container = com.orbit.followthrough.ui.nav.LocalAppContainer.current
    val flow = remember { container.db.market().observeCoins() }
    val coins by flow.collectAsStateWithLifecycle(initialValue = emptyList())
    val c = Orbit.colors
    val shown = coins.filter { it.price != null }.take(3)
    if (shown.isEmpty()) return
    Row(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(com.orbit.followthrough.ui.components.PillShape)
            .background(c.surface.copy(alpha = 0.6f)).pressable(onOpen).padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        shown.forEach { coin ->
            val up = (coin.change24h ?: 0.0) >= 0
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(coin.symbol, style = OrbitType.label, color = c.textSecondary)
                Spacer(Modifier.width(6.dp))
                Text(com.orbit.followthrough.domain.Numbers.price(coin.price ?: 0.0), style = OrbitType.numericSmall, color = c.text)
                Spacer(Modifier.width(4.dp))
                Text(coin.change24h?.let { com.orbit.followthrough.domain.Numbers.percent(it) } ?: "", style = OrbitType.caption, color = if (up) c.green else c.rose)
            }
        }
    }
}
