package com.orbit.followthrough.ui

import android.net.TrafficStats
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.meter.MeterService
import com.orbit.followthrough.meter.Recorder
import com.orbit.followthrough.meter.WifiNow
import com.orbit.followthrough.meter.WifiProbe
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.ProgressRing
import com.orbit.followthrough.ui.components.SecondaryButton
import com.orbit.followthrough.ui.components.ScreenHeader
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.LocalTime

/** Live Wi‑Fi speed for the UI only (bytes/s). */
data class LiveRate(val down: Long, val up: Long)

@Composable
fun rememberLive(): Pair<WifiNow, LiveRate> {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(WifiProbe.read(ctx)) }
    var rate by remember { mutableStateOf(LiveRate(0, 0)) }
    LaunchedEffect(Unit) {
        var lastRx = -1L
        var lastTx = -1L
        var lastT = 0L
        var n = 0
        while (true) {
            val rx = TrafficStats.getTotalRxBytes() - TrafficStats.getMobileRxBytes().coerceAtLeast(0)
            val tx = TrafficStats.getTotalTxBytes() - TrafficStats.getMobileTxBytes().coerceAtLeast(0)
            val t = System.currentTimeMillis()
            if (lastRx >= 0 && t > lastT) {
                val dt = (t - lastT) / 1000.0
                rate = LiveRate(((rx - lastRx).coerceAtLeast(0) / dt).toLong(), ((tx - lastTx).coerceAtLeast(0) / dt).toLong())
            }
            lastRx = rx; lastTx = tx; lastT = t
            // Book usage every few seconds so the numbers move while the screen is open.
            if (n % 5 == 0) now = withContext(Dispatchers.IO) { runCatching { Recorder.sample(ctx) }.getOrElse { WifiProbe.read(ctx) } }
            n++
            delay(1000)
        }
    }
    return now to rate
}

@Composable
fun MemberScreen(profile: Profile, slot: String, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    val person = personOf(slot) ?: People.first()
    val version by DataVersion.flow.collectAsState()
    val (now, rate) = rememberLive()
    val days = remember(version) { UsageStore(ctx).days() }
    val today = LocalDate.now()
    val lastSync = remember(version) { profile.lastSync }

    LaunchedEffect(Unit) {
        MeterService.start(ctx)
        SyncEngine.sync(ctx, onTarget = now.onTarget)
    }

    val todayBytes = Days.sum(days, today, today.plusDays(1)).total
    val (wf, wt) = Days.range(Period.WEEK, today)
    val (mf, mt) = Days.range(Period.CYCLE, today)
    val week = Days.sum(days, wf, wt).total
    val month = Days.sum(days, mf, mt).total
    val yesterday = Days.sum(days, today.minusDays(1), today).total
    val dayFraction = LocalTime.now().toSecondOfDay() / 86_400f

    val nameHidden = now.onWifi && now.ssid == null
    val needsFix = !WifiProbe.hasLocation(ctx) || !WifiProbe.hasBackgroundLocation(ctx) || !WifiProbe.locationServicesOn(ctx) || nameHidden

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        ScreenHeader(title = "أهلاً ${person.name}", subtitle = "عداد شبكة ${Config.TARGET_SSID}") {
            IconCircle(OrbitIcons.Settings, "الأذونات", onSettings)
            Spacer(Modifier.width(10.dp))
            Avatar(person, 48.dp)
        }
        Spacer(Modifier.height(10.dp))

        if (needsFix) {
            NoticeCard(
                OrbitIcons.Info,
                if (nameHidden) "مش قادر أعرف اسم الشبكة" else "العد ممكن يقف",
                "محتاج إذن الموقع «طول الوقت» وزرار الموقع شغال، علشان أعرف إنك على ${Config.TARGET_SSID}.",
                c.amber,
                action = { SecondaryButton("ظبط الأذونات", onSettings, tint = c.amber) },
            )
            Spacer(Modifier.height(14.dp))
        }

        // Hero: today's usage on the target network.
        GlassCard(Modifier.fillMaxWidth(), highlight = if (now.onTarget) c.green else null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ConnectionPill(now)
                Spacer(Modifier.weight(1f))
                if (now.onTarget) {
                    Text("↓ " + Fmt.rate(rate.down) + "   ↑ " + Fmt.rate(rate.up), style = OrbitType.caption.copy(fontFeatureSettings = "tnum"), color = c.textSecondary)
                }
            }
            Spacer(Modifier.height(18.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                ProgressRing(
                    progress = dayFraction,
                    size = 220.dp,
                    stroke = 10.dp,
                    colors = listOf(person.accent, c.cyan),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("النهارده", style = OrbitType.label, color = c.textSecondary)
                        BigBytes(todayBytes)
                        Text("الدايرة = اليوم بيعدي", style = OrbitType.caption, color = c.textMuted, textAlign = TextAlign.Center)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("امبارح", yesterday, c.violet, Modifier.weight(1f))
                StatTile("آخر ٧ أيام", week, c.cyan, Modifier.weight(1f))
                StatTile("الشهر ده", month, person.accent, Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(14.dp))

        MonthChart(Days.monthSeries(days, today), today, person.accent)
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(OrbitIcons.Shield, null, tint = c.textMuted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                "بيتحسب استهلاك الموبايل ده بس وهو على شبكة ${Config.TARGET_SSID}. آخر إرسال للأدمن: ${Ar.ago(lastSync)}",
                style = OrbitType.caption, color = c.textMuted,
            )
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
fun ConnectionPill(now: WifiNow) {
    val c = Orbit.colors
    val color = when {
        now.onTarget -> c.green
        now.onWifi -> c.amber
        else -> c.textMuted
    }
    val text = when {
        now.onTarget -> "متصل بـ ${Config.TARGET_SSID} · بيعد"
        now.onWifi && now.ssid != null -> "على شبكة ${now.ssid} · مش بيعد"
        now.onWifi -> "على واي فاي مش معروف"
        else -> "مش متصل بـ ${Config.TARGET_SSID}"
    }
    val pulse = if (now.onTarget && !Orbit.reducedMotion) {
        val t = rememberInfiniteTransition(label = "pulse")
        val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
        a
    } else 1f
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.12f)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).alpha(pulse).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text(text, style = OrbitType.label, color = color, maxLines = 1)
    }
}
