package com.orbit.followthrough.ui

import android.net.TrafficStats
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.meter.Background
import com.orbit.followthrough.meter.Recorder
import com.orbit.followthrough.meter.WifiNow
import com.orbit.followthrough.meter.WifiProbe
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.YearMonth

/** Live Wi‑Fi speed for the UI only (bytes/s). */
data class LiveRate(val down: Long, val up: Long)

/** While a screen is open: live speed every second, and usage booked every 5 seconds. */
@Composable
fun rememberLive(): Pair<WifiNow, LiveRate> {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(WifiProbe.read(ctx)) }
    var rate by remember { mutableStateOf(LiveRate(0, 0)) }
    LaunchedEffect(Unit) {
        var lastRx = -1L
        var lastTx = -1L
        var lastT = 0L
        var n = 0
        while (true) {
            val rx = TrafficStats.getTotalRxBytes() - TrafficStats.getMobileRxBytes().coerceAtLeast(0)
            val tx = TrafficStats.getTotalTxBytes() - TrafficStats.getMobileTxBytes().coerceAtLeast(0)
            val t = System.currentTimeMillis()
            if (lastRx >= 0 && t > lastT) {
                val dt = (t - lastT) / 1000.0
                rate = LiveRate(((rx - lastRx).coerceAtLeast(0) / dt).toLong(), ((tx - lastTx).coerceAtLeast(0) / dt).toLong())
            }
            lastRx = rx; lastTx = tx; lastT = t
            if (n % 5 == 0) now = withContext(Dispatchers.IO) { runCatching { Recorder.sample(ctx) }.getOrElse { WifiProbe.read(ctx) } }
            n++
            delay(1000)
        }
    }
    return now to rate
}

/** Average of the days with usage in the last 30 days (for "higher than usual"). */
fun dailyAverage(days: Map<String, Bytes>, today: LocalDate): Long {
    val vals = (1..30).mapNotNull { days[today.minusDays(it.toLong()).toString()]?.total?.takeIf { v -> v > 0 } }
    return if (vals.isEmpty()) 0L else vals.sum() / vals.size
}

fun hoursOf(hours: Map<String, Bytes>, date: LocalDate): List<Long> =
    (0 until 24).map { h -> hours[date.toString() + "T" + (if (h < 10) "0" else "") + h]?.total ?: 0L }

@Composable
fun MemberScreen(profile: Profile, slot: String, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    val person = personOf(slot) ?: People.first()
    val version by DataVersion.flow.collectAsState()
    val (now, rate) = rememberLive()
    val store = remember { UsageStore(ctx) }
    val days = remember(version) { store.days() }
    val hours = remember(version) { store.hours() }
    val past = remember(version) { store.past() }
    val known = remember(version) { store.knownNetworks() }
    val lastSync = remember(version) { profile.lastSync }
    val today = LocalDate.now()
    var month by rememberSaveable { mutableStateOf(YearMonth.from(today)) }
    var selected by rememberSaveable { mutableStateOf(today) }

    LaunchedEffect(Unit) {
        runCatching { Background.schedule(ctx) }
        withContext(Dispatchers.IO) { com.orbit.followthrough.meter.NetHistory.importIfDue(ctx) }
        SyncEngine.sync(ctx, onTarget = now.onTarget)
    }

    val todayBytes = Days.sum(days, today, today.plusDays(1)).total
    val (wf, wt) = Days.range(Period.WEEK, today)
    val (mf, mt) = Days.range(Period.CYCLE, today)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Header(title = "أهلاً ${person.name}", subtitle = "عداد شبكة ${Config.TARGET_SSID}", person = person, onSettings = onSettings)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.enter(1)) { ConnectionPill(now, known.isNotEmpty(), onSettings) }
        Spacer(Modifier.height(6.dp))

        // Hero
        Box(Modifier.fillMaxWidth().enter(2), contentAlignment = Alignment.Center) {
            LiveOrb(active = now.onTarget, bytesPerSec = rate.down + rate.up, accent = person.accent) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("النهارده", style = OrbitType.label, color = c.textSecondary)
                    AnimatedBytes(todayBytes, big = false)
                    AnimatedContent(
                        targetState = now.onTarget,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "speed",
                    ) { on ->
                        if (on) Text("↓ ${Fmt.rate(rate.down)}  ↑ ${Fmt.rate(rate.up)}", style = OrbitType.caption.copy(fontFeatureSettings = "tnum"), color = c.textSecondary)
                        else Text("مش بيعد دلوقتي", style = OrbitType.caption, color = c.textMuted)
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.enter(3)) {
            StatTile("امبارح", Days.sum(days, today.minusDays(1), today).total, c.violet, Modifier.weight(1f))
            StatTile("آخر ٧ أيام", Days.sum(days, wf, wt).total, c.cyan, Modifier.weight(1f))
            StatTile("الشهر ده", Days.sum(days, mf, mt).total, person.accent, Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))

        UsageCalendar(
            month = month,
            days = days,
            selected = selected,
            accent = person.accent,
            onSelect = { selected = it },
            onMonth = { month = it },
            modifier = Modifier.enter(4),
            past = past,
        )
        Spacer(Modifier.height(12.dp))
        AnimatedContent(
            targetState = selected,
            transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
            label = "day",
        ) { d ->
            DayDetail(
                date = d,
                bytes = days[d.toString()] ?: Bytes.ZERO,
                average = dailyAverage(days, today),
                accent = person.accent,
                hours = hoursOf(hours, d),
                past = past[d.toString()],
            )
        }
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(OrbitIcons.Shield, null, tint = c.textMuted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                "بيتحسب استهلاك الموبايل ده بس وهو على ${Config.TARGET_SSID}. آخر إرسال للأدمن: ${Ar.ago(lastSync)}",
                style = OrbitType.caption, color = c.textMuted,
            )
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
fun Header(title: String, subtitle: String, person: Person, onSettings: () -> Unit, trailing: @Composable () -> Unit = {}) {
    val c = Orbit.colors
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(top = 12.dp).enter(0),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(person, 52.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(subtitle, style = OrbitType.label, color = c.textSecondary)
            Text(title, style = OrbitType.headline, color = c.text, maxLines = 1)
        }
        trailing()
        IconCircle(OrbitIcons.Settings, "الإعدادات", onSettings)
    }
}

@Composable
fun ConnectionPill(now: WifiNow, knowsTarget: Boolean, onFix: () -> Unit) {
    val c = Orbit.colors
    val needsSetup = now.onWifi && !now.onTarget && !knowsTarget
    val color = when {
        now.onTarget -> c.green
        needsSetup -> c.amber
        now.onWifi -> c.textSecondary
        else -> c.textMuted
    }
    val text = when {
        now.onTarget -> "متصل بـ${Config.TARGET_SSID} · بيعد"
        needsSetup -> "دوس هنا علشان تعرّف التطبيق على ${Config.TARGET_SSID}"
        now.onWifi && now.name != null -> "على شبكة ${now.name} · مش بيعد"
        now.onWifi -> "على واي فاي تاني · مش بيعد"
        else -> "مش متصل بـ${Config.TARGET_SSID}"
    }
    val pulse = if (now.onTarget && !Orbit.reducedMotion) {
        val t = rememberInfiniteTransition(label = "pulse")
        val a by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
        a
    } else 1f
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.12f))
            .clickable(enabled = needsSetup, onClick = onFix)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).alpha(pulse).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text(text, style = OrbitType.label, color = color, maxLines = 1)
    }
}
