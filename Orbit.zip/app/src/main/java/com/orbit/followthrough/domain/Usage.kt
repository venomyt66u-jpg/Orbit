package com.orbit.followthrough.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import java.util.Locale

enum class ThemeMode { SYSTEM, DARK, LIGHT }

/** CYCLE = calendar month. PACKAGE = since the admin's last "new package" press (handled by [Package]). */
enum class Period { TODAY, WEEK, CYCLE, PACKAGE }

/** Received / sent byte pair. */
data class Bytes(val rx: Long, val tx: Long) {
    val total: Long get() = rx + tx
    operator fun plus(o: Bytes) = Bytes(rx + o.rx, tx + o.tx)

    companion object {
        val ZERO = Bytes(0, 0)
    }
}

/** Wi‑Fi network names as Android reports them ("\"Home\"", "<unknown ssid>", hex). */
object Ssid {
    const val UNKNOWN = "<unknown ssid>"

    /** Returns a clean display name, or null when Android hid the name (no location access). */
    fun clean(raw: String?): String? {
        if (raw == null) return null
        var s = raw.trim()
        if (s.isEmpty() || s.equals(UNKNOWN, ignoreCase = true) || s == "0x") return null
        if (s.length >= 2 && s.startsWith("\"") && s.endsWith("\"")) s = s.substring(1, s.length - 1)
        return s.takeIf { it.isNotBlank() }
    }
}

/**
 * One reading of the phone's traffic counters. Counters are cumulative since boot.
 * [elapsed] is time since boot (detects reboots), [wall] is the clock time of the reading.
 */
data class CounterReading(
    val totalRx: Long,
    val totalTx: Long,
    val mobileRx: Long,
    val mobileTx: Long,
    val elapsed: Long,
    val wall: Long,
)

object Meter {

    /**
     * Wi‑Fi bytes moved between two readings = all traffic minus mobile‑data traffic.
     * Returns null when the counters were reset (reboot), so that interval is not guessed.
     */
    fun wifiDelta(prev: CounterReading, cur: CounterReading): Bytes? {
        if (cur.elapsed < prev.elapsed) return null
        if (cur.totalRx < prev.totalRx || cur.totalTx < prev.totalTx) return null
        val mobileRx = (cur.mobileRx - prev.mobileRx).coerceAtLeast(0)
        val mobileTx = (cur.mobileTx - prev.mobileTx).coerceAtLeast(0)
        val rx = (cur.totalRx - prev.totalRx - mobileRx).coerceAtLeast(0)
        val tx = (cur.totalTx - prev.totalTx - mobileTx).coerceAtLeast(0)
        return Bytes(rx, tx)
    }

    data class HourChunk(val hourStart: Long, val bytes: Bytes)

    /**
     * Spreads bytes moved between [start] and [end] over the clock hours they cover, in proportion
     * to time. Rounding leftovers go to the last hour, so the chunks always add up exactly.
     */
    fun splitByHour(start: Long, end: Long, bytes: Bytes, zone: ZoneId = ZoneId.systemDefault()): List<HourChunk> {
        val from = minOf(start, end)
        val to = maxOf(start, end)
        if (to - from <= 0) return listOf(HourChunk(hourStart(to, zone), bytes))
        val chunks = ArrayList<Pair<Long, Long>>() // hourStart → millis inside the interval
        var cursor = from
        while (cursor < to) {
            val h = hourStart(cursor, zone)
            val next = minOf(nextHour(h, zone), to)
            chunks += h to (next - cursor)
            cursor = next
        }
        val span = (to - from).toDouble()
        var leftRx = bytes.rx
        var leftTx = bytes.tx
        return chunks.mapIndexed { i, (h, ms) ->
            if (i == chunks.lastIndex) HourChunk(h, Bytes(leftRx, leftTx))
            else {
                val rx = (bytes.rx * (ms / span)).toLong()
                val tx = (bytes.tx * (ms / span)).toLong()
                leftRx -= rx; leftTx -= tx
                HourChunk(h, Bytes(rx, tx))
            }
        }
    }

    /** Same as [splitByHour] but grouped per calendar day ("2026-10-28" → bytes). */
    fun splitByDay(start: Long, end: Long, bytes: Bytes, zone: ZoneId = ZoneId.systemDefault()): Map<String, Bytes> {
        val out = LinkedHashMap<String, Bytes>()
        for (c in splitByHour(start, end, bytes, zone)) {
            val day = Instant.ofEpochMilli(c.hourStart).atZone(zone).toLocalDate().toString()
            out[day] = (out[day] ?: Bytes.ZERO) + c.bytes
        }
        return out
    }

    /**
     * Should Wi‑Fi traffic between two readings be counted for [target]? Only if we were on it at the
     * previous reading. Then: still on it → yes; Wi‑Fi off now → yes (no other Wi‑Fi was joined, or
     * joining it would have triggered a reading); on another Wi‑Fi → only if that switch happened
     * recently, otherwise we can't tell where the bytes went and skip them rather than guess.
     */
    fun attribute(prevPlace: String?, curPlace: String?, gapMs: Long, target: String): Boolean {
        if (prevPlace != target) return false
        if (curPlace == target || curPlace == null) return true
        return gapMs <= 20 * 60_000L
    }

    fun hourStart(millis: Long, zone: ZoneId = ZoneId.systemDefault()): Long =
        Instant.ofEpochMilli(millis).atZone(zone).truncatedTo(ChronoUnit.HOURS).toInstant().toEpochMilli()

    private fun nextHour(hourStart: Long, zone: ZoneId): Long =
        Instant.ofEpochMilli(hourStart).atZone(zone).plusHours(1).toInstant().toEpochMilli()
}

/** Billing cycle helpers: a cycle starts on [cycleDay] of each month (clamped to short months). */
object Cycle {

    fun startOn(month: LocalDate, cycleDay: Int): LocalDate {
        val m = month.withDayOfMonth(1)
        return m.withDayOfMonth(cycleDay.coerceIn(1, 31).coerceAtMost(m.lengthOfMonth()))
    }

    /** [start, endExclusive) of the cycle containing [today], shifted by [offset] cycles (‑1 = previous). */
    fun range(today: LocalDate, cycleDay: Int, offset: Int = 0): Pair<LocalDate, LocalDate> {
        val thisMonthStart = startOn(today, cycleDay)
        val current = if (today.isBefore(thisMonthStart)) startOn(today.minusMonths(1), cycleDay) else thisMonthStart
        val start = startOn(current.plusMonths(offset.toLong()), cycleDay)
        val end = startOn(start.plusMonths(1), cycleDay)
        return start to end
    }

    /** Stable key for "already alerted this cycle". */
    fun key(today: LocalDate, cycleDay: Int): String = range(today, cycleDay).first.toString()

    fun periodRange(period: Period, today: LocalDate, cycleDay: Int): Pair<LocalDate, LocalDate> = when (period) {
        Period.TODAY -> today to today.plusDays(1)
        Period.WEEK -> today.minusDays(6) to today.plusDays(1)
        Period.CYCLE, Period.PACKAGE -> range(today, cycleDay)
    }
}

object Fmt {
    /** Bytes → "1.24 GB" / "820 MB" (decimal units, like phone settings). */
    fun bytes(b: Long): String {
        val a = b.coerceAtLeast(0).toDouble()
        return when {
            a >= 1e12 -> String.format(Locale.US, "%.2f TB", a / 1e12)
            a >= 1e9 -> String.format(Locale.US, if (a >= 1e11) "%.0f GB" else if (a >= 1e10) "%.1f GB" else "%.2f GB", a / 1e9)
            a >= 1e6 -> String.format(Locale.US, "%.0f MB", a / 1e6)
            a >= 1e3 -> String.format(Locale.US, "%.0f KB", a / 1e3)
            else -> "${b.coerceAtLeast(0)} B"
        }
    }

    /** Splits "1.24 GB" into number and unit for large typography. */
    fun bytesParts(b: Long): Pair<String, String> {
        val s = bytes(b)
        val i = s.lastIndexOf(' ')
        return if (i > 0) s.substring(0, i) to s.substring(i + 1) else s to ""
    }

    /** Very short form for calendar cells: "1.2G", "850M", "40K", "0". */
    fun compact(b: Long): String {
        val a = b.coerceAtLeast(0).toDouble()
        return when {
            a >= 1e10 -> String.format(Locale.US, "%.0fG", a / 1e9)
            a >= 1e9 -> String.format(Locale.US, "%.1fG", a / 1e9)
            a >= 1e6 -> String.format(Locale.US, "%.0fM", a / 1e6)
            a >= 1e3 -> String.format(Locale.US, "%.0fK", a / 1e3)
            else -> "0"
        }
    }

    /** Bytes per second → "2.4 MB/s". */
    fun rate(bytesPerSec: Long): String = bytes(bytesPerSec) + "/s"

    /** Parses a user-entered GB amount ("50", "2.5", "٥٠") into bytes. */
    fun parseGb(text: String): Long? {
        val normalized = buildString {
            text.trim().forEach { ch ->
                append(
                    when (ch) {
                        in '٠'..'٩' -> '0' + (ch - '٠')
                        in '۰'..'۹' -> '0' + (ch - '۰')
                        '٫', ',' -> '.'
                        else -> ch
                    }
                )
            }
        }
        val v = normalized.toDoubleOrNull() ?: return null
        if (v <= 0 || v > 100_000) return null
        return (v * 1e9).toLong()
    }

    fun gbInput(bytes: Long): String {
        val gb = bytes / 1e9
        return if (gb == Math.floor(gb)) gb.toLong().toString() else String.format(Locale.US, "%.1f", gb)
    }
}
