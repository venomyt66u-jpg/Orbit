package com.orbit.followthrough.ui.signals

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.SignalSourceEntity
import com.orbit.followthrough.domain.NotifyMode
import com.orbit.followthrough.domain.SourceType
import com.orbit.followthrough.domain.SyncStatus
import com.orbit.followthrough.ui.components.Divider
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitSwitch
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.StatusDot
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import kotlinx.coroutines.launch

private data class Suggestion(val name: String, val type: SourceType, val target: String)

private val suggestions = listOf(
    Suggestion("Android Developers Blog", SourceType.RSS, "https://android-developers.googleblog.com/feeds/posts/default"),
    Suggestion("Kotlin releases", SourceType.GITHUB, "JetBrains/kotlin"),
    Suggestion("Flutter releases", SourceType.GITHUB, "flutter/flutter"),
    Suggestion("Ethereum Foundation Blog", SourceType.RSS, "https://blog.ethereum.org/feed.xml"),
    Suggestion("Hacker News (front page)", SourceType.RSS, "https://hnrss.org/frontpage"),
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SourcesScreen(nav: NavHostController) {
    val vm = orbitViewModel { SignalsViewModel(it) }
    val sources by vm.sources.collectAsStateWithLifecycle()
    val keywords by vm.keywords.collectAsStateWithLifecycle()
    val c = Orbit.colors
    val scope = rememberCoroutineScope()

    var type by remember { mutableStateOf(SourceType.ACCOUNT) }
    var accountResult by remember { mutableStateOf<String?>(null) }
    var target by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(NotifyMode.IMPORTANT) }
    var error by remember { mutableStateOf<Int?>(null) }
    var adding by remember { mutableStateOf(false) }
    var keyword by remember { mutableStateOf("") }

    fun add(t: SourceType, tgt: String, n: String) {
        if (adding) return
        adding = true
        accountResult = null
        scope.launch {
            if (t == SourceType.ACCOUNT) {
                accountResult = vm.followAccount(tgt, n)
                if (accountResult == null) { target = ""; name = "" }
                adding = false
                return@launch
            }
            error = vm.addSource(t, tgt, n, mode)
            if (error == null) { target = ""; name = "" }
            adding = false
        }
    }

    LazyColumn(Modifier.fillMaxSize().imePadding().padding(horizontal = 20.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
        item { TopBar(stringResource(R.string.sources), { nav.popBackStack() }, stringResource(R.string.back)) }

        // ---- add source ----
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.add_source), style = OrbitType.title, color = c.text)
                Spacer(Modifier.height(12.dp))
                Segmented(
                    listOf(
                        SourceType.ACCOUNT to stringResource(R.string.type_account),
                        SourceType.RSS to stringResource(R.string.type_rss_short),
                        SourceType.GITHUB to stringResource(R.string.type_github_short),
                    ),
                    type, { type = it; error = null; accountResult = null }, Modifier.fillMaxWidth(),
                )
                if (type == SourceType.ACCOUNT) {
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.account_supported), style = OrbitType.caption, color = c.textSecondary)
                }
                Spacer(Modifier.height(12.dp))
                OrbitTextField(
                    target, { target = it; error = null },
                    placeholder = stringResource(
                        when (type) {
                            SourceType.GITHUB -> R.string.github_placeholder
                            SourceType.ACCOUNT -> R.string.account_placeholder
                            SourceType.RSS -> R.string.rss_placeholder
                        }
                    ),
                    leading = when (type) { SourceType.GITHUB -> OrbitIcons.Github; SourceType.ACCOUNT -> OrbitIcons.At; SourceType.RSS -> OrbitIcons.Rss },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(10.dp))
                OrbitTextField(name, { name = it }, placeholder = stringResource(R.string.source_name_optional), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.notify_me), style = OrbitType.caption, color = c.textMuted)
                Spacer(Modifier.height(6.dp))
                Segmented(
                    listOf(NotifyMode.IMPORTANT to stringResource(R.string.notify_important), NotifyMode.ALL to stringResource(R.string.notify_all), NotifyMode.NONE to stringResource(R.string.notify_none)),
                    mode, { mode = it }, Modifier.fillMaxWidth(),
                )
                error?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(it), style = OrbitType.label, color = c.amber)
                }
                accountResult?.let { r ->
                    Spacer(Modifier.height(10.dp))
                    Text(
                        when {
                            r == "invalid" -> stringResource(R.string.error_profile)
                            r == "lookup" -> stringResource(R.string.error_lookup)
                            r.startsWith("unsupported:") -> stringResource(R.string.unsupported_platform, r.substringAfter(':'))
                            else -> r
                        },
                        style = OrbitType.label, color = c.amber,
                    )
                }
                Spacer(Modifier.height(14.dp))
                PrimaryButton(stringResource(if (adding) R.string.connecting else R.string.add_and_sync), { add(type, target, name) }, Modifier.fillMaxWidth(), icon = OrbitIcons.Plus, enabled = target.isNotBlank() && !adding)
            }
        }

        // ---- suggestions ----
        item { SectionHeader(stringResource(R.string.suggested_sources), Modifier.padding(top = 18.dp)) }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val existing = sources.orEmpty().map { it.target }.toSet()
                suggestions.filter { it.target !in existing }.forEach { s ->
                    OrbitChip(s.name, false, { add(s.type, s.target, s.name) }, icon = if (s.type == SourceType.GITHUB) OrbitIcons.Github else OrbitIcons.Rss)
                }
            }
        }

        // ---- connected sources ----
        val list = sources.orEmpty()
        if (list.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.your_sources), Modifier.padding(top = 18.dp)) }
            items(list, key = { it.id }) { s ->
                SourceRow(s, onToggle = { vm.toggleSource(s) }, onMode = { vm.setMode(s, it) }, onSync = { vm.syncOne(s.id) }, onDelete = { vm.deleteSource(s.id) })
            }
        }

        // ---- keywords ----
        item { SectionHeader(stringResource(R.string.keywords), Modifier.padding(top = 18.dp)) }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.keywords_hint), style = OrbitType.label, color = c.textSecondary)
                Spacer(Modifier.height(10.dp))
                OrbitTextField(
                    keyword, { keyword = it }, placeholder = stringResource(R.string.add_keyword),
                    leading = OrbitIcons.Target,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { vm.addKeyword(keyword); keyword = "" }),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (keywords.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        keywords.sorted().forEach { k -> OrbitChip("$k  ✕", true, { vm.removeKeyword(k) }, accent = c.amber) }
                    }
                }
            }
        }

        // ---- honesty / backend note ----
        item {
            GlassCard(Modifier.fillMaxWidth().padding(top = 18.dp).navigationBarsPadding()) {
                Row(verticalAlignment = Alignment.Top) {
                    GlyphBadge(OrbitIcons.Key, c.violet, size = 36.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(R.string.private_sources_title), style = OrbitType.subtitle, color = c.text)
                        Text(stringResource(R.string.private_sources_body), style = OrbitType.caption, color = c.textSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceRow(s: SignalSourceEntity, onToggle: () -> Unit, onMode: (NotifyMode) -> Unit, onSync: () -> Unit, onDelete: () -> Unit) {
    val c = Orbit.colors
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val (statusColor, statusText) = when (s.status) {
        SyncStatus.OK -> c.green to stringResource(R.string.status_ok, s.lastSuccessAt?.let { Fmt.ago(it) } ?: "")
        SyncStatus.ERROR -> c.rose to stringResource(R.string.status_error, s.lastError ?: "?")
        SyncStatus.SYNCING -> c.cyan to stringResource(R.string.status_syncing)
        SyncStatus.NEVER -> c.textMuted to stringResource(R.string.status_never)
    }
    GlassCard(Modifier.fillMaxWidth().padding(bottom = 12.dp), padding = PaddingValues(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlyphBadge(when (s.type) { SourceType.GITHUB -> OrbitIcons.Github; SourceType.ACCOUNT -> OrbitIcons.At; SourceType.RSS -> OrbitIcons.Rss }, if (s.enabled) c.cyan else c.textMuted, size = 38.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.name, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (s.type == SourceType.ACCOUNT) com.orbit.followthrough.signals.Platform.fromFeedUrl(s.target).label else s.target, style = OrbitType.caption, color = c.textMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            OrbitSwitch(s.enabled) { onToggle() }
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(statusColor)
            Spacer(Modifier.width(8.dp))
            Text(statusText, style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.weight(1f), maxLines = 2)
            Text(ctx.resources.getQuantityString(R.plurals.items_count, s.itemCount, s.itemCount), style = OrbitType.caption, color = c.textMuted)
        }
        Spacer(Modifier.height(10.dp))
        Divider()
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Segmented(
                listOf(NotifyMode.IMPORTANT to stringResource(R.string.notify_important), NotifyMode.ALL to stringResource(R.string.notify_all), NotifyMode.NONE to stringResource(R.string.notify_none)),
                s.notifyMode, onMode, Modifier.weight(1f),
            )
            IconCircle(OrbitIcons.Refresh, stringResource(R.string.sync_now), onSync, size = 40.dp, tint = c.cyan)
            IconCircle(OrbitIcons.Trash, stringResource(R.string.delete), onDelete, size = 40.dp, tint = c.rose)
        }
    }
}
