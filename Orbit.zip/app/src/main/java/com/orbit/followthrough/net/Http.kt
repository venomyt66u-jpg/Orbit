package com.orbit.followthrough.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class HttpException(val code: Int, val body: String) : IOException("HTTP $code")

/**
 * Minimal HTTPS client on top of the platform HttpURLConnection (no third-party networking stack).
 * Timeouts, size caps and clear errors; always runs on Dispatchers.IO.
 */
object Http {
    private const val MAX = 3 * 1024 * 1024

    suspend fun get(url: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 15_000): String =
        request("GET", url, headers, null, timeoutMs)

    suspend fun postJson(url: String, json: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 30_000): String =
        request("POST", url, headers + ("Content-Type" to "application/json"), json, timeoutMs)

    private suspend fun request(method: String, url: String, headers: Map<String, String>, body: String?, timeoutMs: Int): String =
        withContext(Dispatchers.IO) {
            require(url.startsWith("https://") || url.startsWith("http://")) { "bad url" }
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Orbit-Android/1.1")
                setRequestProperty("Accept", "application/json, */*;q=0.5")
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
                if (body != null) doOutput = true
            }
            try {
                if (body != null) conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.use { input ->
                    val out = ByteArrayOutputStream()
                    val buf = ByteArray(16 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        if (out.size() > MAX) break
                    }
                    out.toString("UTF-8")
                } ?: ""
                if (code !in 200..299) throw HttpException(code, text.take(400))
                text
            } finally {
                conn.disconnect()
            }
        }

    /** Short, user-presentable reason for a failure. */
    fun reason(e: Throwable): String = when (e) {
        is java.net.UnknownHostException -> "offline"
        is java.net.SocketTimeoutException -> "timeout"
        is HttpException -> when (e.code) {
            401, 403 -> "key rejected (${e.code})"
            429 -> "rate limited"
            else -> "http ${e.code}"
        }
        is org.json.JSONException -> "unexpected response"
        is IOException -> "network"
        else -> e.message?.take(80) ?: e.javaClass.simpleName
    }
}
