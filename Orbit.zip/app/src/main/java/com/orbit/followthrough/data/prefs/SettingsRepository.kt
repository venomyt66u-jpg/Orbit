package com.orbit.followthrough.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.orbit.followthrough.domain.AiTone
import com.orbit.followthrough.domain.NotificationProfile
import com.orbit.followthrough.domain.QuietHours
import com.orbit.followthrough.domain.ThemeMode
import com.orbit.followthrough.notify.ChannelKey
import com.orbit.followthrough.notify.VibePattern
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "orbit_settings")

/** Per-channel sound + vibration choice. Sound id: "raw:<name>", "system", "silent" or "uri:<content uri>". */
data class ChannelStyle(val sound: String, val vibe: VibePattern, val version: Int)

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val onboardingDone: Boolean = false,
    val defaultFollowUpMinutes: Int = 10,
    val defaultMaxFollowUps: Int = 3,
    val quietEnabled: Boolean = false,
    val quietStart: Int = 22 * 60,
    val quietEnd: Int = 7 * 60,
    val importantBypassQuiet: Boolean = true,
    val profile: NotificationProfile = NotificationProfile.NORMAL,
    val aiEnabled: Boolean = true,
    val aiTone: AiTone = AiTone.FRIENDLY,
    val aiCloudEnabled: Boolean = false,
    val aiBackendUrl: String = "",
    val overlayEnabled: Boolean = false,
    val historyEnabled: Boolean = true,
    val streaksEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val signalKeywords: Set<String> = emptySet(),
    val signalSyncHours: Int = 3,
    val weekStartsSaturday: Boolean = false,
    val llmProvider: String = "NONE",
    val llmModel: String = "",
    val liveMode: Boolean = false,
    val watchNewDevices: Boolean = false,
    val routerType: String = "NONE",
    val routerHost: String = "192.168.1.1",
    val routerUser: String = "admin",
    val marketSeeded: Boolean = false,
    val channelStyles: Map<ChannelKey, ChannelStyle> = ChannelKey.entries.associateWith { ChannelStyle(it.defaultSound, it.defaultVibe, 1) },
) {
    val quietHours: QuietHours get() = QuietHours(quietEnabled, quietStart, quietEnd)
    fun style(key: ChannelKey): ChannelStyle = channelStyles[key] ?: ChannelStyle(key.defaultSound, key.defaultVibe, 1)
}

class SettingsRepository(private val context: Context) {

    private object K {
        val theme = stringPreferencesKey("theme")
        val onboarding = booleanPreferencesKey("onboarding_done")
        val followUp = intPreferencesKey("default_follow_up")
        val maxFollowUps = intPreferencesKey("default_max_follow_ups")
        val quietEnabled = booleanPreferencesKey("quiet_enabled")
        val quietStart = intPreferencesKey("quiet_start")
        val quietEnd = intPreferencesKey("quiet_end")
        val bypassQuiet = booleanPreferencesKey("important_bypass_quiet")
        val profile = stringPreferencesKey("profile")
        val aiEnabled = booleanPreferencesKey("ai_enabled")
        val aiTone = stringPreferencesKey("ai_tone")
        val aiCloud = booleanPreferencesKey("ai_cloud")
        val aiBackend = stringPreferencesKey("ai_backend_url")
        val overlay = booleanPreferencesKey("overlay_enabled")
        val history = booleanPreferencesKey("history_enabled")
        val streaks = booleanPreferencesKey("streaks_enabled")
        val haptics = booleanPreferencesKey("haptics_enabled")
        val keywords = stringSetPreferencesKey("signal_keywords")
        val syncHours = intPreferencesKey("signal_sync_hours")
        val weekSat = booleanPreferencesKey("week_starts_saturday")
        val seeded = booleanPreferencesKey("seeded_v1")
        val llmProvider = stringPreferencesKey("llm_provider")
        val llmModel = stringPreferencesKey("llm_model")
        val liveMode = booleanPreferencesKey("live_mode")
        val watchNewDevices = booleanPreferencesKey("watch_new_devices")
        val routerType = stringPreferencesKey("router_type")
        val routerHost = stringPreferencesKey("router_host")
        val routerUser = stringPreferencesKey("router_user")
        val marketSeeded = booleanPreferencesKey("market_seeded")
        fun sound(key: ChannelKey) = stringPreferencesKey("sound_${key.id}")
        fun vibe(key: ChannelKey) = stringPreferencesKey("vibe_${key.id}")
        fun version(key: ChannelKey) = intPreferencesKey("channel_version_${key.id}")
    }

    val settings: Flow<AppSettings> = context.dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p -> read(p) }

    suspend fun current(): AppSettings = settings.first()

    private fun read(p: Preferences): AppSettings = AppSettings(
        themeMode = enumOr(p[K.theme], ThemeMode.SYSTEM),
        onboardingDone = p[K.onboarding] ?: false,
        defaultFollowUpMinutes = p[K.followUp] ?: 10,
        defaultMaxFollowUps = p[K.maxFollowUps] ?: 3,
        quietEnabled = p[K.quietEnabled] ?: false,
        quietStart = p[K.quietStart] ?: (22 * 60),
        quietEnd = p[K.quietEnd] ?: (7 * 60),
        importantBypassQuiet = p[K.bypassQuiet] ?: true,
        profile = enumOr(p[K.profile], NotificationProfile.NORMAL),
        aiEnabled = p[K.aiEnabled] ?: true,
        aiTone = enumOr(p[K.aiTone], AiTone.FRIENDLY),
        aiCloudEnabled = p[K.aiCloud] ?: false,
        aiBackendUrl = p[K.aiBackend] ?: "",
        overlayEnabled = p[K.overlay] ?: false,
        historyEnabled = p[K.history] ?: true,
        streaksEnabled = p[K.streaks] ?: true,
        hapticsEnabled = p[K.haptics] ?: true,
        signalKeywords = p[K.keywords] ?: emptySet(),
        signalSyncHours = p[K.syncHours] ?: 3,
        weekStartsSaturday = p[K.weekSat] ?: false,
        llmProvider = p[K.llmProvider] ?: "NONE",
        llmModel = p[K.llmModel] ?: "",
        liveMode = p[K.liveMode] ?: false,
        watchNewDevices = p[K.watchNewDevices] ?: false,
        routerType = p[K.routerType] ?: "NONE",
        routerHost = p[K.routerHost] ?: "192.168.1.1",
        routerUser = p[K.routerUser] ?: "admin",
        marketSeeded = p[K.marketSeeded] ?: false,
        channelStyles = ChannelKey.entries.associateWith { key ->
            ChannelStyle(
                sound = p[K.sound(key)] ?: key.defaultSound,
                vibe = enumOr(p[K.vibe(key)], key.defaultVibe),
                version = p[K.version(key)] ?: 1,
            )
        },
    )

    suspend fun update(block: SettingsEditor.() -> Unit) {
        context.dataStore.edit { prefs -> SettingsEditor(prefs).block() }
    }

    suspend fun isSeeded(): Boolean = context.dataStore.data.first()[K.seeded] ?: false
    suspend fun markSeeded() { context.dataStore.edit { it[K.seeded] = true } }

    /** Changing a channel's sound/vibration needs a new channel id on Android 8+ – bump its version. */
    suspend fun setChannelStyle(key: ChannelKey, sound: String? = null, vibe: VibePattern? = null) {
        context.dataStore.edit { p ->
            if (sound != null) p[K.sound(key)] = sound
            if (vibe != null) p[K.vibe(key)] = vibe.name
            p[K.version(key)] = (p[K.version(key)] ?: 1) + 1
        }
    }

    inner class SettingsEditor(private val p: androidx.datastore.preferences.core.MutablePreferences) {
        var themeMode: ThemeMode? = null
            set(v) { if (v != null) p[K.theme] = v.name }
        var onboardingDone: Boolean? = null
            set(v) { if (v != null) p[K.onboarding] = v }
        var defaultFollowUpMinutes: Int? = null
            set(v) { if (v != null) p[K.followUp] = v }
        var defaultMaxFollowUps: Int? = null
            set(v) { if (v != null) p[K.maxFollowUps] = v }
        var quietEnabled: Boolean? = null
            set(v) { if (v != null) p[K.quietEnabled] = v }
        var quietStart: Int? = null
            set(v) { if (v != null) p[K.quietStart] = v }
        var quietEnd: Int? = null
            set(v) { if (v != null) p[K.quietEnd] = v }
        var importantBypassQuiet: Boolean? = null
            set(v) { if (v != null) p[K.bypassQuiet] = v }
        var profile: NotificationProfile? = null
            set(v) { if (v != null) p[K.profile] = v.name }
        var aiEnabled: Boolean? = null
            set(v) { if (v != null) p[K.aiEnabled] = v }
        var aiTone: AiTone? = null
            set(v) { if (v != null) p[K.aiTone] = v.name }
        var aiCloudEnabled: Boolean? = null
            set(v) { if (v != null) p[K.aiCloud] = v }
        var aiBackendUrl: String? = null
            set(v) { if (v != null) p[K.aiBackend] = v }
        var overlayEnabled: Boolean? = null
            set(v) { if (v != null) p[K.overlay] = v }
        var historyEnabled: Boolean? = null
            set(v) { if (v != null) p[K.history] = v }
        var streaksEnabled: Boolean? = null
            set(v) { if (v != null) p[K.streaks] = v }
        var hapticsEnabled: Boolean? = null
            set(v) { if (v != null) p[K.haptics] = v }
        var signalKeywords: Set<String>? = null
            set(v) { if (v != null) p[K.keywords] = v }
        var signalSyncHours: Int? = null
            set(v) { if (v != null) p[K.syncHours] = v }
        var weekStartsSaturday: Boolean? = null
            set(v) { if (v != null) p[K.weekSat] = v }
        var llmProvider: String? = null
            set(v) { if (v != null) p[K.llmProvider] = v }
        var llmModel: String? = null
            set(v) { if (v != null) p[K.llmModel] = v }
        var liveMode: Boolean? = null
            set(v) { if (v != null) p[K.liveMode] = v }
        var watchNewDevices: Boolean? = null
            set(v) { if (v != null) p[K.watchNewDevices] = v }
        var routerType: String? = null
            set(v) { if (v != null) p[K.routerType] = v }
        var routerHost: String? = null
            set(v) { if (v != null) p[K.routerHost] = v }
        var routerUser: String? = null
            set(v) { if (v != null) p[K.routerUser] = v }
        var marketSeeded: Boolean? = null
            set(v) { if (v != null) p[K.marketSeeded] = v }
    }

    suspend fun clearAll() {
        context.dataStore.edit { it.clear() }
    }

    private inline fun <reified T : Enum<T>> enumOr(value: String?, fallback: T): T =
        if (value == null) fallback else enumValues<T>().firstOrNull { it.name == value } ?: fallback
}
