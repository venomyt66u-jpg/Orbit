package com.orbit.followthrough.ui.habits

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.orbit.followthrough.R
import com.orbit.followthrough.domain.HabitKind
import com.orbit.followthrough.ui.components.CardShape
import com.orbit.followthrough.ui.components.CompletionCheck
import com.orbit.followthrough.ui.components.EmptyState
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.PrimaryButton
import com.orbit.followthrough.ui.components.ProgressRing
import com.orbit.followthrough.ui.components.ScreenHeader
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.ambientPhase
import com.orbit.followthrough.ui.components.beadRing
import com.orbit.followthrough.ui.home.BOTTOM_SPACE
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun HabitsScreen(nav: NavHostController) {
    val vm = orbitViewModel { HabitsViewModel(it) }
    val state by vm.state.collectAsStateWithLifecycle()
    val c = Orbit.colors

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = BOTTOM_SPACE.dp)) {
        item {
            ScreenHeader(stringResource(R.string.tab_habits), subtitle = stringResource(R.string.habits_subtitle)) {
                IconCircle(OrbitIcons.Plus, stringResource(R.string.new_habit), { nav.navigate(Routes.habitEdit()) }, tint = c.cyan)
            }
        }
        item { WeekSummary(state) }
        state.tasbih?.let { t ->
            item { TasbihCard(t, onOpen = { nav.navigate(Routes.tasbih(t.habit.id)) }) }
        }
        val regular = state.habits.filter { it.habit.kind != HabitKind.TASBIH }
        if (regular.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.your_habits), Modifier.padding(top = 18.dp)) }
            items(regular.chunked(2), key = { row -> row.joinToString("-") { it.habit.id.toString() } }) { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { h ->
                        HabitTile(
                            h, Modifier.weight(1f),
                            onPlus = { vm.plus(h.habit.id) },
                            onMinus = { vm.minus(h.habit.id) },
                            onEdit = { nav.navigate(Routes.habitEdit(h.habit.id)) },
                        )
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            item {
                Text(stringResource(R.string.habit_tip), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 4.dp))
            }
        } else if (!state.loading && state.tasbih == null) {
            item {
                Column {
                    EmptyState(stringResource(R.string.no_habits), stringResource(R.string.no_habits_body), art = { ProgressRing(0.3f, size = 96.dp) })
                    PrimaryButton(stringResource(R.string.new_habit), { nav.navigate(Routes.habitEdit()) }, Modifier.fillMaxWidth(), icon = OrbitIcons.Plus)
                }
            }
        }
    }
}

@Composable
private fun WeekSummary(state: HabitsState) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val encourage = stringArrayResource(R.array.habit_encourage)
    val bucket = when {
        state.todayProgress >= 1f -> 3
        state.todayProgress >= 0.5f -> 2
        state.todayProgress > 0f -> 1
        else -> 0
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(state.todayProgress, size = 76.dp, stroke = 7.dp, colors = listOf(c.green, c.cyan)) {
                Text("${(state.todayProgress * 100).roundToInt()}%", style = OrbitType.subtitle, color = c.text)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.today_progress), style = OrbitType.overline, color = c.textMuted)
                Text(encourage.getOrElse(bucket) { "" }, style = OrbitType.subtitle, color = c.text)
                if (LocalSettings.current.streaksEnabled && state.bestStreak > 1) {
                    Text(stringResource(R.string.best_streak, state.bestStreak), style = OrbitType.caption, color = c.gold)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        // 7-day bars
        Row(Modifier.fillMaxWidth().height(96.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            state.week.forEachIndexed { i, v ->
                val date = state.weekDates.getOrNull(i)
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f).semantics {
                    contentDescription = (date?.let { Fmt.weekdayShort(ctx, it.dayOfWeek) } ?: "") + " ${(v * 100).roundToInt()}%"
                }) {
                    Canvas(Modifier.width(14.dp).height(70.dp)) {
                        drawRoundRect(c.stroke, cornerRadius = CornerRadius(size.width / 2))
                        val h = size.height * v.coerceIn(0f, 1f)
                        if (h > 0f) drawRoundRect(
                            Brush.verticalGradient(listOf(c.cyan, c.electric)),
                            topLeft = Offset(0f, size.height - h), size = Size(size.width, h), cornerRadius = CornerRadius(size.width / 2),
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        date?.let { Fmt.weekdayNarrow(ctx, it.dayOfWeek) } ?: "",
                        style = OrbitType.caption,
                        color = if (i == state.week.lastIndex) c.cyan else c.textMuted,
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.week_average, (state.weekAverage * 100).roundToInt()), style = OrbitType.caption, color = c.textSecondary)
    }
}

@Composable
private fun TasbihCard(t: HabitView, onOpen: () -> Unit) {
    val c = Orbit.colors
    val phase = ambientPhase(4000)
    val round = t.habit.roundSize.coerceAtLeast(1)
    GlassCard(Modifier.fillMaxWidth().padding(top = 16.dp), highlight = c.gold, onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    beadRing(33, ((t.today % round) * 33f / round).toInt(), c.gold, c.stroke, ((sin(phase * 2 * PI) + 1) / 2).toFloat())
                }
                Text("${t.today}", style = OrbitType.subtitle, color = c.text)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.tasbih).uppercase(), style = OrbitType.overline, color = c.gold)
                Text(t.habit.phrase.ifBlank { t.habit.name }, style = OrbitType.title, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(stringResource(R.string.tasbih_goal, t.today, t.habit.target), style = OrbitType.caption, color = c.textSecondary)
            }
            Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(20.dp))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HabitTile(h: HabitView, modifier: Modifier, onPlus: () -> Unit, onMinus: () -> Unit, onEdit: () -> Unit) {
    val c = Orbit.colors
    val color = c.habit(h.habit.colorIndex)
    val haptic = LocalHapticFeedback.current
    val hapticsOn = LocalSettings.current.hapticsEnabled
    var justDone by remember { mutableStateOf(false) }
    LaunchedEffect(h.done) { if (!h.done) justDone = false }
    val label = stringResource(R.string.habit_tile_cd, h.habit.name, h.today, h.habit.target)

    Column(
        modifier
            .clip(CardShape)
            .background(Brush.verticalGradient(listOf(c.surfaceHigh.copy(alpha = 0.7f), c.surface.copy(alpha = 0.6f))))
            .border(1.dp, if (h.done) color.copy(alpha = 0.5f) else c.stroke, CardShape)
            .combinedClickable(
                role = Role.Button,
                onClick = {
                    if (hapticsOn) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    if (h.today + 1 == h.habit.target) justDone = true
                    onPlus()
                },
                onLongClick = onEdit,
            )
            .semantics { contentDescription = label }
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Box(contentAlignment = Alignment.Center) {
                ProgressRing(h.progress, size = 58.dp, stroke = 5.dp, colors = listOf(color, color.copy(alpha = 0.55f))) {
                    Icon(OrbitIcons.habit(h.habit.glyph), null, tint = color, modifier = Modifier.size(22.dp))
                }
                CompletionCheck(justDone, color, Modifier.size(58.dp))
            }
            Spacer(Modifier.weight(1f))
            if (h.today > 0) IconCircle(OrbitIcons.Minus, stringResource(R.string.decrease), onMinus, size = 32.dp, tint = c.textSecondary)
        }
        Spacer(Modifier.height(12.dp))
        Text(h.habit.name, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            "${h.today} / ${h.habit.target}" + (if (h.habit.unit.isNotBlank()) " ${h.habit.unit}" else ""),
            style = OrbitType.numericSmall, color = if (h.done) color else c.textSecondary,
        )
        Spacer(Modifier.height(8.dp))
        // mini 7-day dots
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            h.week.forEach { v ->
                Box(
                    Modifier.size(width = 12.dp, height = 4.dp).clip(CardShape)
                        .background(if (v >= 1f) color else if (v > 0f) color.copy(alpha = 0.35f) else c.stroke)
                )
            }
        }
        if (LocalSettings.current.streaksEnabled && h.streak > 1) {
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.streak_days, h.streak), style = OrbitType.caption, color = c.gold)
        }
    }
}
