package com.orbit.followthrough.signals

import java.net.URI
import java.util.Locale

/** Social / creator platforms Orbit can recognise from a profile link. */
enum class Platform(val label: String, val supported: Boolean) {
    YOUTUBE("YouTube", true),
    REDDIT("Reddit", true),
    BLUESKY("Bluesky", true),
    MASTODON("Mastodon", true),
    MEDIUM("Medium", true),
    SUBSTACK("Substack", true),
    GITHUB("GitHub", true),
    RSS("RSS", true),
    X("X / Twitter", false),
    INSTAGRAM("Instagram", false),
    TIKTOK("TikTok", false),
    FACEBOOK("Facebook", false),
    THREADS("Threads", false),
    LINKEDIN("LinkedIn", false),
    TELEGRAM("Telegram", false);

    companion object {
        /** Best-effort platform detection from a stored feed URL (for icons and labels). */
        fun fromFeedUrl(url: String): Platform {
            val u = url.lowercase(Locale.ROOT)
            return when {
                "youtube.com" in u -> YOUTUBE
                "reddit.com" in u -> REDDIT
                "bsky.app" in u -> BLUESKY
                "medium.com" in u -> MEDIUM
                "substack.com" in u -> SUBSTACK
                "github.com" in u -> GITHUB
                Regex("/@[^/]+\\.rss$").containsMatchIn(u) -> MASTODON
                else -> RSS
            }
        }
    }
}

sealed interface Resolution {
    /** A public, official feed exists for this profile. */
    data class Feed(val platform: Platform, val feedUrl: String, val handle: String) : Resolution
    /** YouTube @handle: the channel id must be read from the public channel page once. */
    data class NeedsLookup(val platform: Platform, val pageUrl: String, val handle: String) : Resolution
    /** The platform offers no free, authorised way to follow posts from a phone. */
    data class Unsupported(val platform: Platform, val handle: String) : Resolution
    data object Invalid : Resolution
}

/**
 * Turns a profile link into an official feed URL. Only public, documented feeds are used —
 * Orbit never scrapes sites that forbid it.
 */
object AccountResolver {

    private val handleOk = Regex("^[A-Za-z0-9_.\\-]+$")

    fun resolve(raw: String): Resolution {
        var input = raw.trim()
        if (input.isEmpty()) return Resolution.Invalid
        if (input.startsWith("@") && !input.contains("/")) return Resolution.Invalid
        if (!input.startsWith("http://") && !input.startsWith("https://")) input = "https://$input"
        val uri = runCatching { URI(input.replace(" ", "")) }.getOrNull() ?: return Resolution.Invalid
        val host = (uri.host ?: return Resolution.Invalid).lowercase(Locale.ROOT)
            .removePrefix("www.").removePrefix("m.").removePrefix("mobile.")
        val parts = (uri.path ?: "").split('/').filter { it.isNotBlank() }
        val first = parts.getOrNull(0).orEmpty()
        val second = parts.getOrNull(1).orEmpty()

        return when {
            host == "youtube.com" || host == "music.youtube.com" -> when {
                first == "channel" && second.startsWith("UC") ->
                    Resolution.Feed(Platform.YOUTUBE, "https://www.youtube.com/feeds/videos.xml?channel_id=$second", second)
                first == "user" && second.isNotBlank() ->
                    Resolution.Feed(Platform.YOUTUBE, "https://www.youtube.com/feeds/videos.xml?user=$second", second)
                first.startsWith("@") && first.length > 1 ->
                    Resolution.NeedsLookup(Platform.YOUTUBE, "https://www.youtube.com/$first", first)
                first == "c" && second.isNotBlank() ->
                    Resolution.NeedsLookup(Platform.YOUTUBE, "https://www.youtube.com/c/$second", second)
                else -> Resolution.Invalid
            }
            host == "reddit.com" || host == "old.reddit.com" -> when {
                (first == "user" || first == "u") && second.matches(handleOk) ->
                    Resolution.Feed(Platform.REDDIT, "https://www.reddit.com/user/$second/submitted/.rss", "u/$second")
                first == "r" && second.matches(handleOk) ->
                    Resolution.Feed(Platform.REDDIT, "https://www.reddit.com/r/$second/new/.rss", "r/$second")
                else -> Resolution.Invalid
            }
            host == "bsky.app" -> if (first == "profile" && second.isNotBlank())
                Resolution.Feed(Platform.BLUESKY, "https://bsky.app/profile/$second/rss", "@$second") else Resolution.Invalid
            host == "medium.com" -> if (first.startsWith("@"))
                Resolution.Feed(Platform.MEDIUM, "https://medium.com/feed/$first", first) else Resolution.Invalid
            host.endsWith(".medium.com") -> {
                val user = host.removeSuffix(".medium.com")
                Resolution.Feed(Platform.MEDIUM, "https://$user.medium.com/feed", user)
            }
            host.endsWith(".substack.com") -> {
                val user = host.removeSuffix(".substack.com")
                Resolution.Feed(Platform.SUBSTACK, "https://$user.substack.com/feed", user)
            }
            host == "github.com" -> when {
                first.isNotBlank() && second.isNotBlank() ->
                    Resolution.Feed(Platform.GITHUB, "https://github.com/$first/$second/releases.atom", "$first/$second")
                first.matches(handleOk) -> Resolution.Feed(Platform.GITHUB, "https://github.com/$first.atom", first)
                else -> Resolution.Invalid
            }
            host == "x.com" || host == "twitter.com" -> Resolution.Unsupported(Platform.X, "@$first")
            host == "instagram.com" -> Resolution.Unsupported(Platform.INSTAGRAM, "@$first")
            host == "tiktok.com" -> Resolution.Unsupported(Platform.TIKTOK, first)
            host == "facebook.com" || host == "fb.com" -> Resolution.Unsupported(Platform.FACEBOOK, first)
            host == "threads.net" || host == "threads.com" -> Resolution.Unsupported(Platform.THREADS, first)
            host == "linkedin.com" -> Resolution.Unsupported(Platform.LINKEDIN, second.ifBlank { first })
            host == "t.me" || host == "telegram.me" -> Resolution.Unsupported(Platform.TELEGRAM, "@$first")
            // Mastodon-compatible servers: https://server/@user
            first.startsWith("@") && first.length > 1 && parts.size == 1 ->
                Resolution.Feed(Platform.MASTODON, "https://$host/$first.rss", "$first@$host")
            // Anything else is treated as a direct RSS/Atom URL and validated on first sync.
            else -> Resolution.Feed(Platform.RSS, input, host)
        }
    }

    /** Extracts the canonical channel id from a public YouTube channel page. */
    fun youtubeChannelId(html: String): String? {
        val patterns = listOf(
            Regex("feeds/videos\\.xml\\?channel_id=(UC[A-Za-z0-9_-]{22})"),
            Regex("\"externalId\":\"(UC[A-Za-z0-9_-]{22})\""),
            Regex("\"channelId\":\"(UC[A-Za-z0-9_-]{22})\""),
            Regex("youtube\\.com/channel/(UC[A-Za-z0-9_-]{22})"),
        )
        for (p in patterns) p.find(html)?.let { return it.groupValues[1] }
        return null
    }
}
