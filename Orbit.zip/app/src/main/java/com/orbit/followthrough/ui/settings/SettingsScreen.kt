package com.orbit.followthrough.ui.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.orbit.followthrough.BuildConfig
import com.orbit.followthrough.R
import com.orbit.followthrough.domain.AiTone
import com.orbit.followthrough.domain.NotificationProfile
import com.orbit.followthrough.domain.ThemeMode
import com.orbit.followthrough.ui.components.Divider
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.OrbitSwitch
import com.orbit.followthrough.ui.components.OrbitTextField
import com.orbit.followthrough.ui.components.ScreenHeader
import com.orbit.followthrough.ui.components.SectionHeader
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.SettingRow
import com.orbit.followthrough.ui.components.Stepper
import com.orbit.followthrough.ui.components.TimePickerDialog
import com.orbit.followthrough.ui.home.BOTTOM_SPACE
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt

@Composable
fun SettingsScreen(nav: NavHostController) {
    val vm = orbitViewModel { SettingsViewModel(it) }
    val s = LocalSettings.current
    val c = Orbit.colors
    val ctx = LocalContext.current
    var pickQuiet by remember { mutableStateOf<String?>(null) } // "start" | "end"
    var backendDraft by remember(s.aiBackendUrl) { mutableStateOf(s.aiBackendUrl) }
    var resumeTick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { resumeTick++ }
    val canOverlay = remember(resumeTick) { vm.c.overlay.canShow() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 40.dp)) {
        item { com.orbit.followthrough.ui.components.TopBar(stringResource(R.string.tab_settings), { nav.popBackStack() }, stringResource(R.string.back)) }

        // ---- Appearance ----
        item {
            Column {
                SectionHeader(stringResource(R.string.appearance))
                GlassCard(Modifier.fillMaxWidth()) {
                    Segmented(
                        listOf(ThemeMode.SYSTEM to stringResource(R.string.theme_system), ThemeMode.DARK to stringResource(R.string.theme_dark), ThemeMode.LIGHT to stringResource(R.string.theme_light)),
                        s.themeMode, { m -> vm.update { themeMode = m } }, Modifier.fillMaxWidth(),
                    )
                    Spacer(Modifier.height(8.dp))
                    SettingRow(stringResource(R.string.week_starts_saturday), icon = OrbitIcons.Calendar, onClick = { vm.update { weekStartsSaturday = !s.weekStartsSaturday } }) {
                        OrbitSwitch(s.weekStartsSaturday) { v -> vm.update { weekStartsSaturday = v } }
                    }
                    SettingRow(stringResource(R.string.haptics), icon = OrbitIcons.Vibrate, onClick = { vm.update { hapticsEnabled = !s.hapticsEnabled } }) {
                        OrbitSwitch(s.hapticsEnabled) { v -> vm.update { hapticsEnabled = v } }
                    }
                    SettingRow(stringResource(R.string.show_streaks), subtitle = stringResource(R.string.show_streaks_hint), icon = OrbitIcons.Star, iconTint = c.gold, onClick = { vm.update { streaksEnabled = !s.streaksEnabled } }) {
                        OrbitSwitch(s.streaksEnabled) { v -> vm.update { streaksEnabled = v } }
                    }
                }
            }
        }

        // ---- Notifications ----
        item {
            Column {
                SectionHeader(stringResource(R.string.notifications), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.profile), style = OrbitType.caption, color = c.textMuted)
                    Spacer(Modifier.height(6.dp))
                    Segmented(
                        listOf(
                            NotificationProfile.SILENT to stringResource(R.string.profile_silent),
                            NotificationProfile.NORMAL to stringResource(R.string.profile_normal),
                            NotificationProfile.HIGH to stringResource(R.string.profile_high),
                        ),
                        s.profile, { p -> vm.update { profile = p } }, Modifier.fillMaxWidth(),
                    )
                    Text(
                        stringResource(
                            when (s.profile) {
                                NotificationProfile.SILENT -> R.string.profile_silent_hint
                                NotificationProfile.NORMAL -> R.string.profile_normal_hint
                                NotificationProfile.HIGH -> R.string.profile_high_hint
                            }
                        ),
                        style = OrbitType.caption, color = c.textSecondary, modifier = Modifier.padding(top = 8.dp),
                    )
                    Spacer(Modifier.height(6.dp))
                    SettingRow(stringResource(R.string.sounds_vibration), subtitle = stringResource(R.string.sounds_vibration_hint), icon = OrbitIcons.Sound, onClick = { nav.navigate(Routes.SOUNDS) }) {
                        Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                    }
                    Divider()
                    SettingRow(stringResource(R.string.quiet_hours), subtitle = stringResource(R.string.quiet_hours_hint), icon = OrbitIcons.Moon, iconTint = c.violet, onClick = { vm.update { quietEnabled = !s.quietEnabled } }) {
                        OrbitSwitch(s.quietEnabled) { v -> vm.update { quietEnabled = v } }
                    }
                    if (s.quietEnabled) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(start = 52.dp, bottom = 6.dp)) {
                            OrbitChip(stringResource(R.string.from_time, Fmt.minutesOfDay(ctx, s.quietStart)), true, { pickQuiet = "start" }, icon = OrbitIcons.Clock, accent = c.violet)
                            OrbitChip(stringResource(R.string.to_time, Fmt.minutesOfDay(ctx, s.quietEnd)), true, { pickQuiet = "end" }, icon = OrbitIcons.Clock, accent = c.violet)
                        }
                        SettingRow(stringResource(R.string.important_bypass), subtitle = stringResource(R.string.important_bypass_hint), icon = OrbitIcons.Flag, iconTint = c.amber) {
                            OrbitSwitch(s.importantBypassQuiet) { v -> vm.update { importantBypassQuiet = v } }
                        }
                    }
                    Divider()
                    SettingRow(stringResource(R.string.notification_history), subtitle = stringResource(R.string.notification_history_hint), icon = OrbitIcons.History, onClick = { nav.navigate(Routes.HISTORY) }) {
                        OrbitSwitch(s.historyEnabled) { v -> vm.update { historyEnabled = v } }
                    }
                }
            }
        }

        // ---- Reminder defaults ----
        item {
            Column {
                SectionHeader(stringResource(R.string.reminder_defaults), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.default_followup), style = OrbitType.subtitle, color = c.text)
                    Text(stringResource(R.string.follow_explain), style = OrbitType.caption, color = c.textSecondary)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OrbitChip(stringResource(R.string.off), s.defaultFollowUpMinutes == 0, { vm.update { defaultFollowUpMinutes = 0 } })
                        listOf(5, 10, 15, 30, 60).forEach { m ->
                            OrbitChip(stringResource(R.string.minutes_short, m), s.defaultFollowUpMinutes == m, { vm.update { defaultFollowUpMinutes = m } })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    SettingRow(stringResource(R.string.max_followups), subtitle = stringResource(R.string.max_followups_hint)) {
                        Stepper(s.defaultMaxFollowUps, { v -> vm.update { defaultMaxFollowUps = v } }, 1..10, decLabel = stringResource(R.string.decrease), incLabel = stringResource(R.string.increase))
                    }
                }
            }
        }

        // ---- Smart assistant ----
        item {
            Column {
                SectionHeader(stringResource(R.string.smart_assistant), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    SettingRow(stringResource(R.string.ai_personalization), subtitle = stringResource(R.string.ai_personalization_hint), icon = OrbitIcons.Spark, iconTint = c.violet, onClick = { vm.update { aiEnabled = !s.aiEnabled } }) {
                        OrbitSwitch(s.aiEnabled) { v -> vm.update { aiEnabled = v } }
                    }
                    if (s.aiEnabled) {
                        Text(stringResource(R.string.tone), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
                        Segmented(
                            listOf(AiTone.GENTLE to stringResource(R.string.tone_gentle), AiTone.FRIENDLY to stringResource(R.string.tone_friendly), AiTone.DIRECT to stringResource(R.string.tone_direct)),
                            s.aiTone, { t -> vm.update { aiTone = t } }, Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        Divider()
                        SettingRow(stringResource(R.string.cloud_ai), subtitle = stringResource(R.string.cloud_ai_hint), icon = OrbitIcons.Link, iconTint = c.electric, onClick = { vm.update { aiCloudEnabled = !s.aiCloudEnabled } }) {
                            OrbitSwitch(s.aiCloudEnabled) { v -> vm.update { aiCloudEnabled = v } }
                        }
                        if (s.aiCloudEnabled) {
                            OrbitTextField(
                                backendDraft, { backendDraft = it.trim() },
                                placeholder = "https://your-backend.example.com",
                                leading = OrbitIcons.Link,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                                keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { vm.update { aiBackendUrl = backendDraft } }),
                                modifier = Modifier.fillMaxWidth(),
                            )
                            Text(
                                stringResource(if (backendDraft.isBlank() || backendDraft.startsWith("https://")) R.string.cloud_ai_disclosure else R.string.https_required),
                                style = OrbitType.caption, color = if (backendDraft.isBlank() || backendDraft.startsWith("https://")) c.textMuted else c.amber,
                                modifier = Modifier.padding(top = 6.dp),
                            )
                            if (backendDraft != s.aiBackendUrl) {
                                OrbitChip(stringResource(R.string.save), true, { vm.update { aiBackendUrl = backendDraft } }, icon = OrbitIcons.Check, modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                    }
                }
            }
        }

        // ---- Floating reminder ----
        item {
            Column {
                SectionHeader(stringResource(R.string.floating_reminder), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    SettingRow(
                        stringResource(R.string.floating_reminder),
                        subtitle = stringResource(if (canOverlay) R.string.floating_hint else R.string.floating_needs_permission),
                        icon = OrbitIcons.Window,
                        onClick = {
                            if (!canOverlay) ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            else vm.update { overlayEnabled = !s.overlayEnabled }
                        },
                    ) {
                        OrbitSwitch(s.overlayEnabled && canOverlay) { v ->
                            if (v && !canOverlay) {
                                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                            vm.update { overlayEnabled = v }
                        }
                    }
                    if (s.overlayEnabled && canOverlay) {
                        OrbitChip(stringResource(R.string.preview_card), false, {
                            vm.c.overlay.show(ctx.getString(R.string.preview_title), ctx.getString(R.string.preview_body), {}, {})
                        }, icon = OrbitIcons.Play, modifier = Modifier.padding(start = 52.dp))
                    }
                }
            }
        }

        // ---- Signal feed ----
        item {
            Column {
                SectionHeader(stringResource(R.string.tab_signals), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth()) {
                    SettingRow(stringResource(R.string.sources), subtitle = stringResource(R.string.sources_hint), icon = OrbitIcons.Layers, iconTint = c.violet, onClick = { nav.navigate(Routes.SOURCES) }) {
                        Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                    }
                    Text(stringResource(R.string.check_every), style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 6.dp, bottom = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1, 3, 6, 12).forEach { h ->
                            OrbitChip(stringResource(R.string.hours_short, h), s.signalSyncHours == h, { vm.setSyncHours(h) })
                        }
                    }
                }
            }
        }

        // ---- System, privacy, help ----
        item {
            Column {
                SectionHeader(stringResource(R.string.system_privacy), Modifier.padding(top = 18.dp))
                GlassCard(Modifier.fillMaxWidth(), padding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)) {
                    SettingRow(stringResource(R.string.permissions), subtitle = stringResource(R.string.permissions_hint), icon = OrbitIcons.Shield, iconTint = c.green, onClick = { nav.navigate(Routes.PERMISSIONS) }) {
                        Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                    }
                    SettingRow(stringResource(R.string.privacy_data), subtitle = stringResource(R.string.privacy_data_hint), icon = OrbitIcons.Lock, iconTint = c.electric, onClick = { nav.navigate(Routes.PRIVACY) }) {
                        Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                    }
                    SettingRow(stringResource(R.string.help_tutorials), subtitle = stringResource(R.string.help_tutorials_hint), icon = OrbitIcons.Help, iconTint = c.cyan, onClick = { nav.navigate(Routes.HELP) }) {
                        Icon(OrbitIcons.ChevronRight, null, tint = c.textMuted, modifier = Modifier.size(18.dp))
                    }
                }
                Text(
                    stringResource(R.string.about_line, BuildConfig.VERSION_NAME),
                    style = OrbitType.caption, color = c.textMuted, modifier = Modifier.padding(top = 18.dp),
                )
            }
        }
    }

    pickQuiet?.let { which ->
        val m = if (which == "start") s.quietStart else s.quietEnd
        TimePickerDialog(m / 60, m % 60, { h, mm ->
            if (which == "start") vm.update { quietStart = h * 60 + mm } else vm.update { quietEnd = h * 60 + mm }
            pickQuiet = null
        }, { pickQuiet = null })
    }
}
