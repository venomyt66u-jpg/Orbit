package com.orbit.followthrough.engine

import com.orbit.followthrough.ai.SmartMessages
import com.orbit.followthrough.data.db.ReminderDao
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.data.db.ReminderEventDao
import com.orbit.followthrough.data.db.ReminderEventEntity
import com.orbit.followthrough.data.db.isRecurring
import com.orbit.followthrough.data.db.schedule
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.domain.EventType
import com.orbit.followthrough.domain.FollowUpPolicy
import com.orbit.followthrough.domain.Recurrence
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.notify.Notifier
import com.orbit.followthrough.overlay.FloatingReminder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import java.time.ZoneId

sealed interface SaveResult {
    data class Saved(val id: Long, val nextAt: Long?) : SaveResult
    data object InThePast : SaveResult
    data object EmptyTitle : SaveResult
}

/**
 * The heart of Orbit. All state transitions of a reminder go through here, are logged as events,
 * and finish by syncing exactly one alarm. Works fully offline.
 */
class ReminderEngine(
    private val dao: ReminderDao,
    private val events: ReminderEventDao,
    private val scheduler: AlarmScheduler,
    private val notifier: Notifier,
    private val settings: SettingsRepository,
    private val overlay: FloatingReminder,
    private val appScope: CoroutineScope,
    private val clock: () -> Long = System::currentTimeMillis,
    private val zone: () -> ZoneId = ZoneId::systemDefault,
) {
    private val mutex = Mutex()

    companion object {
        /** Alarms may be delivered slightly early on some devices. */
        private const val EARLY_TOLERANCE_MS = 30_000L
        /** A recurring occurrence older than this is recorded as missed instead of notifying late. */
        private const val STALE_RECURRING_MS = 2 * 60 * 60_000L
    }

    suspend fun save(input: ReminderEntity): SaveResult = mutex.withLock {
        if (input.title.isBlank()) return@withLock SaveResult.EmptyTitle
        val now = clock()
        var next = Recurrence.next(input.schedule(), Instant.ofEpochMilli(now), zone())?.toEpochMilli()
        if (next != null && input.deadlineAt != null && next > input.deadlineAt) next = null
        if (next == null) return@withLock SaveResult.InThePast

        val existing = if (input.id != 0L) dao.get(input.id) else null
        val toSave = input.copy(
            title = input.title.trim(),
            note = input.note.trim(),
            status = ReminderStatus.SCHEDULED,
            nextOccurrenceAt = next,
            pendingOccurrenceAt = null,
            followUpAt = null,
            followUpsUsed = 0,
            snoozeCount = existing?.snoozeCount ?: 0,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now,
        )
        val id = if (existing == null) dao.insert(toSave.copy(id = 0)) else { dao.update(toSave); toSave.id }
        if (existing == null) log(id, toSave.title, EventType.CREATED, now)
        notifier.cancelReminder(id)
        scheduler.syncReminder(toSave.copy(id = id))
        SaveResult.Saved(id, next)
    }

    /** Called by AlarmReceiver. Handles occurrences, follow-ups and catch-up after downtime. */
    suspend fun onAlarm(id: Long) = mutex.withLock {
        val r = dao.get(id) ?: run { scheduler.cancelReminder(id); return@withLock }
        if (r.status == ReminderStatus.DONE || r.status == ReminderStatus.PAUSED) {
            scheduler.cancelReminder(id); return@withLock
        }
        val now = clock()
        val s = settings.current()
        var u = r

        // 1) A real occurrence is due.
        val occ = r.nextOccurrenceAt
        if (occ != null && occ <= now + EARLY_TOLERANCE_MS) {
            if (r.status == ReminderStatus.PENDING) log(r.id, r.title, EventType.MISSED, r.pendingOccurrenceAt ?: now)
            var next = Recurrence.next(r.schedule(), Instant.ofEpochMilli(maxOf(occ, now)), zone())?.toEpochMilli()
            if (next != null && r.deadlineAt != null && next > r.deadlineAt) next = null
            val stale = r.isRecurring() && now - occ > STALE_RECURRING_MS
            val pastDeadline = r.deadlineAt != null && occ > r.deadlineAt

            if (stale || pastDeadline) {
                log(r.id, r.title, EventType.MISSED, occ)
                u = r.copy(
                    status = if (next != null) ReminderStatus.SCHEDULED else ReminderStatus.DONE,
                    nextOccurrenceAt = next, pendingOccurrenceAt = null, followUpAt = null, followUpsUsed = 0,
                )
            } else {
                u = r.copy(
                    status = ReminderStatus.PENDING,
                    pendingOccurrenceAt = occ,
                    nextOccurrenceAt = next,
                    followUpAt = null,
                    followUpsUsed = 0,
                )
                val late = now - occ > 10 * 60_000L
                log(r.id, r.title, EventType.FIRED, now)
                deliver(u, if (late) SmartMessages.Kind.LATE else SmartMessages.Kind.OCCURRENCE, 0, s, now)
            }
        } else {
            // 2) A follow-up / snooze is due.
            val fu = r.followUpAt
            if (fu != null && fu <= now + EARLY_TOLERANCE_MS) {
                u = r.copy(followUpAt = null)
                if (r.status == ReminderStatus.PENDING && (r.deadlineAt == null || now <= r.deadlineAt)) {
                    log(r.id, r.title, EventType.FOLLOW_UP, now)
                    deliver(u, SmartMessages.Kind.FOLLOW_UP, r.followUpsUsed, s, now)
                }
            }
        }

        u = u.copy(updatedAt = now)
        dao.update(u)
        scheduler.syncReminder(u)
    }

    private suspend fun deliver(r: ReminderEntity, kind: SmartMessages.Kind, followUpIndex: Int, s: com.orbit.followthrough.data.prefs.AppSettings, now: Long) {
        notifier.showReminder(r, kind, followUpIndex, s, now)
        if (s.overlayEnabled && overlay.canShow() && !s.quietHours.isQuiet(now, zone())) {
            val body = r.note.ifBlank { "" }
            overlay.show(
                title = r.title,
                body = body,
                onDone = { appScope.launch { complete(r.id) } },
                onLater = { appScope.launch { snooze(r.id, if (r.followUpMinutes > 0) r.followUpMinutes else s.defaultFollowUpMinutes) } },
            )
        }
    }

    /** The user swiped the notification away. The task stays pending; a follow-up may be scheduled. */
    suspend fun onDismissed(id: Long) = mutex.withLock {
        val r = dao.get(id) ?: return@withLock
        if (r.status != ReminderStatus.PENDING) return@withLock
        val now = clock()
        val s = settings.current()
        val fu = FollowUpPolicy.nextFollowUp(
            nowMillis = now,
            followUpMinutes = r.followUpMinutes,
            followUpsUsed = r.followUpsUsed,
            maxFollowUps = r.maxFollowUps,
            deadlineMillis = r.deadlineAt,
            nextOccurrenceMillis = r.nextOccurrenceAt,
            quiet = s.quietHours,
            bypassQuiet = r.important && s.importantBypassQuiet,
            zone = zone(),
        )
        log(r.id, r.title, EventType.DISMISSED, now)
        val u = r.copy(
            followUpAt = fu,
            followUpsUsed = if (fu != null) r.followUpsUsed + 1 else r.followUpsUsed,
            updatedAt = now,
        )
        dao.update(u)
        scheduler.syncReminder(u)
    }

    /** "Remind me later" – an explicit user choice, so quiet hours / limits don't block it. */
    suspend fun snooze(id: Long, minutes: Int) = mutex.withLock {
        val r = dao.get(id) ?: return@withLock
        if (r.status != ReminderStatus.PENDING) return@withLock
        val now = clock()
        log(r.id, r.title, EventType.SNOOZED, now)
        val u = r.copy(
            followUpAt = now + minutes.coerceIn(1, 24 * 60) * 60_000L,
            snoozeCount = r.snoozeCount + 1,
            updatedAt = now,
        )
        dao.update(u)
        notifier.cancelReminder(id)
        overlay.hide()
        scheduler.syncReminder(u)
    }

    suspend fun complete(id: Long) = resolve(id, EventType.COMPLETED)
    suspend fun skip(id: Long) = resolve(id, EventType.SKIPPED)

    private suspend fun resolve(id: Long, type: EventType) = mutex.withLock {
        val r = dao.get(id) ?: return@withLock
        val now = clock()
        log(r.id, r.title, type, now)
        val u = when (r.status) {
            ReminderStatus.PENDING -> r.copy(
                status = if (r.nextOccurrenceAt != null) ReminderStatus.SCHEDULED else ReminderStatus.DONE,
                pendingOccurrenceAt = null, followUpAt = null, followUpsUsed = 0,
            )
            ReminderStatus.SCHEDULED -> {
                // Done ahead of time: consume the upcoming occurrence.
                val occ = r.nextOccurrenceAt
                var next = if (occ == null || !r.isRecurring()) null
                else Recurrence.next(r.schedule(), Instant.ofEpochMilli(occ), zone())?.toEpochMilli()
                if (next != null && r.deadlineAt != null && next > r.deadlineAt) next = null
                r.copy(
                    status = if (next != null) ReminderStatus.SCHEDULED else ReminderStatus.DONE,
                    nextOccurrenceAt = next, followUpAt = null, followUpsUsed = 0,
                )
            }
            else -> r
        }.copy(updatedAt = now)
        dao.update(u)
        notifier.cancelReminder(id)
        overlay.hide()
        scheduler.syncReminder(u)
    }

    suspend fun pause(id: Long) = mutex.withLock {
        val r = dao.get(id) ?: return@withLock
        val u = r.copy(status = ReminderStatus.PAUSED, followUpAt = null, pendingOccurrenceAt = null, updatedAt = clock())
        dao.update(u)
        notifier.cancelReminder(id)
        scheduler.cancelReminder(id)
    }

    suspend fun resume(id: Long): Boolean = mutex.withLock {
        val r = dao.get(id) ?: return@withLock false
        val now = clock()
        var next = Recurrence.next(r.schedule(), Instant.ofEpochMilli(now), zone())?.toEpochMilli()
        if (next != null && r.deadlineAt != null && next > r.deadlineAt) next = null
        if (next == null) return@withLock false
        val u = r.copy(status = ReminderStatus.SCHEDULED, nextOccurrenceAt = next, followUpsUsed = 0, updatedAt = now)
        dao.update(u)
        scheduler.syncReminder(u)
        true
    }

    suspend fun delete(id: Long) = mutex.withLock {
        scheduler.cancelReminder(id)
        notifier.cancelReminder(id)
        dao.delete(id)
        events.deleteForReminder(id)
    }

    /** Move a reminder's time (used by Smart Suggestions after the user confirms). */
    suspend fun reschedule(id: Long, hour: Int, minute: Int): SaveResult {
        val r = dao.get(id) ?: return SaveResult.EmptyTitle
        return save(r.copy(hour = hour, minute = minute))
    }

    /**
     * After reboot, time/time-zone change, app update or exact-alarm permission change.
     * Future occurrences are recomputed in the current zone (wall-clock semantics);
     * past-due ones get an immediate alarm so onAlarm() can apply catch-up rules.
     */
    suspend fun rescheduleAll() = mutex.withLock {
        val now = clock()
        for (r in dao.schedulable()) {
            var u = r
            val occ = r.nextOccurrenceAt
            if (occ != null && occ > now) {
                var next = Recurrence.next(r.schedule(), Instant.ofEpochMilli(now), zone())?.toEpochMilli()
                if (next != null && r.deadlineAt != null && next > r.deadlineAt) next = null
                if (next != occ) u = r.copy(nextOccurrenceAt = next, updatedAt = now)
                if (u.nextOccurrenceAt == null && u.status == ReminderStatus.SCHEDULED) u = u.copy(status = ReminderStatus.DONE)
                if (u !== r) dao.update(u)
            }
            scheduler.syncReminder(u)
        }
    }

    private suspend fun log(id: Long, title: String, type: EventType, at: Long) {
        val hour = Instant.ofEpochMilli(at).atZone(zone()).hour
        events.insert(ReminderEventEntity(reminderId = id, type = type, at = at, hourOfDay = hour, title = title))
    }
}
