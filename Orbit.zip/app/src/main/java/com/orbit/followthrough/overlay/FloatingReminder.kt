package com.orbit.followthrough.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.orbit.followthrough.R
import kotlin.math.abs

/**
 * Optional floating reminder card drawn with Android's supported overlay window type
 * (TYPE_APPLICATION_OVERLAY + the user-granted "Display over other apps" permission).
 *
 * Design rules: compact, never focusable (never steals input), auto-hides after 15 s,
 * drag vertically to move (position is remembered), swipe sideways to dismiss.
 * If permission is missing, callers simply rely on the regular notification.
 */
class FloatingReminder(private val context: Context) {

    private val wm = context.getSystemService(WindowManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private val prefs = context.getSharedPreferences("orbit_overlay", Context.MODE_PRIVATE)
    private var current: View? = null
    private val hideRunnable = Runnable { hide() }

    fun canShow(): Boolean = Settings.canDrawOverlays(context)

    fun show(title: String, body: String, onDone: () -> Unit, onLater: () -> Unit) {
        if (!canShow()) return
        main.post { showInternal(title, body, onDone, onLater) }
    }

    fun hide() {
        main.removeCallbacks(hideRunnable)
        val v = current ?: return
        current = null
        v.animate().alpha(0f).translationY(-24f).setDuration(180).withEndAction {
            runCatching { wm.removeView(v) }
        }.start()
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, context.resources.displayMetrics).toInt()

    @SuppressLint("ClickableViewAccessibility")
    private fun showInternal(title: String, body: String, onDone: () -> Unit, onLater: () -> Unit) {
        current?.let { runCatching { wm.removeView(it) } }
        current = null

        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18f), dp(14f), dp(18f), dp(12f))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#F2141C33"), Color.parseColor("#F20B1020"))
            ).apply {
                cornerRadius = dp(22f).toFloat()
                setStroke(dp(1f), Color.parseColor("#553BE3FF"))
            }
            elevation = dp(10f).toFloat()
            alpha = 0f
            translationY = -24f
            contentDescription = context.getString(R.string.overlay_cd, title)
        }

        val header = TextView(context).apply {
            text = context.getString(R.string.overlay_label)
            setTextColor(Color.parseColor("#3BE3FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            letterSpacing = 0.12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val titleView = TextView(context).apply {
            text = title
            setTextColor(Color.parseColor("#EAF0FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4f), 0, 0)
        }
        val bodyView = TextView(context).apply {
            text = body
            setTextColor(Color.parseColor("#9AA6C4"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(2f), 0, dp(10f))
        }

        fun pill(label: String, filled: Boolean, action: () -> Unit) = TextView(context).apply {
            text = label
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(if (filled) Color.parseColor("#070A12") else Color.parseColor("#EAF0FF"))
            setPadding(dp(16f), dp(9f), dp(16f), dp(9f))
            background = GradientDrawable().apply {
                cornerRadius = dp(18f).toFloat()
                if (filled) setColor(Color.parseColor("#3BE3FF"))
                else { setColor(Color.TRANSPARENT); setStroke(dp(1f), Color.parseColor("#33EAF0FF")) }
            }
            setOnClickListener { action(); hide() }
        }

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            addView(pill(context.getString(R.string.action_later), false, onLater))
            addView(View(context), LinearLayout.LayoutParams(dp(8f), 1))
            addView(pill(context.getString(R.string.action_done), true, onDone))
        }

        card.addView(header)
        card.addView(titleView)
        card.addView(bodyView)
        card.addView(row)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP
            y = prefs.getInt("y", dp(48f))
            horizontalMargin = 0.04f
        }

        // Drag vertically to reposition, swipe horizontally to dismiss.
        var downX = 0f; var downY = 0f; var startY = 0
        card.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startY = params.y; main.removeCallbacks(hideRunnable); true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dy) > abs(dx) && abs(dy) > dp(6f)) {
                        params.y = (startY + dy).toInt().coerceAtLeast(0)
                        runCatching { wm.updateViewLayout(v, params) }
                    } else {
                        v.translationX = dx
                        v.alpha = (1f - abs(dx) / (v.width.coerceAtLeast(1))).coerceIn(0.2f, 1f)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dx = e.rawX - downX
                    prefs.edit().putInt("y", params.y).apply()
                    if (abs(dx) > v.width / 3f) hide()
                    else { v.animate().translationX(0f).alpha(1f).setDuration(150).start(); main.postDelayed(hideRunnable, 15_000) }
                    abs(dx) > dp(6f) || abs(e.rawY - downY) > dp(6f)
                }
                else -> false
            }
        }

        try {
            wm.addView(card, params)
            current = card
            card.animate().alpha(1f).translationY(0f).setDuration(240).start()
            main.postDelayed(hideRunnable, 15_000)
        } catch (_: Exception) {
            current = null
        }
    }
}
