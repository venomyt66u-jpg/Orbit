package com.orbit.followthrough.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.ui.components.BarChart
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

object Ar {
    private val months = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
    private val weekdays = listOf("الاتنين", "التلات", "الأربع", "الخميس", "الجمعة", "السبت", "الحد")

    fun month(d: LocalDate): String = months[d.monthValue - 1] + " " + d.year
    fun dayShort(d: LocalDate): String = weekdays[d.dayOfWeek.value - 1] + " " + d.dayOfMonth + " " + months[d.monthValue - 1]
    fun dayLong(d: LocalDate): String {
        val today = LocalDate.now()
        val prefix = when (d) {
            today -> "النهارده · "
            today.minusDays(1) -> "امبارح · "
            else -> ""
        }
        return prefix + weekdays[d.dayOfWeek.value - 1] + " " + d.dayOfMonth + " " + months[d.monthValue - 1]
    }

    /** 0..23 → "3 العصر" style labels kept short: "3م" / "10ص". */
    fun hour(h: Int): String = when {
        h == 0 -> "12 بالليل"
        h < 12 -> "$h الصبح"
        h == 12 -> "12 الضهر"
        h < 17 -> "${h - 12} العصر"
        else -> "${h - 12} بالليل"
    }

    fun isoDay(d: LocalDate): String = d.format(DateTimeFormatter.ISO_LOCAL_DATE.withLocale(Locale.US))

    /** "دلوقتي" / "من ٥ دقايق" / "من ٣ ساعات" / "من يومين". */
    fun ago(millis: Long, now: Long = System.currentTimeMillis()): String {
        if (millis <= 0) return "لسه"
        val m = (now - millis).coerceAtLeast(0) / 60_000
        return when {
            m < 1 -> "دلوقتي"
            m < 60 -> "من $m دقيقة"
            m < 60 * 24 -> "من ${m / 60} ساعة"
            else -> "من ${m / (60 * 24)} يوم"
        }
    }
}

@Composable
fun BigBytes(bytes: Long, modifier: Modifier = Modifier, color: Color = Orbit.colors.text, big: Boolean = true) {
    val (num, unit) = Fmt.bytesParts(bytes)
    Row(modifier, verticalAlignment = Alignment.Bottom) {
        Text(num, style = if (big) OrbitType.numeric else OrbitType.headline.copy(fontFeatureSettings = "tnum"), color = color, maxLines = 1)
        Spacer(Modifier.width(6.dp))
        Text(unit, style = if (big) OrbitType.title else OrbitType.label, color = Orbit.colors.textSecondary, modifier = Modifier.padding(bottom = if (big) 10.dp else 4.dp))
    }
}

@Composable
fun StatTile(label: String, bytes: Long, accent: Color, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(c.surface.copy(alpha = 0.7f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(accent))
            Spacer(Modifier.width(6.dp))
            Text(label, style = OrbitType.caption, color = c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(6.dp))
        Text(Fmt.bytes(bytes), style = OrbitType.subtitle.copy(fontFeatureSettings = "tnum"), color = c.text, maxLines = 1)
    }
}

/** Daily bars for one month with first / today / last labels. */
@Composable
fun MonthChart(series: List<Long>, month: LocalDate, accent: Color, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    val today = LocalDate.now()
    val isCurrent = month.year == today.year && month.monthValue == today.monthValue
    val upto = if (isCurrent) today.dayOfMonth else series.size
    val shown = series.take(upto)
    val peakIndex = shown.indices.maxByOrNull { shown[it] } ?: -1
    GlassCard(modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("كل يوم في " + Ar.month(month), style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f))
            if (peakIndex >= 0 && shown[peakIndex] > 0) {
                Text("أعلى يوم: " + Fmt.bytes(shown[peakIndex]), style = OrbitType.caption, color = c.textSecondary)
            }
        }
        Spacer(Modifier.height(14.dp))
        BarChart(
            values = series.mapIndexed { i, v -> if (i < upto) v.toFloat() else 0f },
            modifier = Modifier.fillMaxWidth().height(120.dp),
            highlight = if (isCurrent) upto - 1 else peakIndex,
            color = accent,
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("1", style = OrbitType.caption, color = c.textMuted)
            if (isCurrent) Text("النهارده (${today.dayOfMonth})", style = OrbitType.caption, color = accent)
            Text(series.size.toString(), style = OrbitType.caption, color = c.textMuted)
        }
    }
}

@Composable
fun NoticeCard(icon: ImageVector, title: String, body: String, accent: Color, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    val c = Orbit.colors
    GlassCard(modifier.fillMaxWidth(), highlight = accent) {
        Row(verticalAlignment = Alignment.Top) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = OrbitType.subtitle, color = c.text)
                Spacer(Modifier.height(2.dp))
                Text(body, style = OrbitType.caption, color = c.textSecondary)
                if (action != null) {
                    Spacer(Modifier.height(10.dp))
                    action()
                }
            }
        }
    }
}
