package com.orbit.followthrough.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.meter.AppStats
import com.orbit.followthrough.meter.AppUse
import com.orbit.followthrough.meter.NetHistory
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.ZoneId

data class TabItem(val label: String, val icon: ImageVector)

/** Floating glass tab bar with a glowing pill under the selected tab. */
@Composable
fun BottomTabs(items: List<TabItem>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    val shape = RoundedCornerShape(28.dp)
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(c.surfaceHigh.copy(alpha = 0.96f), c.surface.copy(alpha = 0.96f))))
            .border(1.dp, c.strokeStrong, shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items.forEachIndexed { i, item ->
            val on = i == selected
            val bg by animateColorAsState(if (on) c.cyan.copy(alpha = 0.16f) else Color.Transparent, tween(250), label = "tab")
            val fg by animateColorAsState(if (on) c.cyan else c.textSecondary, tween(250), label = "tabFg")
            val s by animateFloatAsState(if (on) 1f else 0.94f, spring(stiffness = 700f), label = "tabScale")
            Column(
                Modifier
                    .weight(1f)
                    .scale(s)
                    .clip(RoundedCornerShape(22.dp))
                    .background(bg)
                    .clickable { onSelect(i) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(item.icon, null, tint = fg, modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(2.dp))
                Text(item.label, style = OrbitType.caption, color = fg, maxLines = 1)
            }
        }
    }
}

private fun rangeOf(period: Period, packageStart: Long): Pair<Long, Long> {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now()
    val end = System.currentTimeMillis() + 3_600_000L
    return when (period) {
        Period.TODAY -> today.atStartOfDay(zone).toInstant().toEpochMilli() to end
        Period.WEEK -> today.minusDays(6).atStartOfDay(zone).toInstant().toEpochMilli() to end
        Period.CYCLE -> today.withDayOfMonth(1).atStartOfDay(zone).toInstant().toEpochMilli() to end
        Period.PACKAGE -> com.orbit.followthrough.domain.Meter.hourStart(packageStart) to end
    }
}

/** This phone's apps on the target network, GlassWire-style. */
@Composable
fun AppsPanel(accent: Color, packageStart: Long, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    val version by DataVersion.flow.collectAsState()
    var period by rememberSaveable { mutableStateOf(Period.TODAY) }
    var apps by remember { mutableStateOf<List<AppUse>?>(null) }
    var tick by remember { mutableStateOf(0) }
    val access = remember(version, tick) { NetHistory.hasAccess(ctx) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); tick++ } }
    LaunchedEffect(period, tick, access) {
        val (from, to) = rangeOf(period, packageStart)
        apps = withContext(Dispatchers.IO) { runCatching { AppStats.forRange(ctx, from, to) }.getOrDefault(emptyList()) }
    }

    Column(modifier) {
        Segmented(
            options = buildList {
                add(Period.TODAY to "النهارده")
                add(Period.WEEK to "٧ أيام")
                add(Period.CYCLE to "الشهر")
                if (packageStart > 0) add(Period.PACKAGE to "الباقة")
            },
            selected = period,
            onSelect = { period = it; apps = null },
            modifier = Modifier.fillMaxWidth().enter(1),
        )
        Spacer(Modifier.height(14.dp))
        val list = apps
        if (!access) {
            NoticeCard(
                OrbitIcons.History, "محتاج إذن «سجل الاستهلاك»",
                "التطبيقات بتتحسب من سجل أندرويد. فعّل الإذن من شاشة الأذونات.", c.amber,
            )
        } else if (list == null) {
            Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = c.cyan) }
        } else {
            AppsList(list, accent)
        }
    }
}

@Composable
private fun AppsList(list: List<AppUse>, accent: Color) {
    val c = Orbit.colors
    Column {
        val total = list.sumOf { it.bytes.total }
        GlassCard(Modifier.fillMaxWidth().enter(2)) {
            Text("استهلاك ${Config.TARGET_SSID} حسب التطبيق", style = OrbitType.label, color = c.textSecondary)
            AnimatedBytes(total, big = false)
            Spacer(Modifier.height(12.dp))
            // stacked share of the top apps
            val palette = listOf(accent, c.cyan, c.violet, c.amber, c.green, c.rose)
            Row(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
                list.take(6).forEachIndexed { i, a ->
                    if (total > 0 && a.bytes.total > 0) {
                        Box(Modifier.weight(a.bytes.total.toFloat()).fillMaxHeight().background(palette[i % palette.size]))
                    }
                }
                val rest = list.drop(6).sumOf { it.bytes.total }
                if (rest > 0) Box(Modifier.weight(rest.toFloat()).fillMaxHeight().background(c.textMuted.copy(alpha = 0.4f)))
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "الأرقام دي بتتوزع من استهلاك ${Config.TARGET_SSID} المظبوط حسب سجل أندرويد لكل تطبيق، فمجموعها = اللي في التقويم.",
                style = OrbitType.caption, color = c.textMuted,
            )
        }
        Spacer(Modifier.height(12.dp))
        if (list.isEmpty()) {
            NoticeCard(OrbitIcons.Info, "لسه مفيش استهلاك", "أول ما تستخدم النت على ${Config.TARGET_SSID} التطبيقات هتظهر هنا.", c.cyan)
        }
        val max = list.firstOrNull()?.bytes?.total?.coerceAtLeast(1L) ?: 1L
        list.take(40).forEachIndexed { i, a ->
            AppRow(a, total, max, accent, Modifier.enter(3 + minOf(i, 10)))
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun AppRow(a: AppUse, total: Long, max: Long, accent: Color, modifier: Modifier) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val icon = remember(a.pkg) { a.pkg?.let { AppStats.icon(ctx, it) } }
    val share = if (total > 0) (a.bytes.total * 1000 / total) / 10.0 else 0.0
    val f by animateFloatAsState((a.bytes.total.toFloat() / max).coerceIn(0f, 1f), tween(800, easing = FastOutSlowInEasing), label = "app")
    GlassCard(modifier.fillMaxWidth(), padding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Image(icon.asImageBitmap(), null, Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)))
            } else {
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                ) { Text(a.label.take(1), style = OrbitType.subtitle, color = accent) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(a.label, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    Spacer(Modifier.width(6.dp))
                    Text(String.format(java.util.Locale.US, "%.1f٪", share), style = OrbitType.caption, color = c.textMuted)
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
                    if (f > 0f) Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(accent, c.cyan))))
                }
                Spacer(Modifier.height(4.dp))
                Text("↓ ${Fmt.bytes(a.bytes.rx)}   ↑ ${Fmt.bytes(a.bytes.tx)}", style = OrbitType.caption.copy(fontFeatureSettings = "tnum"), color = c.textMuted)
            }
            Spacer(Modifier.width(10.dp))
            Text(Fmt.bytes(a.bytes.total), style = OrbitType.numericSmall, color = c.text)
        }
    }
}

/** Admin view of someone's top apps (as reported by their phone). */
@Composable
fun ReportedApps(today: List<Pair<String, Long>>, month: List<Pair<String, Long>>, accent: Color, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    var showMonth by rememberSaveable { mutableStateOf(false) }
    val list = if (showMonth) month else today
    GlassCard(modifier.fillMaxWidth()) {
        Text("أكتر التطبيقات", style = OrbitType.title, color = c.text)
        Spacer(Modifier.height(8.dp))
        Segmented(listOf(false to "النهارده", true to "الشهر"), showMonth, { showMonth = it }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        if (list.isEmpty()) {
            Text("لسه مفيش بيانات (محتاج نسخة 2.6 وإذن سجل الاستهلاك على موبايله).", style = OrbitType.caption, color = c.textMuted)
        }
        val max = list.maxOfOrNull { it.second }?.coerceAtLeast(1L) ?: 1L
        list.forEach { (name, bytes) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                    Text(name.take(1), style = OrbitType.label, color = accent)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, style = OrbitType.label, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
                        Box(Modifier.fillMaxWidth(bytes.toFloat() / max).fillMaxHeight().clip(RoundedCornerShape(50)).background(accent))
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text(Fmt.bytes(bytes), style = OrbitType.numericSmall, color = c.text)
            }
        }
    }
}
