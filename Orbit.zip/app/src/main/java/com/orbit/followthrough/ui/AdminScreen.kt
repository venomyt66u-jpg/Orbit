package com.orbit.followthrough.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Claim
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.domain.Snapshot
import com.orbit.followthrough.meter.MeterService
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.ScreenHeader
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate

/** One person as the admin sees them. */
private data class Member(
    val person: Person,
    val claim: Claim?,
    val report: Snapshot?,
    val days: Map<String, Bytes>,
    val lastAt: Long,
    val onTargetNow: Boolean,
)

@Composable
fun AdminScreen(profile: Profile, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val c = Orbit.colors
    val scope = rememberCoroutineScope()
    val version by DataVersion.flow.collectAsState()
    val (now, _) = rememberLive()
    val nowState = androidx.compose.runtime.rememberUpdatedState(now)
    var period by rememberSaveable { mutableStateOf(Period.TODAY) }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    var syncing by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        MeterService.start(ctx)
        while (true) {
            syncing = true
            online = SyncEngine.sync(ctx, onTarget = nowState.value.onTarget)
            syncing = false
            delay(120_000)
        }
    }

    val today = LocalDate.now()
    val rows = remember(version) {
        val claims = profile.claims()
        val reports = profile.reports()
        val t = System.currentTimeMillis()
        val members = People.map { p ->
            val r = reports[p.slot]
            Member(p, claims[p.slot], r, r?.days ?: emptyMap(), r?.at ?: 0L, r != null && r.onTarget && t - r.at < 70 * 60_000L)
        }
        val mine = Member(AdminPerson, null, null, UsageStore(ctx).days(), t, now.onTarget)
        members + mine
    }

    val selected = rows.firstOrNull { it.person.slot == open }
    if (selected != null) {
        BackHandler { open = null }
        PersonDetail(selected, today, onBack = { open = null })
    } else {
        AdminList(profile, rows, period, { period = it }, syncing, online, onRefresh = {
            if (!syncing) scope.launch {
                syncing = true
                online = SyncEngine.sync(ctx, force = true, onTarget = nowState.value.onTarget)
                syncing = false
            }
        }, onSettings = onSettings, onOpen = { open = it })
    }
}

@Composable
private fun AdminList(
    profile: Profile,
    rows: List<Member>,
    period: Period,
    onPeriod: (Period) -> Unit,
    syncing: Boolean,
    online: Boolean,
    onRefresh: () -> Unit,
    onSettings: () -> Unit,
    onOpen: (String) -> Unit,
) {
    val c = Orbit.colors
    val today = LocalDate.now()
    val (from, to) = Days.range(period, today)
    val usage = rows.associate { it.person.slot to Days.sum(it.days, from, to).total }
    val total = usage.values.sum()
    val max = usage.values.maxOrNull()?.coerceAtLeast(1L) ?: 1L

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        ScreenHeader(title = "لوحة الأدمن", subtitle = "شبكة ${Config.TARGET_SSID}") {
            IconCircle(OrbitIcons.Refresh, "تحديث", onRefresh, tint = if (syncing) c.cyan else c.text)
            Spacer(Modifier.width(10.dp))
            IconCircle(OrbitIcons.Settings, "الأذونات", onSettings)
        }
        Spacer(Modifier.height(8.dp))

        if (!online) {
            NoticeCard(OrbitIcons.Info, "مفيش إنترنت", "بعرض آخر أرقام وصلت. هحدّث أول ما النت يرجع.", c.rose)
            Spacer(Modifier.height(12.dp))
        }

        Segmented(
            options = listOf(Period.TODAY to "النهارده", Period.WEEK to "٧ أيام", Period.CYCLE to "الشهر ده"),
            selected = period,
            onSelect = onPeriod,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(14.dp))

        // Total + share of the network.
        GlassCard(Modifier.fillMaxWidth()) {
            Text("إجمالي استهلاك ${Config.TARGET_SSID}", style = OrbitType.label, color = c.textSecondary)
            BigBytes(total)
            Spacer(Modifier.height(12.dp))
            val parts = rows.filter { (usage[it.person.slot] ?: 0L) > 0 }
            Row(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
                parts.forEach { r ->
                    Box(Modifier.weight((usage[r.person.slot] ?: 0L).toFloat().coerceAtLeast(0.0001f)).fillMaxHeight().background(r.person.accent))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("آخر تحديث: ${Ar.ago(profile.lastSync)}", style = OrbitType.caption, color = c.textMuted)
        }
        Spacer(Modifier.height(14.dp))

        rows.sortedByDescending { usage[it.person.slot] ?: 0L }.forEach { r ->
            PersonRow(r, usage[r.person.slot] ?: 0L, max, total) { onOpen(r.person.slot) }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(18.dp))
    }
}

private fun status(r: Member): String = when {
    r.person.slot == Config.ADMIN_SLOT -> "الموبايل ده"
    r.claim == null -> "لسه محدش اختاره"
    r.report == null -> "اختاره · لسه مابعتش أرقام"
    else -> "آخر تحديث ${Ar.ago(r.lastAt)}"
}

@Composable
private fun PersonRow(r: Member, bytes: Long, max: Long, total: Long, onClick: () -> Unit) {
    val c = Orbit.colors
    val share = if (total > 0) (bytes * 100 / total).toInt() else 0
    GlassCard(Modifier.fillMaxWidth(), onClick = onClick, padding = androidx.compose.foundation.layout.PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(r.person, 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.person.name, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (r.onTargetNow) {
                        Spacer(Modifier.width(6.dp))
                        Tag("على ${Config.TARGET_SSID}", c.green)
                    }
                }
                Text(status(r), style = OrbitType.caption, color = c.textMuted, maxLines = 1)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
                    Box(
                        Modifier
                            .fillMaxWidth((bytes.toFloat() / max).coerceIn(0f, 1f))
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(50))
                            .background(r.person.accent),
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.bytes(bytes), style = OrbitType.numericSmall, color = c.text, maxLines = 1)
                Text("$share٪", style = OrbitType.caption, color = c.textSecondary)
            }
        }
    }
}

@Composable
private fun PersonDetail(r: Member, today: LocalDate, onBack: () -> Unit) {
    val c = Orbit.colors
    val (wf, wt) = Days.range(Period.WEEK, today)
    val (mf, mt) = Days.range(Period.CYCLE, today)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        TopBar(r.person.name, onBack, "رجوع")
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(r.person, 84.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(r.person.name, style = OrbitType.headline, color = c.text)
                Text(status(r), style = OrbitType.caption, color = c.textSecondary)
                if (r.onTargetNow) {
                    Spacer(Modifier.height(6.dp))
                    Tag("على ${Config.TARGET_SSID} دلوقتي", c.green)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("النهارده", Days.sum(r.days, today, today.plusDays(1)).total, c.cyan, Modifier.weight(1f))
            StatTile("آخر ٧ أيام", Days.sum(r.days, wf, wt).total, c.violet, Modifier.weight(1f))
            StatTile("الشهر ده", Days.sum(r.days, mf, mt).total, r.person.accent, Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        MonthChart(Days.monthSeries(r.days, today), today, r.person.accent)
        Spacer(Modifier.height(14.dp))
        val prev = today.minusMonths(1)
        val prevTotal = Days.sum(r.days, prev.withDayOfMonth(1), today.withDayOfMonth(1)).total
        if (prevTotal > 0) {
            MonthChart(Days.monthSeries(r.days, prev), prev, r.person.accent)
            Spacer(Modifier.height(14.dp))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("آخر ١٤ يوم", style = OrbitType.subtitle, color = c.text)
            Spacer(Modifier.height(8.dp))
            for (i in 0 until 14) {
                val d = today.minusDays(i.toLong())
                val b = r.days[d.toString()] ?: Bytes.ZERO
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (i == 0) "النهارده" else if (i == 1) "امبارح" else Ar.dayShort(d), style = OrbitType.body, color = c.textSecondary, modifier = Modifier.weight(1f))
                    Text(Fmt.bytes(b.total), style = OrbitType.numericSmall, color = if (b.total > 0) c.text else c.textMuted)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}
