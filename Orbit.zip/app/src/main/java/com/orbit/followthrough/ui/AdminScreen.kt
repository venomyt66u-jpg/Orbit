package com.orbit.followthrough.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Claim
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.domain.Snapshot
import com.orbit.followthrough.meter.Background
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

/** One person as the admin sees them. */
private data class Member(
    val person: Person,
    val claim: Claim?,
    val report: Snapshot?,
    val days: Map<String, Bytes>,
    val lastAt: Long,
    val onTargetNow: Boolean,
)

@Composable
fun AdminScreen(profile: Profile, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val version by DataVersion.flow.collectAsState()
    val (now, _) = rememberLive()
    val nowState = rememberUpdatedState(now)
    var period by rememberSaveable { mutableStateOf(Period.TODAY) }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    var syncing by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        runCatching { Background.schedule(ctx) }
        while (true) {
            syncing = true
            online = SyncEngine.sync(ctx, onTarget = nowState.value.onTarget)
            syncing = false
            delay(120_000)
        }
    }

    val members = remember(version, now.onTarget) {
        val claims = profile.claims()
        val reports = profile.reports()
        val t = System.currentTimeMillis()
        val list = People.map { p ->
            val r = reports[p.slot]
            Member(p, claims[p.slot], r, r?.days ?: emptyMap(), r?.at ?: 0L, r != null && r.onTarget && t - r.at < 70 * 60_000L)
        }
        list + Member(AdminPerson, null, null, UsageStore(ctx).days(), t, now.onTarget)
    }

    AnimatedContent(
        targetState = open,
        transitionSpec = {
            if (targetState != null) (slideInHorizontally { -it / 4 } + fadeIn()) togetherWith fadeOut()
            else fadeIn() togetherWith (slideOutHorizontally { -it / 4 } + fadeOut())
        },
        label = "admin",
    ) { slot ->
        val m = members.firstOrNull { it.person.slot == slot }
        if (m != null) {
            BackHandler { open = null }
            PersonDetail(m, onBack = { open = null })
        } else {
            AdminHome(
                profile, members, period, { period = it }, syncing, online,
                onRefresh = {
                    if (!syncing) scope.launch {
                        syncing = true
                        online = SyncEngine.sync(ctx, force = true, onTarget = nowState.value.onTarget)
                        syncing = false
                    }
                },
                onSettings = onSettings,
                onOpen = { open = it },
            )
        }
    }
}

@Composable
private fun AdminHome(
    profile: Profile,
    members: List<Member>,
    period: Period,
    onPeriod: (Period) -> Unit,
    syncing: Boolean,
    online: Boolean,
    onRefresh: () -> Unit,
    onSettings: () -> Unit,
    onOpen: (String) -> Unit,
) {
    val c = Orbit.colors
    val today = LocalDate.now()
    val (from, to) = Days.range(period, today)
    val usage = members.associate { it.person.slot to Days.sum(it.days, from, to).total }
    val total = usage.values.sum()
    val max = usage.values.maxOrNull()?.coerceAtLeast(1L) ?: 1L
    // Whole network per day = everyone added together.
    val networkDays = remember(members) {
        val out = HashMap<String, Bytes>()
        members.forEach { m -> m.days.forEach { (k, v) -> out[k] = (out[k] ?: Bytes.ZERO) + v } }
        out
    }
    var month by rememberSaveable { mutableStateOf(YearMonth.from(today)) }
    var day by rememberSaveable { mutableStateOf(today) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Header(title = "لوحة الأدمن", subtitle = "شبكة ${Config.TARGET_SSID}", person = AdminPerson, onSettings = onSettings) {
            if (syncing) CircularProgressIndicator(color = c.cyan, strokeWidth = 2.dp, modifier = Modifier.padding(end = 4.dp).width(22.dp).height(22.dp))
            else IconCircle(OrbitIcons.Refresh, "تحديث", onRefresh)
            Spacer(Modifier.width(10.dp))
        }
        Spacer(Modifier.height(10.dp))

        if (!online) {
            NoticeCard(OrbitIcons.Info, "مفيش إنترنت", "بعرض آخر أرقام وصلت، وهحدّث أول ما النت يرجع.", c.rose)
            Spacer(Modifier.height(12.dp))
        }

        Segmented(
            options = listOf(Period.TODAY to "النهارده", Period.WEEK to "٧ أيام", Period.CYCLE to "الشهر ده"),
            selected = period,
            onSelect = onPeriod,
            modifier = Modifier.fillMaxWidth().enter(1),
        )
        Spacer(Modifier.height(14.dp))

        GlassCard(Modifier.fillMaxWidth().enter(2)) {
            Text("إجمالي استهلاك ${Config.TARGET_SSID}", style = OrbitType.label, color = c.textSecondary)
            AnimatedBytes(total)
            Spacer(Modifier.height(12.dp))
            ShareBar(members, usage)
            Spacer(Modifier.height(8.dp))
            Text("آخر تحديث: ${Ar.ago(profile.lastSync)}", style = OrbitType.caption, color = c.textMuted)
        }
        Spacer(Modifier.height(14.dp))

        members.sortedByDescending { usage[it.person.slot] ?: 0L }.forEachIndexed { i, m ->
            PersonRow(m, usage[m.person.slot] ?: 0L, max, total, Modifier.enter(3 + i)) { onOpen(m.person.slot) }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(8.dp))
        Text("تقويم الشبكة", style = OrbitType.title, color = c.text, modifier = Modifier.padding(vertical = 6.dp))
        UsageCalendar(month, networkDays, day, c.cyan, onSelect = { day = it }, onMonth = { month = it })
        Spacer(Modifier.height(12.dp))
        AnimatedContent(targetState = day, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "day") { d ->
            DayDetail(
                date = d,
                bytes = networkDays[d.toString()] ?: Bytes.ZERO,
                average = dailyAverage(networkDays, today),
                accent = c.cyan,
            ) {
                val parts = members.map { it to (it.days[d.toString()]?.total ?: 0L) }.filter { it.second > 0 }.sortedByDescending { it.second }
                if (parts.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text("مين استهلك اليوم ده", style = OrbitType.label, color = c.textSecondary)
                    Spacer(Modifier.height(6.dp))
                    val dayMax = parts.first().second
                    parts.forEach { (m, v) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(m.person, 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(m.person.name, style = OrbitType.label, color = c.text)
                                Spacer(Modifier.height(4.dp))
                                Bar(v.toFloat() / dayMax, m.person.accent)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(Fmt.bytes(v), style = OrbitType.numericSmall, color = c.text)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun ShareBar(members: List<Member>, usage: Map<String, Long>) {
    val c = Orbit.colors
    val parts = members.filter { (usage[it.person.slot] ?: 0L) > 0 }
    Row(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
        parts.forEach { m ->
            Box(Modifier.weight((usage[m.person.slot] ?: 0L).toFloat().coerceAtLeast(0.0001f)).fillMaxHeight().background(m.person.accent))
        }
    }
}

@Composable
private fun Bar(fraction: Float, color: androidx.compose.ui.graphics.Color) {
    val c = Orbit.colors
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(800, easing = FastOutSlowInEasing), label = "bar")
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
        if (f > 0f) Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

private fun status(m: Member): String = when {
    m.person.slot == Config.ADMIN_SLOT -> "الموبايل ده"
    m.claim == null -> "لسه محدش اختاره"
    m.report == null -> "اختاره · لسه مابعتش أرقام"
    else -> "آخر تحديث ${Ar.ago(m.lastAt)}"
}

@Composable
private fun PersonRow(m: Member, bytes: Long, max: Long, total: Long, modifier: Modifier, onClick: () -> Unit) {
    val c = Orbit.colors
    val share = if (total > 0) (bytes * 100 / total).toInt() else 0
    GlassCard(modifier.fillMaxWidth(), onClick = onClick, padding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(m.person, 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.person.name, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (m.onTargetNow) {
                        Spacer(Modifier.width(6.dp))
                        Tag("على ${Config.TARGET_SSID}", c.green)
                    }
                }
                Text(status(m), style = OrbitType.caption, color = c.textMuted, maxLines = 1)
                Spacer(Modifier.height(8.dp))
                Bar(bytes.toFloat() / max, m.person.accent)
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.bytes(bytes), style = OrbitType.numericSmall, color = c.text, maxLines = 1)
                Text("$share٪", style = OrbitType.caption, color = c.textSecondary)
            }
        }
    }
}

@Composable
private fun PersonDetail(m: Member, onBack: () -> Unit) {
    val c = Orbit.colors
    val today = LocalDate.now()
    val (wf, wt) = Days.range(Period.WEEK, today)
    val (mf, mt) = Days.range(Period.CYCLE, today)
    var month by rememberSaveable { mutableStateOf(YearMonth.from(today)) }
    var day by rememberSaveable { mutableStateOf(today) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        TopBar(m.person.name, onBack, "رجوع")
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.enter(0)) {
            Avatar(m.person, 84.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(m.person.name, style = OrbitType.headline, color = c.text)
                Text(status(m), style = OrbitType.caption, color = c.textSecondary)
                if (m.onTargetNow) {
                    Spacer(Modifier.height(6.dp))
                    Tag("على ${Config.TARGET_SSID} دلوقتي", c.green)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.enter(1)) {
            StatTile("النهارده", Days.sum(m.days, today, today.plusDays(1)).total, c.cyan, Modifier.weight(1f))
            StatTile("آخر ٧ أيام", Days.sum(m.days, wf, wt).total, c.violet, Modifier.weight(1f))
            StatTile("الشهر ده", Days.sum(m.days, mf, mt).total, m.person.accent, Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        UsageCalendar(month, m.days, day, m.person.accent, onSelect = { day = it }, onMonth = { month = it }, modifier = Modifier.enter(2))
        Spacer(Modifier.height(12.dp))
        AnimatedContent(targetState = day, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "day") { d ->
            DayDetail(
                date = d,
                bytes = m.days[d.toString()] ?: Bytes.ZERO,
                average = dailyAverage(m.days, today),
                accent = m.person.accent,
                hours = if (m.person.slot == Config.ADMIN_SLOT) hoursOf(UsageStore(LocalContext.current).hours(), d) else null,
            )
        }
        Spacer(Modifier.height(28.dp))
    }
}
