package com.orbit.followthrough.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.data.Config
import com.orbit.followthrough.data.DataVersion
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.data.SyncEngine
import com.orbit.followthrough.data.UsageStore
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Claim
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Fmt
import com.orbit.followthrough.domain.Package
import com.orbit.followthrough.domain.Period
import com.orbit.followthrough.domain.Snapshot
import com.orbit.followthrough.meter.Background
import com.orbit.followthrough.meter.Need
import com.orbit.followthrough.meter.Perms
import com.orbit.followthrough.ui.components.GlassCard
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

/** One person as the admin sees them. */
private data class Member(
    val person: Person,
    val claim: Claim?,
    val report: Snapshot?,
    val days: Map<String, Bytes>,
    val lastAt: Long,
    val onTargetNow: Boolean,
    val past: Map<String, Bytes> = emptyMap(),
)

@Composable
fun AdminScreen(profile: Profile, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val version by DataVersion.flow.collectAsState()
    val (now, _) = rememberLive()
    val nowState = rememberUpdatedState(now)
    var period by rememberSaveable { mutableStateOf(Period.TODAY) }
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    var syncing by remember { mutableStateOf(false) }
    var online by remember { mutableStateOf(true) }
    var askNewPackage by remember { mutableStateOf(false) }
    val pkgStart = remember(version) { profile.packageStart }
    val pkgHistory = remember(version) { profile.packageStarts() }

    LaunchedEffect(Unit) {
        runCatching { Background.schedule(ctx) }
        while (true) {
            syncing = true
            online = SyncEngine.sync(ctx, onTarget = nowState.value.onTarget)
            syncing = false
            delay(120_000)
        }
    }

    val members = remember(version, now.onTarget) {
        val claims = profile.claims()
        val reports = profile.reports()
        val t = System.currentTimeMillis()
        val list = People.map { p ->
            val r = reports[p.slot]
            Member(p, claims[p.slot], r, r?.days ?: emptyMap(), r?.at ?: 0L, r != null && r.onTarget && t - r.at < 70 * 60_000L, r?.past ?: emptyMap())
        }
        val mine = UsageStore(ctx)
        list + Member(AdminPerson, null, null, mine.days(), t, now.onTarget, mine.past())
    }

    AnimatedContent(
        targetState = open,
        transitionSpec = {
            if (targetState != null) (slideInHorizontally { -it / 4 } + fadeIn()) togetherWith fadeOut()
            else fadeIn() togetherWith (slideOutHorizontally { -it / 4 } + fadeOut())
        },
        label = "admin",
    ) { slot ->
        val m = members.firstOrNull { it.person.slot == slot }
        if (m != null) {
            BackHandler { open = null }
            PersonDetail(m, pkgHistory, onBack = { open = null })
        } else {
            AdminHome(
                profile, members, period, { period = it }, syncing, online,
                onRefresh = {
                    if (!syncing) scope.launch {
                        syncing = true
                        online = SyncEngine.sync(ctx, force = true, onTarget = nowState.value.onTarget)
                        syncing = false
                    }
                },
                onSettings = onSettings,
                onOpen = { open = it },
                pkgStart = pkgStart,
                pkgHistory = pkgHistory,
                onNewPackage = { askNewPackage = true },
            )
        }
    }

    if (askNewPackage) NewPackageDialog(
        onConfirm = {
            askNewPackage = false
            scope.launch {
                syncing = true
                SyncEngine.startPackage(ctx)
                syncing = false
            }
        },
        onDismiss = { askNewPackage = false },
    )
}

/** A person's usage in the current package: exact from their phone when available, otherwise from daily totals. */
private fun packageUse(m: Member, start: Long, ctx: android.content.Context): Pair<Bytes, Boolean> {
    if (start <= 0L) return Bytes.ZERO to false
    if (m.person.slot == Config.ADMIN_SLOT) {
        val store = UsageStore(ctx)
        val (u, exact) = Package.usageSince(start, store.hours(), store.days())
        return u to !exact
    }
    val r = m.report
    if (r != null && r.packageStart == start && r.packageUse != null) return r.packageUse to false
    return Package.usageSince(start, emptyMap(), m.days).first to true
}

private fun marksOf(history: List<Long>): Set<String> {
    val zone = java.time.ZoneId.systemDefault()
    return history.map { java.time.Instant.ofEpochMilli(it).atZone(zone).toLocalDate().toString() }.toSet()
}

private fun noteFor(day: LocalDate, history: List<Long>): String? {
    val zone = java.time.ZoneId.systemDefault()
    val hits = history.filter { java.time.Instant.ofEpochMilli(it).atZone(zone).toLocalDate() == day }
    return if (hits.isEmpty()) null else "باقة جديدة بدأت الساعة " + hits.joinToString(" و") { Ar.time(it) }
}

@Composable
private fun AdminHome(
    profile: Profile,
    members: List<Member>,
    period: Period,
    onPeriod: (Period) -> Unit,
    syncing: Boolean,
    online: Boolean,
    onRefresh: () -> Unit,
    onSettings: () -> Unit,
    onOpen: (String) -> Unit,
    pkgStart: Long,
    pkgHistory: List<Long>,
    onNewPackage: () -> Unit,
) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val today = LocalDate.now()
    val effective = if (period == Period.PACKAGE && pkgStart <= 0L) Period.CYCLE else period
    val (from, to) = Days.range(effective, today)
    val pkg = remember(members, pkgStart) { members.associate { it.person.slot to packageUse(it, pkgStart, ctx) } }
    val usage = if (effective == Period.PACKAGE) pkg.mapValues { it.value.first.total }
    else members.associate { it.person.slot to Days.sum(it.days, from, to).total }
    val marks = remember(pkgHistory) { marksOf(pkgHistory) }
    val total = usage.values.sum()
    val max = usage.values.maxOrNull()?.coerceAtLeast(1L) ?: 1L
    // Whole network per day = everyone added together.
    val networkDays = remember(members) {
        val out = HashMap<String, Bytes>()
        members.forEach { m -> m.days.forEach { (k, v) -> out[k] = (out[k] ?: Bytes.ZERO) + v } }
        out
    }
    var month by rememberSaveable { mutableStateOf(YearMonth.from(today)) }
    var day by rememberSaveable { mutableStateOf(today) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Header(title = "لوحة الأدمن", subtitle = "شبكة ${Config.TARGET_SSID}", person = AdminPerson, onSettings = onSettings) {
            if (syncing) CircularProgressIndicator(color = c.cyan, strokeWidth = 2.dp, modifier = Modifier.padding(end = 4.dp).width(22.dp).height(22.dp))
            else IconCircle(OrbitIcons.Refresh, "تحديث", onRefresh)
            Spacer(Modifier.width(10.dp))
        }
        Spacer(Modifier.height(10.dp))

        val closed = members.filter { !it.report?.missing.isNullOrEmpty() }
        if (closed.isNotEmpty()) {
            NoticeCard(
                OrbitIcons.Shield, "${closed.size} قافلين أذونات",
                closed.joinToString("\n") { m -> m.person.name + ": " + m.report!!.missing!!.mapNotNull { Need.of(it)?.label }.joinToString("، ") } +
                    "\nاستهلاكهم وقت ما الإذن مقفول بيتحسب لوحده كـ«غير مؤكد».",
                c.amber,
            )
            Spacer(Modifier.height(12.dp))
        }
        if (!online) {
            NoticeCard(OrbitIcons.Info, "مفيش إنترنت", "بعرض آخر أرقام وصلت، وهحدّث أول ما النت يرجع.", c.rose)
            Spacer(Modifier.height(12.dp))
        }

        PackageCard(
            start = pkgStart,
            usage = pkg.values.fold(Bytes.ZERO) { a, b -> a + b.first },
            approximate = pkg.values.any { it.second },
            usageLabel = "استهلاك الكل في الباقة",
            history = pkgHistory,
            modifier = Modifier.enter(1),
            onNewPackage = onNewPackage,
        )
        Spacer(Modifier.height(14.dp))

        Segmented(
            options = listOf(
                Period.TODAY to "النهارده",
                Period.WEEK to "٧ أيام",
                if (pkgStart > 0L) Period.PACKAGE to "الباقة" else Period.CYCLE to "الشهر ده",
            ),
            selected = effective,
            onSelect = onPeriod,
            modifier = Modifier.fillMaxWidth().enter(1),
        )
        Spacer(Modifier.height(14.dp))

        GlassCard(Modifier.fillMaxWidth().enter(2)) {
            Text("إجمالي استهلاك ${Config.TARGET_SSID}", style = OrbitType.label, color = c.textSecondary)
            AnimatedBytes(total)
            Spacer(Modifier.height(12.dp))
            ShareBar(members, usage)
            Spacer(Modifier.height(8.dp))
            Text("آخر تحديث: ${Ar.ago(profile.lastSync)}", style = OrbitType.caption, color = c.textMuted)
        }
        Spacer(Modifier.height(14.dp))

        members.sortedByDescending { usage[it.person.slot] ?: 0L }.forEachIndexed { i, m ->
            PersonRow(m, usage[m.person.slot] ?: 0L, max, total, Modifier.enter(3 + i)) { onOpen(m.person.slot) }
            Spacer(Modifier.height(10.dp))
        }

        Spacer(Modifier.height(8.dp))
        Text("تقويم الشبكة", style = OrbitType.title, color = c.text, modifier = Modifier.padding(vertical = 6.dp))
        UsageCalendar(month, networkDays, day, c.cyan, onSelect = { day = it }, onMonth = { month = it }, marks = marks)
        Spacer(Modifier.height(12.dp))
        AnimatedContent(targetState = day, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "day") { d ->
            DayDetail(
                date = d,
                bytes = networkDays[d.toString()] ?: Bytes.ZERO,
                average = dailyAverage(networkDays, today),
                accent = c.cyan,
                note = noteFor(d, pkgHistory),
            ) {
                val parts = members.map { it to (it.days[d.toString()]?.total ?: 0L) }.filter { it.second > 0 }.sortedByDescending { it.second }
                if (parts.isNotEmpty()) {
                    Spacer(Modifier.height(14.dp))
                    Text("مين استهلك اليوم ده", style = OrbitType.label, color = c.textSecondary)
                    Spacer(Modifier.height(6.dp))
                    val dayMax = parts.first().second
                    parts.forEach { (m, v) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(m.person, 32.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(m.person.name, style = OrbitType.label, color = c.text)
                                Spacer(Modifier.height(4.dp))
                                Bar(v.toFloat() / dayMax, m.person.accent)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(Fmt.bytes(v), style = OrbitType.numericSmall, color = c.text)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun ShareBar(members: List<Member>, usage: Map<String, Long>) {
    val c = Orbit.colors
    val parts = members.filter { (usage[it.person.slot] ?: 0L) > 0 }
    Row(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
        parts.forEach { m ->
            Box(Modifier.weight((usage[m.person.slot] ?: 0L).toFloat().coerceAtLeast(0.0001f)).fillMaxHeight().background(m.person.accent))
        }
    }
}

@Composable
private fun Bar(fraction: Float, color: androidx.compose.ui.graphics.Color) {
    val c = Orbit.colors
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(800, easing = FastOutSlowInEasing), label = "bar")
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(c.stroke)) {
        if (f > 0f) Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

private fun status(m: Member): String = when {
    m.person.slot == Config.ADMIN_SLOT -> "الموبايل ده"
    m.claim == null -> "لسه محدش اختاره"
    m.report == null -> "اختاره · لسه مابعتش أرقام"
    else -> "آخر تحديث ${Ar.ago(m.lastAt)}"
}

@Composable
private fun PersonRow(m: Member, bytes: Long, max: Long, total: Long, modifier: Modifier, onClick: () -> Unit) {
    val c = Orbit.colors
    val share = if (total > 0) (bytes * 100 / total).toInt() else 0
    GlassCard(modifier.fillMaxWidth(), onClick = onClick, padding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(m.person, 52.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.person.name, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (m.onTargetNow) {
                        Spacer(Modifier.width(6.dp))
                        Tag("على ${Config.TARGET_SSID}", c.green)
                    }
                }
                Text(status(m), style = OrbitType.caption, color = c.textMuted, maxLines = 1)
                val miss = m.report?.missing.orEmpty()
                if (miss.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Tag("قافل: " + miss.mapNotNull { Need.of(it)?.label }.joinToString("، "), c.amber, icon = OrbitIcons.Shield)
                }
                Spacer(Modifier.height(8.dp))
                Bar(bytes.toFloat() / max, m.person.accent)
            }
            Spacer(Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(Fmt.bytes(bytes), style = OrbitType.numericSmall, color = c.text, maxLines = 1)
                Text("$share٪", style = OrbitType.caption, color = c.textSecondary)
            }
        }
    }
}

@Composable
private fun PersonDetail(m: Member, pkgHistory: List<Long>, onBack: () -> Unit) {
    val c = Orbit.colors
    val today = LocalDate.now()
    val (wf, wt) = Days.range(Period.WEEK, today)
    val (mf, mt) = Days.range(Period.CYCLE, today)
    var month by rememberSaveable { mutableStateOf(YearMonth.from(today)) }
    var day by rememberSaveable { mutableStateOf(today) }
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        TopBar(m.person.name, onBack, "رجوع")
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.enter(0)) {
            Avatar(m.person, 84.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(m.person.name, style = OrbitType.headline, color = c.text)
                Text(status(m), style = OrbitType.caption, color = c.textSecondary)
                if (m.onTargetNow) {
                    Spacer(Modifier.height(6.dp))
                    Tag("على ${Config.TARGET_SSID} دلوقتي", c.green)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.enter(1)) {
            StatTile("النهارده", Days.sum(m.days, today, today.plusDays(1)).total, c.cyan, Modifier.weight(1f))
            StatTile("آخر ٧ أيام", Days.sum(m.days, wf, wt).total, c.violet, Modifier.weight(1f))
            StatTile("الشهر ده", Days.sum(m.days, mf, mt).total, m.person.accent, Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        DeviceCard(m, Modifier.enter(2))
        Spacer(Modifier.height(14.dp))
        UsageCalendar(month, m.days, day, m.person.accent, onSelect = { day = it }, onMonth = { month = it }, modifier = Modifier.enter(2), past = m.past, marks = marksOf(pkgHistory))
        Spacer(Modifier.height(12.dp))
        AnimatedContent(targetState = day, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "day") { d ->
            DayDetail(
                date = d,
                bytes = m.days[d.toString()] ?: Bytes.ZERO,
                average = dailyAverage(m.days, today),
                accent = m.person.accent,
                hours = when {
                    m.person.slot == Config.ADMIN_SLOT -> hoursOf(UsageStore(LocalContext.current).hours(), d)
                    d == today && m.report?.todayHours?.size == 24 -> m.report!!.todayHours
                    else -> null
                },
                past = m.past[d.toString()],
                note = noteFor(d, pkgHistory),
            )
        }
        Spacer(Modifier.height(28.dp))
    }
}

/** Phone details and health for one person: model, app version, last report, permissions, unverified usage. */
@Composable
private fun DeviceCard(m: Member, modifier: Modifier = Modifier) {
    val c = Orbit.colors
    val r = m.report
    val ctx = LocalContext.current
    val isMe = m.person.slot == Config.ADMIN_SLOT
    val missing = if (isMe) Perms.missingKeys(ctx) else r?.missing
    val unverified = if (isMe) UsageStore(ctx).unverified() else r?.unverified.orEmpty()
    val today = LocalDate.now()
    val unvMonth = Days.sum(unverified, today.withDayOfMonth(1), today.withDayOfMonth(1).plusMonths(1)).total
    GlassCard(modifier.fillMaxWidth()) {
        Text("الجهاز", style = OrbitType.title, color = c.text)
        Spacer(Modifier.height(8.dp))
        InfoLine("الموبايل", if (isMe) (android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL) else r?.model?.ifBlank { null } ?: "—")
        InfoLine("نسخة التطبيق", if (isMe) com.orbit.followthrough.BuildConfig.VERSION_NAME else r?.version?.ifBlank { null } ?: "قديمة")
        InfoLine("آخر تقرير", if (isMe) "دلوقتي" else if (r == null) "لسه" else Ar.ago(r.at) + " · " + Ar.time(r.at))
        InfoLine(
            "الأذونات",
            when {
                missing == null -> "مش معروف (نسخة قديمة)"
                missing.isEmpty() -> "كلها شغالة ✓"
                else -> "قافل: " + missing.mapNotNull { Need.of(it)?.label }.joinToString("، ")
            },
            if (missing.isNullOrEmpty()) c.green else c.amber,
        )
        if (unvMonth > 0) {
            InfoLine("غير مؤكد الشهر ده", Fmt.bytes(unvMonth), c.amber)
            Text(
                "استهلاك على راوتر شبه ${Config.TARGET_SSID} بس اسم الشبكة ماتقراش (الإذن كان مقفول). مش داخل في الإجمالي.",
                style = OrbitType.caption, color = c.textMuted,
            )
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String, tone: androidx.compose.ui.graphics.Color = Orbit.colors.text) {
    val c = Orbit.colors
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = OrbitType.body, color = c.textSecondary, modifier = Modifier.weight(1f))
        Text(value, style = OrbitType.label, color = tone, maxLines = 2)
    }
}
