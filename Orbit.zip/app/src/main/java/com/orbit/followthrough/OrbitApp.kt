package com.orbit.followthrough

import android.app.Application
import android.content.Context
import androidx.work.WorkManager
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.meter.Background

class OrbitApp : Application() {

    override fun onCreate() {
        super.onCreate()
        cleanUpOldVersions()
        if (Profile(this).slot != null) runCatching { Background.schedule(this) }
    }

    private fun cleanUpOldVersions() {
        val p = getSharedPreferences("app", Context.MODE_PRIVATE)
        val schema = p.getInt("schema", 0)
        if (schema < 2) {
            // 1.x was a reminders app: drop its database, jobs and settings.
            runCatching { WorkManager.getInstance(this).cancelAllWork() }
            runCatching { deleteDatabase("orbit.db") }
            runCatching { java.io.File(filesDir, "datastore").deleteRecursively() }
        }
        if (schema < 3) {
            // 2.0 counted with a foreground service + notification; 2.1 needs neither.
            Background.removeOldNotifications(this)
        }
        if (schema < 3) p.edit().putInt("schema", 3).apply()
    }
}
