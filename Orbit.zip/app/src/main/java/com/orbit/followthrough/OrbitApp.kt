package com.orbit.followthrough

import android.app.Application
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class OrbitApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        val c = container
        c.appScope.launch {
            // Keep notification channels in sync with the user's sound / vibration choices.
            c.settings.settings
                .map { it.channelStyles }
                .distinctUntilChanged()
                .collect { c.channels.ensure(c.settings.current()) }
        }
        c.appScope.launch {
            runCatching { c.seedIfNeeded() }
            // Defensive re-sync: restores alarms that may have been cleared by a force-stop.
            runCatching { c.reminderEngine.rescheduleAll() }
            runCatching { c.habitEngine.rescheduleAll() }
            runCatching { c.signals.schedulePeriodic() }
            runCatching { c.runMaintenance() }
            runCatching { c.market.seedIfNeeded() }
            runCatching { com.orbit.followthrough.watch.WatchRunner.reschedule(c) }
        }
    }
}
