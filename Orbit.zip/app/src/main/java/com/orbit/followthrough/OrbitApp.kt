package com.orbit.followthrough

import android.app.Application
import android.content.Context
import androidx.work.WorkManager
import com.orbit.followthrough.data.Profile
import com.orbit.followthrough.meter.MeterWorker
import com.orbit.followthrough.meter.Notifications

class OrbitApp : Application() {

    override fun onCreate() {
        super.onCreate()
        cleanUpOldVersion()
        Notifications.ensureChannels(this)
        if (Profile(this).slot != null) runCatching { MeterWorker.schedule(this) }
    }

    /** Version 2 replaced the old reminders app: drop its database, jobs and settings once. */
    private fun cleanUpOldVersion() {
        val p = getSharedPreferences("app", Context.MODE_PRIVATE)
        if (p.getInt("schema", 0) >= 2) return
        runCatching { WorkManager.getInstance(this).cancelAllWork() }
        runCatching { deleteDatabase("orbit.db") }
        runCatching { java.io.File(filesDir, "datastore").deleteRecursively() }
        p.edit().putInt("schema", 2).apply()
    }
}
