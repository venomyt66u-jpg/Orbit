package com.orbit.followthrough.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.SystemClock
import com.orbit.followthrough.data.db.NetCounterEntity
import com.orbit.followthrough.data.db.NetDeviceEntity
import com.orbit.followthrough.data.db.NetUsageEntity
import com.orbit.followthrough.data.db.NetworkDao
import com.orbit.followthrough.data.prefs.SecretStore
import com.orbit.followthrough.data.prefs.SettingsRepository
import com.orbit.followthrough.domain.UsageMath
import com.orbit.followthrough.notify.Notifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.ConnectException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.time.LocalDate
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

data class LanInfo(val localIp: String, val prefix: Int, val gateway: String?, val onLan: Boolean)
data class Found(val ip: String, val hostname: String?, val latencyMs: Long)

enum class DeviceKind { ROUTER, THIS_PHONE, PHONE, COMPUTER, TV, PRINTER, CONSOLE, SPEAKER, UNKNOWN }

data class ScanState(val running: Boolean = false, val progress: Float = 0f, val lastScanAt: Long? = null, val error: String? = null, val info: LanInfo? = null)

/** A client reported by the router itself (MAC, name, cumulative traffic counters). */
data class RouterClient(val mac: String, val ip: String?, val name: String?, val rxBytes: Long?, val txBytes: Long?)
data class WanUsage(val todayBytes: Long?, val monthBytes: Long?)

/** Router connectors are model specific. Each one is added once its local web API is known. */
interface RouterAdapter {
    val id: String
    suspend fun clients(host: String, user: String, password: String): List<RouterClient>
    suspend fun wanUsage(host: String, user: String, password: String): WanUsage?
}

class AdapterPending(model: String) : IllegalStateException("Connector for $model is being prepared")

/** Greenpacket D2-220G1 (Vodafone Egypt). Wired up as soon as the web UI's request format is captured. */
object GreenpacketD2Adapter : RouterAdapter {
    override val id = "GREENPACKET_D2"
    override suspend fun clients(host: String, user: String, password: String): List<RouterClient> = throw AdapterPending("Greenpacket D2-220G1")
    override suspend fun wanUsage(host: String, user: String, password: String): WanUsage? = throw AdapterPending("Greenpacket D2-220G1")
}

/**
 * Home network section.
 * 1) LAN discovery (works on any router, no login): finds devices that answer on the local subnet.
 * 2) Router connector (model specific): exact client list + per-device traffic → daily/weekly/monthly GB.
 */
class NetworkRepository(
    private val context: Context,
    private val dao: NetworkDao,
    private val settings: SettingsRepository,
    private val secrets: SecretStore,
    private val notifier: Notifier,
) {
    private val _scan = MutableStateFlow(ScanState())
    val scan: StateFlow<ScanState> = _scan.asStateFlow()

    private val ports = intArrayOf(80, 443, 53, 62078, 445, 8080, 7000, 8008, 9100, 22)

    fun lanInfo(): LanInfo? {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return null
        val net = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(net)
        val lp = cm.getLinkProperties(net) ?: return null
        val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address } ?: return null
        val gw = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
        val onLan = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true || caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
        return LanInfo(la.address.hostAddress ?: return null, la.prefixLength, gw, onLan)
    }

    /** Sweeps the local /24 and returns how many devices answered. */
    suspend fun scanLan(notifyNew: Boolean = true): Int = coroutineScope {
        val info = lanInfo()
        if (info == null || !info.onLan) {
            _scan.value = ScanState(error = "not_on_wifi", info = info, lastScanAt = _scan.value.lastScanAt)
            return@coroutineScope 0
        }
        _scan.value = ScanState(running = true, info = info, lastScanAt = _scan.value.lastScanAt)
        val base = info.localIp.substringBeforeLast('.')
        val done = AtomicInteger(0)
        val gate = Semaphore(48)
        val found = (1..254).map { host ->
            async(Dispatchers.IO) {
                gate.withPermit {
                    val ip = "$base.$host"
                    val latency = if (ip == info.localIp) 0L else probe(ip)
                    _scan.value = _scan.value.copy(progress = done.incrementAndGet() / 254f)
                    latency?.let { Found(ip, null, it) }
                }
            }
        }.awaitAll().filterNotNull()

        // Reverse DNS (the router often knows device names); bounded so a slow resolver can't stall.
        val named = found.map { f ->
            async(Dispatchers.IO) {
                val name = withTimeoutOrNull(1500) {
                    async(Dispatchers.IO) { runCatching { InetAddress.getByName(f.ip).canonicalHostName }.getOrNull() }.await()
                }?.takeIf { it != f.ip }
                f.copy(hostname = name)
            }
        }.awaitAll()

        val now = System.currentTimeMillis()
        val known = dao.devices().associateBy { it.deviceKey }
        val hadHistory = known.isNotEmpty()
        val seenKeys = HashSet<String>()
        val upserts = ArrayList<NetDeviceEntity>()
        val newcomers = ArrayList<NetDeviceEntity>()
        for (f in named) {
            val key = "ip:${f.ip}"
            seenKeys += key
            val old = known[key]
            val e = NetDeviceEntity(
                deviceKey = key, alias = old?.alias, hostname = f.hostname ?: old?.hostname, ip = f.ip, mac = old?.mac,
                firstSeen = old?.firstSeen ?: now, lastSeen = now, online = true,
            )
            upserts += e
            if (old == null && f.ip != info.localIp && f.ip != info.gateway) newcomers += e
        }
        known.values.filter { it.deviceKey.startsWith("ip:") && it.deviceKey !in seenKeys && it.online }
            .forEach { upserts += it.copy(online = false) }
        dao.upsertDevices(upserts)
        _scan.value = ScanState(running = false, progress = 1f, lastScanAt = now, info = info)
        if (notifyNew && hadHistory && newcomers.isNotEmpty() && settings.current().watchNewDevices) {
            notifier.showNewDevices(newcomers, settings.current())
        }
        named.size
    }

    private fun probe(ip: String): Long? {
        val start = SystemClock.elapsedRealtime()
        for (port in ports) {
            try {
                Socket().use { s -> s.connect(InetSocketAddress(ip, port), 220) }
                return SystemClock.elapsedRealtime() - start
            } catch (e: ConnectException) {
                // "Connection refused" means a host answered (it just has no service on that port).
                val m = e.message.orEmpty()
                if (m.contains("ECONNREFUSED") || m.contains("refused", ignoreCase = true)) return SystemClock.elapsedRealtime() - start
            } catch (_: Exception) {
            }
        }
        return try {
            if (InetAddress.getByName(ip).isReachable(250)) SystemClock.elapsedRealtime() - start else null
        } catch (_: Exception) {
            null
        }
    }

    fun kindOf(d: NetDeviceEntity, info: LanInfo?): DeviceKind {
        if (info != null && d.ip == info.gateway) return DeviceKind.ROUTER
        if (info != null && d.ip == info.localIp) return DeviceKind.THIS_PHONE
        val h = (d.alias ?: d.hostname ?: "").lowercase(Locale.ROOT)
        return when {
            listOf("iphone", "android", "galaxy", "redmi", "xiaomi", "oppo", "realme", "huawei", "pixel", "phone", "ipad", "honor", "infinix", "tecno", "vivo").any { it in h } -> DeviceKind.PHONE
            listOf("tv", "chromecast", "roku", "firetv", "bravia", "webos", "tizen").any { it in h } -> DeviceKind.TV
            listOf("printer", "hp", "epson", "canon", "brother").any { it in h } -> DeviceKind.PRINTER
            listOf("xbox", "playstation", "ps4", "ps5", "nintendo", "switch").any { it in h } -> DeviceKind.CONSOLE
            listOf("echo", "alexa", "speaker", "homepod", "sonos", "nest").any { it in h } -> DeviceKind.SPEAKER
            listOf("pc", "desktop", "laptop", "macbook", "imac", "windows", "lenovo", "dell", "asus", "acer", "thinkpad").any { it in h } -> DeviceKind.COMPUTER
            else -> DeviceKind.UNKNOWN
        }
    }

    suspend fun rename(key: String, alias: String?) = dao.setAlias(key, alias?.trim()?.ifBlank { null })
    suspend fun forget(key: String) = dao.deleteDevice(key)

    // ------------------------------------------------------------- router connector

    fun adapter(type: String): RouterAdapter? = when (type) {
        GreenpacketD2Adapter.id -> GreenpacketD2Adapter
        else -> null
    }

    /** Pulls clients + counters from the router and converts them into daily usage. */
    suspend fun syncRouter(): String? {
        val s = settings.current()
        val adapter = adapter(s.routerType) ?: return "no_router"
        val pass = secrets.get(SecretStore.Key.ROUTER_PASSWORD) ?: return "no_password"
        return try {
            val clients = adapter.clients(s.routerHost, s.routerUser, pass)
            val now = System.currentTimeMillis()
            val today = LocalDate.now().toEpochDay()
            val known = dao.devices().associateBy { it.deviceKey }
            for (c in clients) {
                val key = "mac:" + c.mac.uppercase(Locale.ROOT)
                val old = known[key]
                dao.upsertDevices(listOf(NetDeviceEntity(key, old?.alias, c.name ?: old?.hostname, c.ip ?: old?.ip ?: "", c.mac, old?.firstSeen ?: now, now, true)))
                if (c.rxBytes != null && c.txBytes != null) {
                    val prev = dao.counter(key)?.let { UsageMath.Counter(it.rx, it.tx) }
                    val d = UsageMath.delta(prev, UsageMath.Counter(c.rxBytes, c.txBytes))
                    dao.upsertCounter(NetCounterEntity(key, c.rxBytes, c.txBytes, now))
                    if (d.rx > 0 || d.tx > 0) {
                        val u = dao.usage(key, today)
                        dao.upsertUsage(NetUsageEntity(key, today, (u?.rxBytes ?: 0) + d.rx, (u?.txBytes ?: 0) + d.tx))
                    }
                }
            }
            null
        } catch (e: AdapterPending) {
            "pending"
        } catch (e: Exception) {
            com.orbit.followthrough.net.Http.reason(e)
        }
    }
}
