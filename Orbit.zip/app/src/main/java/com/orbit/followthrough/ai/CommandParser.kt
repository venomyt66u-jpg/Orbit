package com.orbit.followthrough.ai

import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.domain.Weekdays
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.temporal.TemporalAdjusters

/** A reminder proposal. Never scheduled until the user confirms it in the Assistant. */
data class ReminderDraft(
    val title: String,
    val repeat: RepeatType = RepeatType.ONCE,
    val hour: Int? = null,
    val minute: Int = 0,
    val date: LocalDate,
    val weekdays: Int = 0,
    val interval: Int = 1,
    val followUpMinutes: Int? = null,
    val important: Boolean = false,
    /** "at 8" – we ask whether that means AM or PM instead of guessing. */
    val needsMeridiem: Boolean = false,
    val note: String = "",
) {
    val missingTime: Boolean get() = hour == null
    val missingTitle: Boolean get() = title.isBlank()
}

sealed interface Command {
    data class Create(val draft: ReminderDraft) : Command
    data class QuietAfter(val startMinute: Int, val endMinute: Int?) : Command
    data object ShowPostponed : Command
    data object Summarize : Command
    data object ShowToday : Command
    data class SetFollowUp(val minutes: Int) : Command
    data class Unknown(val text: String) : Command
}

/**
 * Offline natural-language command parser for English and Arabic (MSA + Egyptian).
 * Deterministic and explainable: it only extracts what it understood and flags what is missing
 * so the Assistant can ask a clarifying question.
 */
object CommandParser {

    // ---------- normalisation (1:1 per char, so spans map back onto the original text) ----------
    fun normalize(s: String): String {
        val out = CharArray(s.length)
        for (i in s.indices) {
            out[i] = when (val c = s[i]) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ة' -> 'ه'
                'ى' -> 'ي'
                in '٠'..'٩' -> '0' + (c - '٠')
                in '۰'..'۹' -> '0' + (c - '۰')
                '،' -> ','
                '؟' -> '?'
                else -> Character.toLowerCase(c)
            }
        }
        return String(out)
    }

    private val enNumbers = mapOf(
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
        "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "fifteen" to 15,
        "twenty" to 20, "thirty" to 30, "forty" to 40, "forty-five" to 45, "sixty" to 60, "a" to 1, "an" to 1,
    )

    private fun num(s: String?): Int? = s?.trim()?.let { it.toIntOrNull() ?: enNumbers[it] }

    // ---------- patterns ----------
    private const val EN_NUM = "(\\d{1,3}|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|forty|forty-five|sixty|an?)"
    private const val EN_HOUR = "(\\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)"

    private val rxPostponed = Regex("postpon|snooz|put off|delayed|deferred|اجلت|المؤجل|المتاجل|اتاجل|اتأجل|التاجيل|اللي اجلته")
    private val rxSummarize = Regex("summar|digest|what'?s new|updates|لخص|ملخص|التحديثات|الجديد في|اخر الاخبار")
    private val rxToday = Regex("what'?s (next|today|on my plate)|my day|today'?s (tasks|plan)|مهام النهارده|ايه اللي ورايا|جدول النهارده|ايه ورايا")
    private val rxRemind = Regex("remind|reminder|don'?t let me forget|ذكرني|فكرني|افكر|نبهني|تذكير|ذكرنى|فكرنى")
    private val rxQuietAfter = Regex("\\b(after|from|starting|past)\\b|بعد|من الساعه|من")
    private val rxThis = Regex("\\b(this|it|that)\\b|التذكير ده|التذكير دا|ده|دي|دا|هذا|هذه")
    private val rxQuiet = Regex("silent|quiet|mute|do not disturb|dnd|صامت|سايلنت|بدون صوت|من غير صوت|اسكت|هدوء")

    // relative ("in 30 minutes", "بعد نص ساعه")
    private val rxRelEn = Regex("\\bin\\s+$EN_NUM\\s*(minutes?|mins?|m|hours?|hrs?|h)\\b")
    private val rxRelEnHalf = Regex("\\bin\\s+(half\\s+an?\\s+hour|a\\s+quarter\\s+hour|a\\s+few\\s+minutes)\\b")
    private val rxRelAr = Regex("بعد\\s*(\\d{1,3})\\s*(دقيقه|دقايق|دقائق|د|ساعه|ساعات)")
    private val rxRelArWords = Regex("بعد\\s*(نص\\s*ساعه|نصف\\s*ساعه|ربع\\s*ساعه|ساعتين|ساعه|شويه)")

    // explicit times
    private val rxEnMeridiem = Regex("(?:\\bat\\s+)?(?<![\\d:])(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)(?![a-z])")
    private val rxEnNoon = Regex("(?:\\bat\\s+)?\\b(noon|midday|midnight)\\b")
    private val rxEnAt = Regex("\\bat\\s+$EN_HOUR(?::(\\d{2}))?\\b(?!\\s*(?:min|hour|day|time|pages?))")
    private val rxEn24 = Regex("(?<![\\d:])([01]?\\d|2[0-3]):([0-5]\\d)(?![\\d:])")
    private val rxArTime = Regex("(?:ال)?ساعه\\s*(\\d{1,2})(?:[:.](\\d{2}))?(\\s*(?:و\\s*نص|و\\s*ربع|الا\\s*ربع|الا\\s*تلت|و\\s*تلت|و\\s*(\\d{1,2})\\s*(?:دقيقه|د)))?(\\s*(?:الصبح|صباحا|صباح|الفجر|فجرا|الضهر|الظهر|ظهرا|العصر|عصرا|المغرب|بالليل|الليل|بليل|مساء|مساءا|المسا|بالمسا|ص|م)(?![\\p{L}]))?")
    private val rxArBare = Regex("(?<![\\d:])(\\d{1,2})(?::(\\d{2}))?\\s*(الصبح|صباحا|الفجر|الضهر|الظهر|العصر|المغرب|بالليل|بليل|مساء|مساءا|المسا|ص|م)(?![\\p{L}])")

    // context words that disambiguate AM/PM
    private val rxAmCtx = Regex("\\b(morning|in the morning|a\\.m)\\b|الصبح|صباح|الفجر")
    private val rxPmCtx = Regex("\\b(tonight|evening|afternoon|at night|this evening)\\b|بالليل|الليله|بليل|مساء|المسا|العصر|المغرب")

    // repetition
    private val rxEveryNDaysEn = Regex("\\bevery\\s+(\\d{1,2})\\s+days?\\b")
    private val rxEveryOtherDayEn = Regex("\\bevery\\s+other\\s+day\\b")
    private val rxDailyEn = Regex("\\b(every\\s*day|everyday|daily|each\\s+day|every\\s+morning|every\\s+evening|every\\s+night)\\b")
    private val rxWeekdaysEn = Regex("\\b(every\\s+weekday|on\\s+weekdays|weekdays)\\b")
    private val rxWeekendsEn = Regex("\\b(every\\s+weekend|on\\s+weekends|weekends)\\b")
    private const val EN_DAY = "(?:mon|tues|tue|wednes|wed|thurs|thu|fri|satur|sat|sun)(?:day)?s?"
    private val rxDaysEn = Regex("\\b(?:every|on)\\s+($EN_DAY(?:\\s*(?:,|and|&)\\s*$EN_DAY)*)\\b")
    private val rxWeeklyEn = Regex("\\b(weekly|every\\s+week)\\b")
    private val rxMonthlyEn = Regex("\\b(monthly|every\\s+month)\\b")

    private const val AR_DAY = "(?:ال)?(?:اثنين|اتنين|تنين|ثلاثاء|ثلاث|تلات|اربعاء|اربع|خميس|جمعه|سبت|احد|حد)"
    private val rxEveryNDaysAr = Regex("كل\\s*(\\d{1,2})\\s*(?:ايام|يوم)")
    private val rxEveryOtherDayAr = Regex("كل\\s*يومين|يوم\\s*اه\\s*ويوم\\s*لا")
    private val rxDaysAr = Regex("(?:كل|يوم)\\s*(?:يوم\\s*)?($AR_DAY(?:\\s*و\\s*(?:يوم\\s*)?$AR_DAY)*)")
    private val rxDailyAr = Regex("كل\\s*يوم|يوميا|يومي|كل\\s*صباح|كل\\s*ليله")
    private val rxWeeklyAr = Regex("كل\\s*اسبوع|اسبوعيا|اسبوعي")
    private val rxMonthlyAr = Regex("كل\\s*شهر|شهريا|شهري")

    // dates
    private val rxAfterTomorrowAr = Regex("بعد\\s*بكره|بعد\\s*بكرا|بعد\\s*غد")
    private val rxTomorrow = Regex("\\b(tomorrow|tmrw|tmr)\\b|بكره|بكرا|غدا")
    private val rxToday2 = Regex("\\b(today|tonight)\\b|النهارده|النهاردا|الليله|اليوم")

    // follow-up / priority
    private val rxFollowEn = Regex("\\b(?:repeat|again|follow\\s*up|nag me|keep reminding)\\b[^.]*?\\b(?:in|every|after)\\s+(\\d{1,3})\\s*(?:minutes?|mins?|m)\\b(?:\\s+if\\s+i\\s+(?:haven'?t|don'?t|didn'?t)[^.]*)?")
    private val rxFollowAr = Regex("(?:كرر|كررها|كرره|عيد|عيدها|عيده|تاني)[^.]*?(?:كل|بعد)\\s*(\\d{1,3})\\s*(?:دقيقه|دقايق|دقائق|د)(?:\\s*لو[^.]*)?")
    private val rxImportant = Regex("\\b(important|urgent|asap)\\b|!!|مهم جدا|مهم|ضروري|عاجل")

    // routine
    private val rxRoutineEn = Regex("\\b(?:create|make|build|start|set\\s+up|plan)\\b.*?\\b(?:a\\s+)?(?:daily\\s+)?(\\p{L}+)\\s+routine\\b")
    private val rxRoutineAr = Regex("روتين\\s*(?:يومي\\s*)?(?:لل|ل)?(\\p{L}+)")
    private val rxDurationEn = Regex("\\bfor\\s+(an?|one|two|three|half an?|\\d{1,3})\\s*(hours?|hrs?|h|minutes?|mins?)\\b")
    private val rxDurationAr = Regex("(?:لمده|مده|لمدة)\\s*(ساعتين|ساعه|نص\\s*ساعه|(\\d{1,3})\\s*(?:دقيقه|دقايق|ساعات|ساعه))")

    // leading trigger phrases
    private val rxLeadEn = Regex("^\\s*(?:hey\\s+)?(?:please\\s+)?(?:can you\\s+)?(?:remind\\s+me|set\\s+(?:a\\s+)?reminder|create\\s+(?:a\\s+)?reminder|add\\s+(?:a\\s+)?reminder|reminder|don'?t\\s+let\\s+me\\s+forget)\\s*(?:to|about|that|of|:)?\\s*")
    private val rxLeadAr = Regex("^\\s*(?:لو\\s*سمحت\\s*|من\\s*فضلك\\s*)?(?:ذكرني|فكرني|ذكرنى|فكرنى|افكرني|نبهني|اعمل\\s*تذكير|اعملي\\s*تذكير|عايز\\s*تذكير|عاوز\\s*تذكير|تذكير)\\s*(?:اني|ان|بان|بأن|:)?\\s*")

    fun parse(raw: String, now: ZonedDateTime): Command {
        val text = raw.trim()
        if (text.isEmpty()) return Command.Unknown(raw)
        val n = normalize(text)
        val hasRemind = rxRemind.containsMatchIn(n)

        if (rxPostponed.containsMatchIn(n) && !hasRemind) return Command.ShowPostponed
        if (rxToday.containsMatchIn(n) && !hasRemind) return Command.ShowToday
        if (rxSummarize.containsMatchIn(n) && !hasRemind) return Command.Summarize

        val spans = ArrayList<IntRange>()
        fun free(r: IntRange) = spans.none { it.first <= r.last && r.first <= it.last }
        fun take(m: MatchResult?): MatchResult? {
            if (m == null || !free(m.range)) return null
            spans += m.range
            return m
        }
        fun firstFree(rx: Regex): MatchResult? = rx.findAll(n).firstOrNull { free(it.range) }?.let { take(it) }

        // ---- quiet hours command ("make reminders silent after 10 PM") ----
        if (rxQuiet.containsMatchIn(n) && rxQuietAfter.containsMatchIn(n)) {
            val t = extractTime(n) { rx -> rx.find(n) }
            val th = t?.hour
            if (t != null && th != null) {
                val pmContext = rxPmCtx.containsMatchIn(n) || !rxAmCtx.containsMatchIn(n)
                val h = if (t.needsMeridiem && th in 1..11 && pmContext) th + 12 else th
                return Command.QuietAfter(h * 60 + t.minute, null)
            }
        }

        // ---- follow-up for an existing reminder ("repeat this reminder in 30 minutes if I haven't…") ----
        val followMatch = rxFollowEn.find(n) ?: rxFollowAr.find(n)
        if (followMatch != null && rxThis.containsMatchIn(n) && extractTime(n) { rx -> rx.find(n) } == null) {
            val minutes = followMatch.groupValues[1].toIntOrNull()
            if (minutes != null) return Command.SetFollowUp(nearestFollowUp(minutes))
        }

        // ---- reminder / routine ----
        var title: String? = null
        var note = ""
        var routineHit = false
        (take(rxRoutineEn.find(n)) ?: take(rxRoutineAr.find(n)))?.let { m ->
            routineHit = true
            val topic = text.substring(m.groups[1]!!.range).trim()
            val dur = take(rxDurationEn.find(n)) ?: take(rxDurationAr.find(n))
            val minutes = dur?.let { durationMinutes(it.value) }
            title = topic.replaceFirstChar { it.titlecase() } + (minutes?.let { " · ${it}m" } ?: "")
            note = minutes?.let { "⏱ $it" } ?: ""
        }

        if (!routineHit && !hasRemind && !looksLikeTimeCommand(n)) return Command.Unknown(raw)

        var repeat = RepeatType.ONCE
        var weekdays = 0
        var interval = 1
        var ampmHint: Boolean? = null // true = AM, false = PM
        var date = now.toLocalDate()
        var dateExplicit = false

        val follow = take(rxFollowEn.find(n)) ?: take(rxFollowAr.find(n))
        val followUp = follow?.groups?.get(1)?.value?.toIntOrNull()?.let { nearestFollowUp(it) }

        val important = take(rxImportant.find(n)) != null

        // relative times first ("in 30 minutes" must not be read as a clock time)
        var relMinutes: Int? = null
        take(rxRelEn.find(n))?.let { m ->
            val v = num(m.groupValues[1]) ?: 1
            relMinutes = if (m.groupValues[2].startsWith("h")) v * 60 else v
        } ?: take(rxRelEnHalf.find(n))?.let { m ->
            relMinutes = when {
                m.value.contains("half") -> 30
                m.value.contains("quarter") -> 15
                else -> 5
            }
        } ?: take(rxRelAr.find(n))?.let { m ->
            val v = m.groupValues[1].toInt()
            relMinutes = if (m.groupValues[2].startsWith("ساع")) v * 60 else v
        } ?: take(rxRelArWords.find(n))?.let { m ->
            relMinutes = when {
                m.value.contains("نص") -> 30
                m.value.contains("ربع") -> 15
                m.value.contains("ساعتين") -> 120
                m.value.contains("شويه") -> 15
                else -> 60
            }
        }

        // repetition
        when {
            take(rxEveryNDaysEn.find(n)) != null -> {
                repeat = RepeatType.INTERVAL
                interval = rxEveryNDaysEn.find(n)!!.groupValues[1].toInt().coerceIn(1, 90)
            }
            take(rxEveryNDaysAr.find(n)) != null -> {
                repeat = RepeatType.INTERVAL
                interval = rxEveryNDaysAr.find(n)!!.groupValues[1].toInt().coerceIn(1, 90)
            }
            take(rxEveryOtherDayEn.find(n)) != null || take(rxEveryOtherDayAr.find(n)) != null -> {
                repeat = RepeatType.INTERVAL; interval = 2
            }
            take(rxWeekdaysEn.find(n)) != null -> { repeat = RepeatType.WEEKLY; weekdays = Weekdays.WORKWEEK_MON_FRI }
            take(rxWeekendsEn.find(n)) != null -> { repeat = RepeatType.WEEKLY; weekdays = Weekdays.WEEKEND_SAT_SUN }
            else -> {
                val dEn = rxDaysEn.find(n)
                val dAr = rxDaysAr.find(n)
                val mask = when {
                    dEn != null && free(dEn.range) -> { val v = parseDaysEn(dEn.groupValues[1]); if (v != 0) spans += dEn.range; v }
                    dAr != null && free(dAr.range) -> { val v = parseDaysAr(dAr.groupValues[1]); if (v != 0) spans += dAr.range; v }
                    else -> 0
                }
                val isEvery = (dEn?.value?.startsWith("every") == true) || (dAr?.value?.startsWith("كل") == true)
                if (mask != 0 && isEvery) {
                    repeat = RepeatType.WEEKLY; weekdays = mask
                } else if (mask != 0) {
                    // "on Friday" – a one-time reminder on the next such day.
                    val dow = DayOfWeek.values().first { Weekdays.has(mask, it) }
                    date = now.toLocalDate().with(TemporalAdjusters.nextOrSame(dow))
                    dateExplicit = true
                } else {
                    val daily = take(rxDailyEn.find(n)) ?: take(rxDailyAr.find(n))
                    if (daily != null) {
                        repeat = RepeatType.DAILY
                        val v = daily.value
                        if (v.contains("morning") || v.contains("صباح")) ampmHint = true
                        if (v.contains("evening") || v.contains("night") || v.contains("ليله")) ampmHint = false
                    } else if (take(rxWeeklyEn.find(n)) != null || take(rxWeeklyAr.find(n)) != null) {
                        repeat = RepeatType.WEEKLY; weekdays = Weekdays.bit(now.dayOfWeek)
                    } else if (take(rxMonthlyEn.find(n)) != null || take(rxMonthlyAr.find(n)) != null) {
                        repeat = RepeatType.MONTHLY
                    }
                }
            }
        }
        if (routineHit && repeat == RepeatType.ONCE) repeat = RepeatType.DAILY

        // dates
        if (take(rxAfterTomorrowAr.find(n)) != null) { date = date.plusDays(2); dateExplicit = true }
        else if (take(rxTomorrow.find(n)) != null) { date = now.toLocalDate().plusDays(1); dateExplicit = true }
        else take(rxToday2.find(n))?.let { m ->
            dateExplicit = true
            if (m.value.contains("tonight") || m.value.contains("الليله")) ampmHint = false
        }

        // clock time
        var hour: Int? = null
        var minute = 0
        var needsMeridiem = false
        if (relMinutes != null) {
            val target = now.plusMinutes(relMinutes!!.toLong())
            hour = target.hour; minute = target.minute; date = target.toLocalDate(); dateExplicit = true
        } else {
            val t = extractTime(n, ::firstFree)
            val th = t?.hour
            if (t != null && th != null) {
                var h: Int = th
                minute = t.minute
                if (t.needsMeridiem) {
                    val hint = ampmHint ?: when {
                        rxAmCtx.containsMatchIn(n) -> true
                        rxPmCtx.containsMatchIn(n) -> false
                        else -> null
                    }
                    if (hint == true && h == 12) h = 0
                    if (hint == false && h < 12) h += 12
                    if (hint == null) needsMeridiem = true
                }
                hour = h
            }
        }

        // one-time with a time that already passed today → tomorrow (unless the user said "today")
        val hourNow = hour
        if (repeat == RepeatType.ONCE && hourNow != null && !dateExplicit && !needsMeridiem) {
            val candidate = date.atTime(hourNow, minute).atZone(now.zone)
            if (!candidate.isAfter(now)) date = date.plusDays(1)
        }

        // title = what's left after removing everything we understood
        val finalTitle = title ?: cleanTitle(text, n, spans)

        return Command.Create(
            ReminderDraft(
                title = finalTitle,
                repeat = repeat,
                hour = hour,
                minute = minute,
                date = date,
                weekdays = weekdays,
                interval = interval,
                followUpMinutes = followUp,
                important = important,
                needsMeridiem = needsMeridiem,
                note = note,
            )
        )
    }

    private fun looksLikeTimeCommand(n: String): Boolean =
        rxEnMeridiem.containsMatchIn(n) || rxArTime.containsMatchIn(n) || rxDailyEn.containsMatchIn(n) || rxDailyAr.containsMatchIn(n) ||
            rxRelEn.containsMatchIn(n) || rxRelAr.containsMatchIn(n) || rxTomorrow.containsMatchIn(n)

    private data class TimeHit(val hour: Int?, val minute: Int, val needsMeridiem: Boolean)

    private fun extractTime(n: String, firstFree: (Regex) -> MatchResult?): TimeHit? {
        firstFree(rxEnMeridiem)?.let { m ->
            var h = m.groupValues[1].toInt().coerceIn(0, 23)
            val min = m.groupValues[2].toIntOrNull() ?: 0
            val pm = m.groupValues[3].startsWith("p")
            if (pm && h < 12) h += 12
            if (!pm && h == 12) h = 0
            return TimeHit(h, min.coerceIn(0, 59), false)
        }
        firstFree(rxEnNoon)?.let { m ->
            return TimeHit(if (m.groupValues[1] == "midnight") 0 else 12, 0, false)
        }
        firstFree(rxArTime)?.let { m -> return arabicTime(m.groupValues[1], m.groupValues[2], m.groupValues[3], m.groupValues[4], m.groupValues[5]) }
        firstFree(rxArBare)?.let { m -> return arabicTime(m.groupValues[1], m.groupValues[2], "", "", m.groupValues[3]) }
        firstFree(rxEn24)?.let { m ->
            val h = m.groupValues[1].toInt(); val min = m.groupValues[2].toInt()
            return TimeHit(h, min, h in 1..11)
        }
        firstFree(rxEnAt)?.let { m ->
            val h = num(m.groupValues[1]) ?: return null
            val min = m.groupValues[2].toIntOrNull() ?: 0
            return TimeHit(h.coerceIn(0, 23), min.coerceIn(0, 59), h in 1..11)
        }
        return null
    }

    private fun arabicTime(hRaw: String, mRaw: String, fraction: String, fracMin: String, period: String): TimeHit {
        var h = hRaw.toInt().coerceIn(0, 23)
        var min = mRaw.toIntOrNull() ?: 0
        val f = fraction.replace(" ", "")
        when {
            f.contains("ونص") -> min = 30
            f.contains("وربع") -> min = 15
            f.contains("وتلت") -> min = 20
            f.contains("الاربع") -> { min = 45; h = (h - 1 + 24) % 24 }
            f.contains("الاتلت") -> { min = 40; h = (h - 1 + 24) % 24 }
            fracMin.isNotBlank() -> min = fracMin.toInt().coerceIn(0, 59)
        }
        val p = period.trim()
        var needs = false
        when {
            p.isEmpty() -> needs = h in 1..11
            p in listOf("الصبح", "صباحا", "صباح", "الفجر", "فجرا", "ص") -> if (h == 12) h = 0
            p in listOf("الضهر", "الظهر", "ظهرا") -> if (h in 1..5) h += 12
            else -> if (h < 12) h += 12
        }
        return TimeHit(h, min, needs)
    }

    private fun parseDaysEn(s: String): Int {
        var mask = 0
        Regex(EN_DAY).findAll(s).forEach { m ->
            val v = m.value
            mask = mask or when {
                v.startsWith("mon") -> Weekdays.MON
                v.startsWith("tue") -> Weekdays.TUE
                v.startsWith("wed") -> Weekdays.WED
                v.startsWith("thu") -> Weekdays.THU
                v.startsWith("fri") -> Weekdays.FRI
                v.startsWith("sat") -> Weekdays.SAT
                v.startsWith("sun") -> Weekdays.SUN
                else -> 0
            }
        }
        return mask
    }

    private fun parseDaysAr(s: String): Int {
        var mask = 0
        Regex(AR_DAY).findAll(s).forEach { m ->
            val v = m.value.removePrefix("ال")
            mask = mask or when {
                v.startsWith("اثنين") || v.startsWith("اتنين") || v.startsWith("تنين") -> Weekdays.MON
                v.startsWith("ثلاث") || v.startsWith("تلات") -> Weekdays.TUE
                v.startsWith("اربع") -> Weekdays.WED
                v.startsWith("خميس") -> Weekdays.THU
                v.startsWith("جمعه") -> Weekdays.FRI
                v.startsWith("سبت") -> Weekdays.SAT
                v.startsWith("احد") || v == "حد" -> Weekdays.SUN
                else -> 0
            }
        }
        return mask
    }

    private fun durationMinutes(s: String): Int? {
        val n = s.trim()
        return when {
            n.contains("half") || n.contains("نص") -> 30
            n.contains("ساعتين") -> 120
            n.contains("hour") || n.contains("hr") || Regex("\\d+\\s*h\\b").containsMatchIn(n) || n.contains("ساع") -> {
                val v = Regex("\\d+").find(n)?.value?.toIntOrNull()
                    ?: enNumbers.entries.firstOrNull { (k, _) -> Regex("\\b$k\\b").containsMatchIn(n) }?.value ?: 1
                v * 60
            }
            else -> Regex("\\d+").find(n)?.value?.toIntOrNull()
        }
    }

    private fun nearestFollowUp(v: Int): Int = listOf(5, 10, 15, 30, 60).minBy { kotlin.math.abs(it - v) }

    private val rxTrimEdges = Regex("^[\\s,.;:!?\\-–—]+|[\\s,.;:!?\\-–—]+$")
    private val rxDanglingEn = Regex("^(?:to|at|on|in|and|for|about|by|that|please)\\s+|\\s+(?:to|at|on|in|and|for|about|by|please)$", RegexOption.IGNORE_CASE)
    private val rxDanglingAr = Regex("^(?:و|في|علي|على|ان|اني|إني|عشان|يوم|الساعه|الساعة)\\s+|\\s+(?:و|في|علي|على|الساعه|الساعة|يوم)$")

    private fun cleanTitle(original: String, normalized: String, spans: List<IntRange>): String {
        val keep = BooleanArray(original.length) { true }
        spans.forEach { r -> for (i in r) if (i in keep.indices) keep[i] = false }
        val sb = StringBuilder()
        for (i in original.indices) sb.append(if (keep[i]) original[i] else ' ')
        var t = sb.toString().replace(Regex("\\s+"), " ").trim()
        // leading trigger ("remind me to", "فكرني اني") – matched on normalised text of the remainder
        repeat(2) {
            val nt = normalize(t)
            val lead = rxLeadEn.find(nt) ?: rxLeadAr.find(nt)
            if (lead != null && lead.range.first == 0) t = t.substring(lead.range.last + 1)
        }
        repeat(4) {
            t = t.replace(rxTrimEdges, "").trim()
            t = t.replace(rxDanglingEn, "").trim()
            t = t.replace(rxDanglingAr, "").trim()
        }
        // Arabic: "بالدوا" → "الدوا"
        if (t.startsWith("بال")) t = t.substring(1)
        if (normalized.isNotEmpty() && t.isNotEmpty() && t[0].isLowerCase()) t = t.replaceFirstChar { it.titlecase() }
        return t
    }
}
