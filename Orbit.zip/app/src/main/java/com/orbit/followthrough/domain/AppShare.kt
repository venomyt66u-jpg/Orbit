package com.orbit.followthrough.domain

/**
 * Splits the exact usage on the target network between apps.
 *
 * Android records Wi‑Fi bytes per app in time slots (2 hours) but not per Wi‑Fi network. For each
 * slot we know exactly how much was used on the target network (our own count); we share that
 * amount between the apps in proportion to what each app moved over Wi‑Fi in the same slot. The
 * per-app numbers therefore always add up to the calendar total – nothing is added or lost.
 */
object AppShare {
    const val SLOT_MS = 2 * 60 * 60_000L

    fun slotStart(t: Long): Long = t - Math.floorMod(t, SLOT_MS)

    /**
     * @param targetPerSlot exact target-network bytes per slot start
     * @param appsPerSlot   all Wi‑Fi bytes per app key in that slot (from Android)
     */
    fun split(targetPerSlot: Map<Long, Bytes>, appsPerSlot: Map<Long, Map<String, Bytes>>): Map<String, Bytes> {
        val out = HashMap<String, DoubleArray>()
        for ((slot, target) in targetPerSlot) {
            if (target.total <= 0) continue
            val apps = appsPerSlot[slot].orEmpty().filterValues { it.total > 0 }
            val sumRx = apps.values.sumOf { it.rx }.toDouble()
            val sumTx = apps.values.sumOf { it.tx }.toDouble()
            val sum = sumRx + sumTx
            if (sum <= 0.0) {
                // Android has nothing for this slot (yet): keep the bytes visible instead of dropping them.
                val a = out.getOrPut(UNKNOWN) { DoubleArray(2) }
                a[0] += target.rx.toDouble(); a[1] += target.tx.toDouble()
                continue
            }
            for ((key, b) in apps) {
                val a = out.getOrPut(key) { DoubleArray(2) }
                // Received and sent are shared separately, so download‑heavy apps get the download.
                a[0] += if (sumRx > 0) target.rx * (b.rx / sumRx) else target.rx * (b.total / sum)
                a[1] += if (sumTx > 0) target.tx * (b.tx / sumTx) else target.tx * (b.total / sum)
            }
        }
        return out.mapValues { (_, v) -> Bytes(Math.round(v[0]), Math.round(v[1])) }.filterValues { it.total > 0 }
    }

    /** Groups hourly target bytes ("2026-10-29T13" keys converted to millis) into slots. */
    fun slots(hourly: Map<Long, Bytes>): Map<Long, Bytes> {
        val out = HashMap<Long, Bytes>()
        for ((h, b) in hourly) {
            val s = slotStart(h)
            out[s] = (out[s] ?: Bytes.ZERO) + b
        }
        return out
    }

    const val UNKNOWN = "?"
}
