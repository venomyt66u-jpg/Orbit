package com.orbit.followthrough.ai

import com.orbit.followthrough.net.Http
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** Supported AI providers. The key is the user's own and stays on the device (encrypted). */
enum class LlmProvider(val label: String, val defaultModel: String, val needsKey: Boolean) {
    NONE("Off", "", false),
    ANTHROPIC("Claude (Anthropic)", "claude-haiku-5-5", true),
    OPENAI("OpenAI", "gpt-4o-mini", true),
    GEMINI("Google Gemini", "gemini-2.0-flash", true),
    BACKEND("My backend", "", false),
}

data class LlmConfig(val provider: LlmProvider, val model: String, val apiKey: String?, val backendUrl: String) {
    val ready: Boolean get() = when (provider) {
        LlmProvider.NONE -> false
        LlmProvider.BACKEND -> backendUrl.startsWith("https://")
        else -> !apiKey.isNullOrBlank()
    }
}

/** Thin, dependency-free client for the three major LLM HTTP APIs (plus the user's own backend). */
class LlmClient(private val config: LlmConfig) {

    suspend fun complete(system: String, user: String, maxTokens: Int = 700): Result<String> = runCatching {
        val model = config.model.ifBlank { config.provider.defaultModel }
        when (config.provider) {
            LlmProvider.ANTHROPIC -> {
                val body = JSONObject()
                    .put("model", model)
                    .put("max_tokens", maxTokens)
                    .put("system", system)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
                val res = JSONObject(
                    Http.postJson(
                        "https://api.anthropic.com/v1/messages", body.toString(),
                        mapOf("x-api-key" to config.apiKey.orEmpty(), "anthropic-version" to "2023-06-01"),
                    )
                )
                val content = res.getJSONArray("content")
                buildString {
                    for (i in 0 until content.length()) {
                        val part = content.getJSONObject(i)
                        if (part.optString("type") == "text") append(part.optString("text"))
                    }
                }
            }
            LlmProvider.OPENAI -> {
                val body = JSONObject()
                    .put("model", model)
                    .put("max_tokens", maxTokens)
                    .put(
                        "messages", JSONArray()
                            .put(JSONObject().put("role", "system").put("content", system))
                            .put(JSONObject().put("role", "user").put("content", user))
                    )
                val res = JSONObject(Http.postJson("https://api.openai.com/v1/chat/completions", body.toString(), mapOf("Authorization" to "Bearer ${config.apiKey}")))
                res.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
            }
            LlmProvider.GEMINI -> {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", user)))))
                    .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens))
                val url = "https://generativelanguage.googleapis.com/v1beta/models/${URLEncoder.encode(model, "UTF-8")}:generateContent"
                val res = JSONObject(Http.postJson(url, body.toString(), mapOf("x-goog-api-key" to config.apiKey.orEmpty())))
                val parts = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }
            }
            LlmProvider.BACKEND -> {
                val body = JSONObject().put("system", system).put("user", user).put("maxTokens", maxTokens)
                JSONObject(Http.postJson(config.backendUrl.trimEnd('/') + "/chat", body.toString())).optString("text")
            }
            LlmProvider.NONE -> error("AI is off")
        }.trim().also { if (it.isEmpty()) error("empty answer") }
    }
}
