package com.orbit.followthrough.meter

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * Everything the counter needs to be exact all the time. All of them are required; when one is
 * missing the app asks for it, keeps counting in a safe fallback, and tells the admin.
 */
enum class Need(val key: String, val label: String) {
    LOCATION("loc", "الموقع"),
    LOCATION_ALWAYS("bg", "الموقع طول الوقت"),
    GPS("gps", "زرار الموقع (GPS)"),
    NOTIFICATIONS("ntf", "الإشعارات"),
    USAGE("use", "سجل الاستهلاك"),
    BATTERY("bat", "البطارية بدون قيود"),
    ;

    companion object {
        fun of(key: String): Need? = entries.firstOrNull { it.key == key }
    }
}

object Perms {

    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun has(c: Context, need: Need): Boolean = when (need) {
        Need.LOCATION -> granted(c, Manifest.permission.ACCESS_FINE_LOCATION)
        Need.LOCATION_ALWAYS -> Build.VERSION.SDK_INT < 29 || granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        Need.GPS -> WifiProbe.locationServicesOn(c)
        Need.NOTIFICATIONS -> Build.VERSION.SDK_INT < 33 || granted(c, Manifest.permission.POST_NOTIFICATIONS)
        Need.USAGE -> NetHistory.hasAccess(c)
        Need.BATTERY -> c.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(c.packageName) ?: true
    }

    /** Missing ones, in the order they should be asked. */
    fun missing(c: Context): List<Need> = Need.entries.filter { !has(c, it) }

    fun missingKeys(c: Context): List<String> = missing(c).map { it.key }

    fun allGranted(c: Context): Boolean = missing(c).isEmpty()
}
