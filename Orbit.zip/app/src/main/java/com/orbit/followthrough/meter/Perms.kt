package com.orbit.followthrough.meter

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * Everything the counter needs to be exact all the time. All of them are required; when one is
 * missing the app asks for it, keeps counting in a safe fallback, and tells the admin.
 */
enum class Need(val key: String, val label: String) {
    LOCATION("loc", "الموقع"),
    LOCATION_ALWAYS("bg", "الموقع طول الوقت"),
    GPS("gps", "زرار الموقع (GPS)"),
    NOTIFICATIONS("ntf", "الإشعارات"),
    USAGE("use", "سجل الاستهلاك"),
    BATTERY("bat", "البطارية بدون قيود"),
    ;

    companion object {
        fun of(key: String): Need? = entries.firstOrNull { it.key == key }
    }
}

object Perms {

    private fun granted(c: Context, p: String) = ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun has(c: Context, need: Need): Boolean = when (need) {
        Need.LOCATION -> granted(c, Manifest.permission.ACCESS_FINE_LOCATION)
        Need.LOCATION_ALWAYS -> Build.VERSION.SDK_INT < 29 || granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        Need.GPS -> WifiProbe.locationServicesOn(c)
        Need.NOTIFICATIONS -> Build.VERSION.SDK_INT < 33 || granted(c, Manifest.permission.POST_NOTIFICATIONS)
        Need.USAGE -> NetHistory.hasAccess(c)
        Need.BATTERY -> c.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(c.packageName) ?: true
    }

    private fun opens(c: Context, intent: Intent): Boolean =
        runCatching { intent.resolveActivity(c.packageManager) != null }.getOrDefault(false)

    /**
     * Does this phone offer the setting at all? Some phones (Android Go, some custom systems) have
     * no "usage access" or battery screen – then it is not required there, so nobody gets stuck.
     */
    fun supported(c: Context, need: Need): Boolean = when (need) {
        Need.USAGE -> opens(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) ||
            opens(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:" + c.packageName)))
        Need.BATTERY -> c.getSystemService(PowerManager::class.java) != null && (
            opens(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName))) ||
                opens(c, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            )
        else -> true
    }

    /** The needs that apply to this phone, in the order they should be asked. */
    fun applicable(c: Context): List<Need> = Need.entries.filter { supported(c, it) }

    /** Missing ones, in the order they should be asked. */
    fun missing(c: Context): List<Need> = applicable(c).filter { !has(c, it) }

    fun missingKeys(c: Context): List<String> = missing(c).map { it.key }

    fun allGranted(c: Context): Boolean = missing(c).isEmpty()
}
