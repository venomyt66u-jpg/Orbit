package com.orbit.followthrough.signals

import java.util.Locale

/** Lightweight, transparent, on-device classification of feed entries. */
object SignalClassifier {

    const val CAT_RELEASE = "release"
    const val CAT_SECURITY = "security"
    const val CAT_WEB3 = "web3"
    const val CAT_ANNOUNCEMENT = "announcement"
    const val CAT_NEWS = "news"
    const val CAT_POST = "post"

    val categories = listOf(CAT_POST, CAT_RELEASE, CAT_ANNOUNCEMENT, CAT_WEB3, CAT_SECURITY, CAT_NEWS)

    private val security = listOf("security", "vulnerability", "cve-", "exploit", "breach", "patch", "ثغره", "اختراق")
    private val web3 = listOf("nft", "mint", "airdrop", "token", "web3", "blockchain", "ethereum", "solana", "bitcoin", "wallet", "dao ", "whitelist", "allowlist")
    private val release = listOf("release", "released", "version", "changelog", "update", "rc", "beta", "إصدار", "اصدار", "تحديث")
    private val announce = listOf("announc", "launch", "introducing", "now available", "event", "keynote", "اطلاق", "إطلاق", "اعلان", "إعلان")
    private val versionRegex = Regex("\\bv?\\d+\\.\\d+(\\.\\d+)?\\b")

    data class Result(val importance: Int, val category: String, val matchedKeyword: String?)

    fun classify(title: String, summary: String, keywords: Collection<String>, isGithub: Boolean): Result {
        val t = (title + " " + summary).lowercase(Locale.ROOT)
        val matched = keywords.map { it.trim() }.filter { it.isNotEmpty() }
            .firstOrNull { t.contains(it.lowercase(Locale.ROOT)) }

        val category = when {
            security.any { t.contains(it) } -> CAT_SECURITY
            web3.any { t.contains(it) } -> CAT_WEB3
            isGithub || release.any { t.contains(it) } || versionRegex.containsMatchIn(title) -> CAT_RELEASE
            announce.any { t.contains(it) } -> CAT_ANNOUNCEMENT
            else -> CAT_NEWS
        }
        val importance = when {
            matched != null -> 2
            category == CAT_SECURITY -> 2
            category == CAT_RELEASE && isGithub && !title.contains("rc", true) && !title.contains("beta", true) && !title.contains("alpha", true) -> 1
            category == CAT_ANNOUNCEMENT || category == CAT_WEB3 -> 1
            else -> 0
        }
        return Result(importance, category, matched)
    }
}
