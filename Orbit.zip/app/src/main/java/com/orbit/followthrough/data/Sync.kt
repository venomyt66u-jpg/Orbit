package com.orbit.followthrough.data

import android.content.Context
import com.orbit.followthrough.domain.Claim
import com.orbit.followthrough.domain.Bytes
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Package
import com.orbit.followthrough.domain.Snapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

/**
 * Tiny message relay (ntfy.sh, no account needed). Every phone posts a small report
 * (who it is, the group's known claims, its daily usage on the target network).
 * Messages stay on the relay for ~12 h, and every report repeats all known claims,
 * so the group keeps its memory as long as any phone is active.
 */
object Relay {
    private const val BASE = "https://ntfy.sh/"

    fun publish(body: String) {
        val c = URL(BASE + Config.RELAY_TOPIC).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
            c.setRequestProperty("Firebase", "no")
            c.setRequestProperty("User-Agent", "OrbitWifi/2.0")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) throw java.io.IOException("relay HTTP $code")
        } finally {
            c.disconnect()
        }
    }

    /** All messages still held by the relay, oldest first. */
    fun poll(): List<String> {
        val c = URL(BASE + Config.RELAY_TOPIC + "/json?poll=1&since=all").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "OrbitWifi/2.0")
            val code = c.responseCode
            if (code !in 200..299) throw java.io.IOException("relay HTTP $code")
            val out = ArrayList<String>()
            BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.isBlank()) continue
                    val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
                    if (o.optString("event") == "message") o.optString("message").takeIf { it.isNotBlank() }?.let { out += it }
                }
            }
            return out
        } finally {
            c.disconnect()
        }
    }
}

sealed interface ClaimResult {
    data object Ok : ClaimResult
    data object Taken : ClaimResult
    data object Offline : ClaimResult
}

object SyncEngine {
    private val mutex = Mutex()
    private const val PUBLISH_EVERY = 30 * 60_000L
    /** Even with no change, post now and then so the group's claims never expire from the relay. */
    private const val HEARTBEAT_EVERY = 3 * 60 * 60_000L
    private const val KEEP_DAYS = 40
    /** Days of pre-install Wi‑Fi history shared with the admin (keeps the message under the relay's 4 KB). */
    private const val PAST_DAYS = 45

    private data class Report(val claims: List<Claim>, val snapshot: Snapshot?, val nets: List<String>, val packages: List<Long>)

    private fun parse(body: String): Report? {
        val o = runCatching { JSONObject(body) }.getOrNull() ?: return null
        if (o.optInt("v") != 1) return null
        val claims = Json.claimsFromJson(o.optJSONArray("c"))
        val slot = o.optString("s")
        val dev = o.optString("d")
        val snap = if (slot.isNotBlank() && dev.isNotBlank())
            Snapshot(
                slot, dev, o.optLong("at"), Json.daysFromJson(o.optJSONObject("u")), o.optBoolean("on"), Json.daysFromJson(o.optJSONObject("p")),
                o.optLong("cs"), o.optJSONArray("cu")?.let { Bytes(it.optLong(0), it.optLong(1)) },
            )
        else null
        val nets = ArrayList<String>()
        o.optJSONArray("n")?.let { a -> for (i in 0 until a.length()) a.optString(i).takeIf { it.isNotBlank() }?.let { nets += it } }
        val pk = ArrayList<Long>()
        o.optJSONArray("cy")?.let { a -> for (i in 0 until a.length()) a.optLong(i).takeIf { it > 0 }?.let { pk += it } }
        return Report(claims, snap, nets, pk)
    }

    private fun buildReport(context: Context, profile: Profile, onTarget: Boolean): String {
        // Shrink the pre-install history if needed so the message stays under the relay's 4 KB limit.
        for (pastDays in listOf(PAST_DAYS, 30, 14, 0)) {
            val body = buildReport(context, profile, onTarget, pastDays)
            if (body.toByteArray(Charsets.UTF_8).size <= 3800 || pastDays == 0) return body
        }
        return buildReport(context, profile, onTarget, 0)
    }

    private fun buildReport(context: Context, profile: Profile, onTarget: Boolean, pastDays: Int): String {
        val slot = profile.slot ?: ""
        val store = UsageStore(context)
        val today = LocalDate.now()
        val days = if (slot.isBlank()) emptyMap() else Days.recent(store.days(), today, KEEP_DAYS)
        val past = if (slot.isBlank() || pastDays == 0) emptyMap() else Days.recent(store.past(), today, pastDays)
        return JSONObject()
            .put("v", 1)
            .put("s", slot)
            .put("d", profile.deviceId)
            .put("at", System.currentTimeMillis())
            .put("on", onTarget)
            .put("c", Json.claimsToJson(profile.claims().values))
            .put("u", Json.daysToJson(days))
            .put("p", Json.daysToJson(past))
            .apply {
                // Our usage in the current package, counted to the hour on this phone.
                val start = profile.packageStart
                if (start > 0 && slot.isNotBlank()) {
                    val use = Package.usageSince(start, store.hours(), store.days()).first
                    put("cs", start)
                    put("cu", org.json.JSONArray().put(use.rx).put(use.tx))
                }
                if (profile.isAdmin) {
                    // The admin shares how to recognise the router and when each package started.
                    put("n", org.json.JSONArray(store.knownNetworks().toList()))
                    put("cy", org.json.JSONArray(profile.packageStarts().takeLast(12)))
                }
            }
            .toString()
    }

    /** Reads the relay, updates claims (and reports for the admin). Throws when offline. */
    private fun pull(profile: Profile) {
        val reports = Relay.poll().mapNotNull { parse(it) }
        val merged = profile.mergeClaims(reports.flatMap { it.claims })
        // Did someone else own our person first?
        val mine = profile.slot
        if (mine != null && mine != Config.ADMIN_SLOT) {
            val owner = merged[mine]
            if (owner != null && owner.device != profile.deviceId) {
                profile.lostSlot = mine
                profile.slot = null
            }
        }
        // After "clear data" / reinstall: get our own history back from our last report.
        val me = profile.slot
        if (me != null) {
            reports.mapNotNull { it.snapshot }
                .filter { it.slot == me && it.device == profile.deviceId }
                .maxByOrNull { it.at }
                ?.let { UsageStore(profile.appContext).restoreIfEmpty(it.days) }
        }
        // Learn the target router and the package starts from the admin's reports (only the admin can start a package).
        val fromAdmin = reports.filter { it.snapshot?.slot == Config.ADMIN_SLOT }
        if (!profile.isAdmin) {
            val store = UsageStore(profile.appContext)
            fromAdmin.flatMap { it.nets }.forEach { store.learnNetwork(it) }
        }
        profile.mergePackageStarts(fromAdmin.flatMap { it.packages })
        if (profile.isAdmin) {
            val valid = reports.mapNotNull { it.snapshot }.filter { s ->
                s.slot == Config.ADMIN_SLOT || merged[s.slot]?.device == s.device
            }
            profile.mergeReports(valid)
        }
        profile.lastSync = System.currentTimeMillis()
    }

    /** Report content without the timestamp, to skip posting identical reports. */
    private fun contentKey(body: String): String =
        runCatching { JSONObject(body).apply { remove("at") }.toString().hashCode().toString() }.getOrDefault("")

    /** Fetches the latest claims. @return true when the relay was reachable. */
    suspend fun refresh(context: Context): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            runCatching { pull(Profile(context)) }.isSuccess
        }
    }

    /** Pull, then post our own report when due (or when [force]). Safe to call often. */
    suspend fun sync(context: Context, force: Boolean = false, onTarget: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            val profile = Profile(context)
            val ok = runCatching { pull(profile) }.isSuccess
            if (!ok) return@withLock false
            if (profile.slot != null) {
                val since = System.currentTimeMillis() - profile.lastPublish
                val body = buildReport(context, profile, onTarget)
                val fingerprint = contentKey(body)
                val changed = fingerprint != profile.lastPublishedKey
                if (force || (changed && since > PUBLISH_EVERY) || since > HEARTBEAT_EVERY) {
                    val sent = runCatching { Relay.publish(body) }.isSuccess
                    if (sent) {
                        profile.lastPublish = System.currentTimeMillis()
                        profile.lastPublishedKey = fingerprint
                    }
                }
            }
            true
        }
    }

    /** Takes a person for this phone, if nobody else has. */
    suspend fun claim(context: Context, slot: String): ClaimResult = withContext(Dispatchers.IO) {
        mutex.withLock {
            val profile = Profile(context)
            if (runCatching { pull(profile) }.isFailure) return@withLock ClaimResult.Offline
            val owner = profile.claims()[slot]
            if (owner != null && owner.device != profile.deviceId) return@withLock ClaimResult.Taken
            val claim = owner ?: Claim(slot, profile.deviceId, System.currentTimeMillis())
            profile.mergeClaims(listOf(claim))
            profile.slot = slot
            profile.lostSlot = null
            val sent = runCatching { Relay.publish(buildReport(context, profile, false)) }.isSuccess
            if (!sent) {
                profile.slot = null
                return@withLock ClaimResult.Offline
            }
            profile.lastPublish = System.currentTimeMillis()
            ClaimResult.Ok
        }
    }

    /** Admin only: a new package starts now. Every phone learns the exact date and time. */
    suspend fun startPackage(context: Context): Long = withContext(Dispatchers.IO) {
        mutex.withLock {
            val profile = Profile(context)
            if (!profile.isAdmin) return@withLock 0L
            val now = System.currentTimeMillis()
            profile.mergePackageStarts(listOf(now))
            val sent = runCatching { Relay.publish(buildReport(context, profile, false)) }.isSuccess
            if (sent) profile.lastPublish = System.currentTimeMillis()
            now
        }
    }

    /** Admin login (any number of admin phones is fine). */
    fun becomeAdmin(context: Context) {
        val p = Profile(context)
        p.slot = Config.ADMIN_SLOT
        p.lostSlot = null
    }
}
