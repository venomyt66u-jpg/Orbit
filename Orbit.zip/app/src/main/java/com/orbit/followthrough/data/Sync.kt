package com.orbit.followthrough.data

import android.content.Context
import com.orbit.followthrough.domain.Claim
import com.orbit.followthrough.domain.Days
import com.orbit.followthrough.domain.Snapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate

/**
 * Tiny message relay (ntfy.sh, no account needed). Every phone posts a small report
 * (who it is, the group's known claims, its daily usage on the target network).
 * Messages stay on the relay for ~12 h, and every report repeats all known claims,
 * so the group keeps its memory as long as any phone is active.
 */
object Relay {
    private const val BASE = "https://ntfy.sh/"

    fun publish(body: String) {
        val c = URL(BASE + Config.RELAY_TOPIC).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "text/plain; charset=utf-8")
            c.setRequestProperty("Firebase", "no")
            c.setRequestProperty("User-Agent", "OrbitWifi/2.0")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) throw java.io.IOException("relay HTTP $code")
        } finally {
            c.disconnect()
        }
    }

    /** All messages still held by the relay, oldest first. */
    fun poll(): List<String> {
        val c = URL(BASE + Config.RELAY_TOPIC + "/json?poll=1&since=all").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "OrbitWifi/2.0")
            val code = c.responseCode
            if (code !in 200..299) throw java.io.IOException("relay HTTP $code")
            val out = ArrayList<String>()
            BufferedReader(InputStreamReader(c.inputStream, Charsets.UTF_8)).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.isBlank()) continue
                    val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
                    if (o.optString("event") == "message") o.optString("message").takeIf { it.isNotBlank() }?.let { out += it }
                }
            }
            return out
        } finally {
            c.disconnect()
        }
    }
}

sealed interface ClaimResult {
    data object Ok : ClaimResult
    data object Taken : ClaimResult
    data object Offline : ClaimResult
}

object SyncEngine {
    private val mutex = Mutex()
    private const val PUBLISH_EVERY = 55 * 60_000L
    private const val KEEP_DAYS = 40

    private data class Report(val claims: List<Claim>, val snapshot: Snapshot?)

    private fun parse(body: String): Report? {
        val o = runCatching { JSONObject(body) }.getOrNull() ?: return null
        if (o.optInt("v") != 1) return null
        val claims = Json.claimsFromJson(o.optJSONArray("c"))
        val slot = o.optString("s")
        val dev = o.optString("d")
        val snap = if (slot.isNotBlank() && dev.isNotBlank())
            Snapshot(slot, dev, o.optLong("at"), Json.daysFromJson(o.optJSONObject("u")), o.optBoolean("on"))
        else null
        return Report(claims, snap)
    }

    private fun buildReport(context: Context, profile: Profile, onTarget: Boolean): String {
        val slot = profile.slot ?: ""
        val days = if (slot.isBlank()) emptyMap() else Days.recent(UsageStore(context).days(), LocalDate.now(), KEEP_DAYS)
        return JSONObject()
            .put("v", 1)
            .put("s", slot)
            .put("d", profile.deviceId)
            .put("at", System.currentTimeMillis())
            .put("on", onTarget)
            .put("c", Json.claimsToJson(profile.claims().values))
            .put("u", Json.daysToJson(days))
            .toString()
    }

    /** Reads the relay, updates claims (and reports for the admin). Throws when offline. */
    private fun pull(profile: Profile) {
        val reports = Relay.poll().mapNotNull { parse(it) }
        val merged = profile.mergeClaims(reports.flatMap { it.claims })
        // Did someone else own our person first?
        val mine = profile.slot
        if (mine != null && mine != Config.ADMIN_SLOT) {
            val owner = merged[mine]
            if (owner != null && owner.device != profile.deviceId) {
                profile.lostSlot = mine
                profile.slot = null
            }
        }
        if (profile.isAdmin) {
            val valid = reports.mapNotNull { it.snapshot }.filter { s ->
                s.slot == Config.ADMIN_SLOT || merged[s.slot]?.device == s.device
            }
            profile.mergeReports(valid)
        }
        profile.lastSync = System.currentTimeMillis()
    }

    /** Fetches the latest claims. @return true when the relay was reachable. */
    suspend fun refresh(context: Context): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            runCatching { pull(Profile(context)) }.isSuccess
        }
    }

    /** Pull, then post our own report when due (or when [force]). Safe to call often. */
    suspend fun sync(context: Context, force: Boolean = false, onTarget: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            val profile = Profile(context)
            val ok = runCatching { pull(profile) }.isSuccess
            if (!ok) return@withLock false
            val due = System.currentTimeMillis() - profile.lastPublish > PUBLISH_EVERY
            if ((force || due) && profile.slot != null) {
                val sent = runCatching { Relay.publish(buildReport(context, profile, onTarget)) }.isSuccess
                if (sent) profile.lastPublish = System.currentTimeMillis()
            }
            true
        }
    }

    /** Takes a person for this phone, if nobody else has. */
    suspend fun claim(context: Context, slot: String): ClaimResult = withContext(Dispatchers.IO) {
        mutex.withLock {
            val profile = Profile(context)
            if (runCatching { pull(profile) }.isFailure) return@withLock ClaimResult.Offline
            val owner = profile.claims()[slot]
            if (owner != null && owner.device != profile.deviceId) return@withLock ClaimResult.Taken
            val claim = owner ?: Claim(slot, profile.deviceId, System.currentTimeMillis())
            profile.mergeClaims(listOf(claim))
            profile.slot = slot
            profile.lostSlot = null
            val sent = runCatching { Relay.publish(buildReport(context, profile, false)) }.isSuccess
            if (!sent) {
                profile.slot = null
                return@withLock ClaimResult.Offline
            }
            profile.lastPublish = System.currentTimeMillis()
            ClaimResult.Ok
        }
    }

    /** Admin login (any number of admin phones is fine). */
    fun becomeAdmin(context: Context) {
        val p = Profile(context)
        p.slot = Config.ADMIN_SLOT
        p.lostSlot = null
    }
}
