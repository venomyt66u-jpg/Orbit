package com.orbit.followthrough.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import com.orbit.followthrough.data.prefs.AppSettings

/**
 * Android 8+ freezes a channel's sound/vibration once created. When the user picks a new sound
 * we create a fresh, versioned channel ("reminders_v3") and delete the stale one.
 */
class ChannelManager(private val context: Context) {

    private val nm = context.getSystemService(NotificationManager::class.java)

    fun channelId(key: ChannelKey, settings: AppSettings): String = "${key.id}_v${settings.style(key).version}"

    fun ensure(settings: AppSettings) {
        val existing = nm.notificationChannels.map { it.id }.toSet()
        for (key in ChannelKey.entries) {
            val id = channelId(key, settings)
            if (id !in existing) nm.createNotificationChannel(build(key, id, settings))
            existing.filter { it.startsWith("${key.id}_v") && it != id }.forEach { stale ->
                runCatching { nm.deleteNotificationChannel(stale) }
            }
        }
    }

    private fun build(key: ChannelKey, id: String, settings: AppSettings): NotificationChannel {
        val style = settings.style(key)
        return NotificationChannel(id, context.getString(key.nameRes), key.importance).apply {
            description = context.getString(key.descRes)
            val uri = SoundLibrary.uriFor(context, style.sound)
            if (uri == null) setSound(null, null) else setSound(uri, SoundLibrary.audioAttributes())
            if (style.vibe == VibePattern.NONE) {
                enableVibration(false)
            } else {
                enableVibration(true)
                vibrationPattern = style.vibe.pattern
            }
            enableLights(key.importance >= NotificationManager.IMPORTANCE_DEFAULT)
            lightColor = Color.rgb(0x3B, 0xE3, 0xFF)
            setShowBadge(key != ChannelKey.SIGNAL_QUIET && key != ChannelKey.QUIET)
        }
    }

    /** Whether the user disabled the channel in system settings (we surface this in the UI). */
    fun isBlocked(key: ChannelKey, settings: AppSettings): Boolean =
        nm.getNotificationChannel(channelId(key, settings))?.importance == NotificationManager.IMPORTANCE_NONE
}
