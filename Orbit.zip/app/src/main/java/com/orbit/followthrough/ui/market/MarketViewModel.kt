package com.orbit.followthrough.ui.market

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.data.db.CoinEntity
import com.orbit.followthrough.data.db.WalletActivityEntity
import com.orbit.followthrough.data.db.WalletEntity
import com.orbit.followthrough.market.CoinHit
import com.orbit.followthrough.market.MarketSnapshot
import com.orbit.followthrough.net.Http
import com.orbit.followthrough.wallets.AddressRules
import com.orbit.followthrough.wallets.Chain
import com.orbit.followthrough.watch.WatchRunner
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class AiBrief(val loading: Boolean = false, val text: String? = null, val error: String? = null)

class MarketViewModel(val c: AppContainer) : ViewModel() {

    val coins: StateFlow<List<CoinEntity>?> = c.db.market().observeCoins().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val wallets: StateFlow<List<WalletEntity>?> = c.db.wallets().observeWallets().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val recentActivity: StateFlow<List<WalletActivityEntity>> = c.db.wallets().observeRecent(6).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val snapshot: StateFlow<MarketSnapshot> = c.market.snapshot

    val searchResults = MutableStateFlow<List<CoinHit>>(emptyList())
    val searching = MutableStateFlow(false)
    val brief = MutableStateFlow(AiBrief())
    private var searchJob: Job? = null

    init {
        // While the screen is open, prices refresh every 60 s (cheap: one request).
        viewModelScope.launch {
            c.market.refreshAll()
            while (isActive) {
                delay(60_000)
                c.market.refreshPrices()
            }
        }
    }

    fun refresh() = viewModelScope.launch { c.market.refreshAll() }

    fun search(q: String) {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            delay(350)
            searching.value = true
            searchResults.value = runCatching { c.market.search(q) }.getOrDefault(emptyList())
            searching.value = false
        }
    }

    fun addCoin(hit: CoinHit) = viewModelScope.launch {
        c.market.add(hit)
        WatchRunner.reschedule(c)
    }

    fun removeCoin(id: String) = viewModelScope.launch { c.market.remove(id) }

    fun setAlerts(id: String, above: Double?, below: Double?) = viewModelScope.launch {
        c.market.setAlerts(id, above, below)
        WatchRunner.reschedule(c)
    }

    fun toggleLive(on: Boolean) = viewModelScope.launch {
        c.settings.update { liveMode = on }
        WatchRunner.reschedule(c)
    }

    /** @return error string resource or null. */
    suspend fun addWallet(name: String, chain: Chain, address: String, minUsd: Double): Int? {
        val a = address.trim()
        if (name.isBlank()) return com.orbit.followthrough.R.string.error_wallet_name
        if (!AddressRules.valid(chain, a)) return com.orbit.followthrough.R.string.error_wallet_address
        if (chain.needsKey) {
            val usable = c.wallets.availableEvm()
            val ok = if (chain == Chain.ALL_EVM) usable.isNotEmpty() else chain in usable
            if (!ok) return if (chain == Chain.BSC) com.orbit.followthrough.R.string.error_wallet_key_bsc else com.orbit.followthrough.R.string.error_wallet_key
        }
        c.wallets.add(name, chain, a, minUsd)
        WatchRunner.reschedule(c)
        return null
    }

    fun aiBrief() = viewModelScope.launch {
        val s = c.settings.current()
        if (!c.ai.ready(s)) { brief.value = AiBrief(error = "connect"); return@launch }
        brief.value = AiBrief(loading = true)
        c.ai.marketBrief(s, c.market.briefContext()).fold(
            onSuccess = { brief.value = AiBrief(text = it) },
            onFailure = { brief.value = AiBrief(error = Http.reason(it)) },
        )
    }
}
