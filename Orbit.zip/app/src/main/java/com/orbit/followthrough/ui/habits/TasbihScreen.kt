package com.orbit.followthrough.ui.habits

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.orbit.followthrough.AppContainer
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.HabitEntity
import com.orbit.followthrough.ui.components.CompletionCheck
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.Segmented
import com.orbit.followthrough.ui.components.TopBar
import com.orbit.followthrough.ui.components.ambientPhase
import com.orbit.followthrough.ui.components.beadRing
import com.orbit.followthrough.ui.nav.LocalSettings
import com.orbit.followthrough.ui.nav.Routes
import com.orbit.followthrough.ui.nav.orbitViewModel
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.PI
import kotlin.math.sin

/**
 * Verified, widely used dhikr phrases (fixed text – never generated).
 * Users may also type their own phrase; Orbit does not create religious text.
 */
object Dhikr {
    data class Phrase(val arabic: String, val transliteration: String)
    val presets = listOf(
        Phrase("سُبْحَانَ اللَّهِ", "SubhanAllah"),
        Phrase("الْحَمْدُ لِلَّهِ", "Alhamdulillah"),
        Phrase("اللَّهُ أَكْبَرُ", "Allahu Akbar"),
        Phrase("لَا إِلَٰهَ إِلَّا اللَّهُ", "La ilaha illallah"),
        Phrase("أَسْتَغْفِرُ اللَّهَ", "Astaghfirullah"),
        Phrase("سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "SubhanAllahi wa bihamdihi"),
        Phrase("لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "La hawla wa la quwwata illa billah"),
        Phrase("اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ", "Allahumma salli ala Muhammad"),
    )
}

class TasbihViewModel(private val c: AppContainer, private val habitId: Long) : ViewModel() {
    private val day = LocalDate.now().toEpochDay()
    val habit: StateFlow<HabitEntity?> = c.db.habits().observe(habitId).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    val stored: StateFlow<Int?> = kotlinx.coroutines.flow.flow {
        c.db.habits().observeLog(habitId, day).collect { emit(it?.count ?: 0) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val todayByPhrase: StateFlow<List<com.orbit.followthrough.data.db.DhikrLogEntity>> =
        c.db.dhikr().observeDay(day).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val history: StateFlow<List<com.orbit.followthrough.data.db.DhikrLogEntity>> =
        c.db.dhikr().observeHistory(120).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val allTime: StateFlow<Int> = c.db.dhikr().observeAllTime().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)
    private val dhikrMutex = kotlinx.coroutines.sync.Mutex()

    /** Every tap is saved immediately: today's habit progress + the per-phrase dhikr log. */
    fun add(delta: Int, phrase: String) = viewModelScope.launch {
        c.habitEngine.add(habitId, delta)
        dhikrMutex.lock()
        try {
            val p = phrase.ifBlank { "—" }
            val cur = c.db.dhikr().get(p, day)?.taps ?: 0
            c.db.dhikr().upsert(com.orbit.followthrough.data.db.DhikrLogEntity(p, day, (cur + delta).coerceAtLeast(0)))
        } finally {
            dhikrMutex.unlock()
        }
    }

    fun setTotal(total: Int) = viewModelScope.launch { c.habitEngine.setToday(habitId, total) }

    /** "Delete all": wipes every saved dhikr count (all days, all phrases) and the tasbih progress. */
    fun deleteAll() = viewModelScope.launch {
        c.db.dhikr().deleteAll()
        c.db.habits().deleteLogs(habitId)
    }
    fun update(block: HabitEntity.() -> HabitEntity) = viewModelScope.launch {
        val h = c.db.habits().get(habitId) ?: return@launch
        c.habitEngine.save(h.block())
    }
}

@Composable
fun TasbihScreen(nav: NavHostController, habitId: Long) {
    val vm = orbitViewModel(key = "tasbih$habitId") { TasbihViewModel(it, habitId) }
    val habit by vm.habit.collectAsStateWithLifecycle()
    val stored by vm.stored.collectAsStateWithLifecycle()
    val todayList by vm.todayByPhrase.collectAsStateWithLifecycle()
    val historyList by vm.history.collectAsStateWithLifecycle()
    val allTimeTotal by vm.allTime.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf(false) }
    val c = Orbit.colors
    val view = LocalView.current
    val hapticsOn = LocalSettings.current.hapticsEnabled
    val scope = rememberCoroutineScope()

    // Local count for instant feedback while taps are persisted in the background.
    var total by remember { mutableIntStateOf(-1) }
    LaunchedEffect(stored) { val s = stored; if (s != null && (total < 0 || s > total)) total = s }
    val h = habit
    val round = (h?.roundSize ?: 33).coerceAtLeast(1)
    val inRound = if (total < 0) 0 else total % round
    val rounds = if (total < 0) 0 else total / round
    var celebrate by remember { mutableStateOf(false) }
    val press = remember { Animatable(1f) }
    val phase = ambientPhase(2600)
    val gold = c.gold

    if (confirmDelete) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = c.surface,
            title = { Text(stringResource(R.string.dhikr_delete_q), color = c.text) },
            text = { Text(stringResource(R.string.dhikr_delete_body), color = c.textSecondary) },
            confirmButton = { androidx.compose.material3.TextButton(onClick = { confirmDelete = false; total = 0; vm.deleteAll() }) { Text(stringResource(R.string.delete_all), color = c.rose) } },
            dismissButton = { androidx.compose.material3.TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.cancel), color = c.textSecondary) } },
        )
    }
    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 20.dp)) {
        TopBar(stringResource(R.string.tasbih), { nav.popBackStack() }, stringResource(R.string.back)) {
            IconCircle(OrbitIcons.Edit, stringResource(R.string.edit), { nav.navigate(Routes.habitEdit(habitId)) })
        }
        if (h != null) {

        // phrase selector
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val isPreset = Dhikr.presets.any { it.arabic == h.phrase }
            if (!isPreset && h.phrase.isNotBlank()) OrbitChip(h.phrase, true, {}, accent = gold)
            Dhikr.presets.forEach { p ->
                OrbitChip(p.arabic, h.phrase == p.arabic, { vm.update { copy(phrase = p.arabic) } }, accent = gold)
            }
        }
        val translit = Dhikr.presets.firstOrNull { it.arabic == h.phrase }?.transliteration

        Spacer(Modifier.height(12.dp))
        Text(h.phrase.ifBlank { h.name }, style = OrbitType.headline.copy(fontSize = 30.sp), color = c.text, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        if (translit != null) Text(translit, style = OrbitType.label, color = c.textMuted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(18.dp))

        // the counter
        val tapLabel = stringResource(R.string.tasbih_tap_cd, inRound, round)
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .scale(press.value)
                .clip(CircleShape)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, role = Role.Button) {
                    if (total < 0) total = 0
                    total += 1
                    vm.add(1, h.phrase)
                    val completed = total % round == 0
                    if (hapticsOn) view.performHapticFeedback(if (completed) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.KEYBOARD_TAP)
                    if (completed) celebrate = true
                    scope.launch { press.snapTo(0.97f); press.animateTo(1f, tween(140)) }
                }
                .semantics { contentDescription = tapLabel },
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(Brush.radialGradient(listOf(gold.copy(alpha = 0.16f), Color.Transparent), center, size.minDimension / 2))
                beadRing(round, inRound, gold, c.strokeStrong, ((sin(phase * 2 * PI) + 1) / 2).toFloat())
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$inRound", style = OrbitType.numeric.copy(fontSize = 84.sp), color = c.text)
                Text(stringResource(R.string.round_of, rounds + 1, round), style = OrbitType.label, color = c.textSecondary)
                Text(stringResource(R.string.today_total, if (total < 0) 0 else total, h.target), style = OrbitType.caption, color = gold)
            }
            CompletionCheck(celebrate, gold, Modifier.size(140.dp))
        }
        LaunchedEffect(celebrate) { if (celebrate) { kotlinx.coroutines.delay(1400); celebrate = false } }

        Spacer(Modifier.height(12.dp))
        Segmented(
            options = listOf(33 to "33", 99 to "99", 100 to "100"),
            selected = round,
            onSelect = { v -> vm.update { copy(roundSize = v) } },
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(
                Modifier.clip(CircleShape).border(1.dp, c.stroke, CircleShape).clickable {
                    if (total > 0) { total -= 1; vm.add(-1, h.phrase) }
                }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                androidx.compose.material3.Icon(OrbitIcons.Undo, null, tint = c.textSecondary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.undo), style = OrbitType.label, color = c.textSecondary)
            }
            Row(
                Modifier.clip(CircleShape).background(c.surface).border(1.dp, c.stroke, CircleShape).clickable {
                    // Reset the current round only; today's completed rounds are kept.
                    if (total > 0 && inRound > 0) { total -= inRound; vm.setTotal(total) }
                }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                androidx.compose.material3.Icon(OrbitIcons.Refresh, null, tint = c.textSecondary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.reset_round), style = OrbitType.label, color = c.textSecondary)
            }
        }
        Spacer(Modifier.height(4.dp))
        TasbihHistory(
            today = todayList, history = historyList, allTime = allTimeTotal,
            onDeleteAll = { confirmDelete = true },
        )
    }
    }
}

@Composable
private fun TasbihHistory(
    today: List<com.orbit.followthrough.data.db.DhikrLogEntity>,
    history: List<com.orbit.followthrough.data.db.DhikrLogEntity>,
    allTime: Int,
    onDeleteAll: () -> Unit,
) {
    val c = Orbit.colors
    val ctx = androidx.compose.ui.platform.LocalContext.current
    com.orbit.followthrough.ui.components.GlassCard(Modifier.fillMaxWidth().padding(bottom = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.dhikr_log), style = OrbitType.title, color = c.text)
                Text(stringResource(R.string.dhikr_all_time, allTime), style = OrbitType.caption, color = c.gold)
            }
            if (allTime > 0) com.orbit.followthrough.ui.components.SecondaryButton(stringResource(R.string.delete_all), onDeleteAll, icon = OrbitIcons.Trash, tint = c.rose)
        }
        if (today.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.today), style = OrbitType.overline, color = c.textMuted)
            today.forEach { d ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(d.phrase, style = OrbitType.subtitle, color = c.text, modifier = Modifier.weight(1f))
                    Text("${d.taps}", style = OrbitType.numericSmall, color = c.gold)
                }
            }
        }
        val past = history.filter { it.epochDay != java.time.LocalDate.now().toEpochDay() }.groupBy { it.epochDay }.entries.take(14)
        if (past.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(stringResource(R.string.previous_days), style = OrbitType.overline, color = c.textMuted)
            past.forEach { (day, rows) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(com.orbit.followthrough.ui.util.Fmt.dayLabel(ctx, java.time.LocalDate.ofEpochDay(day)), style = OrbitType.body, color = c.textSecondary, modifier = Modifier.weight(1f))
                    Text("${rows.sumOf { it.taps }}", style = OrbitType.numericSmall, color = c.text)
                }
            }
        }
        if (allTime == 0) {
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.dhikr_empty), style = OrbitType.caption, color = c.textMuted)
        }
    }
}
