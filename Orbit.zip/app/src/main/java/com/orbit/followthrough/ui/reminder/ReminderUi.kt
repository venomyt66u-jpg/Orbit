package com.orbit.followthrough.ui.reminder

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.orbit.followthrough.R
import com.orbit.followthrough.data.db.ReminderEntity
import com.orbit.followthrough.domain.ReminderCategory
import com.orbit.followthrough.domain.ReminderStatus
import com.orbit.followthrough.ui.components.GlyphBadge
import com.orbit.followthrough.ui.components.IconCircle
import com.orbit.followthrough.ui.components.OrbitChip
import com.orbit.followthrough.ui.components.OrbitIcons
import com.orbit.followthrough.ui.components.Tag
import com.orbit.followthrough.ui.components.pressable
import com.orbit.followthrough.ui.theme.Orbit
import com.orbit.followthrough.ui.theme.OrbitType
import com.orbit.followthrough.ui.util.Fmt

fun categoryIcon(c: ReminderCategory): ImageVector = when (c) {
    ReminderCategory.GENERAL -> OrbitIcons.Dot
    ReminderCategory.WORK -> OrbitIcons.Briefcase
    ReminderCategory.HEALTH -> OrbitIcons.Heart
    ReminderCategory.STUDY -> OrbitIcons.Book
    ReminderCategory.SPIRITUAL -> OrbitIcons.Crescent
    ReminderCategory.PERSONAL -> OrbitIcons.Person
}

fun categoryLabel(c: ReminderCategory): Int = when (c) {
    ReminderCategory.GENERAL -> R.string.cat_general
    ReminderCategory.WORK -> R.string.cat_work
    ReminderCategory.HEALTH -> R.string.cat_health
    ReminderCategory.STUDY -> R.string.cat_study
    ReminderCategory.SPIRITUAL -> R.string.cat_spiritual
    ReminderCategory.PERSONAL -> R.string.cat_personal
}

/** One reminder line used on Home and in the full list. */
@Composable
fun ReminderRow(
    r: ReminderEntity,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
    onDone: (() -> Unit)? = null,
    onLater: (() -> Unit)? = null,
    now: Long = System.currentTimeMillis(),
) {
    val c = Orbit.colors
    val ctx = LocalContext.current
    val color = c.category(r.category)
    val pending = r.status == ReminderStatus.PENDING
    Row(
        modifier.fillMaxWidth().pressable(onOpen).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        GlyphBadge(categoryIcon(r.category), if (pending) c.amber else color)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(r.title, style = OrbitType.subtitle, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            val line = when (r.status) {
                ReminderStatus.PENDING -> {
                    val since = r.pendingOccurrenceAt?.let { stringResource(R.string.waiting_since, Fmt.time(ctx, it)) } ?: ""
                    val fu = r.followUpAt?.let { " · " + stringResource(R.string.returns_at, Fmt.time(ctx, it)) } ?: ""
                    since + fu
                }
                ReminderStatus.SCHEDULED -> r.nextOccurrenceAt?.let { Fmt.dayAndTime(ctx, it) + " · " + Fmt.countdown(ctx, it, now) } ?: ""
                ReminderStatus.PAUSED -> stringResource(R.string.status_paused)
                ReminderStatus.DONE -> stringResource(R.string.status_done)
            }
            Text(line, style = OrbitType.caption, color = if (pending) c.amber else c.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (r.important) {
            Spacer(Modifier.width(8.dp))
            Tag(stringResource(R.string.important_short), c.amber, icon = OrbitIcons.Flag)
        }
        if (onLater != null) {
            Spacer(Modifier.width(8.dp))
            IconCircle(OrbitIcons.Later, stringResource(R.string.action_later), onLater, size = 40.dp, tint = c.textSecondary)
        }
        if (onDone != null) {
            Spacer(Modifier.width(8.dp))
            IconCircle(OrbitIcons.Check, stringResource(R.string.action_done), onDone, size = 40.dp, tint = c.green, background = c.green.copy(alpha = 0.12f))
        }
    }
}

/** "Remind me later" chooser: 5 / 10 / 15 / 30 / 60 minutes. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LaterSheet(title: String, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val c = Orbit.colors
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = c.surface, contentColor = c.text) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp).navigationBarsPadding().padding(bottom = 24.dp)) {
            Text(stringResource(R.string.later_title), style = OrbitType.title, color = c.text)
            Text(title, style = OrbitType.body, color = c.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(18.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(5, 10, 15, 30, 60).forEach { m ->
                    OrbitChip(stringResource(R.string.minutes_short, m), selected = false, onClick = { onPick(m) }, icon = OrbitIcons.Later)
                }
            }
        }
    }
}
