package com.orbit.followthrough.ai

import com.orbit.followthrough.domain.RepeatType
import com.orbit.followthrough.domain.Weekdays
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

class CommandParserTest {
    // Sunday 2026-10-11, 08:00 Cairo
    private val now = ZonedDateTime.of(LocalDateTime.of(2026, 10, 11, 8, 0), ZoneId.of("Africa/Cairo"))

    private fun draft(text: String): ReminderDraft {
        val c = CommandParser.parse(text, now)
        assertTrue("expected Create for '$text' but was $c", c is Command.Create)
        return (c as Command.Create).draft
    }

    @Test fun englishDailyWithTime() {
        val d = draft("Remind me every day at 9 AM to read ten pages.")
        assertEquals("Read ten pages", d.title)
        assertEquals(RepeatType.DAILY, d.repeat)
        assertEquals(9, d.hour)
        assertEquals(0, d.minute)
    }

    @Test fun englishEveningTime() {
        val d = draft("Remind me every day at 8 PM to read.")
        assertEquals(20, d.hour)
        assertEquals("Read", d.title)
    }

    @Test fun englishOneTimeTitleFirst() {
        val d = draft("remind me to call mom at 5:30pm")
        assertEquals("Call mom", d.title)
        assertEquals(17, d.hour)
        assertEquals(30, d.minute)
        assertEquals(RepeatType.ONCE, d.repeat)
        assertEquals(LocalDate.of(2026, 10, 11), d.date)
    }

    @Test fun englishRelative() {
        val d = draft("remind me in 30 minutes to stretch")
        assertEquals("Stretch", d.title)
        assertEquals(8, d.hour)
        assertEquals(30, d.minute)
    }

    @Test fun englishTomorrow() {
        val d = draft("Remind me tomorrow at 7:15 am to take vitamins")
        assertEquals(LocalDate.of(2026, 10, 12), d.date)
        assertEquals(7, d.hour)
        assertEquals(15, d.minute)
        assertEquals("Take vitamins", d.title)
    }

    @Test fun englishWeekdaysList() {
        val d = draft("remind me every monday and thursday at 6pm to go to the gym")
        assertEquals(RepeatType.WEEKLY, d.repeat)
        assertEquals(Weekdays.MON or Weekdays.THU, d.weekdays)
        assertEquals(18, d.hour)
        assertEquals("Go to the gym", d.title)
    }

    @Test fun ambiguousHourAsksForMeridiem() {
        val d = draft("remind me at 8 to call Sara")
        assertTrue(d.needsMeridiem)
        assertEquals("Call Sara", d.title)
    }

    @Test fun missingTimeIsFlagged() {
        val d = draft("remind me to renew my passport")
        assertTrue(d.missingTime)
        assertEquals("Renew my passport", d.title)
    }

    @Test fun routineWithDuration() {
        val d = draft("Create a daily study routine for one hour")
        assertEquals(RepeatType.DAILY, d.repeat)
        assertTrue(d.title.startsWith("Study"))
        assertTrue(d.missingTime)
    }

    @Test fun arabicDailyMorning() {
        val d = draft("ذكرني كل يوم الساعة 9 الصبح أقرأ 10 صفحات")
        assertEquals(RepeatType.DAILY, d.repeat)
        assertEquals(9, d.hour)
        assertEquals("أقرأ 10 صفحات", d.title)
    }

    @Test fun arabicEveningHalfPast() {
        val d = draft("فكرني بكرة الساعة 7 ونص بالليل اتصل بماما")
        assertEquals(LocalDate.of(2026, 10, 12), d.date)
        assertEquals(19, d.hour)
        assertEquals(30, d.minute)
        assertEquals("اتصل بماما", d.title)
    }

    @Test fun arabicRelative() {
        val d = draft("فكرني بعد نص ساعة أشرب مية")
        assertEquals(8, d.hour)
        assertEquals(30, d.minute)
        assertEquals("أشرب مية", d.title)
    }

    @Test fun arabicEveryFriday() {
        val d = draft("ذكرني كل جمعة الساعة 11 الصبح أقرأ سورة الكهف")
        assertEquals(RepeatType.WEEKLY, d.repeat)
        assertEquals(Weekdays.FRI, d.weekdays)
        assertEquals(11, d.hour)
        assertEquals("أقرأ سورة الكهف", d.title)
    }

    @Test fun arabicDigits() {
        val d = draft("ذكرني الساعة ٥ م أخرج الزبالة")
        assertEquals(17, d.hour)
        assertEquals("أخرج الزبالة", d.title)
    }

    @Test fun postponedQuery() {
        assertEquals(Command.ShowPostponed, CommandParser.parse("Show me all tasks I postponed today", now))
        assertEquals(Command.ShowPostponed, CommandParser.parse("ايه المهام اللي أجلتها النهاردة", now))
    }

    @Test fun summarizeQuery() {
        assertEquals(Command.Summarize, CommandParser.parse("Summarize important updates from my selected sources", now))
        assertEquals(Command.Summarize, CommandParser.parse("لخص لي التحديثات", now))
    }

    @Test fun quietAfter() {
        val c = CommandParser.parse("Make this reminder silent after 10 PM", now)
        assertEquals(Command.QuietAfter(22 * 60, null), c)
    }

    @Test fun followUpForExistingReminder() {
        val c = CommandParser.parse("Repeat this reminder in 30 minutes if I haven't completed it", now)
        assertEquals(Command.SetFollowUp(30), c)
    }

    @Test fun unrelatedTextIsUnknown() {
        assertTrue(CommandParser.parse("hello there", now) is Command.Unknown)
    }
}
