package com.orbit.followthrough.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

class UsageTest {
    private val cairo = ZoneId.of("Africa/Cairo")
    private fun at(y: Int, mo: Int, d: Int, h: Int, mi: Int) = LocalDateTime.of(y, mo, d, h, mi).atZone(cairo).toInstant().toEpochMilli()

    @Test fun ssidIsCleaned() {
        assertEquals("G", Ssid.clean("\"G\""))
        assertNull(Ssid.clean("<unknown ssid>"))
        assertNull(Ssid.clean(""))
        assertEquals("My Net", Ssid.clean("My Net"))
    }

    @Test fun wifiDeltaSubtractsMobile() {
        val a = CounterReading(1000, 500, 100, 50, 10, 0)
        val b = CounterReading(5000, 900, 300, 60, 20, 0)
        assertEquals(Bytes(3800, 390), Meter.wifiDelta(a, b))
    }

    @Test fun rebootIsNotGuessed() {
        val a = CounterReading(9000, 9000, 0, 0, 5000, 0)
        val b = CounterReading(100, 100, 0, 0, 10, 0)
        assertNull(Meter.wifiDelta(a, b))
    }

    @Test fun splitAcrossMidnightAddsUp() {
        val start = at(2026, 10, 27, 23, 30)
        val end = at(2026, 10, 28, 0, 30)
        val days = Meter.splitByDay(start, end, Bytes(1000, 101), cairo)
        assertEquals(2, days.size)
        assertEquals(500L, days["2026-10-27"]!!.rx)
        assertEquals(1101L, days.values.sumOf { it.total })
    }

    @Test fun zeroLengthIntervalGoesToOneHour() {
        val t = at(2026, 10, 28, 12, 0)
        assertEquals(Bytes(7, 3), Meter.splitByDay(t, t, Bytes(7, 3), cairo)["2026-10-28"])
    }

    @Test fun attributionRules() {
        assertTrue(Meter.attribute("G", "G", 5 * 3_600_000L, "G"))
        assertTrue(Meter.attribute("G", null, 60_000L, "G"))
        assertTrue(Meter.attribute("G", null, 5 * 3_600_000L, "G"))
        assertTrue(Meter.attribute("G", "~", 10 * 60_000L, "G"))
        assertFalse(Meter.attribute("G", "~", 60 * 60_000L, "G"))
        assertFalse(Meter.attribute("Other", "G", 1000L, "G"))
        assertFalse(Meter.attribute(null, "G", 1000L, "G"))
    }

    @Test fun earliestClaimWins() {
        val m = Claims.merge(emptyMap(), listOf(Claim("dahab", "B", 200), Claim("dahab", "A", 100), Claim("waleed", "C", 50)))
        assertEquals("A", m["dahab"]!!.device)
        assertEquals("dahab", Claims.slotOf("A", m))
        assertEquals(setOf("dahab"), Claims.takenByOthers("C", m))
        val again = Claims.merge(m, listOf(Claim("dahab", "Z", 300)))
        assertEquals("A", again["dahab"]!!.device)
    }

    @Test fun daySumsAndSeries() {
        val days = mapOf("2026-10-01" to Bytes(1, 1), "2026-10-28" to Bytes(10, 0), "2026-09-30" to Bytes(100, 0))
        val today = LocalDate.of(2026, 10, 28)
        val (f, t) = Days.range(Period.CYCLE, today)
        assertEquals(12L, Days.sum(days, f, t).total)
        val (wf, wt) = Days.range(Period.WEEK, today)
        assertEquals(10L, Days.sum(days, wf, wt).total)
        val series = Days.monthSeries(days, today)
        assertEquals(31, series.size)
        assertEquals(10L, series[27])
        assertEquals(2, Days.recent(days, today, 28).size)
    }

    @Test fun parsesArabicDigits() {
        assertEquals(50_000_000_000L, Fmt.parseGb("٥٠"))
        assertEquals(2_500_000_000L, Fmt.parseGb("2,5"))
        assertNull(Fmt.parseGb("abc"))
        assertEquals("1.24 GB", Fmt.bytes(1_240_000_000))
        assertEquals("820 MB", Fmt.bytes(820_000_000))
        assertEquals("1.2G", Fmt.compact(1_240_000_000))
        assertEquals("850M", Fmt.compact(850_000_000))
        assertEquals("0", Fmt.compact(12))
    }
}

class NetPrintTest {
    @Test fun subnetMath() {
        assertEquals("192.168.0.0/24", NetPrint.subnetOf("192.168.0.37", 24))
        assertEquals("10.0.0.0/8", NetPrint.subnetOf("10.20.30.40", 8))
        assertNull(NetPrint.subnetOf("bad", 24))
    }

    @Test fun matching() {
        val g = NetPrint("192.168.0.1", "192.168.0.0/24", "fe80::1a2b")
        val roundTrip = NetPrint.decode(g.encode())!!
        assertEquals(g, roundTrip)
        assertTrue(g.sameAs(NetPrint("192.168.0.1", "192.168.0.0/24", null)))
        assertFalse(g.sameAs(NetPrint("192.168.0.1", "192.168.0.0/24", "fe80::9999")))
        assertFalse(g.sameAs(NetPrint("192.168.1.1", "192.168.1.0/24", null)))
        assertTrue(NetPrint.matchesAny(NetPrint("192.168.0.1", "192.168.0.0/24", null), listOf(g.encode())))
        assertFalse(NetPrint.matchesAny(null, listOf(g.encode())))
    }

    @Test fun maxMergeKeepsLargerDay() {
        val m = Days.mergeMax(mapOf("d1" to Bytes(10, 0), "d2" to Bytes(5, 0)), mapOf("d1" to Bytes(3, 0), "d3" to Bytes(1, 1)))
        assertEquals(10L, m["d1"]!!.total)
        assertEquals(3, m.size)
    }
}

/** Replays a day of readings the way the app books them and checks every byte lands once, on the right day. */
class CalendarAccuracyTest {
    private val zone = ZoneId.of("Africa/Cairo")
    private fun t(d: Int, h: Int, m: Int) = LocalDateTime.of(2026, 10, d, h, m).atZone(zone).toInstant().toEpochMilli()

    private data class Step(val wall: Long, val totalRx: Long, val mobileRx: Long, val place: String?, val elapsed: Long)

    private fun replay(steps: List<Step>): Map<String, Bytes> {
        val book = LinkedHashMap<String, Bytes>()
        var prev: Step? = null
        for (s in steps) {
            val p = prev
            if (p != null && Meter.attribute(p.place, s.place, s.wall - p.wall, "G")) {
                val d = Meter.wifiDelta(
                    CounterReading(p.totalRx, 0, p.mobileRx, 0, p.elapsed, p.wall),
                    CounterReading(s.totalRx, 0, s.mobileRx, 0, s.elapsed, s.wall),
                )
                if (d != null) for ((k, v) in Meter.splitByDay(p.wall, s.wall, d, zone)) book[k] = (book[k] ?: Bytes.ZERO) + v
            }
            prev = s
        }
        return book
    }

    @Test fun overnightOnGSplitsExactlyAtMidnight() {
        // 23:00 → 01:00 on G, 1200 bytes, steady rate: 600 before midnight, 600 after.
        val days = replay(listOf(
            Step(t(28, 23, 0), 0, 0, "G", 1),
            Step(t(29, 1, 0), 1200, 0, "G", 2),
        ))
        assertEquals(600L, days["2026-10-28"]!!.rx)
        assertEquals(600L, days["2026-10-29"]!!.rx)
    }

    @Test fun mobileDataIsNeverCounted() {
        val days = replay(listOf(
            Step(t(29, 10, 0), 0, 0, "G", 1),
            Step(t(29, 10, 15), 5000, 3000, "G", 2), // 3000 of it went over mobile data
        ))
        assertEquals(2000L, days["2026-10-29"]!!.rx)
    }

    @Test fun otherWifiIsNotCountedAndNothingTwice() {
        val days = replay(listOf(
            Step(t(29, 9, 0), 0, 0, "G", 1),
            Step(t(29, 9, 15), 100, 0, "G", 2),     // +100 on G
            Step(t(29, 9, 16), 110, 0, "~", 3),     // switched to another Wi‑Fi right away: +10 booked to G (switch moment)
            Step(t(29, 11, 0), 9110, 0, "~", 4),    // 9000 on the other Wi‑Fi: not counted
            Step(t(29, 11, 5), 9120, 0, "G", 5),    // back on G: previous place was other → not counted
            Step(t(29, 11, 20), 9220, 0, "G", 6),   // +100 on G
        ))
        assertEquals(210L, days["2026-10-29"]!!.rx)
    }

    @Test fun restartWithoutHistoryLosesOnlyThatWindow() {
        val days = replay(listOf(
            Step(t(29, 12, 0), 5000, 0, "G", 50_000),
            Step(t(29, 12, 10), 6000, 0, "G", 50_600),  // +1000
            Step(t(29, 12, 20), 300, 0, "G", 100),       // phone restarted: counters reset → window skipped
            Step(t(29, 12, 30), 800, 0, "G", 700),       // +500
        ))
        assertEquals(1500L, days["2026-10-29"]!!.rx)
    }
}
