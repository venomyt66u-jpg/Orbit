package com.orbit.followthrough.signals

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AccountResolverTest {
    private fun feed(url: String) = AccountResolver.resolve(url) as Resolution.Feed

    @Test fun youtubeChannelId() {
        val r = feed("https://www.youtube.com/channel/UCX6OQ3DkcsbYNE6H8uQQuVA")
        assertEquals(Platform.YOUTUBE, r.platform)
        assertEquals("https://www.youtube.com/feeds/videos.xml?channel_id=UCX6OQ3DkcsbYNE6H8uQQuVA", r.feedUrl)
    }

    @Test fun youtubeHandleNeedsLookup() {
        val r = AccountResolver.resolve("youtube.com/@MrBeast")
        assertTrue(r is Resolution.NeedsLookup)
        assertEquals("https://www.youtube.com/@MrBeast", (r as Resolution.NeedsLookup).pageUrl)
    }

    @Test fun redditUserAndSub() {
        assertEquals("https://www.reddit.com/user/spez/submitted/.rss", feed("https://www.reddit.com/u/spez").feedUrl)
        assertEquals("https://www.reddit.com/r/bitcoin/new/.rss", feed("reddit.com/r/bitcoin").feedUrl)
    }

    @Test fun blueskyMastodonMediumSubstack() {
        assertEquals("https://bsky.app/profile/jay.bsky.team/rss", feed("https://bsky.app/profile/jay.bsky.team").feedUrl)
        assertEquals("https://mastodon.social/@Gargron.rss", feed("https://mastodon.social/@Gargron").feedUrl)
        assertEquals("https://medium.com/feed/@someone", feed("medium.com/@someone").feedUrl)
        assertEquals("https://news.substack.com/feed", feed("https://news.substack.com/p/abc").feedUrl)
    }

    @Test fun githubUserAndRepo() {
        assertEquals("https://github.com/torvalds.atom", feed("github.com/torvalds").feedUrl)
        assertEquals("https://github.com/JetBrains/kotlin/releases.atom", feed("https://github.com/JetBrains/kotlin").feedUrl)
    }

    @Test fun closedPlatformsAreUnsupported() {
        val x = AccountResolver.resolve("https://x.com/elonmusk")
        assertTrue(x is Resolution.Unsupported)
        assertEquals(Platform.X, (x as Resolution.Unsupported).platform)
        assertTrue(AccountResolver.resolve("instagram.com/nasa") is Resolution.Unsupported)
        assertTrue(AccountResolver.resolve("https://t.me/durov") is Resolution.Unsupported)
    }

    @Test fun youtubeChannelIdFromHtml() {
        val html = """<link rel="alternate" type="application/rss+xml" title="RSS" href="https://www.youtube.com/feeds/videos.xml?channel_id=UCX6OQ3DkcsbYNE6H8uQQuVA">"""
        assertEquals("UCX6OQ3DkcsbYNE6H8uQQuVA", AccountResolver.youtubeChannelId(html))
    }
}
