package com.orbit.followthrough.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

class RecurrenceTest {
    private val cairo = ZoneId.of("Africa/Cairo")
    private val ny = ZoneId.of("America/New_York")

    private fun at(zone: ZoneId, y: Int, m: Int, d: Int, h: Int, min: Int = 0) =
        ZonedDateTime.of(LocalDateTime.of(y, m, d, h, min), zone).toInstant()

    @Test fun onceInFutureFiresOnce() {
        val s = Schedule(RepeatType.ONCE, 9, 0, LocalDate.of(2026, 10, 12))
        val now = at(cairo, 2026, 10, 11, 8)
        assertEquals(at(cairo, 2026, 10, 12, 9), Recurrence.next(s, now, cairo))
        assertNull(Recurrence.next(s, at(cairo, 2026, 10, 12, 9), cairo))
    }

    @Test fun dailyMovesToTomorrowAfterTime() {
        val s = Schedule(RepeatType.DAILY, 9, 0, LocalDate.of(2026, 10, 1))
        assertEquals(at(cairo, 2026, 10, 11, 9), Recurrence.next(s, at(cairo, 2026, 10, 11, 8, 59), cairo))
        assertEquals(at(cairo, 2026, 10, 12, 9), Recurrence.next(s, at(cairo, 2026, 10, 11, 9), cairo))
    }

    @Test fun dailyRespectsStartDate() {
        val s = Schedule(RepeatType.DAILY, 7, 30, LocalDate.of(2026, 11, 1))
        assertEquals(at(cairo, 2026, 11, 1, 7, 30), Recurrence.next(s, at(cairo, 2026, 10, 11, 12), cairo))
    }

    @Test fun weeklyPicksNextSelectedDay() {
        // 2026-10-11 is a Sunday.
        val s = Schedule(RepeatType.WEEKLY, 18, 0, LocalDate.of(2026, 10, 1), weekdays = Weekdays.TUE or Weekdays.THU)
        assertEquals(at(cairo, 2026, 10, 13, 18), Recurrence.next(s, at(cairo, 2026, 10, 11, 12), cairo))
        assertEquals(at(cairo, 2026, 10, 15, 18), Recurrence.next(s, at(cairo, 2026, 10, 13, 18), cairo))
    }

    @Test fun monthlyClampsToShortMonths() {
        val s = Schedule(RepeatType.MONTHLY, 10, 0, LocalDate.of(2026, 1, 31), dayOfMonth = 31)
        assertEquals(at(cairo, 2026, 2, 28, 10), Recurrence.next(s, at(cairo, 2026, 2, 1, 0), cairo))
        assertEquals(at(cairo, 2026, 3, 31, 10), Recurrence.next(s, at(cairo, 2026, 2, 28, 10), cairo))
    }

    @Test fun intervalEveryThreeDays() {
        val s = Schedule(RepeatType.INTERVAL, 8, 0, LocalDate.of(2026, 10, 1), interval = 3)
        // occurrences: 1, 4, 7, 10, 13 …
        assertEquals(at(cairo, 2026, 10, 13, 8), Recurrence.next(s, at(cairo, 2026, 10, 11, 0), cairo))
        assertEquals(at(cairo, 2026, 10, 10, 8), Recurrence.next(s, at(cairo, 2026, 10, 10, 7), cairo))
    }

    @Test fun dstSpringForwardGapStillFires() {
        // 2026-03-08 02:30 does not exist in New York; it must shift forward, not vanish.
        val s = Schedule(RepeatType.DAILY, 2, 30, LocalDate.of(2026, 3, 1))
        val next = Recurrence.next(s, at(ny, 2026, 3, 8, 0), ny)!!
        val local = next.atZone(ny)
        assertEquals(LocalDate.of(2026, 3, 8), local.toLocalDate())
        assertEquals(3, local.hour)
    }

    @Test fun dstFallBackDoesNotFireTwice() {
        val s = Schedule(RepeatType.DAILY, 1, 30, LocalDate.of(2026, 10, 1))
        val first = Recurrence.next(s, at(ny, 2026, 11, 1, 0), ny)!!
        val second = Recurrence.next(s, first, ny)!!
        assertEquals(LocalDate.of(2026, 11, 2), second.atZone(ny).toLocalDate())
    }

    @Test fun wallClockTimeSurvivesTimeZoneChange() {
        val s = Schedule(RepeatType.DAILY, 9, 0, LocalDate.of(2026, 10, 1))
        val next = Recurrence.next(s, at(ny, 2026, 10, 11, 6), ny)!!
        assertEquals(9, next.atZone(ny).hour)
    }

    @Test fun occurrencesBetweenListsTodayOnly() {
        val s = Schedule(RepeatType.DAILY, 9, 0, LocalDate.of(2026, 10, 1))
        val list = Recurrence.occurrencesBetween(s, at(cairo, 2026, 10, 11, 0), at(cairo, 2026, 10, 12, 0), cairo)
        assertEquals(1, list.size)
        assertTrue(list[0] == at(cairo, 2026, 10, 11, 9))
    }
}
