package com.orbit.followthrough.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

class FollowUpPolicyTest {
    private val zone = ZoneId.of("Africa/Cairo")
    private fun t(h: Int, m: Int = 0, day: Int = 11) = ZonedDateTime.of(LocalDateTime.of(2026, 10, day, h, m), zone).toInstant().toEpochMilli()

    private fun next(now: Long, minutes: Int = 10, used: Int = 0, max: Int = 3, deadline: Long? = null, nextOcc: Long? = null, quiet: QuietHours = QuietHours.OFF, bypass: Boolean = false) =
        FollowUpPolicy.nextFollowUp(now, minutes, used, max, deadline, nextOcc, quiet, bypass, zone)

    @Test fun schedulesAfterConfiguredMinutes() {
        assertEquals(t(9, 15), next(t(9, 0), minutes = 15))
    }

    @Test fun respectsMaximumFollowUps() {
        assertNull(next(t(9), used = 3, max = 3))
    }

    @Test fun zeroMinutesMeansNoFollowUp() {
        assertNull(next(t(9), minutes = 0))
    }

    @Test fun respectsDeadline() {
        assertNull(next(t(9), minutes = 30, deadline = t(9, 20)))
    }

    @Test fun neverCollidesWithNextOccurrence() {
        assertNull(next(t(9), minutes = 60, nextOcc = t(9, 30)))
    }

    @Test fun quietHoursDeferToMorning() {
        val quiet = QuietHours(true, 22 * 60, 7 * 60)
        assertEquals(t(7, 0, day = 12), next(t(21, 55), minutes = 10, quiet = quiet))
        assertEquals(t(22, 15), next(t(22, 5), minutes = 10, quiet = quiet, bypass = true))
    }

    @Test fun quietHoursAcrossMidnight() {
        val q = QuietHours(true, 22 * 60, 7 * 60)
        assertTrue(q.isQuiet(t(23), zone))
        assertTrue(q.isQuiet(t(3), zone))
        assertFalse(q.isQuiet(t(7), zone))
        assertEquals(t(7), q.deferIfQuiet(t(3), zone))
    }

    @Test fun daytimeQuietWindow() {
        val q = QuietHours(true, 13 * 60, 15 * 60)
        assertTrue(q.isQuiet(t(14), zone))
        assertEquals(t(15), q.deferIfQuiet(t(14), zone))
        assertFalse(q.isQuiet(t(12), zone))
    }
}
