package com.orbit.followthrough.ai

import com.orbit.followthrough.domain.EventType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InsightsTest {
    private val gym = InsightReminder(1, "Gym", 7, 0, recurring = true)

    @Test fun morningPostponesSuggestEvening() {
        val events = List(4) { InsightEvent(1, EventType.SNOOZED, 7) }
        val out = Insights.compute(listOf(gym), events)
        assertEquals(1, out.size)
        assertEquals(Insight.Kind.MOVE_LATER, out[0].kind)
        assertEquals(19, out[0].suggestedHour)
    }

    @Test fun usualCompletionTimeWins() {
        val events = List(3) { InsightEvent(1, EventType.DISMISSED, 7) } + List(3) { InsightEvent(1, EventType.COMPLETED, 21) }
        val out = Insights.compute(listOf(gym), events)
        assertEquals(Insight.Kind.MOVE_TO_USUAL, out[0].kind)
        assertEquals(21, out[0].suggestedHour)
    }

    @Test fun fewPostponesNoSuggestion() {
        val events = List(2) { InsightEvent(1, EventType.SNOOZED, 7) }
        assertTrue(Insights.compute(listOf(gym), events).isEmpty())
    }

    @Test fun dismissedSuggestionsStayHidden() {
        val events = List(4) { InsightEvent(1, EventType.SNOOZED, 7) }
        val first = Insights.compute(listOf(gym), events)
        assertTrue(Insights.compute(listOf(gym), events, setOf(first[0].key)).isEmpty())
    }
}
