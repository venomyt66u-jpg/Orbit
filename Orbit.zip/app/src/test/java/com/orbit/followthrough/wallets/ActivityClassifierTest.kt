package com.orbit.followthrough.wallets

import com.orbit.followthrough.domain.Numbers
import com.orbit.followthrough.domain.UsageMath
import org.junit.Assert.assertEquals
import org.junit.Test

class ActivityClassifierTest {

    @Test fun buyTokenWithEth() {
        val c = ActivityClassifier.classify(listOf(Transfer("ETH", 3.1, false), Transfer("PEPE", 1_200_000.0, true)))
        assertEquals(ActivityKind.BUY, c.kind)
        assertEquals("PEPE", c.inSymbol)
        assertEquals("ETH", c.outSymbol)
        assertEquals(3.1 * 2500, ActivityClassifier.estimateUsd(c) { if (it == "ETH") 2500.0 else null }!!, 1e-6)
    }

    @Test fun sellTokenForUsdcThroughRouter() {
        // Multi-hop: PEPE → WETH → USDC; WETH nets to zero.
        val c = ActivityClassifier.classify(
            listOf(
                Transfer("PEPE", 5_000_000.0, false),
                Transfer("WETH", 1.0, true), Transfer("WETH", 1.0, false),
                Transfer("USDC", 2400.0, true),
            )
        )
        assertEquals(ActivityKind.SELL, c.kind)
        assertEquals("PEPE", c.outSymbol)
        assertEquals("USDC", c.inSymbol)
        assertEquals(2400.0, ActivityClassifier.estimateUsd(c) { null }!!, 1e-9)
    }

    @Test fun receiveAndSend() {
        assertEquals(ActivityKind.RECEIVE, ActivityClassifier.classify(listOf(Transfer("USDT", 50.0, true))).kind)
        assertEquals(ActivityKind.SEND, ActivityClassifier.classify(listOf(Transfer("BTC", 0.2, false))).kind)
        assertEquals(ActivityKind.CONTRACT, ActivityClassifier.classify(emptyList()).kind)
    }

    @Test fun nftMintPaidInEth() {
        val c = ActivityClassifier.classify(
            listOf(Transfer("ETH", 0.0008, false), Transfer("ZORB", 2.0, true, nft = true, fromZero = true))
        )
        assertEquals(ActivityKind.MINT, c.kind)
        assertEquals("ZORB", c.inSymbol)
        assertEquals(2.0, c.inAmount!!, 1e-9)
        assertEquals("ETH", c.outSymbol)
    }

    @Test fun freeMintHasNoPayment() {
        val c = ActivityClassifier.classify(listOf(Transfer("BASEPASS", 1.0, true, nft = true, fromZero = true)))
        assertEquals(ActivityKind.MINT, c.kind)
        assertEquals(null, c.outSymbol)
    }

    @Test fun tokenToTokenIsSwap() {
        assertEquals(ActivityKind.SWAP, ActivityClassifier.classify(listOf(Transfer("ARB", 10.0, false), Transfer("OP", 7.0, true))).kind)
    }

    @Test fun numberFormatting() {
        assertEquals("$67,432", Numbers.price(67432.4))
        assertEquals("$2.35", Numbers.price(2.3456))
        assertEquals("$0.00001235", Numbers.price(0.000012345))
        assertEquals("1.2M", Numbers.compact(1_200_000.0))
        assertEquals("$2.35T", Numbers.compact(2.345e12, "$"))
        assertEquals("1.50 GB", Numbers.bytes(1_500_000_000))
        assertEquals("0x1234…cdef", Numbers.shortAddress("0x1234567890abcdef1234567890abcdef12cdef"))
    }

    @Test fun usageCounterReset() {
        val d1 = UsageMath.delta(UsageMath.Counter(1000, 200), UsageMath.Counter(1500, 260))
        assertEquals(500L, d1.rx); assertEquals(60L, d1.tx)
        val reset = UsageMath.delta(UsageMath.Counter(9000, 900), UsageMath.Counter(300, 40))
        assertEquals(300L, reset.rx)
        assertEquals(0L, UsageMath.delta(null, UsageMath.Counter(5, 5)).rx)
        assertEquals(30L, UsageMath.total(mapOf(1L to 10L, 2L to 20L, 9L to 99L), 1, 2))
    }
}
