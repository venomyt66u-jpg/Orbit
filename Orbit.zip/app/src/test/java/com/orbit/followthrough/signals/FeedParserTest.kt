package com.orbit.followthrough.signals

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class FeedParserTest {

    private val rss = """
        <?xml version="1.0" encoding="UTF-8"?>
        <rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/">
          <channel>
            <title>Example Blog</title>
            <item>
              <title>Introducing Orbit 2.0 &amp; more</title>
              <link>https://example.com/orbit-2</link>
              <guid>orbit-2</guid>
              <pubDate>Sat, 10 Oct 2026 14:30:00 GMT</pubDate>
              <description><![CDATA[<p>We are launching <b>Orbit 2.0</b> today. It is faster. It is calmer. Many more details follow in this long paragraph that keeps going.</p>]]></description>
            </item>
            <item>
              <title>Second post</title>
              <link>https://example.com/second</link>
            </item>
          </channel>
        </rss>
    """.trimIndent()

    private val atom = """
        <?xml version="1.0" encoding="UTF-8"?>
        <feed xmlns="http://www.w3.org/2005/Atom">
          <title>Release notes from kotlin</title>
          <entry>
            <id>tag:github.com,2008:Repository/3432266/v2.1.0</id>
            <updated>2026-10-09T12:00:00Z</updated>
            <link rel="alternate" type="text/html" href="https://github.com/JetBrains/kotlin/releases/tag/v2.1.0"/>
            <title>Kotlin 2.1.0</title>
            <content type="html">&lt;p&gt;Changelog: compiler improvements&lt;/p&gt;</content>
          </entry>
        </feed>
    """.trimIndent()

    @Test fun parsesRss() {
        val items = FeedParser.parse(rss.toByteArray())
        assertEquals(2, items.size)
        val first = items[0]
        assertEquals("Introducing Orbit 2.0 & more", first.title)
        assertEquals("https://example.com/orbit-2", first.link)
        assertEquals("orbit-2", first.guid)
        assertEquals(Instant.parse("2026-10-10T14:30:00Z").toEpochMilli(), first.publishedAt)
        assertTrue(first.summary.startsWith("We are launching Orbit 2.0 today."))
        assertTrue(first.summary.length <= 220)
        assertEquals("https://example.com/second", items[1].guid)
    }

    @Test fun parsesAtom() {
        val items = FeedParser.parse(atom.toByteArray())
        assertEquals(1, items.size)
        assertEquals("Kotlin 2.1.0", items[0].title)
        assertEquals("https://github.com/JetBrains/kotlin/releases/tag/v2.1.0", items[0].link)
        assertNotNull(items[0].publishedAt)
        assertEquals("Changelog: compiler improvements", items[0].summary)
    }

    @Test fun titleKeyIgnoresPunctuationAndCase() {
        assertEquals(FeedParser.titleKey("Orbit 2.0 — Released!"), FeedParser.titleKey("orbit 2 0 released"))
    }

    @Test fun classifierFlagsKeywordsAsImportant() {
        val r = SignalClassifier.classify("New mint opens Friday", "allowlist live", listOf("mint"), isGithub = false)
        assertEquals(2, r.importance)
        assertEquals("mint", r.matchedKeyword)
        assertEquals(SignalClassifier.CAT_WEB3, r.category)
    }

    @Test fun githubReleaseIsRelease() {
        val r = SignalClassifier.classify("v2.1.0", "", emptyList(), isGithub = true)
        assertEquals(SignalClassifier.CAT_RELEASE, r.category)
        assertEquals(1, r.importance)
    }
}
