# Room entities and WorkManager workers ship their own consumer rules.
# Keep worker class names (instantiated reflectively by WorkManager).
-keep class * extends androidx.work.ListenableWorker { <init>(...); }
# Broadcast receivers are referenced from the manifest (kept automatically by AAPT rules).
-dontwarn org.xmlpull.**
