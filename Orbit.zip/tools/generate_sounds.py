"""Synthesises Orbit's built-in notification sounds (original, royalty-free).
Run: python3 tools/generate_sounds.py  -> writes app/src/main/res/raw/*.wav"""
import math, struct, wave, os, random
SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "res", "raw")

def env(t, a, d):  # attack/exponential decay
    return min(1.0, t / a) * math.exp(-t / d) if a > 0 else math.exp(-t / d)

def bell(f, t, d, partials=((1,1),(2.0,.35),(2.76,.2),(5.4,.08))):
    return sum(amp * math.sin(2*math.pi*f*m*t) * math.exp(-t/(d/(1+m*.6))) for m, amp in partials)

def render(name, dur, fn):
    n = int(SR*dur); data = [fn(i/SR) for i in range(n)]
    peak = max(1e-9, max(abs(x) for x in data)); data = [x/peak*0.82 for x in data]
    fade = int(SR*0.02)
    for i in range(fade): data[-1-i] *= i/fade
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(x*32767)) for x in data))

def note(t, start, f, d, kind="bell"):
    if t < start: return 0.0
    tt = t - start
    return env(tt, .004, d) * (bell(f, tt, d) if kind == "bell" else math.sin(2*math.pi*f*tt))

# Habits – soft two-note chime (calm)
render("chime_soft", 1.6, lambda t: note(t,0,1046.5,.7)*.8 + note(t,.18,1318.5,.8)*.7)
# General reminder – clear bright ping
render("ping_bright", 0.9, lambda t: note(t,0,1760,.25)+note(t,0,2637,.15,"sine")*.25)
# Important – rising triple pulse, distinctive
render("pulse_alert", 1.1, lambda t: sum(note(t,s,f,.12,"sine")*(1+.3*math.sin(2*math.pi*7*t)) for s,f in ((0,880),(.16,1108.7),(.32,1318.5))) + note(t,.5,1760,.3)*.6)
# AI – crystal arpeggio
render("crystal", 1.4, lambda t: sum(note(t,s,f,.45)*.6 for s,f in ((0,1567.98),(.08,1975.5),(.16,2349.3),(.24,3136))))
# Signals – droplet blip (pitch drop)
def droplet(t):
    if t > .35: return 0.0
    f = 1400*math.exp(-t*9)+500
    return math.sin(2*math.pi*f*t) * env(t,.003,.09)
render("droplet", 0.5, droplet)
# Orbit – gliding sweep with shimmer
def orbit(t):
    f = 660 + 660*(1-math.exp(-t*4))
    return (math.sin(2*math.pi*f*t)*.7 + math.sin(2*math.pi*f*1.5*t)*.2) * env(t,.05,.5)
render("orbit_glide", 1.3, orbit)
# Warm bell – lower register
render("bell_warm", 2.0, lambda t: note(t,0,523.25,1.1) + note(t,0,784,1.0)*.35)
# Zen bowl – long gentle decay with beating
render("zen_bowl", 2.6, lambda t: env(t,.02,1.3)*(math.sin(2*math.pi*432*t)+.6*math.sin(2*math.pi*434.5*t)+.25*math.sin(2*math.pi*1188*t)))
print("ok", sorted(os.listdir(OUT)))
