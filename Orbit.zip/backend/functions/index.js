/**
 * Optional Orbit backend (Firebase Cloud Functions v2, Node 20).
 * Keeps every API key server-side. The Android app never contains secrets.
 *
 *   firebase functions:secrets:set LLM_API_KEY
 *   firebase deploy --only functions
 *
 * Then in Orbit: Settings → Smart assistant → "Use my AI backend" → https://<region>-<project>.cloudfunctions.net/orbit
 */
const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");

const LLM_API_KEY = defineSecret("LLM_API_KEY");
const LLM_URL = process.env.LLM_URL || "https://api.anthropic.com/v1/messages";
const LLM_MODEL = process.env.LLM_MODEL || "claude-haiku-5-5";

// Very small in-memory rate limit per instance (use Firestore/Redis for production).
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 60_000);
  arr.push(now);
  hits.set(ip, arr);
  return arr.length > 20;
}

const SYSTEM = `Convert the user's reminder command into JSON only.
Schema: {"intent":"create|postponed|summarize|unknown","title":string,"repeat":"ONCE|DAILY|WEEKLY|MONTHLY|INTERVAL",
"hour":0-23,"minute":0-59,"date":"YYYY-MM-DD","weekdays":bitmask Mon=1..Sun=64}.
Omit "hour" if no time was given. Never invent religious text. Reply with JSON only.`;

async function llm(system, user, maxTokens) {
  const r = await fetch(LLM_URL, {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": LLM_API_KEY.value(), "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: LLM_MODEL, max_tokens: maxTokens, system, messages: [{ role: "user", content: user }] }),
  });
  const data = await r.json();
  return (data.content || []).filter((p) => p.type === "text").map((p) => p.text).join("");
}

exports.orbit = onRequest({ secrets: [LLM_API_KEY], cors: false, maxInstances: 5 }, async (req, res) => {
  if (req.method !== "POST") return res.status(404).send("not found");
  if (limited(req.ip)) return res.status(429).send("slow down");
  // Generic chat used by the in-app AI features (system prompt is built by the app).
  if (req.path.endsWith("/chat")) {
    const system = String((req.body && req.body.system) || "").slice(0, 6000);
    const user = String((req.body && req.body.user) || "").slice(0, 8000);
    const maxTokens = Math.min(Number((req.body && req.body.maxTokens) || 600), 1200);
    try { return res.json({ text: await llm(system, user, maxTokens) }); }
    catch (e) { return res.status(502).json({ text: "" }); }
  }
  if (!req.path.endsWith("/parse")) return res.status(404).send("not found");
  const text = String((req.body && req.body.text) || "").slice(0, 500);
  const now = String((req.body && req.body.now) || new Date().toISOString());
  if (!text) return res.status(400).send("missing text");

  try {
    const r = await fetch(LLM_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": LLM_API_KEY.value(),
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: LLM_MODEL,
        max_tokens: 200,
        system: SYSTEM,
        messages: [{ role: "user", content: `Now: ${now}\nCommand: ${text}` }],
      }),
    });
    const data = await r.json();
    const raw = (data.content && data.content[0] && data.content[0].text) || "{}";
    const parsed = JSON.parse(raw.replace(/^```json|```$/g, "").trim());
    return res.json(parsed); // the app validates every field again
  } catch (e) {
    return res.status(502).json({ intent: "unknown" });
  }
});
