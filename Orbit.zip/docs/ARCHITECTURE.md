# Architecture

## Principles
Reliability → simplicity → privacy → performance. Everything that can run offline does.
No DI framework (manual `AppContainer`), no background services, one alarm per reminder.

## Layers
```
UI (Compose screens + ViewModels)
   │  StateFlow
Engines (ReminderEngine, HabitEngine, SignalRepository, AiProvider)
   │
Data (Room DAOs, DataStore)      Platform (AlarmManager, NotificationManager, WorkManager, WindowManager)
```

## Reminder state machine
```
             save()                      alarm (occurrence)
  (new) ───────────────▶ SCHEDULED ────────────────────────▶ PENDING ──┐
                             ▲   ▲                              │  │   │ dismiss → follow-up at +N min
                             │   └──── complete/skip (recurring)┘  │   │ (≤ max, before deadline,
                             │                                     │   │  deferred by quiet hours)
            resume ◀── PAUSED                       complete/skip  ▼   ▼
                                                    (one-time) → DONE  alarm (follow-up) → notify again
```
* **Dismiss ≠ complete.** Swiping a notification fires `deleteIntent` → `onDismissed()`, which keeps the task
  PENDING and may schedule a follow-up. Only *Done* / *Skip* resolve it.
* Each reminder owns exactly **one** alarm: `min(nextOccurrenceAt, followUpAt)`; `onAlarm()` decides which fired.
* **Catch-up:** a recurring occurrence > 2 h late (device off) is logged as MISSED instead of notifying late;
  one-time reminders are still delivered with a "due earlier" note.
* **Time zones / DST:** schedules are stored as wall-clock (`hour`, `minute`, `startEpochDay`) and resolved with
  `ZonedDateTime` in the current zone. `SystemEventReceiver` recomputes future occurrences on
  `TIME_SET`, `TIMEZONE_CHANGED`, `BOOT_COMPLETED`, `MY_PACKAGE_REPLACED` and exact-alarm permission changes.
  The app also re-syncs on every cold start (defends against force-stop).
* **Exact alarms:** `setExactAndAllowWhileIdle` when allowed; otherwise `setAndAllowWhileIdle` (graceful).

## Notification channels
`reminders_vN`, `urgent_vN`, `habits_vN`, `signals_alert_vN`, `signals_quiet_vN`, `assistant_vN`, `quiet_vN`.
Android freezes a channel's sound after creation, so changing a sound bumps the version and recreates the channel
(the stale one is deleted). Profiles: *Silent* routes to `quiet`, *High* routes reminders to `urgent`.

## Data model (Room v1, schema exported to `app/schemas`)
| Table | Purpose |
|---|---|
| `reminders` | schedule, follow-up policy, status, nextOccurrenceAt / pendingOccurrenceAt / followUpAt |
| `reminder_events` | CREATED, FIRED, FOLLOW_UP, DISMISSED, SNOOZED, COMPLETED, SKIPPED, MISSED (+ hour of day) |
| `habits`, `habit_logs` | habit definition (incl. tasbih phrase & round size) and per-day counts |
| `signal_sources`, `signal_items` | feeds with ETag/Last-Modified, status; items with publishedAt vs discoveredAt |
| `notification_log` | optional in-app notification history (30-day retention) |

Migrations: add to `OrbitDatabase.MIGRATIONS`. Destructive migration is **not** used on upgrade.

## Performance notes
* Cold start: no network, no heavy init; Room/engines are `lazy`.
* Background work: only alarms the user created + one periodic WorkManager job **only while a source is enabled**
  (network + battery-not-low constraints, conditional GET).
* Lists are capped/paginated (`LIMIT` that grows on "Load more").
* Animations use a shared infinite transition and freeze when *Remove animations* is enabled.
* Not yet measured on devices — see STATUS.md (no RAM/battery figures are promised).
