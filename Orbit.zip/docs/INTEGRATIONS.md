# Integrations

## Built in (no credentials)
| Type | Input | Fetched URL |
|---|---|---|
| RSS / Atom | any public feed URL | as given |
| GitHub releases | `owner/repo` or a github.com URL | `https://github.com/<owner>/<repo>/releases.atom` |

Sync: WorkManager every 1/3/6/12 h (user choice), only while at least one source is enabled, with
`If-None-Match` / `If-Modified-Since`. First sync of a new source stores the backlog without notifying.
Duplicates: same `(source, guid)` is ignored; the same normalised title from another source within 72 h is dropped.
Importance: keyword match or security → important; announcements/Web3/stable GitHub releases → normal; rest → low.

## Anything needing credentials (private APIs, webhooks, NFT/Web3 APIs, paid news APIs)
Orbit never stores secrets in the APK. Use a backend you control:

1. Deploy `backend/functions` (Firebase Cloud Functions, Node 20) or any equivalent server.
2. Store keys as secrets (`firebase functions:secrets:set LLM_API_KEY`, `…:set SOME_API_KEY`).
3. Expose a public **feed** from your backend (e.g. `/feed/<name>.xml` in Atom format) that aggregates the private API
   or webhook payloads. Add that URL in Orbit as an RSS source — no app change needed.

### Adding a new native adapter
`SignalRepository.feedUrl()` maps a `SourceType` to a URL and `FeedParser` handles RSS/Atom. To add a JSON API:
add a `SourceType`, a parser returning `List<FeedEntry>`, and branch on it in `syncSource()`. The reminder engine is untouched.

## Optional cloud AI
Settings → Smart assistant → *Use my AI backend* → `https://…`. The app POSTs `{"text","now"}` to `<url>/parse` and expects:
```json
{"intent":"create","title":"Read","repeat":"DAILY","hour":9,"minute":0,"date":"2026-10-12","weekdays":0}
```
Every field is validated in `RemoteAiProvider`; anything invalid falls back to the on-device parser, and the user must still
confirm before anything is scheduled. Only the typed command text is sent.

## Followed accounts (v1.1)
| Platform | How | Key |
|---|---|---|
| YouTube | official channel feed `feeds/videos.xml?channel_id=…` (`@handle` resolved once from the public page) | none |
| Reddit | `/user/<name>/submitted/.rss`, `/r/<sub>/new/.rss` | none |
| Bluesky | `bsky.app/profile/<handle>/rss` | none |
| Mastodon & compatible | `https://<server>/@<user>.rss` | none |
| Medium / Substack / GitHub | official feeds | none |
| X, Instagram, TikTok, Facebook, Threads, LinkedIn, Telegram | **not possible for free from an app**: only paid official APIs. Run your own bridge (e.g. a self-hosted RSSHub on your backend) and add its feed URL as RSS. | — |

## Wallets on every network + mint detection (v1.1.1)
- **Blockscout PRO API** (free key from dev.blockscout.com: 100K credits/day, 5 req/s, all Blockscout chains) is the primary source:
  `https://api.blockscout.com/v2/api?chain_id=<id>&module=account&action=txlist|tokentx|tokennfttx|token1155tx|txlistinternal&address=…&apikey=…`
- Networks: Ethereum 1 · Base 8453 · **Robinhood Chain 4663** · Arbitrum 42161 · Optimism 10 · Polygon 137 · Zora 7777777 · Scroll 534352
  (+ BNB Chain 56 through Etherscan, which is a paid plan for BNB/Base/OP since late 2025).
- **"All EVM networks"** wallets: one 0x address checked on every network. A full sweep runs every 6 h; in between only networks where the
  wallet has activity are polled (at most every 4 min in Live mode) to stay inside the free credits.
- **Mint** = an NFT (ERC-721/1155) or token arriving from the zero address; the price paid is the base asset that left the wallet.
  Mints always notify, regardless of the minimum-value filter.

## Market & wallets (v1.1)
- CoinGecko public API (optional demo key raises limits), alternative.me Fear & Greed, CoinDesk/Cointelegraph RSS.
- Wallets: Etherscan V2 multichain (`tokentx`, `txlist`, `txlistinternal`; free key from etherscan.io/myapikey — some chains may need a paid plan,
  the app shows Etherscan's message if so), mempool.space for Bitcoin, Solana public RPC (`getSignaturesForAddress` + `getTransaction`).
- True push (seconds) needs webhooks: deploy a provider webhook (e.g. Alchemy Notify / QuickNode Streams) to your backend and forward via FCM.
  Without a server, Live mode polls every 60 s.

## Router: Greenpacket D2-220G1 (Vodafone Egypt)
`network/NetworkRepository.kt` → `GreenpacketD2Adapter` implements `RouterAdapter.clients()` / `wanUsage()`.
To finish it, capture the web UI once: Chrome on a PC → `192.168.0.1` → F12 → Network → *Preserve log* → log in → open
*Connected devices* and *Statistics* → right-click → *Save all as HAR*. The HAR shows the login and data endpoints;
the adapter then maps them to `RouterClient(mac, ip, name, rxBytes, txBytes)` and `UsageMath` turns counters into daily GB.
