# Implemented vs pending

## ✅ Implemented
**Reminder engine (Phase 1)**
- One-time, daily, weekly (any weekdays), monthly (clamped to short months), every-N-days
- Done / Later (5·10·15·30·60) / Skip from the notification and in-app
- Dismiss ≠ complete; configurable follow-up delay, max follow-ups, deadline, quiet hours (cross-midnight)
- Important reminders on a distinctive high-priority channel, optional quiet-hours bypass
- Exact alarms when permitted, inexact fallback; reboot / time / time-zone / app-update rescheduling
- Pause / resume / complete early / delete; full event log; Home dashboard (needs-you, today timeline, coming up)

**Notifications**
- 7 versioned channels, 8 original synthesized sounds with preview, system/silent/device sound picker,
  6 vibration patterns, Silent/Normal/High profiles, in-app notification history, grouped signal notifications

**Habits**
- Custom habits with glyphs/colours/targets/units, presets (incl. optional spiritual ones – names only)
- Animated progress rings, 7-day summary, optional streaks, per-habit daily reminders with quick actions
- Tasbih counter: verified fixed dhikr presets or your own phrase, 33/99/100 rounds, haptics, undo, reset round

**Smart assistant (on-device, EN + AR)**
- Natural-language → structured proposal → explicit confirmation; clarifies missing time / AM-PM
- "What did I postpone today", "what's today", "summarize updates", "silent after 10 PM", "repeat this in 30 min"
- Rotating, non-judgmental notification wording in 3 tones; postponement-pattern insights (move later / usual time / first step)
- Optional remote provider that only talks to *your* backend; validated responses

**Signal Feed**
- RSS/Atom + GitHub releases, source status & last sync, enable/disable, per-source notify rules, keywords,
  duplicate filter, category + importance classification, search, filters, published vs detected time, pagination

**UX**
- Dark Premium + light theme + system, custom vector icon set, animated hero orbit / AI emblem / sound waves / bead ring
- Onboarding (5 pages), 4 animated tutorials with captions, Help section, RTL Arabic + English, reduced-motion support
- Permissions center with explanations, Privacy & data screen (disclosure, retention, delete history / everything)
- Optional floating reminder card (drag to move, swipe to dismiss, auto-hide)

**Quality**
- 61 unit tests (recurrence/DST, follow-up policy, EN/AR command parsing, feed parsing, classification, insights, account links, buy/sell detection, number & usage math)
- GitHub Actions: tests + debug APK + minified release APK

**v1.1.1**
- Wallet tracker on **all EVM networks at once** (incl. **Robinhood Chain** and Base) via one free Blockscout key; NFT/token **mint detection**
  with "‹name› minted X on ‹network›" notifications; per-transaction network tag

**v1.1 additions**
- **Market**: live prices + 7-day sparklines (CoinGecko), total cap, BTC dominance, 24h volume, Fear & Greed gauge,
  crypto headlines (CoinDesk, Cointelegraph RSS), one-shot price alerts above/below, coin search & watchlist
- **Wallet tracker**: name any public wallet; Ethereum, Base, Arbitrum, BNB Chain, Polygon (Etherscan V2, free key),
  Bitcoin (mempool.space) and Solana (public RPC). Transactions are explained as bought / sold / swapped / received / sent
  with USD estimate; minimum-value filter; rich expandable notifications that open the exact transaction highlighted
- **Follow accounts**: paste a YouTube, Reddit, Bluesky, Mastodon, Medium, Substack or GitHub link → notification for every new post
- **Live mode**: optional foreground service that checks every 60 s (visible ongoing notification); otherwise WorkManager every 15 min
- **AI**: bring-your-own-key Claude / OpenAI / Gemini (or your backend). Assistant answers anything, creates reminders from free text,
  market brief, wallet behaviour explanation, feed summary. Keys encrypted with Android Keystore
- **Tasbih**: every tap saved per phrase per day, all-time total, history, "Delete all" (dhikr only)
- **Home network**: LAN discovery (device count, names, new-device alerts), rename/forget devices, usage dashboard (day/week/30 days, per device)

## ⏳ Pending / next
- **Router connector for Greenpacket D2-220G1**: framework, encrypted login and usage math are done; the model-specific requests
  need one HAR capture of its web UI (see INTEGRATIONS.md) before per-device GB can be pulled
- Device measurements (cold start, memory, battery) on representative mid-range phones
- Instrumented UI tests (Compose) and notification end-to-end tests on emulators
- Firebase Auth + Firestore sync (architecture-ready; deliberately off – app is offline-first)
- LLM-based summaries (local extractive summary is used today; backend sample provided)
- Lottie / video tutorials (current tutorials are code-drawn animations; `TutorialScene` is the extension point)
- Home-screen widget, Wear OS tile, backup/restore export
- Play Store assets, privacy policy hosting, release keystore
